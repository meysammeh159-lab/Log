<?php
/**
 * جایگزینی wp-login.php با فرم لاگین‌پرو
 * 
 * @package LoginPro
 * @version 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ جایگزینی کامل صفحه wp-login.php
// ==================================================

add_action('login_init', 'loginpro_replace_wp_login_force');

function loginpro_replace_wp_login_force() {
    if (is_user_logged_in()) {
        wp_redirect(home_url());
        exit;
    }
    
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    if (defined('REST_REQUEST') && REST_REQUEST) return;
    
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
    $allowed_actions = ['logout', 'lostpassword', 'rp', 'resetpass', 'postpass'];
    if (in_array($action, $allowed_actions)) return;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['log']) && isset($_POST['pwd'])) {
        return;
    }
    
    $login_page_id = (int) get_option('loginpro_login_page_id', 0);
    
    if ($login_page_id > 0 && strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false) {
        $login_page_url = get_permalink($login_page_id);
        if ($login_page_url) {
            wp_redirect($login_page_url);
            exit;
        }
    }
    
    loginpro_display_login_page();
    exit;
}

// ==================================================
// ✅ تابع نمایش صفحه لاگین
// ==================================================
function loginpro_display_login_page() {
    // دریافت تنظیمات
    $primary_color = get_option('loginpro_primary_color', '#ef394e');
    $secondary_color = get_option('loginpro_secondary_color', '#c62828');
    $hover_color = get_option('loginpro_hover_color', '');
    if (empty($hover_color)) {
        $hover_color = get_option('loginpro_secondary_color', '');
    }
    if (empty($hover_color)) {
        $hover_color = $primary_color;
    }
    
    $background_color = get_option('loginpro_background_color', '#ffffff');
    $border_radius = get_option('loginpro_border_radius', 24);
    $font_family = get_option('loginpro_font_family', 'IRANSans, Tahoma, sans-serif');
    $form_width = get_option('loginpro_form_width', '400px');
    $button_style = get_option('loginpro_button_style', 'rounded');
    $header_logo = get_option('loginpro_logo_url', '');
    $footer_text = get_option('loginpro_footer_text', '');
    $otp_length = (int) get_option('loginpro_otp_length', 6);
    $layout = get_option('loginpro_login_page_layout', 'centered');
    
    // متون فرم
    $text_title = get_option('loginpro_text_title', 'ورود');
    $text_subtitle = get_option('loginpro_text_subtitle', 'شماره موبایل، ایمیل یا نام کاربری خود را وارد کنید');
    $text_help_identifier = get_option('loginpro_text_help_identifier', 'شماره موبایل، ایمیل یا نام کاربری');
    $text_continue_btn = get_option('loginpro_text_continue_btn', 'بررسی');
    $text_password_title = get_option('loginpro_text_password_title', 'ورود با رمز عبور');
    $text_help_password = get_option('loginpro_text_help_password', 'رمز عبور خود را وارد کنید');
    $text_login_btn = get_option('loginpro_text_login_btn', 'ورود');
    $text_otp_title = get_option('loginpro_text_otp_title', 'کد تایید');
    $text_verify_btn = get_option('loginpro_text_verify_btn', 'تایید و ورود');
    $text_forgot_password = get_option('loginpro_text_forgot_password', 'فراموشی رمز عبور');
    $text_header_title = get_option('loginpro_text_header_title', 'لاگین پرو');
    $text_otp_login_message = get_option('loginpro_text_otp_login_message', 'کد تایید برای شما ارسال شد.');
    
    // تنظیمات شبکه‌های اجتماعی
    $show_reset = get_option('loginpro_show_password_reset', true);
    $show_social = get_option('loginpro_show_social_login', true);
    $social_enabled = get_option('loginpro_social_enabled', false);
    $social_show_in_modal = get_option('loginpro_social_show_in_modal', true);
    $social_button_style = get_option('loginpro_social_button_style', 'default');
    $social_button_radius = get_option('loginpro_social_button_radius', 8);
    $social_button_padding = get_option('loginpro_social_button_padding', '8px 16px');
    
    $google_enabled = get_option('loginpro_google_enabled', false);
    $google_button_text = get_option('loginpro_google_button_text', 'ورود با گوگل');
    $facebook_enabled = get_option('loginpro_facebook_enabled', false);
    $facebook_button_text = get_option('loginpro_facebook_button_text', 'فیسبوک');
    $github_enabled = get_option('loginpro_github_enabled', false);
    $github_button_text = get_option('loginpro_github_button_text', 'گیت‌هاب');
    
    $ajax_url = admin_url('admin-ajax.php');
    $ajax_nonce = wp_create_nonce('loginpro_ajax_nonce');
    $modal_close_on_click = (int) get_option('loginpro_modal_close_on_click', 1);
    $modal_close_on_esc = (int) get_option('loginpro_modal_close_on_esc', 1);
    
    // تابع تبدیل رنگ
    if (!function_exists('loginpro_hex2rgb')) {
        function loginpro_hex2rgb($hex) {
            $hex = str_replace('#', '', $hex);
            if (strlen($hex) == 3) {
                $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
                $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
                $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
            } else {
                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));
            }
            return "$r, $g, $b";
        }
    }
    
    $button_class = 'loginpro-btn';
    if ($button_style === 'square') {
        $button_class .= ' loginpro-btn-square';
    } elseif ($button_style === 'pill') {
        $button_class .= ' loginpro-btn-pill';
    }
    
    $social_btn_class = 'loginpro-social-btn';
    if ($social_button_style === 'outline') {
        $social_btn_class .= ' outline';
    } elseif ($social_button_style === 'solid') {
        $social_btn_class .= ' solid';
    }
    
    $any_social_enabled = ($google_enabled || $facebook_enabled || $github_enabled);
    $show_social_section = ($show_social && $social_enabled && $social_show_in_modal && $any_social_enabled);
    
    $plugin_url = LOGINPRO_PLUGIN_URL;
    $version = LOGINPRO_VERSION;
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?> dir="rtl">
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo esc_html($text_header_title); ?> - <?php _e('ورود', 'loginpro'); ?></title>
        
        <!-- ========================================== -->
        <!-- ✅ بارگذاری فونت‌ها -->
        <!-- ========================================== -->
        <link rel="stylesheet" href="<?php echo esc_url($plugin_url . 'assets/fonts/font-styles.css'); ?>?ver=<?php echo esc_attr($version); ?>">
        <script type="text/javascript">
// Fix for Modernizr error from Avada theme
window.Modernizr = window.Modernizr || {
    mq: function() { return false; },
    touch: false,
    csstransforms: true,
    csstransforms3d: true,
    csstransitions: true,
    flexbox: true,
    flexboxlegacy: true
};
</script>
        <script src="<?php echo esc_url(includes_url('js/jquery/jquery.min.js')); ?>?ver=<?php echo esc_attr($version); ?>"></script>
        <script src="<?php echo esc_url(includes_url('js/jquery/jquery-migrate.min.js')); ?>?ver=<?php echo esc_attr($version); ?>"></script>
        
        <style>
            /* ... تمام استایل‌های شما ... */
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                background: <?php echo esc_attr($background_color); ?>;
                font-family: <?php echo esc_attr($font_family); ?>;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                margin: 0;
                direction: rtl;
            }
            /* ... ادامه استایل‌ها ... */
            .loginpro-message.success {
                display: block;
                background: #f0fff4;
                color: #2e7d32;
                border: 1px solid #c3e6cb;
            }
            /* ... بقیه استایل‌ها ... */
        </style>
    </head>
    <body class="loginpro-body">
        
        <div class="loginpro-back-to-site" id="loginpro-back-to-site">
            <a href="<?php echo esc_url(home_url()); ?>" style="background:<?php echo esc_attr($primary_color); ?>;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                </svg>
                <?php esc_html_e('بازگشت', 'loginpro'); ?>
            </a>
        </div>
        
        <div class="loginpro-page-wrapper">
            <div class="loginpro-page-box">
                
                <!-- Header -->
                <div class="loginpro-page-header">
                    <?php if (!empty($header_logo)): ?>
                        <img src="<?php echo esc_url($header_logo); ?>" alt="<?php echo esc_attr($text_header_title); ?>" class="loginpro-logo">
                    <?php endif; ?>
                    <h1><?php echo esc_html($text_title); ?></h1>
                    <p id="loginpro-header-subtitle"><?php echo esc_html($text_subtitle); ?></p>
                </div>
                
                <!-- Message -->
                <div id="loginpro-message" class="loginpro-message"></div>
                
                <?php if (isset($_GET['logged_out']) && $_GET['logged_out'] == '1'): ?>
                <div id="loginpro-message" class="loginpro-message success" style="display:block;">
                    ✅ <?php _e('با موفقیت از حساب کاربری خود خارج شدید.', 'loginpro'); ?>
                </div>
                <?php endif; ?>
                
                <!-- Step 1: Identifier -->
                <div id="loginpro-step-identifier" class="loginpro-step active">
                    <div class="loginpro-field-group">
                        <input type="text" id="loginpro-identifier" class="loginpro-input" placeholder=" " dir="ltr">
                        <label for="loginpro-identifier" class="loginpro-label"><?php echo esc_html($text_help_identifier); ?></label>
                    </div>
                    
                    <button id="loginpro-check-user" class="<?php echo $button_class; ?>" data-original-text="<?php echo esc_attr($text_continue_btn); ?>">
                        <?php echo esc_html($text_continue_btn); ?>
                    </button>
                    
                    <div class="loginpro-hint">
                        <?php esc_html_e('کاربران جدید با شماره موبایل ثبت‌نام می‌کنند.', 'loginpro'); ?>
                    </div>
                    
                    <div class="loginpro-links">
                        <?php if ($show_reset): ?>
                            <a href="#" id="loginpro-forgot-link">🔐 <?php echo esc_html($text_forgot_password); ?></a>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($show_social_section): ?>
                    <div class="loginpro-social-login">
                        <div class="social-divider"><?php esc_html_e('یا', 'loginpro'); ?></div>
                        <div class="loginpro-social-buttons">
                            <?php if ($google_enabled): ?>
                            <a href="<?php echo esc_url(home_url('/?loginpro_google_login=1')); ?>" class="<?php echo $social_btn_class; ?> google">
                                <span style="font-weight:bold;font-size:16px;">G</span> 
                                <?php echo esc_html($google_button_text); ?>
                            </a>
                            <?php endif; ?>
                            <?php if ($facebook_enabled): ?>
                            <a href="<?php echo esc_url(home_url('/?loginpro_facebook_login=1')); ?>" class="<?php echo $social_btn_class; ?> facebook">
                                <span style="font-weight:bold;font-size:16px;">f</span> 
                                <?php echo esc_html($facebook_button_text); ?>
                            </a>
                            <?php endif; ?>
                            <?php if ($github_enabled): ?>
                            <a href="<?php echo esc_url(home_url('/?loginpro_github_login=1')); ?>" class="<?php echo $social_btn_class; ?> github">
                                <span style="font-weight:bold;font-size:16px;">GH</span> 
                                <?php echo esc_html($github_button_text); ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Step 2: OTP با خط زیرین -->
                <div id="loginpro-step-otp" class="loginpro-step">
                    <div class="loginpro-box">
                        <h3 style="text-align:center;margin:0 0 8px;font-size:18px;">🔐 <?php echo esc_html($text_otp_title); ?></h3>
                        <p id="loginpro-otp-info" style="text-align:center;margin:0 0 15px;color:#666;font-size:13px;">
                            <?php echo esc_html($text_otp_login_message); ?>
                            <span id="loginpro-mobile-display" style="color:<?php echo esc_attr($primary_color); ?>;font-weight:bold;"></span>
                        </p>
                        
                        <!-- OTP Inputs با خط زیرین -->
                        <div class="otp-input-group" id="otp-container">
                            <?php for ($i = 0; $i < $otp_length; $i++): ?>
                            <input type="text" class="otp-digit" maxlength="1" inputmode="numeric" pattern="[0-9]" data-index="<?php echo $i; ?>">
                            <?php endfor; ?>
                        </div>
                        
                        <button id="loginpro-verify-otp" class="<?php echo $button_class; ?>" data-original-text="<?php echo esc_attr($text_verify_btn); ?>">
                            <?php echo esc_html($text_verify_btn); ?>
                        </button>
                        
                        <div class="loginpro-otp-actions">
                            <button id="loginpro-resend-otp" class="resend-btn">🔄 <?php esc_html_e('ارسال مجدد کد', 'loginpro'); ?></button>
                            <div class="timer" id="loginpro-timer">⏱️ <span id="loginpro-countdown">120</span> <?php esc_html_e('ثانیه', 'loginpro'); ?></div>
                        </div>
                        
                        <button id="loginpro-back-identifier-otp" class="loginpro-back-btn">← <?php esc_html_e('بازگشت', 'loginpro'); ?></button>
                    </div>
                </div>
                
                <!-- Step 3: Password -->
                <div id="loginpro-step-password" class="loginpro-step">
                    <div class="loginpro-box">
                        <h3 style="text-align:center;margin:0 0 8px;font-size:18px;">🔐 <?php echo esc_html($text_password_title); ?></h3>
                        <p id="loginpro-user-name" style="text-align:center;margin:0 0 15px;color:#666;font-size:13px;"></p>
                        
                        <div class="loginpro-field-group">
                            <input type="password" id="loginpro-password" class="loginpro-input" placeholder=" ">
                            <label for="loginpro-password" class="loginpro-label"><?php echo esc_html($text_help_password); ?></label>
                        </div>
                        
                        <button id="loginpro-submit-password" class="<?php echo $button_class; ?>" data-original-text="<?php echo esc_attr($text_login_btn); ?>">
                            <?php echo esc_html($text_login_btn); ?>
                        </button>
                        
                        <button id="loginpro-back-identifier-pwd" class="loginpro-back-btn">← <?php esc_html_e('بازگشت', 'loginpro'); ?></button>
                    </div>
                </div>
                
                <?php if (!empty($footer_text)): ?>
                <div class="loginpro-footer"><?php echo wp_kses_post($footer_text); ?></div>
                <?php endif; ?>
                
            </div>
        </div>
        
        <!-- Forgot Modal -->
        <div id="loginpro-forgot-modal" class="loginpro-forgot-modal-overlay">
            <div class="loginpro-forgot-modal-box">
                <button class="close-btn" id="loginpro-modal-close-btn">✕</button>
                <h3>🔑 <?php echo esc_html($text_forgot_password); ?></h3>
                <p><?php esc_html_e('ایمیل خود را جهت دریافت لینک بازیابی رمز، وارد کنید.', 'loginpro'); ?></p>
                <div id="loginpro-modal-msg" class="modal-msg"></div>
                <input type="email" id="loginpro-modal-email" class="modal-input" placeholder="<?php esc_attr_e('ایمیل خود را وارد کنید', 'loginpro'); ?>">
                <button id="loginpro-modal-submit" class="modal-btn"><?php esc_html_e('ارسال لینک بازیابی', 'loginpro'); ?></button>
                <button class="modal-close-btn" id="loginpro-modal-cancel"><?php esc_html_e('انصراف', 'loginpro'); ?></button>
            </div>
        </div>
        
        <!-- Profile Modal -->
        <div id="loginpro-profile-modal" class="loginpro-profile-modal-overlay">
            <div class="loginpro-profile-modal-box">
                <button class="close-btn" id="loginpro-profile-close-btn">✕</button>
                <h3>📝 <?php esc_html_e('تکمیل اطلاعات', 'loginpro'); ?></h3>
                <p class="subtitle"><?php esc_html_e('شماره موبایل شما با موفقیت تایید شد. لطفاً اطلاعات خود را تکمیل کنید.', 'loginpro'); ?></p>
                
                <div id="loginpro-profile-msg" class="profile-msg"></div>
                
                <div class="loginpro-field-group">
                    <input type="text" id="profile-fullname" class="loginpro-input" placeholder=" " required>
                    <label for="profile-fullname" class="loginpro-label"><?php esc_html_e('نام و نام خانوادگی *', 'loginpro'); ?></label>
                </div>
                
                <div class="loginpro-field-group">
                    <input type="email" id="profile-email" class="loginpro-input ltr" placeholder=" " required dir="ltr">
                    <label for="profile-email" class="loginpro-label"><?php esc_html_e('ایمیل *', 'loginpro'); ?></label>
                </div>
                
                <div class="loginpro-field-group">
                    <input type="text" id="profile-username" class="loginpro-input ltr" placeholder=" " required dir="ltr">
                    <label for="profile-username" class="loginpro-label"><?php esc_html_e('نام کاربری *', 'loginpro'); ?></label>
                </div>
                
                <div class="loginpro-field-group">
                    <input type="password" id="profile-password" class="loginpro-input" placeholder=" " required>
                    <label for="profile-password" class="loginpro-label"><?php esc_html_e('رمز عبور * (حداقل 6 کاراکتر)', 'loginpro'); ?></label>
                </div>
                
                <div class="loginpro-field-group">
                    <input type="password" id="profile-password-confirm" class="loginpro-input" placeholder=" " required>
                    <label for="profile-password-confirm" class="loginpro-label"><?php esc_html_e('تکرار رمز عبور *', 'loginpro'); ?></label>
                </div>
                
                <button id="loginpro-profile-submit" class="profile-btn"><?php esc_html_e('تکمیل و ثبت نام', 'loginpro'); ?></button>
                
                <div class="login-link">
                    <a id="loginpro-profile-to-login">← <?php esc_html_e('بازگشت', 'loginpro'); ?></a>
                </div>
            </div>
        </div>
        
        <script>
        // ============================================
        // ✅ اسکریپت کامل صفحه لاگین
        // ============================================
        (function() {
            'use strict';
            
            console.log('✅ LoginPro: Form loaded');
            
            var config = {
                ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>',
                nonce: '<?php echo wp_create_nonce('loginpro_ajax_nonce'); ?>',
                primary_color: '<?php echo esc_js($primary_color); ?>'
            };
            
            // ============================================
            // ✅ عناصر صفحه
            // ============================================
            var identifierInput = document.getElementById('loginpro-identifier');
            var checkBtn = document.getElementById('loginpro-check-user');
            var verifyBtn = document.getElementById('loginpro-verify-otp');
            var resendBtn = document.getElementById('loginpro-resend-otp');
            var backBtn = document.getElementById('loginpro-back-identifier-otp');
            var messageEl = document.getElementById('loginpro-message');
            var otpInputs = document.querySelectorAll('.otp-digit');
            var mobileDisplay = document.getElementById('loginpro-mobile-display');
            var countdownEl = document.getElementById('loginpro-countdown');
            var timerEl = document.getElementById('loginpro-timer');
            var passwordInput = document.getElementById('loginpro-password');
            var submitPasswordBtn = document.getElementById('loginpro-submit-password');
            var backBtnPwd = document.getElementById('loginpro-back-identifier-pwd');
            var userNameDisplay = document.getElementById('loginpro-user-name');
            
            var currentIdentifier = '';
            var currentToken = '';
            var otpTimer = null;
            var countdown = 120;
            
            // ✅ تبدیل ارقام فارسی/عربی به انگلیسی
            function toEnglishDigits(str) {
                if (!str) return '';
                var persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
                var arabic  = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
                return String(str).replace(/[۰-۹]/g, function(d) { return String(persian.indexOf(d)); })
                                   .replace(/[٠-٩]/g, function(d) { return String(arabic.indexOf(d)); });
            }
            
            // ============================================
            // ✅ توابع
            // ============================================
            function showMsg(msg, type) {
                if (!messageEl) return;
                messageEl.className = 'loginpro-message ' + type;
                messageEl.textContent = msg;
                messageEl.style.display = 'block';
                clearTimeout(messageEl._timer);
                messageEl._timer = setTimeout(function() {
                    messageEl.style.display = 'none';
                }, 5000);
            }
            
            function setLoading(btn, loading) {
                if (!btn) return;
                btn.disabled = loading;
                btn.textContent = loading ? '⏳ در حال ارسال...' : btn.getAttribute('data-original-text') || 'ادامه';
            }
            
            function getOtpCode() {
                var code = '';
                otpInputs.forEach(function(inp) {
                    code += inp.value;
                });
                return code;
            }
            
            function clearOtp() {
                otpInputs.forEach(function(inp) {
                    inp.value = '';
                    inp.classList.remove('filled');
                });
                if (otpInputs[0]) otpInputs[0].focus();
            }
            
            function startCountdown(seconds) {
                countdown = seconds || 120;
                if (timerEl) timerEl.style.display = 'block';
                if (resendBtn) {
                    resendBtn.disabled = true;
                    resendBtn.style.opacity = '0.4';
                }
                clearInterval(otpTimer);
                otpTimer = setInterval(function() {
                    countdown--;
                    if (countdownEl) countdownEl.textContent = countdown;
                    if (countdown <= 0) {
                        clearInterval(otpTimer);
                        if (timerEl) timerEl.style.display = 'none';
                        if (resendBtn) {
                            resendBtn.disabled = false;
                            resendBtn.style.opacity = '1';
                            resendBtn.textContent = '🔄 ارسال مجدد کد';
                        }
                    }
                }, 1000);
            }
            
            function showStep(step) {
                var steps = ['identifier', 'otp', 'password'];
                for (var i = 0; i < steps.length; i++) {
                    var el = document.getElementById('loginpro-step-' + steps[i]);
                    if (el) {
                        el.className = 'loginpro-step' + (steps[i] === step ? ' active' : '');
                    }
                }
            }
            
            // ============================================
            // ✅ OTP Inputs
            // ============================================
            otpInputs.forEach(function(input, index) {
                input.addEventListener('input', function(e) {
                    var val = toEnglishDigits(e.target.value).replace(/\D/g, '');
                    e.target.value = val;
                    if (val.length === 1) {
                        e.target.classList.add('filled');
                        if (index < otpInputs.length - 1) {
                            otpInputs[index + 1].focus();
                        }
                    } else {
                        e.target.classList.remove('filled');
                    }
                });
                
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Backspace' && e.target.value === '' && index > 0) {
                        e.preventDefault();
                        otpInputs[index - 1].focus();
                        otpInputs[index - 1].value = '';
                        otpInputs[index - 1].classList.remove('filled');
                    }
                });
            });
            
            // ============================================
            // ✅ دکمه ارسال OTP
            // ============================================
            if (checkBtn) {
                checkBtn.addEventListener('click', function() {
                    var raw = identifierInput ? identifierInput.value.trim() : '';
                    if (!raw) {
                        showMsg('لطفاً شماره موبایل، ایمیل یا نام کاربری را وارد کنید', 'error');
                        return;
                    }

                    var normalized = toEnglishDigits(raw);
                    var digitsOnly = normalized.replace(/[^0-9]/g, '');
                    var looksLikeMobile = normalized.replace(/[\s\-]/g, '') === digitsOnly && digitsOnly.length >= 10 && digitsOnly.length <= 11;

                    var payloadIdentifier;

                    if (looksLikeMobile) {
                        var clean = digitsOnly;
                        if (clean.length === 10) clean = '0' + clean;

                        if (clean.length !== 11) {
                            showMsg('لطفاً شماره موبایل معتبر وارد کنید (09123456789)', 'error');
                            return;
                        }
                        payloadIdentifier = clean;
                    } else {
                        payloadIdentifier = normalized;
                    }

                    currentIdentifier = payloadIdentifier;
                    
                    setLoading(checkBtn, true);
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_check_identifier');
                    formData.append('_nonce', config.nonce);
                    formData.append('identifier', payloadIdentifier);
                    formData.append('type', 'login');
                    
                    fetch(config.ajax_url, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { 
                        if (!res.ok) throw new Error('HTTP ' + res.status);
                        return res.json(); 
                    })
                    .then(function(data) {
                        console.log('📥 Response:', data);
                        setLoading(checkBtn, false);
                        
                        if (data.success) {
                            var isMobileResult = !!(data.data && data.data.is_mobile);

                            if (isMobileResult) {
                                currentToken = (data.data && data.data.token) ? data.data.token : '';

                                if (mobileDisplay) {
                                    mobileDisplay.textContent = payloadIdentifier;
                                }
                                
                                showMsg('✅ کد تایید به شماره شما ارسال شد', 'success');
                                showStep('otp');
                                clearOtp();
                                startCountdown(120);
                            } else {
                                if (userNameDisplay) {
                                    userNameDisplay.textContent = (data.data && data.data.email) ? data.data.email : payloadIdentifier;
                                }
                                showStep('password');
                                if (passwordInput) passwordInput.focus();
                            }
                        } else {
                            showMsg('❌ ' + (data.message || 'خطا در ارسال کد'), 'error');
                        }
                    })
                    .catch(function(error) {
                        console.error('❌ Error:', error);
                        setLoading(checkBtn, false);
                        showMsg('❌ خطا در ارتباط با سرور: ' + error.message, 'error');
                    });
                });
            }
            
            // ============================================
            // ✅ دکمه تأیید OTP
            // ============================================
            if (verifyBtn) {
                verifyBtn.addEventListener('click', function() {
                    var code = getOtpCode();
                    if (code.length < 6) {
                        showMsg('لطفاً کد ۶ رقمی را کامل وارد کنید', 'error');
                        return;
                    }
                    
                    setLoading(verifyBtn, true);
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_verify_otp');
                    formData.append('_nonce', config.nonce);
                    formData.append('mobile', currentIdentifier);
                    formData.append('code', code);
                    formData.append('token', currentToken);
                    
                    fetch(config.ajax_url, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        console.log('📥 Verify response:', data);
                        setLoading(verifyBtn, false);
                        
                        if (data.success) {
                            showMsg('✅ ورود موفق! در حال انتقال...', 'success');
                            if (data.data && data.data.redirect) {
                                setTimeout(function() {
                                    window.location.href = data.data.redirect;
                                }, 1000);
                            } else {
                                setTimeout(function() {
                                    window.location.reload();
                                }, 1000);
                            }
                        } else {
                            showMsg('❌ ' + (data.message || 'کد نامعتبر است'), 'error');
                            clearOtp();
                        }
                    })
                    .catch(function(error) {
                        console.error('❌ Error:', error);
                        setLoading(verifyBtn, false);
                        showMsg('❌ خطا: ' + error.message, 'error');
                    });
                });
            }
            
            // ============================================
            // ✅ دکمه ارسال مجدد
            // ============================================
            if (resendBtn) {
                resendBtn.addEventListener('click', function() {
                    if (this.disabled) return;
                    
                    this.disabled = true;
                    this.textContent = '⏳ در حال ارسال...';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_resend_otp');
                    formData.append('_nonce', config.nonce);
                    formData.append('mobile', currentIdentifier);
                    
                    fetch(config.ajax_url, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        resendBtn.disabled = false;
                        resendBtn.textContent = '🔄 ارسال مجدد کد';
                        
                        if (data.success) {
                            if (data.data && data.data.token) {
                                currentToken = data.data.token;
                            }
                            showMsg('✅ کد جدید ارسال شد', 'success');
                            clearOtp();
                            startCountdown(120);
                        } else {
                            showMsg('❌ ' + (data.message || 'خطا در ارسال مجدد'), 'error');
                        }
                    })
                    .catch(function(error) {
                        resendBtn.disabled = false;
                        resendBtn.textContent = '🔄 ارسال مجدد کد';
                        showMsg('❌ خطا: ' + error.message, 'error');
                    });
                });
            }
            
            // ============================================
            // ✅ دکمه بازگشت
            // ============================================
            if (backBtn) {
                backBtn.addEventListener('click', function() {
                    clearInterval(otpTimer);
                    showStep('identifier');
                    if (identifierInput) identifierInput.focus();
                });
            }
            
            // ============================================
            // ✅ دکمه ورود با رمز عبور
            // ============================================
            if (submitPasswordBtn) {
                submitPasswordBtn.addEventListener('click', function() {
                    var pwd = passwordInput ? passwordInput.value : '';

                    if (!pwd) {
                        showMsg('لطفاً رمز عبور را وارد کنید', 'error');
                        return;
                    }

                    setLoading(submitPasswordBtn, true);

                    var formData = new FormData();
                    formData.append('action', 'loginpro_login_password');
                    formData.append('_nonce', config.nonce);
                    formData.append('identifier', currentIdentifier);
                    formData.append('password', pwd);

                    fetch(config.ajax_url, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        setLoading(submitPasswordBtn, false);

                        if (data.success) {
                            showMsg('✅ ورود موفق! در حال انتقال...', 'success');
                            setTimeout(function() {
                                if (data.data && data.data.redirect) {
                                    window.location.href = data.data.redirect;
                                } else {
                                    window.location.reload();
                                }
                            }, 800);
                        } else {
                            showMsg('❌ ' + (data.message || 'رمز عبور اشتباه است'), 'error');
                        }
                    })
                    .catch(function(error) {
                        console.error('❌ Error:', error);
                        setLoading(submitPasswordBtn, false);
                        showMsg('❌ خطا: ' + error.message, 'error');
                    });
                });
            }

            if (passwordInput) {
                passwordInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        if (submitPasswordBtn) submitPasswordBtn.click();
                    }
                });
            }

            if (backBtnPwd) {
                backBtnPwd.addEventListener('click', function() {
                    showStep('identifier');
                    if (identifierInput) identifierInput.focus();
                });
            }
            
            // ============================================
            // ✅ Enter
            // ============================================
            if (identifierInput) {
                identifierInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        if (checkBtn) checkBtn.click();
                    }
                });
            }
            
            console.log('✅ LoginPro: Script ready');
        })();
        </script>
        
        <?php wp_footer(); ?>
    </body>
    </html>
    <?php
}

// ==================================================
// ✅ ریدایرکت بعد از خروج از حساب
// ==================================================
add_action('wp_logout', 'loginpro_after_logout_redirect');

function loginpro_after_logout_redirect() {
    // ✅ بعد از خروج به صفحه لاگین برو
    $login_page_id = (int) get_option('loginpro_login_page_id', 0);
    if ($login_page_id) {
        $login_url = get_permalink($login_page_id);
        if ($login_url) {
            wp_redirect(add_query_arg('logged_out', '1', $login_url));
            exit;
        }
    }
    wp_redirect(home_url('/login/?logged_out=1'));
    exit;
}