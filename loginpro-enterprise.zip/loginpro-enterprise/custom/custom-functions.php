<?php
/**
 * کدهای سفارشی لاگین پرو - نسخه اصلاح‌شده
 * 
 * @package LoginPro
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ ایجاد جدول تیکت‌ها در هنگام فعال‌سازی
// ==================================================
function loginpro_create_tickets_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    $table = $wpdb->prefix . 'loginpro_tickets';
    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        title varchar(255) NOT NULL,
        message text NOT NULL,
        reply text DEFAULT NULL,
        reply_date datetime DEFAULT NULL,
        status varchar(20) DEFAULT 'open',
        priority varchar(20) DEFAULT 'normal',
        category varchar(50) DEFAULT 'general',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status),
        KEY priority (priority)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// اجرا هنگام بارگذاری افزونه
add_action('init', function() {
    global $wpdb;
    $table = $wpdb->prefix . 'loginpro_tickets';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
        loginpro_create_tickets_table();
    }
});

// ==================================================
// ✅ تبدیل خودکار لینک‌های ورود به پنل کاربری بعد از لاگین
// ==================================================

// ✅ فقط هوک‌های ضروری با اولویت بالا (اجرای دیرتر)
add_filter('the_content', 'loginpro_auto_replace_login_links', 999, 1);
add_filter('wp_nav_menu_objects', 'loginpro_change_menu_login_items', 999, 2);
add_filter('gettext', 'loginpro_change_login_button_text', 999, 3);
add_filter('ngettext', 'loginpro_change_login_button_text', 999, 3);
add_filter('loginpro_modal_button', 'loginpro_replace_modal_button', 999, 2);

// ==================================================
// ✅ تبدیل لینک‌های ورود در محتوا
// ==================================================
function loginpro_auto_replace_login_links($content) {
    // ✅ بررسی وجود تابع
    if (!function_exists('is_user_logged_in') || !is_user_logged_in()) {
        return $content;
    }
    
    if (empty($content) || strlen($content) < 30) {
        return $content;
    }
    
    static $profile_url = null;
    if ($profile_url === null) {
        $profile_url = loginpro_get_profile_url();
    }
    
    $login_patterns = ['wp-login', '/login', '/register', 'ورود', 'ثبت نام', 'عضویت', 'حساب کاربری'];
    $has_login = false;
    foreach ($login_patterns as $pattern) {
        if (stripos($content, $pattern) !== false) {
            $has_login = true;
            break;
        }
    }
    if (!$has_login) {
        return $content;
    }
    
    $login_keywords = [
        'ورود', 'ثبت‌نام', 'ثبت نام', 'ورود / ثبت‌نام', 'ورود/ثبت‌نام',
        'ورود و ثبت‌نام', 'حساب کاربری', 'عضویت', 'ورود به سایت',
        'لاگین', 'ثبت نام', 'ورود | ثبت نام',
        'Sign in', 'Sign up', 'Login', 'Register', 'Log in', 'My Account'
    ];
    
    $pattern = '/<a([^>]*)>(.*?)<\/a>/i';
    
    $content = preg_replace_callback($pattern, function($matches) use ($profile_url, $login_keywords) {
        $link_text = strip_tags($matches[2]);
        $link_text_clean = trim(preg_replace('/[^آ-یa-zA-Z0-9\s\/]/u', '', $link_text));
        $attrs = strtolower($matches[1]);
        
        if (strpos($attrs, 'wp-login.php') !== false || 
            strpos($attrs, '/login') !== false || 
            strpos($attrs, '/register') !== false) {
            return '<a href="' . esc_url($profile_url) . '">پنل کاربری</a>';
        }
        
        foreach ($login_keywords as $keyword) {
            $keyword_clean = trim(preg_replace('/[^آ-یa-zA-Z0-9\s\/]/u', '', $keyword));
            if (stripos($link_text_clean, $keyword_clean) !== false || 
                stripos($link_text, $keyword) !== false) {
                
                $new_attrs = preg_replace('/class=["\'][^"\']*["\']/', '', $matches[1]);
                $new_attrs = preg_replace('/style=["\'][^"\']*["\']/', '', $new_attrs);
                return '<a href="' . esc_url($profile_url) . '" ' . trim($new_attrs) . '>پنل کاربری</a>';
            }
        }
        
        return $matches[0];
    }, $content);
    
    return $content;
}

// ==================================================
// ✅ تبدیل منوی ورود به پنل کاربری
// ==================================================
function loginpro_change_menu_login_items($items, $args) {
    // ✅ بررسی وجود تابع
    if (!function_exists('is_user_logged_in') || !is_user_logged_in()) {
        return $items;
    }
    
    static $profile_url = null;
    if ($profile_url === null) {
        $profile_url = loginpro_get_profile_url();
    }
    
    $login_keywords = [
        'ورود', 'ثبت‌نام', 'ثبت نام', 'ورود / ثبت‌نام', 'ورود/ثبت‌نام',
        'ورود و ثبت‌نام', 'حساب کاربری', 'عضویت', 'ورود به سایت',
        'login', 'register', 'sign in', 'sign up', 'log in',
        'my account', 'account'
    ];
    
    foreach ($items as $item) {
        $item_title = strtolower(trim($item->title));
        $item_title_clean = trim(preg_replace('/[^آ-یa-zA-Z0-9\s\/]/u', '', $item_title));
        $item_url = strtolower($item->url);
        
        $is_login_item = false;
        
        foreach ($login_keywords as $keyword) {
            $keyword_clean = trim(preg_replace('/[^آ-یa-zA-Z0-9\s\/]/u', '', $keyword));
            if (stripos($item_title_clean, $keyword_clean) !== false || 
                stripos($item_title, $keyword) !== false) {
                $is_login_item = true;
                break;
            }
        }
        
        if (!$is_login_item) {
            if (strpos($item_url, 'wp-login') !== false ||
                strpos($item_url, '/login') !== false ||
                strpos($item_url, '/register') !== false) {
                $is_login_item = true;
            }
        }
        
        if ($is_login_item) {
            $item->title = 'پنل کاربری';
            $item->url = $profile_url;
            $item->classes = array_filter($item->classes, function($class) {
                return strpos($class, 'login') === false && 
                       strpos($class, 'register') === false &&
                       strpos($class, 'sign') === false;
            });
            $item->classes[] = 'loginpro-profile-menu';
        }
    }
    
    return $items;
}

// ==================================================
// ✅ تبدیل متن دکمه‌های لاگین - اصلاح‌شده
// ==================================================
function loginpro_change_login_button_text($translated_text, $text, $domain) {
    // ✅ بررسی وجود تابع
    if (!function_exists('is_user_logged_in') || !is_user_logged_in()) {
        return $translated_text;
    }
    
    static $login_texts = null;
    if ($login_texts === null) {
        $login_texts = [
            'Log in' => 'پنل کاربری',
            'Login' => 'پنل کاربری',
            'Sign in' => 'پنل کاربری',
            'Sign Up' => 'پنل کاربری',
            'Register' => 'پنل کاربری',
            'ورود' => 'پنل کاربری',
            'ثبت‌نام' => 'پنل کاربری',
            'ثبت نام' => 'پنل کاربری',
            'ورود / ثبت‌نام' => 'پنل کاربری',
            'ورود/ثبت‌نام' => 'پنل کاربری',
            'ورود | ثبت نام' => 'پنل کاربری',
            'ورود و ثبت‌نام' => 'پنل کاربری',
            'عضویت' => 'پنل کاربری',
            'حساب کاربری' => 'پنل کاربری',
        ];
    }
    
    if (isset($login_texts[$text])) {
        return $login_texts[$text];
    }
    
    return $translated_text;
}

// ==================================================
// ✅ تبدیل دکمه مودال ورود/ثبت‌نام
// ==================================================
function loginpro_replace_modal_button($output, $atts) {
    // ✅ بررسی وجود تابع
    if (!function_exists('is_user_logged_in') || !is_user_logged_in()) {
        return $output;
    }
    
    static $profile_url = null;
    if ($profile_url === null) {
        $profile_url = loginpro_get_profile_url();
    }
    
    static $logged_in_text = null;
    if ($logged_in_text === null) {
        $logged_in_text = get_option('loginpro_modal_btn_logged_text', 'پنل کاربری');
    }
    
    static $logged_in_icon = null;
    if ($logged_in_icon === null) {
        $logged_in_icon = get_option('loginpro_modal_btn_logged_icon', '👤');
    }
    
    if (strpos($output, 'loginpro-modal-trigger') !== false) {
        return '<a href="' . esc_url($profile_url) . '" class="loginpro-profile-button">' . 
               esc_html($logged_in_icon) . ' ' . esc_html($logged_in_text) . '</a>';
    }
    
    return $output;
}

// ==================================================
// ✅ شورت‌کد دکمه مودال - بهینه‌شده
// ==================================================
add_shortcode('loginpro_modal_button', function($atts) {
    $defaults = [
        'text' => get_option('loginpro_modal_btn_text', __('ورود / ثبت‌نام', 'loginpro')),
        'logged_in_text' => get_option('loginpro_modal_btn_logged_text', __('پنل کاربری', 'loginpro')),
        'icon' => get_option('loginpro_modal_btn_icon', '🔐'),
        'logged_in_icon' => get_option('loginpro_modal_btn_logged_icon', '👤'),
        'class' => '',
        'bg_color' => get_option('loginpro_modal_btn_bg_color', '#ef394e'),
        'text_color' => get_option('loginpro_modal_btn_text_color', '#ffffff'),
    ];
    
    $atts = shortcode_atts($defaults, $atts);
    
    if (is_user_logged_in()) {
        static $profile_url = null;
        if ($profile_url === null) {
            $profile_url = loginpro_get_profile_url();
        }
        return '<a href="' . esc_url($profile_url) . '" class="' . esc_attr($atts['class']) . '">' . 
               esc_html($atts['logged_in_icon']) . ' ' . esc_html($atts['logged_in_text']) . '</a>';
    }
    
    return '<button type="button" class="loginpro-modal-trigger ' . esc_attr($atts['class']) . '">' . 
           esc_html($atts['icon']) . ' ' . esc_html($atts['text']) . '</button>';
});

// ==================================================
// ✅ loginpro_user - داشبورد کامل کاربری
// ==================================================
if (!function_exists('loginpro_render_user_dashboard_shortcode')) {
function loginpro_render_user_dashboard_shortcode($atts) {
    $atts = shortcode_atts([
        'tabs' => '',
        'layout' => 'tabs',
        'class' => ''
    ], $atts);
    
    if (!is_user_logged_in()) {
        return '<div style="text-align:center;padding:40px;">' . 
                sprintf(__('لطفاً <a href="%s">وارد شوید</a>', 'loginpro'), wp_login_url(get_permalink())) . 
                '</div>';
    }
    
    $user = wp_get_current_user();
    
    // ==========================================
    // ✅ تعریف کامل تب‌ها
    // ==========================================
    $all_tabs = [
        'account_details' => ['icon' => '👤', 'label' => 'اطلاعات حساب کاربری', 'shortcode' => ''],
        'messages' => ['icon' => '✉️', 'label' => 'پیام‌ها', 'shortcode' => ''],
        'addresses' => ['icon' => '📍', 'label' => 'آدرس‌ها', 'shortcode' => ''],
        'orders' => ['icon' => '🛒', 'label' => 'سفارش‌ها', 'shortcode' => ''],
        'wishlist' => ['icon' => '❤️', 'label' => 'لیست‌های من', 'shortcode' => 'loginpro_wishlist'],
        'downloads' => ['icon' => '📥', 'label' => 'دانلودها', 'shortcode' => ''],
        'subscription' => ['icon' => '📋', 'label' => 'اشتراک', 'shortcode' => 'loginpro_subscriptions'],
        'gifts' => ['icon' => '🎁', 'label' => 'هدیه‌ها', 'shortcode' => 'loginpro_gifts'],
        'tickets' => ['icon' => '🎫', 'label' => 'تیکت‌های پشتیبانی', 'shortcode' => ''],
        'reviews' => ['icon' => '💬', 'label' => 'دیدگاه و پرسش‌ها', 'shortcode' => 'loginpro_reviews'],
        'recent_views' => ['icon' => '👁️', 'label' => 'بازدیدهای اخیر', 'shortcode' => 'loginpro_recent_views'],
        'logout' => ['icon' => '🚪', 'label' => 'خروج از حساب', 'shortcode' => ''],
        'security' => ['icon' => '🔒', 'label' => 'امنیت', 'shortcode' => 'loginpro_security'],
        'sessions' => ['icon' => '🌐', 'label' => 'نشست‌ها', 'shortcode' => 'loginpro_sessions'],
        'history' => ['icon' => '📜', 'label' => 'تاریخچه', 'shortcode' => 'loginpro_history']
    ];
    
    // دریافت تب‌های فعال از دیتابیس (با کش)
    static $active_tabs_keys = null;
    if ($active_tabs_keys === null) {
        $active_tabs_keys = get_option('loginpro_user_dashboard_tabs');
        if (empty($active_tabs_keys) || !is_array($active_tabs_keys)) {
            $active_tabs_keys = array_keys($all_tabs);
            update_option('loginpro_user_dashboard_tabs', $active_tabs_keys);
        }
    }
    
    // اگر از طریق attribute تب مشخص شده
    if (!empty($atts['tabs'])) {
        $custom_tabs = array_map('trim', explode(',', $atts['tabs']));
        $active_tabs_keys = array_intersect($custom_tabs, array_keys($all_tabs));
        if (empty($active_tabs_keys)) {
            $active_tabs_keys = $custom_tabs;
        }
    }
    
    // ساخت آرایه نهایی تب‌ها
    $tabs = [];
    foreach ($active_tabs_keys as $key) {
        if (isset($all_tabs[$key])) {
            $tabs[$key] = $all_tabs[$key];
        }
    }
    
    if (empty($tabs)) {
        $tabs = ['account_details' => $all_tabs['account_details']];
    }
    
    $primary_color = get_option('loginpro_primary_color', '#ef394e');
    $is_woocommerce = class_exists('WooCommerce');
    
    // دریافت تب فعال از کوکی
    $active_tab = isset($_COOKIE['loginpro_active_tab']) ? $_COOKIE['loginpro_active_tab'] : '';
    if (!isset($tabs[$active_tab])) {
        $active_tab = array_key_first($tabs);
    }
    
    ob_start();
    ?>
    <div class="loginpro-user-dashboard <?php echo esc_attr($atts['class']); ?>" style="max-width:900px;margin:0 auto;background:#fff;border-radius:16px;padding:25px;box-shadow:0 2px 12px rgba(0,0,0,0.05);font-family:'IRANSans', Tahoma, sans-serif;" data-active-tab="<?php echo esc_attr($active_tab); ?>">
        
        <!-- هدر کاربر -->
        <div class="loginpro-user-header" style="display:flex;align-items:center;gap:15px;padding:15px 20px;background:#f8f9fa;border-radius:12px;margin-bottom:20px;flex-wrap:wrap;">
            <div style="width:60px;height:60px;display:flex;align-items:center;justify-content:center;background:<?php echo esc_attr($primary_color); ?>;color:#fff;border-radius:50%;font-size:24px;font-weight:bold;">
                <?php echo strtoupper(substr($user->display_name, 0, 1)); ?>
            </div>
            <div>
                <h2 style="margin:0;font-size:20px;"><?php echo esc_html($user->display_name); ?></h2>
                <p style="margin:0;color:#666;font-size:14px;"><?php echo esc_html($user->user_email); ?></p>
            </div>
        </div>
        
        <!-- تب‌ها -->
        <div class="loginpro-tabs-container">
            <?php foreach ($tabs as $key => $tab): 
                $is_active = ($key === $active_tab);
            ?>
            <div class="loginpro-tab-item" style="margin-bottom:4px;border-bottom:1px solid #f0f0f0;">
                <div class="loginpro-tab-header" data-tab="<?php echo esc_attr($key); ?>" style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;cursor:pointer;background:<?php echo $is_active ? '#fff' : '#f8f9fa'; ?>;border-radius:8px;transition:all 0.3s;border-right:3px solid <?php echo $is_active ? esc_attr($primary_color) : 'transparent'; ?>;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:18px;"><?php echo esc_html($tab['icon']); ?></span>
                        <span style="font-size:14px;font-weight:500;color:#555;"><?php echo esc_html($tab['label']); ?></span>
                    </div>
                    <span class="tab-arrow" style="font-size:14px;color:#999;transition:transform 0.3s;display:inline-block;transform:<?php echo $is_active ? 'rotate(180deg)' : 'rotate(0deg)'; ?>;">▾</span>
                </div>
                <div class="loginpro-tab-content" id="tab-<?php echo esc_attr($key); ?>" style="display:<?php echo $is_active ? 'block' : 'none'; ?>;padding:12px 10px 8px 10px;">
                    <?php
                    switch ($key) {
                        case 'account_details':
                            if ($is_woocommerce) {
                                echo '<div class="woocommerce-account-wrapper">';
                                wc_get_template('myaccount/form-edit-account.php', ['user' => $user]);
                                echo '</div>';
                            } else {
                                echo do_shortcode('[loginpro_profile]');
                            }
                            break;
                            
                        case 'addresses':
                            if ($is_woocommerce) {
                                $customer = new WC_Customer($user->ID);
                                $billing = $customer->get_billing();
                                $shipping = $customer->get_shipping();
                                ?>
                                <div class="woocommerce-account-wrapper">
                                    <h3 style="margin:0 0 15px;font-size:17px;">📍 <?php _e('آدرس‌های من', 'loginpro'); ?></h3>
                                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                                        <div style="background:#f8f9fa;padding:15px 20px;border-radius:12px;">
                                            <h4 style="margin:0 0 10px;font-size:15px;">🏠 <?php _e('آدرس صورتحساب', 'loginpro'); ?></h4>
                                            <?php if (empty($billing)): ?>
                                                <p style="color:#999;font-size:13px;"><?php _e('آدرسی ثبت نشده است.', 'loginpro'); ?></p>
                                            <?php else: ?>
                                                <address style="font-style:normal;line-height:1.8;font-size:14px;">
                                                    <?php 
                                                    $address_parts = [];
                                                    if (!empty($billing['first_name']) || !empty($billing['last_name'])) {
                                                        $address_parts[] = trim($billing['first_name'] . ' ' . $billing['last_name']);
                                                    }
                                                    if (!empty($billing['address_1'])) {
                                                        $address_parts[] = $billing['address_1'];
                                                    }
                                                    if (!empty($billing['city'])) {
                                                        $address_parts[] = $billing['city'];
                                                    }
                                                    if (!empty($billing['postcode'])) {
                                                        $address_parts[] = $billing['postcode'];
                                                    }
                                                    if (!empty($billing['phone'])) {
                                                        $address_parts[] = '📞 ' . $billing['phone'];
                                                    }
                                                    echo implode('<br>', $address_parts);
                                                    ?>
                                                </address>
                                            <?php endif; ?>
                                            <a href="<?php echo esc_url(wc_get_account_endpoint_url('edit-address/billing')); ?>" style="display:inline-block;margin-top:10px;color:<?php echo esc_attr($primary_color); ?>;text-decoration:none;font-size:13px;">✏️ <?php _e('ویرایش', 'loginpro'); ?></a>
                                        </div>
                                        <div style="background:#f8f9fa;padding:15px 20px;border-radius:12px;">
                                            <h4 style="margin:0 0 10px;font-size:15px;">🚚 <?php _e('آدرس ارسال', 'loginpro'); ?></h4>
                                            <?php if (empty($shipping)): ?>
                                                <p style="color:#999;font-size:13px;"><?php _e('آدرسی ثبت نشده است.', 'loginpro'); ?></p>
                                            <?php else: ?>
                                                <address style="font-style:normal;line-height:1.8;font-size:14px;">
                                                    <?php 
                                                    $address_parts = [];
                                                    if (!empty($shipping['first_name']) || !empty($shipping['last_name'])) {
                                                        $address_parts[] = trim($shipping['first_name'] . ' ' . $shipping['last_name']);
                                                    }
                                                    if (!empty($shipping['address_1'])) {
                                                        $address_parts[] = $shipping['address_1'];
                                                    }
                                                    if (!empty($shipping['city'])) {
                                                        $address_parts[] = $shipping['city'];
                                                    }
                                                    if (!empty($shipping['postcode'])) {
                                                        $address_parts[] = $shipping['postcode'];
                                                    }
                                                    echo implode('<br>', $address_parts);
                                                    ?>
                                                </address>
                                            <?php endif; ?>
                                            <a href="<?php echo esc_url(wc_get_account_endpoint_url('edit-address/shipping')); ?>" style="display:inline-block;margin-top:10px;color:<?php echo esc_attr($primary_color); ?>;text-decoration:none;font-size:13px;">✏️ <?php _e('ویرایش', 'loginpro'); ?></a>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            } else {
                                echo '<div class="loginpro-tab-placeholder"><p>' . __('ووکامرس فعال نیست.', 'loginpro') . '</p></div>';
                            }
                            break;
                            
                        case 'orders':
                            loginpro_render_orders_tab_with_accordion();
                            break;
                            
                        case 'downloads':
                            loginpro_render_downloads_tab($user);
                            break;
                            
                        case 'messages':
                            loginpro_render_messages_tab($user);
                            break;
                            
                        case 'tickets':
                            echo loginpro_render_tickets_tab_content($user);
                            break;
                            
                        case 'wishlist':
                            loginpro_render_wishlist_tab($user);
                            break;
                            
                        case 'reviews':
                            loginpro_render_reviews_tab($user);
                            break;
                            
                        case 'recent_views':
                            loginpro_render_recent_views_tab($user);
                            break;
                            
                        case 'gifts':
                            loginpro_render_gifts_tab($user);
                            break;
                            
                        case 'subscription':
                            loginpro_render_subscription_tab($user);
                            break;
                            
                        case 'security':
                            loginpro_render_security_tab($user);
                            break;
                            
                        case 'sessions':
                            loginpro_render_sessions_tab($user);
                            break;
                            
                        case 'history':
                            loginpro_render_history_tab($user);
                            break;
                            
                           case 'logout':
    // ✅ استفاده از wp_logout_url با redirect به صفحه اصلی
    $logout_url = wp_logout_url(home_url());
    $logout_url = add_query_arg('_t', time(), $logout_url);
    ?>
    <div style="text-align:center;padding:30px 20px;background:#f8f9fa;border-radius:12px;">
        <div style="font-size:48px;margin-bottom:15px;">🚪</div>
        <h3 style="margin:0 0 10px;color:#333;"><?php _e('خروج از حساب کاربری', 'loginpro'); ?></h3>
        <p style="margin:0 0 25px;color:#666;font-size:15px;">
            <?php _e('برای خروج از حساب کاربری روی دکمه زیر کلیک کنید.', 'loginpro'); ?>
        </p>
        <a href="<?php echo esc_url($logout_url); ?>" 
           onclick="return confirm('<?php _e('آیا مطمئن هستید که می‌خواهید خارج شوید؟', 'loginpro'); ?>');"
           style="display:inline-block;background:#dc3545;color:#fff;padding:14px 40px;border-radius:8px;text-decoration:none;font-size:16px;font-weight:500;transition:all 0.3s;box-shadow:0 4px 15px rgba(220,53,69,0.3);">
            🚪 <?php _e('خروج از حساب کاربری', 'loginpro'); ?>
        </a>
        <p style="margin-top:15px;font-size:12px;color:#999;">
            <?php _e('پس از خروج، به صفحه اصلی هدایت می‌شوید.', 'loginpro'); ?>
        </p>
    </div>
    <?php
    break;
                            
                        default:
                            echo '<div class="loginpro-tab-placeholder"><p>' . sprintf(__('محتوای تب %s در حال بارگذاری است...', 'loginpro'), esc_html($tab['label'])) . '</p></div>';
                            break;
                    }
                    ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
    (function() {
        document.addEventListener('DOMContentLoaded', function() {
            var container = document.querySelector('.loginpro-user-dashboard');
            var tabHeaders = document.querySelectorAll('.loginpro-tab-header');
            var activeTab = container ? container.dataset.activeTab : null;
            
            function setActiveTabCookie(tabId) {
                document.cookie = 'loginpro_active_tab=' + tabId + '; path=/; max-age=86400';
            }
            
            if (activeTab) {
                var activeHeader = document.querySelector('.loginpro-tab-header[data-tab="' + activeTab + '"]');
                if (activeHeader) {
                    document.querySelectorAll('.loginpro-tab-content').forEach(function(c) {
                        c.style.display = 'none';
                    });
                    document.querySelectorAll('.loginpro-tab-header').forEach(function(h) {
                        h.style.background = '#f8f9fa';
                        h.style.borderRightColor = 'transparent';
                        var a = h.querySelector('.tab-arrow');
                        if (a) {
                            a.textContent = '▾';
                            a.style.transform = 'rotate(0deg)';
                        }
                    });
                    
                    var content = document.getElementById('tab-' + activeTab);
                    if (content) {
                        content.style.display = 'block';
                    }
                    activeHeader.style.background = '#fff';
                    activeHeader.style.borderRightColor = '<?php echo esc_js($primary_color); ?>';
                    var arrow = activeHeader.querySelector('.tab-arrow');
                    if (arrow) {
                        arrow.textContent = '▴';
                        arrow.style.transform = 'rotate(180deg)';
                    }
                }
            }
            
            tabHeaders.forEach(function(header) {
                header.addEventListener('click', function() {
                    var tabId = this.dataset.tab;
                    if (!tabId) return;
                    
                    var content = document.getElementById('tab-' + tabId);
                    var arrow = this.querySelector('.tab-arrow');
                    
                    setActiveTabCookie(tabId);
                    
                    if (activeTab === tabId) {
                        if (content) {
                            content.style.display = 'none';
                        }
                        this.style.background = '#f8f9fa';
                        this.style.borderRightColor = 'transparent';
                        if (arrow) {
                            arrow.textContent = '▾';
                            arrow.style.transform = 'rotate(0deg)';
                        }
                        activeTab = null;
                        return;
                    }
                    
                    var allContents = document.querySelectorAll('.loginpro-tab-content');
                    allContents.forEach(function(c) {
                        c.style.display = 'none';
                    });
                    
                    var allHeaders = document.querySelectorAll('.loginpro-tab-header');
                    allHeaders.forEach(function(h) {
                        h.style.background = '#f8f9fa';
                        h.style.borderRightColor = 'transparent';
                        var a = h.querySelector('.tab-arrow');
                        if (a) {
                            a.textContent = '▾';
                            a.style.transform = 'rotate(0deg)';
                        }
                    });
                    
                    if (content) {
                        content.style.display = 'block';
                    }
                    this.style.background = '#fff';
                    this.style.borderRightColor = '<?php echo esc_js($primary_color); ?>';
                    if (arrow) {
                        arrow.textContent = '▴';
                        arrow.style.transform = 'rotate(180deg)';
                    }
                    
                    activeTab = tabId;
                });
            });
        });
    })();
    </script>
    
    <style>
    @media (max-width: 768px) {
        .loginpro-user-dashboard { padding: 12px !important; }
        .loginpro-tab-header { padding: 14px 16px !important; border-radius: 10px !important; }
        .loginpro-tab-header span:first-child { font-size: 20px !important; }
        .loginpro-tab-header span:last-child { font-size: 15px !important; }
        .loginpro-tab-content { padding: 12px 8px 8px 8px !important; }
        .loginpro-tab-content h3 { font-size: 16px !important; }
        .loginpro-tab-content .woocommerce-account-wrapper > div[style*="display:grid"] { grid-template-columns: 1fr !important; gap: 12px !important; }
    }
    @media (max-width: 480px) {
        .loginpro-user-dashboard { padding: 8px !important; }
        .loginpro-tab-header { padding: 12px 14px !important; }
        .loginpro-user-header h2 { font-size: 17px !important; }
    }
    </style>
    
    <?php
    return ob_get_clean();
}
}

add_shortcode('loginpro_user', 'loginpro_render_user_dashboard_shortcode');
add_shortcode('loginpro_dashboard', 'loginpro_render_user_dashboard_shortcode');

// ==================================================
// ✅ توابع رندر تب‌ها (همه از دیتابیس)
// ==================================================

// 1. پیام‌ها
if (!function_exists('loginpro_render_messages_tab')) {
    function loginpro_render_messages_tab($user) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_messages';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            echo '<div class="loginpro-tab-placeholder"><p>📨 ' . __('سیستم پیام‌ها راه‌اندازی نشده است.', 'loginpro') . '</p></div>';
            return;
        }
        
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d ORDER BY date DESC LIMIT 20",
            $user->ID
        ));
        
        if (empty($messages)) {
            echo '<div class="loginpro-tab-placeholder"><p>📨 ' . __('هیچ پیامی یافت نشد.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-messages-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">📨 <?php _e('پیام‌های من', 'loginpro'); ?></h3>
            <?php foreach ($messages as $msg): ?>
            <div style="background:#f8f9fa;padding:12px 18px;border-radius:10px;margin-bottom:10px;border-right:3px solid <?php echo $msg->is_read ? '#28a745' : '#ef394e'; ?>;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <strong><?php echo esc_html($msg->subject); ?></strong>
                    <span style="font-size:12px;color:#999;"><?php echo esc_html($msg->date); ?></span>
                </div>
                <p style="margin:5px 0 0;font-size:14px;color:#666;"><?php echo esc_html($msg->message); ?></p>
                <?php if (!$msg->is_read): ?>
                <span style="display:inline-block;margin-top:5px;font-size:11px;background:#ef394e;color:#fff;padding:2px 10px;border-radius:12px;"><?php _e('جدید', 'loginpro'); ?></span>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
}

// 2. سفارش‌ها
if (!function_exists('loginpro_render_orders_tab_with_accordion')) {
    function loginpro_render_orders_tab_with_accordion() {
        if (!class_exists('WooCommerce')) {
            echo '<div class="loginpro-tab-placeholder"><p>' . __('ووکامرس فعال نیست.', 'loginpro') . '</p></div>';
            return;
        }
        
        $user_id = get_current_user_id();
        $orders = wc_get_orders([
            'customer_id' => $user_id,
            'limit' => 20,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array_keys(wc_get_order_statuses()),
        ]);
        
        if (empty($orders)) {
            echo '<div class="loginpro-tab-placeholder"><p>🛒 ' . __('هیچ سفارشی ثبت نشده است.', 'loginpro') . '</p></div>';
            return;
        }
        
        $primary_color = get_option('loginpro_primary_color', '#ef394e');
        ?>
        <div class="loginpro-orders-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">📦 <?php _e('سفارش‌های من', 'loginpro'); ?></h3>
            <?php foreach ($orders as $order): 
                $order_status = $order->get_status();
                $is_completed = ($order_status === 'completed');
            ?>
            <div style="background:#f8f9fa;padding:15px 20px;border-radius:12px;margin-bottom:10px;border-right:4px solid <?php echo $is_completed ? '#28a745' : '#ffc107'; ?>;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <div>
                        <strong>#<?php echo esc_html($order->get_order_number()); ?></strong>
                        <span style="font-size:12px;color:#999;margin:0 10px;"><?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></span>
                        <span style="display:inline-block;padding:2px 12px;border-radius:12px;font-size:11px;background:<?php echo $is_completed ? '#d4edda' : '#fff3cd'; ?>;color:<?php echo $is_completed ? '#155724' : '#856404'; ?>;">
                            <?php echo esc_html(wc_get_order_status_name($order_status)); ?>
                        </span>
                    </div>
                    <div>
                        <span style="font-weight:500;"><?php echo wp_kses_post($order->get_formatted_order_total()); ?></span>
                        <?php if ($is_completed): ?>
                        <button onclick="loginpro_print_invoice(<?php echo esc_attr($order->get_id()); ?>)" style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;border:none;padding:4px 14px;border-radius:6px;cursor:pointer;font-size:12px;margin-right:10px;">🖨️ <?php _e('پرینت', 'loginpro'); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
}

// 3. لیست‌های من (Wishlist)
if (!function_exists('loginpro_render_wishlist_tab')) {
    function loginpro_render_wishlist_tab($user) {
        $wishlist = get_user_meta($user->ID, 'wishlist', true);
        
        if (empty($wishlist) || !is_array($wishlist)) {
            echo '<div class="loginpro-tab-placeholder"><p>❤️ ' . __('هیچ محصولی در لیست علاقه‌مندی‌ها وجود ندارد.', 'loginpro') . '</p></div>';
            return;
        }
        
        if (!class_exists('WooCommerce')) {
            echo '<div class="loginpro-tab-placeholder"><p>' . __('ووکامرس فعال نیست.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-wishlist-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">❤️ <?php _e('لیست‌های من', 'loginpro'); ?></h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(150px, 1fr));gap:15px;">
                <?php foreach ($wishlist as $product_id): 
                    $product = wc_get_product($product_id);
                    if (!$product) continue;
                ?>
                <div style="background:#f8f9fa;padding:12px;border-radius:10px;text-align:center;border:1px solid #eee;">
                    <a href="<?php echo esc_url(get_permalink($product_id)); ?>" style="text-decoration:none;color:#333;">
                        <div style="font-size:13px;font-weight:500;line-height:1.4;height:40px;overflow:hidden;"><?php echo esc_html($product->get_name()); ?></div>
                        <div style="font-size:14px;color:<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;margin-top:6px;font-weight:bold;">
                            <?php echo wp_kses_post($product->get_price_html()); ?>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}

// 4. دانلودها
if (!function_exists('loginpro_render_downloads_tab')) {
    function loginpro_render_downloads_tab($user) {
        if (!class_exists('WooCommerce')) {
            echo '<div class="loginpro-tab-placeholder"><p>' . __('ووکامرس فعال نیست.', 'loginpro') . '</p></div>';
            return;
        }
        
        $downloads = wc_get_customer_available_downloads($user->ID);
        
        if (empty($downloads)) {
            echo '<div class="loginpro-tab-placeholder"><p>📥 ' . __('هیچ فایل دانلودی موجود نیست.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-downloads-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">📥 <?php _e('دانلودهای من', 'loginpro'); ?></h3>
            <table style="width:100%;border-collapse:collapse;font-size:14px;">
                <thead>
                    <tr style="background:#f8f9fa;">
                        <th style="padding:10px 15px;text-align:right;font-weight:600;"><?php _e('محصول', 'loginpro'); ?></th>
                        <th style="padding:10px 15px;text-align:right;font-weight:600;"><?php _e('تاریخ', 'loginpro'); ?></th>
                        <th style="padding:10px 15px;text-align:right;font-weight:600;"><?php _e('عملیات', 'loginpro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($downloads as $download): ?>
                    <tr style="border-bottom:1px solid #eee;">
                        <td style="padding:10px 15px;"><?php echo esc_html($download['product_name'] ?? ''); ?></td>
                        <td style="padding:10px 15px;"><?php echo esc_html($download['date'] ?? ''); ?></td>
                        <td style="padding:10px 15px;">
                            <a href="<?php echo esc_url($download['download_url'] ?? '#'); ?>" style="background:<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;color:#fff;padding:4px 14px;border-radius:6px;text-decoration:none;font-size:13px;">📥 <?php _e('دانلود', 'loginpro'); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}

// 5. اشتراک
if (!function_exists('loginpro_render_subscription_tab')) {
    function loginpro_render_subscription_tab($user) {
        if (!class_exists('WC_Subscriptions')) {
            echo '<div class="loginpro-tab-placeholder"><p>📋 ' . __('سیستم اشتراک فعال نیست.', 'loginpro') . '</p></div>';
            return;
        }
        
        $subscriptions = wcs_get_users_subscriptions($user->ID);
        
        if (empty($subscriptions)) {
            echo '<div class="loginpro-tab-placeholder"><p>📋 ' . __('هیچ اشتراک فعالی ندارید.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-subscriptions-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">📋 <?php _e('اشتراک‌های من', 'loginpro'); ?></h3>
            <?php foreach ($subscriptions as $sub): ?>
            <div style="background:#f8f9fa;padding:12px 16px;border-radius:10px;margin-bottom:10px;border-right:3px solid <?php echo $sub->get_status() == 'active' ? '#28a745' : '#dc3545'; ?>;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
                    <strong><?php echo esc_html($sub->get_product_name()); ?></strong>
                    <span style="background:<?php echo $sub->get_status() == 'active' ? '#d4edda' : '#f8d7da'; ?>;color:<?php echo $sub->get_status() == 'active' ? '#155724' : '#721c24'; ?>;padding:2px 14px;border-radius:12px;font-size:12px;">
                        <?php echo $sub->get_status() == 'active' ? '✅ ' . __('فعال', 'loginpro') : '❌ ' . __('منقضی شده', 'loginpro'); ?>
                    </span>
                </div>
                <div style="font-size:12px;color:#999;margin-top:4px;">
                    <?php _e('تاریخ شروع:', 'loginpro'); ?> <?php echo esc_html($sub->get_date_created()->date('Y-m-d')); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
}

// 6. هدیه‌ها
if (!function_exists('loginpro_render_gifts_tab')) {
    function loginpro_render_gifts_tab($user) {
        $gifts = get_user_meta($user->ID, 'user_gifts', true);
        
        if (empty($gifts) || !is_array($gifts)) {
            echo '<div class="loginpro-tab-placeholder"><p>🎁 ' . __('هیچ هدیه‌ای دریافت نکرده‌اید.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-gifts-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">🎁 <?php _e('هدیه‌های من', 'loginpro'); ?></h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(200px, 1fr));gap:15px;">
                <?php foreach ($gifts as $gift): ?>
                <div style="background:#f8f9fa;padding:15px;border-radius:10px;text-align:center;border:1px solid #eee;">
                    <div style="font-size:32px;margin-bottom:8px;">🎁</div>
                    <div style="font-weight:500;font-size:15px;"><?php echo esc_html($gift['title'] ?? 'هدیه'); ?></div>
                    <?php if (isset($gift['code'])): ?>
                    <div style="margin-top:8px;background:#fff;padding:4px 12px;border-radius:4px;border:1px dashed <?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;font-size:14px;font-weight:bold;color:<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;">
                        <?php echo esc_html($gift['code']); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}

// 7. تیکت‌های پشتیبانی - تابع اصلی رندر
if (!function_exists('loginpro_render_tickets_tab_content')) {
    function loginpro_render_tickets_tab_content($user) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        $primary_color = get_option('loginpro_primary_color', '#ef394e');
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            loginpro_create_tickets_table();
        }
        
        $message = '';
        $message_type = '';
        
        if (isset($_POST['loginpro_submit_ticket']) && isset($_POST['ticket_nonce']) && wp_verify_nonce($_POST['ticket_nonce'], 'loginpro_submit_ticket')) {
            $subject = isset($_POST['ticket_subject']) ? sanitize_text_field($_POST['ticket_subject']) : '';
            $ticket_message = isset($_POST['ticket_message']) ? sanitize_textarea_field($_POST['ticket_message']) : '';
            $priority = isset($_POST['ticket_priority']) ? sanitize_text_field($_POST['ticket_priority']) : 'normal';
            
            $attachment_url = '';
            $attachment_name = '';
            
            if (isset($_FILES['ticket_attachment']) && $_FILES['ticket_attachment']['error'] == 0) {
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'];
                $file_type = $_FILES['ticket_attachment']['type'];
                $file_size = $_FILES['ticket_attachment']['size'];
                $max_size = 5 * 1024 * 1024;
                
                if (in_array($file_type, $allowed_types) && $file_size <= $max_size) {
                    $upload_dir = wp_upload_dir();
                    $upload_path = $upload_dir['path'] . '/loginpro_tickets/';
                    
                    if (!file_exists($upload_path)) {
                        wp_mkdir_p($upload_path);
                    }
                    
                    $file_name = time() . '_' . sanitize_file_name($_FILES['ticket_attachment']['name']);
                    $file_path = $upload_path . $file_name;
                    
                    if (move_uploaded_file($_FILES['ticket_attachment']['tmp_name'], $file_path)) {
                        $attachment_url = $upload_dir['url'] . '/loginpro_tickets/' . $file_name;
                        $attachment_name = $_FILES['ticket_attachment']['name'];
                    }
                } else {
                    $message = 'فرمت فایل مجاز نیست یا حجم فایل بیش از 5 مگابایت است.';
                    $message_type = 'error';
                }
            }
            
            if (empty($subject) || empty($ticket_message)) {
                $message = 'لطفاً موضوع و متن تیکت را وارد کنید.';
                $message_type = 'error';
            } elseif (empty($message_type) || $message_type != 'error') {
                $result = $wpdb->insert(
                    $table,
                    [
                        'user_id' => $user->ID,
                        'title' => $subject,
                        'message' => $ticket_message,
                        'attachment_url' => $attachment_url,
                        'attachment_name' => $attachment_name,
                        'status' => 'open',
                        'priority' => $priority,
                        'category' => 'general',
                        'created_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql')
                    ],
                    ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
                );
                
                if ($result) {
                    $message = 'تیکت شما با موفقیت ارسال شد.';
                    $message_type = 'success';
                    
                    $admin_email = get_option('admin_email');
                    $attachment_info = !empty($attachment_url) ? "\n\nفایل پیوست: " . $attachment_name . "\nلینک: " . $attachment_url : '';
                    wp_mail(
                        $admin_email,
                        'تیکت جدید از ' . $user->display_name,
                        "موضوع: $subject\n\nپیام: $ticket_message\n\nاولویت: $priority\n\nکاربر: {$user->display_name} ({$user->user_email})" . $attachment_info
                    );
                } else {
                    $message = 'خطا در ارسال تیکت. لطفاً مجدداً تلاش کنید.';
                    $message_type = 'error';
                }
            }
        }
        
        if (isset($_POST['loginpro_reply_ticket']) && isset($_POST['reply_nonce']) && wp_verify_nonce($_POST['reply_nonce'], 'loginpro_reply_ticket')) {
            $ticket_id = isset($_POST['ticket_id']) ? intval($_POST['ticket_id']) : 0;
            $reply_message = isset($_POST['reply_message']) ? sanitize_textarea_field($_POST['reply_message']) : '';
            
            $reply_attachment_url = '';
            $reply_attachment_name = '';
            
            if (isset($_FILES['reply_attachment']) && $_FILES['reply_attachment']['error'] == 0) {
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'];
                $file_type = $_FILES['reply_attachment']['type'];
                $file_size = $_FILES['reply_attachment']['size'];
                $max_size = 5 * 1024 * 1024;
                
                if (in_array($file_type, $allowed_types) && $file_size <= $max_size) {
                    $upload_dir = wp_upload_dir();
                    $upload_path = $upload_dir['path'] . '/loginpro_tickets/';
                    
                    if (!file_exists($upload_path)) {
                        wp_mkdir_p($upload_path);
                    }
                    
                    $file_name = time() . '_reply_' . sanitize_file_name($_FILES['reply_attachment']['name']);
                    $file_path = $upload_path . $file_name;
                    
                    if (move_uploaded_file($_FILES['reply_attachment']['tmp_name'], $file_path)) {
                        $reply_attachment_url = $upload_dir['url'] . '/loginpro_tickets/' . $file_name;
                        $reply_attachment_name = $_FILES['reply_attachment']['name'];
                    }
                }
            }
            
            if ($ticket_id && !empty($reply_message)) {
                $ticket = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$table} WHERE id = %d AND user_id = %d",
                    $ticket_id, $user->ID
                ));
                
                if ($ticket && $ticket->status != 'closed') {
                    $reply_text = "\n\n---\n" . __('پاسخ کاربر:', 'loginpro') . "\n" . $reply_message . "\n" . __('تاریخ:', 'loginpro') . ' ' . current_time('mysql');
                    if (!empty($reply_attachment_url)) {
                        $reply_text .= "\n" . __('فایل پیوست:', 'loginpro') . ' ' . $reply_attachment_name . ' (' . $reply_attachment_url . ')';
                    }
                    
                    $new_message = $ticket->message . $reply_text;
                    
                    $wpdb->update(
                        $table,
                        [
                            'message' => $new_message,
                            'updated_at' => current_time('mysql')
                        ],
                        ['id' => $ticket_id],
                        ['%s', '%s'],
                        ['%d']
                    );
                    
                    $admin_email = get_option('admin_email');
                    $attachment_info = !empty($reply_attachment_url) ? "\n\nفایل پیوست: " . $reply_attachment_name . "\nلینک: " . $reply_attachment_url : '';
                    wp_mail(
                        $admin_email,
                        'پاسخ جدید به تیکت #' . $ticket_id,
                        "کاربر {$user->display_name} به تیکت #{$ticket_id} پاسخ داد.\n\nپاسخ:\n{$reply_message}" . $attachment_info
                    );
                    
                    $message = 'پاسخ شما با موفقیت ارسال شد.';
                    $message_type = 'success';
                }
            }
        }
        
        $tickets = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d ORDER BY created_at DESC LIMIT 20",
            $user->ID
        ));
        
        $view_ticket_id = isset($_GET['view_ticket']) ? intval($_GET['view_ticket']) : 0;
        $view_ticket = null;
        if ($view_ticket_id) {
            $view_ticket = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d AND user_id = %d",
                $view_ticket_id, $user->ID
            ));
        }
        
        ob_start();
        
        if ($view_ticket) {
            ?>
            <div class="loginpro-ticket-full-view">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;">
                    <h3 style="margin:0;font-size:18px;">🎫 <?php _e('مشاهده تیکت', 'loginpro'); ?> #<?php echo esc_html($view_ticket->id); ?></h3>
                    <a href="<?php echo esc_url(remove_query_arg('view_ticket')); ?>" style="background:#6c757d;color:#fff;padding:6px 18px;border-radius:6px;text-decoration:none;font-size:13px;">⬅️ <?php _e('بازگشت به لیست', 'loginpro'); ?></a>
                </div>
                
                <div style="background:#f8f9fa;padding:20px 24px;border-radius:12px;border-right:4px solid <?php echo esc_attr($primary_color); ?>;">
                    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;margin-bottom:15px;">
                        <div>
                            <span style="font-weight:600;font-size:16px;"><?php echo esc_html($view_ticket->title); ?></span>
                            <span style="display:inline-block;font-size:11px;padding:2px 14px;border-radius:20px;background:<?php echo $view_ticket->status == 'closed' ? '#6c757d' : '#28a745'; ?>;color:#fff;margin-right:10px;">
                                <?php echo $view_ticket->status == 'closed' ? __('بسته شده', 'loginpro') : __('باز', 'loginpro'); ?>
                            </span>
                            <span style="display:inline-block;font-size:10px;padding:2px 10px;border-radius:20px;background:<?php 
                                $priority_colors = ['low' => '#28a745', 'normal' => '#ffc107', 'high' => '#fd7e14', 'urgent' => '#dc3545'];
                                echo isset($priority_colors[$view_ticket->priority]) ? esc_attr($priority_colors[$view_ticket->priority]) : '#6c757d';
                            ?>;color:#fff;">
                                <?php 
                                $priority_labels = ['low' => 'کم', 'normal' => 'معمولی', 'high' => 'بالا', 'urgent' => 'فوری'];
                                echo isset($priority_labels[$view_ticket->priority]) ? esc_html($priority_labels[$view_ticket->priority]) : esc_html($view_ticket->priority);
                                ?>
                            </span>
                        </div>
                        <span style="font-size:12px;color:#999;"><?php echo esc_html($view_ticket->created_at); ?></span>
                    </div>
                    
                    <div style="background:#fff;padding:16px 20px;border-radius:8px;border:1px solid #e0e0e0;margin-bottom:15px;">
                        <div style="font-size:12px;color:#999;margin-bottom:5px;">
                            <strong><?php _e('متن تیکت:', 'loginpro'); ?></strong>
                        </div>
                        <div style="font-size:14px;color:#333;line-height:1.8;white-space:pre-wrap;"><?php echo esc_html($view_ticket->message); ?></div>
                        
                        <?php if (!empty($view_ticket->attachment_url)): ?>
                        <div style="margin-top:10px;padding-top:10px;border-top:1px solid #eee;">
                            <span style="font-size:13px;color:#666;">📎 <?php _e('فایل پیوست:', 'loginpro'); ?></span>
                            <a href="<?php echo esc_url($view_ticket->attachment_url); ?>" target="_blank" style="color:<?php echo esc_attr($primary_color); ?>;text-decoration:none;font-size:13px;margin-right:5px;">
                                <?php echo esc_html($view_ticket->attachment_name); ?>
                            </a>
                            <a href="<?php echo esc_url($view_ticket->attachment_url); ?>" download style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;padding:2px 12px;border-radius:4px;text-decoration:none;font-size:12px;">📥 <?php _e('دانلود', 'loginpro'); ?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($view_ticket->status != 'closed'): ?>
                    <div style="margin-top:15px;padding:16px 20px;background:#f0f4f8;border-radius:8px;">
                        <h4 style="margin:0 0 12px;font-size:15px;">💬 <?php _e('پاسخ به تیکت', 'loginpro'); ?></h4>
                        <form method="post" action="" enctype="multipart/form-data">
                            <?php wp_nonce_field('loginpro_reply_ticket', 'reply_nonce'); ?>
                            <input type="hidden" name="ticket_id" value="<?php echo esc_attr($view_ticket->id); ?>">
                            <textarea name="reply_message" rows="4" style="width:100%;padding:10px 14px;border:1px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;font-family:inherit;" placeholder="<?php _e('پاسخ خود را وارد کنید...', 'loginpro'); ?>"></textarea>
                            
                            <div style="margin-top:10px;">
                                <label style="display:block;margin-bottom:5px;font-size:13px;color:#666;">📎 <?php _e('پیوست فایل (اختیاری - حداکثر 5 مگابایت)', 'loginpro'); ?></label>
                                <input type="file" name="reply_attachment" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.zip" style="width:100%;padding:8px;border:1px dashed #ddd;border-radius:6px;font-size:13px;">
                                <span style="font-size:11px;color:#999;"><?php _e('فرمت‌های مجاز: JPG, PNG, GIF, PDF, DOC, DOCX, ZIP', 'loginpro'); ?></span>
                            </div>
                            
                            <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
                                <button type="submit" name="loginpro_reply_ticket" style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;border:none;padding:8px 24px;border-radius:6px;cursor:pointer;font-size:14px;">
                                    📤 <?php _e('ارسال پاسخ', 'loginpro'); ?>
                                </button>
                                <a href="<?php echo esc_url(remove_query_arg('view_ticket')); ?>" style="background:#6c757d;color:#fff;padding:8px 24px;border-radius:6px;text-decoration:none;font-size:14px;">
                                    ❌ <?php _e('بازگشت', 'loginpro'); ?>
                                </a>
                            </div>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php
        } else {
            ?>
            <div class="loginpro-tickets-wrapper">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:15px;flex-wrap:wrap;">
                    <h3 style="margin:0;font-size:17px;">🎫 <?php _e('تیکت‌های پشتیبانی', 'loginpro'); ?></h3>
                    <span style="font-size:13px;color:#999;"><?php echo count($tickets); ?> <?php _e('تیکت', 'loginpro'); ?></span>
                </div>
                
                <?php if (!empty($message)): ?>
                <div style="padding:12px 16px;border-radius:8px;margin-bottom:15px;background:<?php echo $message_type == 'success' ? '#d4edda' : '#f8d7da'; ?>;color:<?php echo $message_type == 'success' ? '#155724' : '#721c24'; ?>;border:1px solid <?php echo $message_type == 'success' ? '#c3e6cb' : '#f5c6cb'; ?>;">
                    <?php echo esc_html($message); ?>
                </div>
                <?php endif; ?>
                
                <div style="margin-bottom:15px;">
                    <button onclick="toggleTicketForm()" style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;border:none;padding:10px 24px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:500;">
                        ✉️ <?php _e('ارسال تیکت جدید', 'loginpro'); ?>
                    </button>
                </div>
                
                <div id="new-ticket-form" style="display:none;background:#f8f9fa;padding:20px 24px;border-radius:12px;margin-bottom:20px;border-right:3px solid <?php echo esc_attr($primary_color); ?>;">
                    <h4 style="margin:0 0 15px;font-size:16px;">📝 <?php _e('تیکت جدید', 'loginpro'); ?></h4>
                    
                    <form method="post" action="" enctype="multipart/form-data">
                        <?php wp_nonce_field('loginpro_submit_ticket', 'ticket_nonce'); ?>
                        
                        <div style="margin-bottom:15px;">
                            <label style="display:block;margin-bottom:5px;font-weight:500;font-size:14px;"><?php _e('موضوع', 'loginpro'); ?> <span style="color:#dc3545;">*</span></label>
                            <input type="text" name="ticket_subject" required style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
                        </div>
                        
                        <div style="margin-bottom:15px;">
                            <label style="display:block;margin-bottom:5px;font-weight:500;font-size:14px;"><?php _e('اولویت', 'loginpro'); ?></label>
                            <select name="ticket_priority" style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
                                <option value="low">🟢 <?php _e('کم', 'loginpro'); ?></option>
                                <option value="normal" selected>🟡 <?php _e('معمولی', 'loginpro'); ?></option>
                                <option value="high">🟠 <?php _e('بالا', 'loginpro'); ?></option>
                                <option value="urgent">🔴 <?php _e('فوری', 'loginpro'); ?></option>
                            </select>
                        </div>
                        
                        <div style="margin-bottom:15px;">
                            <label style="display:block;margin-bottom:5px;font-weight:500;font-size:14px;"><?php _e('متن تیکت', 'loginpro'); ?> <span style="color:#dc3545;">*</span></label>
                            <textarea name="ticket_message" required rows="5" style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;font-family:inherit;box-sizing:border-box;"></textarea>
                        </div>
                        
                        <div style="margin-bottom:15px;">
                            <label style="display:block;margin-bottom:5px;font-weight:500;font-size:14px;">📎 <?php _e('پیوست فایل (اختیاری)', 'loginpro'); ?></label>
                            <input type="file" name="ticket_attachment" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.zip" style="width:100%;padding:8px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:13px;box-sizing:border-box;">
                            <span style="font-size:11px;color:#999;"><?php _e('فرمت‌های مجاز: JPG, PNG, GIF, PDF, DOC, DOCX, ZIP - حداکثر حجم: 5 مگابایت', 'loginpro'); ?></span>
                        </div>
                        
                        <div style="display:flex;gap:10px;flex-wrap:wrap;">
                            <button type="submit" name="loginpro_submit_ticket" style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;border:none;padding:10px 28px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:500;">
                                📤 <?php _e('ارسال تیکت', 'loginpro'); ?>
                            </button>
                            <button type="button" onclick="toggleTicketForm()" style="background:#6c757d;color:#fff;border:none;padding:10px 28px;border-radius:8px;cursor:pointer;font-size:14px;">
                                ❌ <?php _e('انصراف', 'loginpro'); ?>
                            </button>
                        </div>
                    </form>
                </div>
                
                <?php if (empty($tickets)): ?>
                    <div class="loginpro-tab-placeholder" style="padding:40px 20px;text-align:center;color:#999;background:#f8f9fa;border-radius:12px;">
                        <div style="font-size:48px;margin-bottom:15px;">🎫</div>
                        <p style="margin:0;font-size:16px;color:#666;"><?php _e('هیچ تیکتی ثبت نکرده‌اید.', 'loginpro'); ?></p>
                        <p style="margin:5px 0 0;font-size:13px;color:#999;"><?php _e('برای ثبت تیکت جدید روی دکمه «ارسال تیکت جدید» کلیک کنید.', 'loginpro'); ?></p>
                    </div>
                <?php else: ?>
                    <?php foreach ($tickets as $ticket): ?>
                    <div style="background:#f8f9fa;padding:15px 20px;border-radius:12px;margin-bottom:12px;border-right:4px solid <?php echo $ticket->status == 'closed' ? '#6c757d' : esc_attr($primary_color); ?>;">
                        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:8px;">
                            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                                <span style="font-weight:600;font-size:15px;color:#333;">#<?php echo esc_html($ticket->id); ?></span>
                                <strong style="font-size:15px;"><?php echo esc_html($ticket->title); ?></strong>
                                <span style="display:inline-block;font-size:11px;padding:2px 14px;border-radius:20px;background:<?php echo $ticket->status == 'closed' ? '#6c757d' : '#28a745'; ?>;color:#fff;">
                                    <?php echo $ticket->status == 'closed' ? __('بسته شده', 'loginpro') : __('باز', 'loginpro'); ?>
                                </span>
                                <span style="display:inline-block;font-size:10px;padding:2px 10px;border-radius:20px;background:<?php 
                                    $priority_colors = ['low' => '#28a745', 'normal' => '#ffc107', 'high' => '#fd7e14', 'urgent' => '#dc3545'];
                                    echo isset($priority_colors[$ticket->priority]) ? esc_attr($priority_colors[$ticket->priority]) : '#6c757d';
                                ?>;color:#fff;">
                                    <?php 
                                    $priority_labels = ['low' => 'کم', 'normal' => 'معمولی', 'high' => 'بالا', 'urgent' => 'فوری'];
                                    echo isset($priority_labels[$ticket->priority]) ? esc_html($priority_labels[$ticket->priority]) : esc_html($ticket->priority);
                                    ?>
                                </span>
                                <?php if (!empty($ticket->attachment_url)): ?>
                                <span style="font-size:14px;">📎</span>
                                <?php endif; ?>
                            </div>
                            <span style="font-size:12px;color:#999;"><?php echo esc_html($ticket->created_at); ?></span>
                        </div>
                        
                        <div style="background:#f0f4f8;padding:12px 16px;border-radius:8px;margin-bottom:10px;">
                            <div style="font-size:12px;color:#999;margin-bottom:3px;">
                                <strong><?php _e('شما:', 'loginpro'); ?></strong>
                            </div>
                            <p style="margin:0;font-size:14px;color:#333;line-height:1.6;white-space:pre-wrap;"><?php echo esc_html(wp_trim_words($ticket->message, 30)); ?></p>
                            <?php if (str_word_count($ticket->message) > 30): ?>
                            <span style="font-size:12px;color:#999;">... </span>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (!empty($ticket->attachment_url)): ?>
                        <div style="margin-bottom:8px;font-size:12px;color:#666;">
                            📎 <?php _e('فایل پیوست:', 'loginpro'); ?>
                            <a href="<?php echo esc_url($ticket->attachment_url); ?>" target="_blank" style="color:<?php echo esc_attr($primary_color); ?>;text-decoration:none;">
                                <?php echo esc_html($ticket->attachment_name); ?>
                            </a>
                            <a href="<?php echo esc_url($ticket->attachment_url); ?>" download style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;padding:1px 10px;border-radius:4px;text-decoration:none;font-size:11px;margin-right:5px;">📥</a>
                        </div>
                        <?php endif; ?>
                        
                        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:5px;">
                            <a href="<?php echo esc_url(add_query_arg('view_ticket', $ticket->id)); ?>" style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;padding:4px 16px;border-radius:6px;text-decoration:none;font-size:12px;">
                                👁️ <?php _e('مشاهده کامل', 'loginpro'); ?>
                            </a>
                            <?php if ($ticket->status != 'closed'): ?>
                            <button onclick="toggleReplyForm(<?php echo esc_attr($ticket->id); ?>)" style="background:transparent;color:<?php echo esc_attr($primary_color); ?>;border:1px solid <?php echo esc_attr($primary_color); ?>;padding:4px 14px;border-radius:6px;cursor:pointer;font-size:12px;">
                                💬 <?php _e('پاسخ سریع', 'loginpro'); ?>
                            </button>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($ticket->status != 'closed'): ?>
                        <div id="reply-form-<?php echo esc_attr($ticket->id); ?>" style="display:none;margin-top:10px;padding:12px 16px;background:#fff;border-radius:8px;border:1px solid #eee;">
                            <form method="post" action="" enctype="multipart/form-data">
                                <?php wp_nonce_field('loginpro_reply_ticket', 'reply_nonce'); ?>
                                <input type="hidden" name="ticket_id" value="<?php echo esc_attr($ticket->id); ?>">
                                <textarea name="reply_message" rows="3" style="width:100%;padding:8px 12px;border:1px solid #ddd;border-radius:6px;font-size:13px;box-sizing:border-box;font-family:inherit;" placeholder="<?php _e('پاسخ خود را وارد کنید...', 'loginpro'); ?>"></textarea>
                                
                                <div style="margin-top:8px;">
                                    <label style="display:block;margin-bottom:3px;font-size:12px;color:#666;">📎 <?php _e('پیوست فایل (اختیاری)', 'loginpro'); ?></label>
                                    <input type="file" name="reply_attachment" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.zip" style="width:100%;padding:6px;border:1px dashed #ddd;border-radius:6px;font-size:12px;">
                                </div>
                                
                                <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;">
                                    <button type="submit" name="loginpro_reply_ticket" style="background:<?php echo esc_attr($primary_color); ?>;color:#fff;border:none;padding:6px 18px;border-radius:6px;cursor:pointer;font-size:13px;">
                                        📤 <?php _e('ارسال پاسخ', 'loginpro'); ?>
                                    </button>
                                    <button type="button" onclick="toggleReplyForm(<?php echo esc_attr($ticket->id); ?>)" style="background:#6c757d;color:#fff;border:none;padding:6px 18px;border-radius:6px;cursor:pointer;font-size:13px;">
                                        ❌ <?php _e('بستن', 'loginpro'); ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <?php
        }
        ?>
        
        <script>
        function toggleTicketForm() {
            var form = document.getElementById('new-ticket-form');
            if (form.style.display === 'none' || form.style.display === '') {
                form.style.display = 'block';
                form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                form.style.display = 'none';
            }
        }
        
        function toggleReplyForm(ticketId) {
            var form = document.getElementById('reply-form-' + ticketId);
            if (form.style.display === 'none' || form.style.display === '') {
                form.style.display = 'block';
            } else {
                form.style.display = 'none';
            }
        }
        
        <?php if (!empty($message) && $message_type == 'error'): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('new-ticket-form').style.display = 'block';
        });
        <?php endif; ?>
        </script>
        <?php
        return ob_get_clean();
    }
}

// 8. دیدگاه و پرسش‌ها
if (!function_exists('loginpro_render_reviews_tab')) {
    function loginpro_render_reviews_tab($user) {
        global $wpdb;
        
        $reviews = $wpdb->get_results($wpdb->prepare(
            "SELECT c.comment_ID, c.comment_content, c.comment_date, p.post_title 
             FROM {$wpdb->comments} c
             LEFT JOIN {$wpdb->posts} p ON c.comment_post_ID = p.ID
             WHERE c.user_id = %d AND c.comment_approved = 1
             ORDER BY c.comment_date DESC LIMIT 20",
            $user->ID
        ));
        
        if (empty($reviews)) {
            echo '<div class="loginpro-tab-placeholder"><p>💬 ' . __('هنوز دیدگاهی ثبت نکرده‌اید.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-reviews-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">💬 <?php _e('دیدگاه‌های من', 'loginpro'); ?></h3>
            <?php foreach ($reviews as $review): ?>
            <div style="background:#f8f9fa;padding:12px 18px;border-radius:10px;margin-bottom:10px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <strong><?php echo esc_html($review->post_title); ?></strong>
                    <span style="font-size:12px;color:#999;"><?php echo esc_html($review->comment_date); ?></span>
                </div>
                <p style="margin:5px 0 0;font-size:14px;color:#666;"><?php echo esc_html(wp_trim_words($review->comment_content, 20)); ?></p>
                <a href="<?php echo esc_url(get_permalink($review->comment_ID)); ?>" style="display:inline-block;margin-top:5px;color:<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;text-decoration:none;font-size:13px;"><?php _e('مشاهده', 'loginpro'); ?></a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
}

// 9. بازدیدهای اخیر
if (!function_exists('loginpro_render_recent_views_tab')) {
    function loginpro_render_recent_views_tab($user) {
        global $wpdb;
        
        $views = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_date 
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE pm.meta_key = '_last_viewed_by' 
             AND pm.meta_value LIKE %s
             AND p.post_status = 'publish'
             ORDER BY p.post_date DESC LIMIT 20",
            '%' . $wpdb->esc_like($user->ID) . '%'
        ));
        
        if (empty($views)) {
            echo '<div class="loginpro-tab-placeholder"><p>👁️ ' . __('هنوز محصولی را مشاهده نکرده‌اید.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-recent-views-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">👁️ <?php _e('بازدیدهای اخیر', 'loginpro'); ?></h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(150px, 1fr));gap:15px;">
                <?php foreach ($views as $view): ?>
                <div style="background:#f8f9fa;padding:12px;border-radius:10px;text-align:center;border:1px solid #eee;">
                    <a href="<?php echo esc_url(get_permalink($view->ID)); ?>" style="text-decoration:none;color:#333;">
                        <div style="font-size:13px;font-weight:500;line-height:1.4;"><?php echo esc_html($view->post_title); ?></div>
                        <div style="font-size:11px;color:#999;margin-top:4px;"><?php echo esc_html($view->post_date); ?></div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}

// 10. امنیت
if (!function_exists('loginpro_render_security_tab')) {
    function loginpro_render_security_tab($user) {
        $last_login = get_user_meta($user->ID, 'last_login', true);
        $login_count = get_user_meta($user->ID, 'login_count', true);
        $two_factor_enabled = get_user_meta($user->ID, 'two_factor_enabled', true);
        ?>
        <div class="loginpro-security-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">🔒 <?php _e('تنظیمات امنیتی', 'loginpro'); ?></h3>
            
            <div style="background:#f8f9fa;padding:15px 20px;border-radius:12px;margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <span><?php _e('آخرین ورود:', 'loginpro'); ?></span>
                    <span style="font-weight:500;"><?php echo $last_login ? esc_html($last_login) : __('نامشخص', 'loginpro'); ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-top:6px;">
                    <span><?php _e('تعداد ورود:', 'loginpro'); ?></span>
                    <span style="font-weight:500;"><?php echo $login_count ? esc_html($login_count) : '0'; ?></span>
                </div>
            </div>
            
            <div style="background:#f8f9fa;padding:15px 20px;border-radius:12px;margin-bottom:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <span><?php _e('ورود دو مرحله‌ای:', 'loginpro'); ?></span>
                    <span style="display:inline-block;padding:2px 12px;border-radius:12px;font-size:12px;background:<?php echo $two_factor_enabled ? '#d4edda' : '#f8d7da'; ?>;color:<?php echo $two_factor_enabled ? '#155724' : '#721c24'; ?>;">
                        <?php echo $two_factor_enabled ? __('✅ فعال', 'loginpro') : __('❌ غیرفعال', 'loginpro'); ?>
                    </span>
                </div>
                <?php if (!$two_factor_enabled): ?>
                <a href="#" style="display:inline-block;margin-top:10px;color:<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;text-decoration:none;font-size:14px;"><?php _e('🔑 فعال‌سازی ورود دو مرحله‌ای', 'loginpro'); ?></a>
                <?php endif; ?>
            </div>
            
            <div style="background:#f8f9fa;padding:15px 20px;border-radius:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <span><?php _e('تغییر رمز عبور:', 'loginpro'); ?></span>
                    <a href="<?php echo esc_url(wp_lostpassword_url()); ?>" style="background:<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;color:#fff;padding:6px 18px;border-radius:6px;text-decoration:none;font-size:14px;">🔑 <?php _e('تغییر رمز', 'loginpro'); ?></a>
                </div>
            </div>
        </div>
        <?php
    }
}

// 11. نشست‌ها
if (!function_exists('loginpro_render_sessions_tab')) {
    function loginpro_render_sessions_tab($user) {
        $sessions = WP_Session_Tokens::get_instance($user->ID);
        $session_data = $sessions->get_all();
        
        if (empty($session_data)) {
            echo '<div class="loginpro-tab-placeholder"><p>🌐 ' . __('هیچ نشست فعالی وجود ندارد.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-sessions-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">🌐 <?php _e('نشست‌های فعال', 'loginpro'); ?></h3>
            <?php foreach ($session_data as $session): ?>
            <div style="background:#f8f9fa;padding:12px 18px;border-radius:10px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                <div>
                    <span style="font-weight:500;"><?php echo esc_html($session['ip'] ?? __('نامشخص', 'loginpro')); ?></span>
                    <span style="font-size:12px;color:#999;margin-right:10px;"><?php echo esc_html($session['ua'] ?? ''); ?></span>
                </div>
                <div>
                    <span style="font-size:12px;color:#999;">
                        <?php echo sprintf(__('آخرین فعالیت: %s', 'loginpro'), date_i18n('Y-m-d H:i:s', $session['login'])); ?>
                    </span>
                </div>
            </div>
            <?php endforeach; ?>
            <div style="margin-top:15px;">
                <a href="#" onclick="if(confirm('<?php _e('آیا از خروج از تمام دستگاه‌ها مطمئن هستید؟', 'loginpro'); ?>')){ document.getElementById('logout-all-sessions-form').submit(); }" style="background:#dc3545;color:#fff;padding:6px 18px;border-radius:6px;text-decoration:none;font-size:14px;">🚪 <?php _e('خروج از تمام دستگاه‌ها', 'loginpro'); ?></a>
                <form id="logout-all-sessions-form" method="post" action="" style="display:none;">
                    <?php wp_nonce_field('logout_all_sessions'); ?>
                    <input type="hidden" name="action" value="logout_all_sessions">
                </form>
            </div>
        </div>
        <?php
    }
}

// 12. تاریخچه
if (!function_exists('loginpro_render_history_tab')) {
    function loginpro_render_history_tab($user) {
        $history = get_user_meta($user->ID, 'user_activity_history', true);
        
        if (empty($history) || !is_array($history)) {
            echo '<div class="loginpro-tab-placeholder"><p>📜 ' . __('هیچ فعالیتی ثبت نشده است.', 'loginpro') . '</p></div>';
            return;
        }
        ?>
        <div class="loginpro-history-wrapper">
            <h3 style="margin:0 0 15px;font-size:17px;">📜 <?php _e('تاریخچه فعالیت‌ها', 'loginpro'); ?></h3>
            <div style="max-height:400px;overflow-y:auto;">
                <?php foreach ($history as $item): ?>
                <div style="background:#f8f9fa;padding:10px 16px;border-radius:8px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;border-right:2px solid <?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;">
                    <span style="font-size:14px;"><?php echo esc_html($item['action'] ?? ''); ?></span>
                    <span style="font-size:12px;color:#999;"><?php echo esc_html($item['time'] ?? ''); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}

// ==================================================
// ✅ تابع کمکی برای دریافت آدرس پروفایل (با کش)
// ==================================================
if (!function_exists('loginpro_get_profile_url')) {
    function loginpro_get_profile_url() {
        static $cached_url = null;
        
        if ($cached_url !== null) {
            return $cached_url;
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            $cached_url = home_url();
            return $cached_url;
        }
        
        $profile_page_id = get_option('loginpro_profile_page_id', 0);
        if ($profile_page_id) {
            $cached_url = get_permalink($profile_page_id);
        } else {
            $cached_url = home_url();
        }
        
        return $cached_url;
    }
}

// ==================================================
// ✅ پردازش خروج از تمام دستگاه‌ها
// ==================================================
add_action('init', function() {
    if (isset($_POST['action']) && $_POST['action'] === 'logout_all_sessions' && isset($_POST['_wpnonce'])) {
        if (wp_verify_nonce($_POST['_wpnonce'], 'logout_all_sessions')) {
            $user_id = get_current_user_id();
            if ($user_id) {
                $sessions = WP_Session_Tokens::get_instance($user_id);
                $sessions->destroy_all();
                wp_redirect(add_query_arg('logged_out_all', '1', wp_get_referer()));
                exit;
            }
        }
    }
});

// ==================================================
// ✅ دکمه پرینت فاکتور (Ajax) — با استایل اختصاصی
// ==================================================
add_action('wp_ajax_loginpro_print_invoice', function() {
    if (!wp_verify_nonce($_POST['nonce'], 'loginpro_print_invoice')) {
        wp_die('Invalid nonce');
    }
    
    $order_id = intval($_POST['order_id']);
    $user_id = get_current_user_id();
    
    if (!$order_id || !$user_id) {
        wp_die('Invalid request');
    }
    
    $order = wc_get_order($order_id);
    if (!$order || $order->get_customer_id() != $user_id) {
        wp_die('Access denied');
    }

    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>فاکتور خرید</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Tahoma', 'Segoe UI', sans-serif;
                background: #f2f2f2;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                padding: 20px;
            }
            .invoice {
                max-width: 900px;
                width: 100%;
                background: #fff;
                border-radius: 16px;
                box-shadow: 0 8px 30px rgba(0,0,0,0.12);
                padding: 30px 35px 40px;
            }
            .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 2px dashed #ddd;
                padding-bottom: 18px;
                margin-bottom: 20px;
                flex-wrap: wrap;
                gap: 12px;
            }
            .header-left, .header-center, .header-right {
                flex: 1 1 0;
                min-width: 130px;
            }
            .header-left { text-align: right; }
            .header-center { text-align: center; }
            .header-right { text-align: left; }
            .header-label {
                font-size: 13px;
                color: #6b7280;
                font-weight: 600;
                display: block;
                margin-bottom: 3px;
            }
            .header-value {
                font-size: 17px;
                font-weight: 700;
                color: #1f2937;
                background: #f9fafb;
                padding: 4px 12px;
                border-radius: 30px;
                display: inline-block;
            }
            .brand-name {
                font-size: 26px;
                font-weight: 800;
                color: #0a4b7a;
                background: #eef6ff;
                padding: 4px 24px;
                border-radius: 40px;
                display: inline-block;
                box-shadow: 0 2px 6px rgba(0,80,150,0.08);
            }
            .parties {
                display: flex;
                flex-wrap: wrap;
                gap: 20px 40px;
                background: #f8fafc;
                border-radius: 14px;
                padding: 18px 25px;
                margin-bottom: 28px;
                border: 1px solid #e5e9f0;
            }
            .seller, .buyer {
                flex: 1 1 200px;
            }
            .parties h4 {
                font-size: 15px;
                color: #374151;
                border-bottom: 2px solid #d1d9e6;
                padding-bottom: 5px;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 6px;
            }
            .parties p {
                margin: 4px 0;
                font-size: 14px;
                color: #1e293b;
                line-height: 1.6;
            }
            .parties .label {
                font-weight: 600;
                color: #4b5563;
                display: inline-block;
                width: 70px;
            }
            .table-wrap {
                overflow-x: auto;
                margin: 20px 0 18px;
                border-radius: 14px;
                border: 1px solid #e2e8f0;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                font-size: 14px;
                min-width: 480px;
            }
            th {
                background: #f1f5f9;
                color: #1e293b;
                font-weight: 700;
                padding: 14px 12px;
                text-align: center;
                border-bottom: 2px solid #cbd5e1;
            }
            td {
                padding: 14px 12px;
                text-align: center;
                border-bottom: 1px solid #e9edf4;
                color: #1e293b;
            }
            tr:last-child td { border-bottom: none; }
            .text-right { text-align: right; }
            .text-left { text-align: left; }
            .total-row {
                background: #f9fcff;
                font-weight: 700;
                border-top: 2px solid #b0c4de;
            }
            .total-row td { padding: 16px 12px; }
            .print-btn-wrap {
                text-align: center;
                margin-top: 25px;
            }
            .print-btn {
                background: <?php echo esc_attr(get_option('loginpro_primary_color', '#0a4b7a')); ?>;
                color: #fff;
                border: none;
                padding: 10px 30px;
                border-radius: 8px;
                cursor: pointer;
                font-size: 16px;
                transition: 0.2s;
            }
            .print-btn:hover { opacity: 0.85; }
            @media (max-width: 650px) {
                .header {
                    flex-direction: column;
                    align-items: stretch;
                    gap: 8px;
                }
                .header-left, .header-center, .header-right {
                    text-align: center;
                    width: 100%;
                }
                .parties {
                    flex-direction: column;
                    gap: 12px;
                }
            }
        </style>
    </head>
    <body>
        <div class="invoice">
            <div class="header">
                <div class="header-left">
                    <span class="header-label">📅 تاریخ سفارش</span>
                    <span class="header-value"><?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></span>
                </div>
                <div class="header-center">
                    <span class="brand-name"><?php echo esc_html(get_bloginfo('name')); ?></span>
                </div>
                <div class="header-right">
                    <span class="header-label">🔖 شماره فاکتور</span>
                    <span class="header-value">#<?php echo esc_html($order->get_order_number()); ?></span>
                </div>
            </div>

            <div class="parties">
                <div class="seller">
                    <h4>🏢 فروشنده</h4>
                    <p><span class="label">نام:</span> <?php echo esc_html(get_bloginfo('name')); ?></p>
                    <p><span class="label">تلفن:</span> <?php echo esc_html(get_option('loginpro_seller_phone', 'نامشخص')); ?></p>
                    <p><span class="label">آدرس:</span> <?php echo esc_html(get_option('loginpro_seller_address', 'نامشخص')); ?></p>
                </div>
                <div class="buyer">
                    <h4>🧑‍💼 خریدار</h4>
                    <p><span class="label">نام:</span> <?php echo esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()); ?></p>
                    <p><span class="label">تلفن:</span> <?php echo esc_html($order->get_billing_phone()); ?></p>
                    <p><span class="label">آدرس:</span> <?php echo esc_html($order->get_billing_address_1() . ' - ' . $order->get_billing_city()); ?></p>
                </div>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-right">نام کالا</th>
                            <th>تعداد</th>
                            <th>قیمت واحد (ریال)</th>
                            <th>جمع (ریال)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($order->get_items() as $item): ?>
                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td class="text-right"><?php echo esc_html($item->get_name()); ?></td>
                            <td><?php echo esc_html($item->get_quantity()); ?></td>
                            <td><?php echo wp_kses_post(wc_price($order->get_item_subtotal($item, false, true))); ?></td>
                            <td><?php echo wp_kses_post(wc_price($item->get_total())); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr class="total-row">
                            <td colspan="4" style="text-align: left; font-size: 16px;">💰 جمع کل سفارش</td>
                            <td style="font-size: 18px; color: #0b3b5c;"><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="print-btn-wrap">
                <button class="print-btn" onclick="window.print();">🖨️ چاپ فاکتور</button>
            </div>
        </div>
    </body>
    </html>
    <?php
    wp_die();
});

// ==================================================
// ✅ جاوااسکریپت برای دکمه پرینت - بهینه‌شده
// ==================================================
add_action('wp_footer', 'loginpro_print_invoice_js', 999);

function loginpro_print_invoice_js() {
    if (!is_user_logged_in()) {
        return;
    }
    ?>
    <script type="text/javascript">
    (function($) {
        'use strict';
        
        // ✅ فقط یک بار تعریف شود
        if (window._loginpro_print_defined) return;
        window._loginpro_print_defined = true;
        
        window.loginpro_print_invoice = function(orderId) {
            if (!orderId) {
                alert('شناسه سفارش نامعتبر است.');
                return;
            }
            
            var loading = '<div style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.7);z-index:999999;display:flex;align-items:center;justify-content:center;flex-direction:column;color:#fff;">' +
                          '<div style="font-size:48px;margin-bottom:20px;">⏳</div>' +
                          '<div style="font-size:18px;">در حال آماده‌سازی فاکتور...</div>' +
                          '</div>';
            document.body.insertAdjacentHTML('beforeend', loading);
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            xhr.onload = function() {
                var loadingDiv = document.querySelector('div[style*="position:fixed"]');
                if (loadingDiv) {
                    loadingDiv.remove();
                }
                
                if (xhr.status === 200) {
                    var win = window.open('', '_blank', 'width=800,height=600,scrollbars=yes');
                    if (win) {
                        win.document.write(xhr.responseText);
                        win.document.close();
                    } else {
                        alert('لطفاً باز شدن پنجره جدید را در مرورگر خود فعال کنید.');
                    }
                } else {
                    alert('خطا در دریافت فاکتور. کد خطا: ' + xhr.status);
                }
            };
            
            xhr.onerror = function() {
                var loadingDiv = document.querySelector('div[style*="position:fixed"]');
                if (loadingDiv) {
                    loadingDiv.remove();
                }
                alert('خطا در ارتباط با سرور. لطفاً مجدداً تلاش کنید.');
            };
            
            var data = 'action=loginpro_print_invoice&order_id=' + orderId + 
                       '&nonce=<?php echo wp_create_nonce('loginpro_print_invoice'); ?>';
            xhr.send(data);
        };
        
        if (typeof jQuery !== 'undefined') {
            $(document).ready(function() {
                console.log('LoginPro: Print function ready');
            });
        }
        
    })(jQuery);
    </script>
    <?php
}