<?php
/**
 * Unit tests for LoginShortcode
 * 
 * @package LoginPro
 * @since 3.0.0
 */

// ✅ FIXED: استفاده از WP_UnitTestCase به جای TestCase
class LoginShortcodeTest extends WP_UnitTestCase {
    
    /**
     * @var LoginShortcode
     */
    private $login_shortcode;
    
    /**
     * Set up before each test
     */
    public function setUp(): void {
        parent::setUp();
        
        // ✅ FIXED: بارگذاری کلاس LoginShortcode
        if (!class_exists('LoginPro\Frontend\Shortcodes\LoginShortcode')) {
            require_once LOGINPRO_PLUGIN_DIR . 'frontend/Shortcodes/LoginShortcode.php';
        }
        
        $this->login_shortcode = new LoginPro\Frontend\Shortcodes\LoginShortcode();
    }
    
    /**
     * Test mobile number normalization
     * 
     * @dataProvider mobileProvider
     */
    public function test_normalize_mobile($input, $expected) {
        $result = $this->login_shortcode->normalizeMobile($input);
        $this->assertEquals($expected, $result);
    }
    
    /**
     * Test plausible mobile validation
     * 
     * @dataProvider plausibleMobileProvider
     */
    public function test_is_plausible_mobile($mobile, $expected) {
        $result = $this->login_shortcode->is_plausible_mobile($mobile);
        $this->assertEquals($expected, $result);
    }
    
    /**
     * Test email domain validation
     * 
     * @dataProvider emailProvider
     */
    public function test_is_valid_email_domain($email, $expected) {
        $result = $this->login_shortcode->is_valid_email_domain($email);
        $this->assertEquals($expected, $result);
    }
    
    /**
     * Data provider for mobile normalization tests
     */
    public function mobileProvider() {
        return [
            'persian digits' => ['۰۹۱۲۳۴۵۶۷۸۹', '09123456789'],
            'with dashes' => ['0912-345-6789', '09123456789'],
            'without zero' => ['9123456789', '09123456789'],
            'with spaces' => ['0912 345 6789', '09123456789'],
            'with parentheses' => ['(0912)3456789', '09123456789'],
            'english digits' => ['09123456789', '09123456789'],
            'mixed digits' => ['۰912۳45۶7۸9', '09123456789'],
        ];
    }
    
    /**
     * Data provider for plausible mobile tests
     */
    public function plausibleMobileProvider() {
        return [
            'valid mobile' => ['09123456789', true],
            'invalid format' => ['1234567890', false],
            'short number' => ['0912345678', false],
            'long number' => ['091234567890', false],
            'all same digits' => ['09111111111', false],
            'sequential up' => ['09123456789', false],
            'sequential down' => ['09876543219', false],
            'valid with different digits' => ['09124356789', true],
        ];
    }
    
    /**
     * Data provider for email validation tests
     */
    public function emailProvider() {
        return [
            'valid gmail' => ['test@gmail.com', true],
            'valid yahoo' => ['test@yahoo.com', true],
            'valid outlook' => ['test@outlook.com', true],
            'invalid domain' => ['test@invalid', false],
            'empty domain' => ['test@', false],
            'without at' => ['testgmail.com', false],
        ];
    }
    
    // ==================================================
    // ✅ FIXED: تست‌های جدید برای کامل‌تر شدن
    // ==================================================
    
    /**
     * Test OTP generation
     */
    public function test_generate_otp() {
        $otp = $this->login_shortcode->generateOtp(6);
        $this->assertEquals(6, strlen($otp));
        $this->assertTrue(is_numeric($otp));
    }
    
    /**
     * Test mobile number formatting
     */
    public function test_mobile_formatting() {
        $result = $this->login_shortcode->normalizeMobile('0912-345-6789');
        $this->assertEquals('09123456789', $result);
        
        $result = $this->login_shortcode->normalizeMobile('۰۹۱۲۳۴۵۶۷۸۹');
        $this->assertEquals('09123456789', $result);
    }
}