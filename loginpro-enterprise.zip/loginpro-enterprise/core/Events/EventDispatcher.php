<?php
namespace LoginPro\Core\Events;

use LoginPro\Core\Contracts\EventDispatcherInterface;

class EventDispatcher implements EventDispatcherInterface {
    private $listeners = [];
    private $sorted = [];
    
    public function dispatch($eventName, array $payload = []) {
        $listeners = $this->getListeners($eventName);
        
        foreach ($listeners as $listener) {
            if (is_callable($listener)) {
                call_user_func($listener, $eventName, $payload);
            } elseif (is_array($listener) && method_exists($listener[0], $listener[1])) {
                call_user_func([$listener[0], $listener[1]], $eventName, $payload);
            }
        }
        
        do_action($eventName, $payload);
    }
    
    public function subscribe($eventName, $listener, $priority = 10) {
        if (!isset($this->listeners[$eventName])) {
            $this->listeners[$eventName] = [];
        }
        
        $this->listeners[$eventName][$priority][] = $listener;
        $this->sorted[$eventName] = null;
    }
    
    public function unsubscribe($eventName, $listener) {
        if (!isset($this->listeners[$eventName])) {
            return;
        }
        
        foreach ($this->listeners[$eventName] as $priority => $listeners) {
            $key = array_search($listener, $listeners, true);
            if ($key !== false) {
                unset($this->listeners[$eventName][$priority][$key]);
            }
        }
        
        $this->sorted[$eventName] = null;
    }
    
    public function getListeners($eventName) {
        if (!isset($this->sorted[$eventName])) {
            $this->sortListeners($eventName);
        }
        
        return $this->sorted[$eventName] ?? [];
    }
    
    private function sortListeners($eventName) {
        if (!isset($this->listeners[$eventName])) {
            $this->sorted[$eventName] = [];
            return;
        }
        
        krsort($this->listeners[$eventName]);
        $this->sorted[$eventName] = array_merge(...$this->listeners[$eventName]);
    }
    
    public function hasListeners($eventName) {
        return !empty($this->getListeners($eventName));
    }
}
