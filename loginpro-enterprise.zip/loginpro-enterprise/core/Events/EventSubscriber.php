<?php
namespace LoginPro\Core\Events;

abstract class EventSubscriber {
    abstract public static function getSubscribedEvents();
    
    public function subscribe(EventDispatcher $dispatcher) {
        $events = static::getSubscribedEvents();
        
        foreach ($events as $eventName => $params) {
            if (is_string($params)) {
                $dispatcher->subscribe($eventName, [$this, $params]);
            } elseif (is_array($params)) {
                if (isset($params[0])) {
                    $dispatcher->subscribe($eventName, [$this, $params[0]], $params[1] ?? 10);
                } else {
                    foreach ($params as $listener) {
                        $dispatcher->subscribe($eventName, [$this, $listener]);
                    }
                }
            }
        }
    }
}
