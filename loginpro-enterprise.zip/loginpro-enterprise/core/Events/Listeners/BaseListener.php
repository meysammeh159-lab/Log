<?php
namespace LoginPro\Core\Events\Listeners;

abstract class BaseListener {
    protected $logger;
    
    public function __construct() {
        $this->logger = \LoginPro\Bootstrap\Container::getInstance()->make('logger');
    }
    
    abstract public function handle($eventName, array $payload = []);
    
    protected function log($message, $level = 'info') {
        $this->logger->log($level, $message);
    }
}
