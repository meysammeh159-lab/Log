<?php
namespace LoginPro\Core\Session;

class SessionManager {
    private $handler;
    
    public function __construct() {
        $driver = get_option('loginpro_session_driver', 'database');
        $this->handler = $this->createHandler($driver);
        session_set_save_handler($this->handler, true);
    }
    
    private function createHandler($driver) {
        switch ($driver) {
            case 'database':
                return new Handlers\DatabaseSessionHandler();
            case 'file':
                return new Handlers\FileSessionHandler();
            case 'redis':
                return new Handlers\RedisSessionHandler();
            default:
                return new Handlers\DatabaseSessionHandler();
        }
    }
    
    public function start() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    public function set($key, $value) {
        $_SESSION[$key] = $value;
    }
    
    public function get($key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }
    
    public function has($key) {
        return isset($_SESSION[$key]);
    }
    
    public function remove($key) {
        unset($_SESSION[$key]);
    }
    
    public function all() {
        return $_SESSION;
    }
    
    public function destroy() {
        session_destroy();
        $_SESSION = [];
    }
    
    public function regenerate($deleteOldSession = true) {
        session_regenerate_id($deleteOldSession);
    }
}
