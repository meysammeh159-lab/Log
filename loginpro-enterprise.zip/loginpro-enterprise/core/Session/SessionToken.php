<?php
namespace LoginPro\Core\Session;

class SessionToken {
    public static function generate() {
        return bin2hex(random_bytes(32));
    }
    
    public static function verify($token, $userId) {
        $stored = get_user_meta($userId, 'loginpro_session_token', true);
        return hash_equals($stored, $token);
    }
    
    public static function rotate($userId) {
        $newToken = self::generate();
        update_user_meta($userId, 'loginpro_session_token', $newToken);
        return $newToken;
    }
    
    public static function invalidate($userId) {
        delete_user_meta($userId, 'loginpro_session_token');
    }
}
