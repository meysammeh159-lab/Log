<?php
namespace LoginPro\Core\Session\Handlers;

use SessionHandlerInterface;

class FileSessionHandler implements SessionHandlerInterface {
    private $savePath;
    
    public function open($savePath, $sessionName): bool {
        $this->savePath = LOGINPRO_PLUGIN_DIR . 'storage/framework/sessions';
        if (!is_dir($this->savePath)) {
            mkdir($this->savePath, 0755, true);
        }
        return true;
    }
    
    public function close(): bool {
        return true;
    }
    
    public function read($id): string {
        $file = $this->savePath . '/sess_' . $id;
        if (file_exists($file)) {
            return file_get_contents($file);
        }
        return '';
    }
    
    public function write($id, $data): bool {
        $file = $this->savePath . '/sess_' . $id;
        return file_put_contents($file, $data) !== false;
    }
    
    public function destroy($id): bool {
        $file = $this->savePath . '/sess_' . $id;
        if (file_exists($file)) {
            return unlink($file);
        }
        return true;
    }
    
    public function gc($max_lifetime): int|false {
        $files = glob($this->savePath . '/sess_*');
        $now = time();
        foreach ($files as $file) {
            if (is_file($file) && ($now - filemtime($file)) > $max_lifetime) {
                unlink($file);
            }
        }
        return 0;
    }
}
