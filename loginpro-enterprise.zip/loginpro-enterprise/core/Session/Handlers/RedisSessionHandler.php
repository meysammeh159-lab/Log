<?php
namespace LoginPro\Core\Session\Handlers;

use SessionHandlerInterface;

class RedisSessionHandler implements SessionHandlerInterface {
    private $redis;
    private $prefix = 'loginpro_session:';
    
    public function __construct() {
        if (!class_exists('Redis')) {
            throw new \Exception('Redis extension not loaded');
        }
        $this->redis = new \Redis();
        $this->redis->connect('127.0.0.1', 6379);
    }
    
    public function open($savePath, $sessionName): bool {
        return true;
    }
    
    public function close(): bool {
        return true;
    }
    
    public function read($id): string {
        $data = $this->redis->get($this->prefix . $id);
        return $data ?: '';
    }
    
    public function write($id, $data): bool {
        $ttl = (int)ini_get('session.gc_maxlifetime');
        return $this->redis->setex($this->prefix . $id, $ttl, $data);
    }
    
    public function destroy($id): bool {
        return $this->redis->del($this->prefix . $id) > 0;
    }
    
    public function gc($max_lifetime): int|false {
        return 0;
    }
}
