<?php
namespace LoginPro\Core\Session\Handlers;

use SessionHandlerInterface;
use LoginPro\Core\Database\Connection;

class DatabaseSessionHandler implements SessionHandlerInterface {
    private $connection;
    private $table;
    
    public function __construct() {
        $this->connection = Connection::getInstance();
        $this->table = $this->connection->table('sessions');
    }
    
    public function open($savePath, $sessionName): bool {
        return true;
    }
    
    public function close(): bool {
        return true;
    }
    
    public function read($id): string {
        $sql = $this->connection->prepare(
            "SELECT payload FROM {$this->table} WHERE id = %s",
            [$id]
        );
        $result = $this->connection->getResults($sql);
        return $result ? $result[0]['payload'] ?? '' : '';
    }
    
    public function write($id, $data): bool {
        $userId = get_current_user_id();
        $sql = $this->connection->prepare(
            "REPLACE INTO {$this->table} (id, user_id, payload, last_activity) VALUES (%s, %d, %s, %d)",
            [$id, $userId, $data, time()]
        );
        return $this->connection->query($sql) !== false;
    }
    
    public function destroy($id): bool {
        $sql = $this->connection->prepare(
            "DELETE FROM {$this->table} WHERE id = %s",
            [$id]
        );
        return $this->connection->query($sql) !== false;
    }
    
    public function gc($max_lifetime): int|false {
        $sql = $this->connection->prepare(
            "DELETE FROM {$this->table} WHERE last_activity < %d",
            [time() - $max_lifetime]
        );
        return $this->connection->query($sql);
    }
}
