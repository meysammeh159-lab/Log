<?php
namespace LoginPro\Core\Contracts;

interface EventDispatcherInterface {
    public function dispatch($eventName, array $payload = []);
    public function subscribe($eventName, $listener, $priority = 10);
    public function unsubscribe($eventName, $listener);
}
