<?php
namespace LoginPro\Core\Contracts;

interface QueueInterface {
    public function push($job, $data = [], $queue = null);
    public function pushRaw($payload, $queue = null);
    public function later($delay, $job, $data = [], $queue = null);
    public function pop($queue = null);
    public function delete($job);
    public function release($job, $delay = 0);
}
