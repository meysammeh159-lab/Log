<?php
/**
 * Cache Interface
 * قراردادهای مربوط به کش
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Core\Contracts;

defined('ABSPATH') || exit;

/**
 * رابط کش
 * تمام درایورهای کش باید این رابط را پیاده‌سازی کنند
 */
interface CacheInterface {
    
    /**
     * دریافت مقدار از کش
     * 
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض در صورت عدم وجود
     * @return mixed
     */
    public function get($key, $default = null);
    
    /**
     * ذخیره مقدار در کش
     * 
     * @param string $key کلید
     * @param mixed $value مقدار
     * @param int $ttl زمان انقضا به ثانیه (پیش‌فرض: 0 = نامحدود)
     * @return bool
     */
    public function set($key, $value, $ttl = 0);
    
    /**
     * حذف مقدار از کش
     * 
     * @param string $key کلید
     * @return bool
     */
    public function delete($key);
    
    /**
     * بررسی وجود کلید در کش
     * 
     * @param string $key کلید
     * @return bool
     */
    public function has($key);
    
    /**
     * پاکسازی تمام کش
     * 
     * @return bool
     */
    public function clear();
    
    /**
     * دریافت چندین مقدار به صورت همزمان
     * 
     * @param array $keys لیست کلیدها
     * @return array
     */
    public function getMultiple($keys);
    
    /**
     * ذخیره چندین مقدار به صورت همزمان
     * 
     * @param array $values آرایه کلید => مقدار
     * @param int $ttl زمان انقضا به ثانیه
     * @return bool
     */
    public function setMultiple($values, $ttl = 0);
    
    /**
     * حذف چندین کلید به صورت همزمان
     * 
     * @param array $keys لیست کلیدها
     * @return bool
     */
    public function deleteMultiple($keys);
    
    /**
     * دریافت وضعیت کش
     * 
     * @return array
     */
    public function getStats();
}