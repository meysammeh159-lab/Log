<?php
namespace LoginPro\Core;

class PluginLifecycle {
    public static function activate() {
        self::createDatabaseTables();
        self::setDefaultOptions();
        self::scheduleCronJobs();
        self::flushRewrites();
        
        update_option('loginpro_version', LOGINPRO_VERSION);
        update_option('loginpro_activated_at', current_time('mysql'));
    }
    
    public static function deactivate() {
        self::clearScheduledCronJobs();
        self::flushRewrites();
    }
    
    private static function createDatabaseTables() {
        // بررسی وجود فایل Migrator
        $migratorFile = LOGINPRO_PLUGIN_DIR . 'core/Database/Migrator.php';
        if (!file_exists($migratorFile)) {
            error_log('LoginPro: Migrator.php not found at ' . $migratorFile);
            return;
        }
        
        require_once $migratorFile;
        $migrator = new \LoginPro\Core\Database\Migrator();
        $migrator->run();
    }
    
    private static function setDefaultOptions() {
        $defaults = [
            'loginpro_version' => LOGINPRO_VERSION,
            'loginpro_settings' => [
                'enable_2fa' => true,
                'enable_bruteforce' => true,
                'max_login_attempts' => 5,
                'lockout_time' => 15,
                'default_role' => 'subscriber',
            ],
            'loginpro_db_version' => '1.0.0',
        ];
        
        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
    }
    
    private static function scheduleCronJobs() {
        if (!wp_next_scheduled('loginpro_hourly_cleanup')) {
            wp_schedule_event(time(), 'hourly', 'loginpro_hourly_cleanup');
        }
        
        if (!wp_next_scheduled('loginpro_daily_cleanup')) {
            wp_schedule_event(time(), 'daily', 'loginpro_daily_cleanup');
        }
        
        add_action('loginpro_hourly_cleanup', [self::class, 'hourlyCleanup']);
        add_action('loginpro_daily_cleanup', [self::class, 'dailyCleanup']);
    }
    
    private static function clearScheduledCronJobs() {
        wp_clear_scheduled_hook('loginpro_hourly_cleanup');
        wp_clear_scheduled_hook('loginpro_daily_cleanup');
    }
    
    public static function hourlyCleanup() {
        global $wpdb;
        
        $wpdb->query("DELETE FROM {$wpdb->prefix}loginpro_otps WHERE expires_at < NOW()");
        $wpdb->query("DELETE FROM {$wpdb->prefix}loginpro_sessions WHERE last_activity < " . (time() - 3600));
    }
    
    public static function dailyCleanup() {
        global $wpdb;
        
        $wpdb->query("DELETE FROM {$wpdb->prefix}loginpro_login_history WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $wpdb->query("DELETE FROM {$wpdb->prefix}loginpro_security_events WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)");
    }
    
    private static function flushRewrites() {
        flush_rewrite_rules();
    }
}