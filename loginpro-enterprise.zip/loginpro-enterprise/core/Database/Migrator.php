<?php
/**
 * Database Migrator
 * مدیریت و اجرای Migration‌ها
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Core\Database;

defined('ABSPATH') || exit;

/**
 * کلاس مدیریت Migration
 * 
 * این کلاس مسئول اجرا و مدیریت Migration‌ها است
 */
class Migrator {
    
    /**
     * @var \wpdb $db نمونه دیتابیس وردپرس
     */
    private $db;
    
    /**
     * @var string $table_name نام جدول migrations
     */
    private $table_name;
    
    /**
     * @var array $migrations لیست Migration‌های موجود
     */
    private $migrations = [];
    
    /**
     * @var array $migration_files لیست فایل‌های Migration
     */
    private $migration_files = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->table_name = $this->db->prefix . 'loginpro_migrations';
        $this->ensure_migration_table();
        $this->load_migrations();
    }
    
    /**
     * اطمینان از وجود جدول migrations
     */
    private function ensure_migration_table() {
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            migration varchar(255) NOT NULL,
            batch int(11) NOT NULL,
            executed_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY migration (migration)
        ) {$this->db->get_charset_collate()}";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * بارگذاری فایل‌های Migration
     */
    private function load_migrations() {
        $migration_dir = LOGINPRO_DATABASE_DIR . 'Migrations/';
        if (!is_dir($migration_dir)) {
            return;
        }
        
        $files = glob($migration_dir . '*.php');
        foreach ($files as $file) {
            $class_name = 'LoginPro\\Database\\Migrations\\' . basename($file, '.php');
            $this->migration_files[basename($file, '.php')] = [
                'file' => $file,
                'class' => $class_name,
            ];
        }
        
        // مرتب‌سازی بر اساس نام فایل
        ksort($this->migration_files);
    }
    
    /**
     * اجرای تمام Migration‌های اجرا نشده
     * 
     * @return array نتیجه اجرا
     */
    public function migrate() {
        $results = [];
        $batch = $this->get_next_batch();
        $executed = $this->get_executed_migrations();
        
        foreach ($this->migration_files as $name => $file) {
            if (in_array($name, $executed)) {
                $results[$name] = 'skipped';
                continue;
            }
            
            try {
                require_once $file['file'];
                if (class_exists($file['class'])) {
                    $migration = new $file['class']();
                    if (method_exists($migration, 'up')) {
                        $migration->up();
                        $this->mark_executed($name, $batch);
                        $results[$name] = 'executed';
                    }
                }
            } catch (\Exception $e) {
                $results[$name] = 'failed: ' . $e->getMessage();
            }
        }
        
        return $results;
    }
    
    /**
     * بازگشت آخرین دسته از Migration‌ها
     * 
     * @param int $steps تعداد مراحل بازگشت
     * @return array نتیجه بازگشت
     */
    public function rollback($steps = 1) {
        $results = [];
        $executed = $this->get_executed_migrations_with_batch();
        
        if (empty($executed)) {
            return ['message' => 'No migrations to rollback'];
        }
        
        // دریافت آخرین شماره batch
        $last_batch = $executed[0]->batch;
        $target_batch = $last_batch - $steps + 1;
        
        foreach ($executed as $row) {
            if ($row->batch < $target_batch) {
                break;
            }
            
            $name = $row->migration;
            if (isset($this->migration_files[$name])) {
                try {
                    require_once $this->migration_files[$name]['file'];
                    if (class_exists($this->migration_files[$name]['class'])) {
                        $migration = new $this->migration_files[$name]['class']();
                        if (method_exists($migration, 'down')) {
                            $migration->down();
                            $this->unmark_executed($name);
                            $results[$name] = 'rolled_back';
                        }
                    }
                } catch (\Exception $e) {
                    $results[$name] = 'failed: ' . $e->getMessage();
                }
            }
        }
        
        return $results;
    }
    
    /**
     * بازنشانی کامل (حذف تمام جدول‌ها)
     * 
     * @return array نتیجه بازنشانی
     */
    public function reset() {
        $results = [];
        $executed = $this->get_executed_migrations_with_batch();
        
        foreach ($executed as $row) {
            $name = $row->migration;
            if (isset($this->migration_files[$name])) {
                try {
                    require_once $this->migration_files[$name]['file'];
                    if (class_exists($this->migration_files[$name]['class'])) {
                        $migration = new $this->migration_files[$name]['class']();
                        if (method_exists($migration, 'down')) {
                            $migration->down();
                            $this->unmark_executed($name);
                            $results[$name] = 'dropped';
                        }
                    }
                } catch (\Exception $e) {
                    $results[$name] = 'failed: ' . $e->getMessage();
                }
            }
        }
        
        return $results;
    }
    
    /**
     * دریافت لیست Migration‌های اجرا شده
     * 
     * @return array
     */
    public function get_executed_migrations() {
        return $this->db->get_col("SELECT migration FROM {$this->table_name} ORDER BY batch, id");
    }
    
    /**
     * دریافت لیست Migration‌های اجرا شده با شماره batch
     * 
     * @return array
     */
    public function get_executed_migrations_with_batch() {
        return $this->db->get_results("SELECT migration, batch FROM {$this->table_name} ORDER BY batch DESC, id DESC");
    }
    
    /**
     * دریافت شماره batch بعدی
     * 
     * @return int
     */
    private function get_next_batch() {
        $max = $this->db->get_var("SELECT MAX(batch) FROM {$this->table_name}");
        return intval($max) + 1;
    }
    
    /**
     * علامت‌گذاری Migration به عنوان اجرا شده
     * 
     * @param string $migration_name نام Migration
     * @param int $batch شماره batch
     */
    private function mark_executed($migration_name, $batch) {
        $this->db->insert(
            $this->table_name,
            [
                'migration' => $migration_name,
                'batch' => $batch,
            ],
            ['%s', '%d']
        );
    }
    
    /**
     * حذف علامت اجرا از Migration
     * 
     * @param string $migration_name نام Migration
     */
    private function unmark_executed($migration_name) {
        $this->db->delete(
            $this->table_name,
            ['migration' => $migration_name],
            ['%s']
        );
    }
    
    /**
     * دریافت وضعیت Migration‌ها
     * 
     * @return array
     */
    public function get_status() {
        $executed = $this->get_executed_migrations();
        $status = [];
        
        foreach ($this->migration_files as $name => $file) {
            $status[$name] = [
                'class' => $file['class'],
                'executed' => in_array($name, $executed),
            ];
        }
        
        return $status;
    }
}