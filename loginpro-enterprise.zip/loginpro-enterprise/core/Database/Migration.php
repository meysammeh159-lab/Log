<?php
/**
 * Database Migration Base Class
 * کلاس پایه برای مدیریت Migration‌ها
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Core\Database;

defined('ABSPATH') || exit;

/**
 * کلاس پایه Migration
 * 
 * تمام Migration‌ها باید از این کلاس ارث‌بری کنند
 */
abstract class Migration {
    
    /**
     * @var \wpdb $db نمونه دیتابیس وردپرس
     */
    protected $db;
    
    /**
     * @var string $table_prefix پیشوند جدول
     */
    protected $table_prefix;
    
    /**
     * @var string $charset_collate کاراکترست جدول
     */
    protected $charset_collate;
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->table_prefix = $wpdb->prefix;
        $this->charset_collate = $wpdb->get_charset_collate();
    }
    
    /**
     * اجرای Migration (ایجاد جدول)
     * 
     * @return bool
     */
    abstract public function up();
    
    /**
     * بازگشت Migration (حذف جدول)
     * 
     * @return bool
     */
    abstract public function down();
    
    /**
     * دریافت نام جدول با پیشوند
     * 
     * @param string $table_name نام جدول بدون پیشوند
     * @return string
     */
    protected function get_table_name($table_name) {
        return $this->table_prefix . $table_name;
    }
    
    /**
     * ایجاد جدول با SQL
     * 
     * @param string $table_name نام جدول
     * @param string $sql SQL ایجاد جدول
     * @return bool
     */
    protected function create_table($table_name, $sql) {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $full_sql = "CREATE TABLE IF NOT EXISTS {$this->get_table_name($table_name)} (\n" . $sql . "\n) {$this->charset_collate};";
        dbDelta($full_sql);
        return $this->table_exists($table_name);
    }
    
    /**
     * بررسی وجود جدول
     * 
     * @param string $table_name نام جدول
     * @return bool
     */
    protected function table_exists($table_name) {
        $table = $this->get_table_name($table_name);
        return $this->db->get_var("SHOW TABLES LIKE '$table'") === $table;
    }
    
    /**
     * حذف جدول
     * 
     * @param string $table_name نام جدول
     * @return bool
     */
    protected function drop_table($table_name) {
        $table = $this->get_table_name($table_name);
        return $this->db->query("DROP TABLE IF EXISTS $table");
    }
    
    /**
     * افزودن ستون به جدول
     * 
     * @param string $table_name نام جدول
     * @param string $column_name نام ستون
     * @param string $definition تعریف ستون
     * @return bool
     */
    protected function add_column($table_name, $column_name, $definition) {
        $table = $this->get_table_name($table_name);
        $sql = "ALTER TABLE $table ADD COLUMN $column_name $definition";
        return $this->db->query($sql);
    }
    
    /**
     * حذف ستون از جدول
     * 
     * @param string $table_name نام جدول
     * @param string $column_name نام ستون
     * @return bool
     */
    protected function drop_column($table_name, $column_name) {
        $table = $this->get_table_name($table_name);
        $sql = "ALTER TABLE $table DROP COLUMN $column_name";
        return $this->db->query($sql);
    }
    
    /**
     * بررسی وجود ستون در جدول
     * 
     * @param string $table_name نام جدول
     * @param string $column_name نام ستون
     * @return bool
     */
    protected function column_exists($table_name, $column_name) {
        $table = $this->get_table_name($table_name);
        $result = $this->db->get_results("SHOW COLUMNS FROM $table LIKE '$column_name'");
        return !empty($result);
    }
    
    /**
     * ایجاد ایندکس روی جدول
     * 
     * @param string $table_name نام جدول
     * @param string $index_name نام ایندکس
     * @param string|array $columns ستون‌ها
     * @return bool
     */
    protected function create_index($table_name, $index_name, $columns) {
        $table = $this->get_table_name($table_name);
        if (is_array($columns)) {
            $columns = implode(', ', $columns);
        }
        $sql = "ALTER TABLE $table ADD INDEX $index_name ($columns)";
        return $this->db->query($sql);
    }
    
    /**
     * حذف ایندکس از جدول
     * 
     * @param string $table_name نام جدول
     * @param string $index_name نام ایندکس
     * @return bool
     */
    protected function drop_index($table_name, $index_name) {
        $table = $this->get_table_name($table_name);
        $sql = "ALTER TABLE $table DROP INDEX $index_name";
        return $this->db->query($sql);
    }
    
    /**
     * ایجاد کلید خارجی
     * 
     * @param string $table_name نام جدول
     * @param string $constraint_name نام محدودیت
     * @param string $column ستون
     * @param string $ref_table جدول مرجع
     * @param string $ref_column ستون مرجع
     * @param string $on_delete عملکرد حذف
     * @param string $on_update عملکرد بروزرسانی
     * @return bool
     */
    protected function add_foreign_key($table_name, $constraint_name, $column, $ref_table, $ref_column, $on_delete = 'CASCADE', $on_update = 'CASCADE') {
        $table = $this->get_table_name($table_name);
        $ref_table_full = $this->get_table_name($ref_table);
        $sql = "ALTER TABLE $table ADD CONSTRAINT $constraint_name FOREIGN KEY ($column) REFERENCES $ref_table_full ($ref_column) ON DELETE $on_delete ON UPDATE $on_update";
        return $this->db->query($sql);
    }
    
    /**
     * حذف کلید خارجی
     * 
     * @param string $table_name نام جدول
     * @param string $constraint_name نام محدودیت
     * @return bool
     */
    protected function drop_foreign_key($table_name, $constraint_name) {
        $table = $this->get_table_name($table_name);
        $sql = "ALTER TABLE $table DROP FOREIGN KEY $constraint_name";
        return $this->db->query($sql);
    }
    
    /**
     * دریافت زمان اجرا
     * 
     * @return string زمان فعلی
     */
    protected function get_current_time() {
        return current_time('mysql');
    }
    
    /**
     * دریافت timestamp فعلی
     * 
     * @return int
     */
    protected function get_current_timestamp() {
        return current_time('timestamp');
    }
}