<?php
namespace LoginPro\Core\Database;

use wpdb;

class Connection {
    private static $instance = null;
    private $wpdb;
    private $prefix;
    
    private function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->prefix = $wpdb->prefix . 'loginpro_';
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function table($name) {
        return $this->prefix . $name;
    }
    
    public function get($table, $where = [], $select = '*') {
        $table = $this->table($table);
        $sql = "SELECT {$select} FROM {$table}";
        
        if (!empty($where)) {
            $conditions = [];
            foreach ($where as $key => $value) {
                $conditions[] = $this->wpdb->prepare("{$key} = %s", $value);
            }
            $sql .= " WHERE " . implode(' AND ', $conditions);
        }
        
        return $this->wpdb->get_results($sql, ARRAY_A);
    }
    
    public function insert($table, $data) {
        $table = $this->table($table);
        return $this->wpdb->insert($table, $data);
    }
    
    public function update($table, $data, $where) {
        $table = $this->table($table);
        return $this->wpdb->update($table, $data, $where);
    }
    
    public function delete($table, $where) {
        $table = $this->table($table);
        return $this->wpdb->delete($table, $where);
    }
    
    public function query($sql) {
        return $this->wpdb->query($sql);
    }
    
    public function getResults($sql) {
        return $this->wpdb->get_results($sql, ARRAY_A);
    }
    
    public function getVar($sql) {
        return $this->wpdb->get_var($sql);
    }
    
    public function prepare($sql, $args) {
        return $this->wpdb->prepare($sql, $args);
    }
    
    public function getInsertId() {
        return $this->wpdb->insert_id;
    }
    
    public function getLastError() {
        return $this->wpdb->last_error;
    }
}
