<?php
namespace LoginPro\Core\Database;

abstract class Model {
    protected static $table;
    protected static $primaryKey = 'id';
    protected $attributes = [];
    protected $original = [];
    protected $exists = false;
    
    public function __construct(array $attributes = []) {
        $this->fill($attributes);
    }
    
    public static function query() {
        return new QueryBuilder(static::getTable());
    }
    
    public static function find($id) {
        $result = static::query()->where(static::$primaryKey, $id)->first();
        if ($result) {
            $model = new static($result);
            $model->exists = true;
            $model->original = $result;
            return $model;
        }
        return null;
    }
    
    public static function all() {
        $results = static::query()->get();
        return array_map(function($data) {
            return new static($data);
        }, $results);
    }
    
    public static function where($column, $operator = null, $value = null) {
        return static::query()->where($column, $operator, $value);
    }
    
    public function fill(array $attributes) {
        foreach ($attributes as $key => $value) {
            $this->setAttribute($key, $value);
        }
        return $this;
    }
    
    public function setAttribute($key, $value) {
        $this->attributes[$key] = $value;
    }
    
    public function getAttribute($key) {
        return $this->attributes[$key] ?? null;
    }
    
    public function save() {
        $data = $this->attributes;
        
        if ($this->exists && isset($this->attributes[static::$primaryKey])) {
            $result = static::query()->where(static::$primaryKey, $this->attributes[static::$primaryKey])->update($data);
        } else {
            $result = static::query()->insert($data);
            if ($result) {
                $this->attributes[static::$primaryKey] = Connection::getInstance()->getInsertId();
                $this->exists = true;
            }
        }
        
        if ($result) {
            $this->original = $this->attributes;
        }
        
        return $result;
    }
    
    public function delete() {
        if (!$this->exists) {
            return false;
        }
        
        $result = static::query()->where(static::$primaryKey, $this->attributes[static::$primaryKey])->delete();
        if ($result) {
            $this->exists = false;
        }
        return $result;
    }
    
    public static function getTable() {
        if (static::$table) {
            return static::$table;
        }
        
        $class = basename(str_replace('\\', '/', get_called_class()));
        return strtolower(preg_replace('/(?<!^)[A-Z]/', '_' . '$0', $class)) . 's';
    }
    
    public function __get($key) {
        return $this->getAttribute($key);
    }
    
    public function __set($key, $value) {
        $this->setAttribute($key, $value);
    }
}
