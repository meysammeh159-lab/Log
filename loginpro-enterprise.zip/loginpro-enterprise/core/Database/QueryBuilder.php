<?php
namespace LoginPro\Core\Database;

class QueryBuilder {
    private $connection;
    private $table;
    private $select = [];
    private $where = [];
    private $orderBy = [];
    private $limit = null;
    private $offset = null;
    
    public function __construct($table) {
        $this->connection = Connection::getInstance();
        $this->table = $this->connection->table($table);
    }
    
    public function select($columns) {
        $this->select = is_array($columns) ? $columns : func_get_args();
        return $this;
    }
    
    public function where($column, $operator = null, $value = null) {
        if (func_num_args() === 2) {
            $value = $operator;
            $operator = '=';
        }
        
        $this->where[] = [
            'type' => 'basic',
            'column' => $column,
            'operator' => $operator,
            'value' => $value
        ];
        
        return $this;
    }
    
    public function orderBy($column, $direction = 'ASC') {
        $this->orderBy[] = [
            'column' => $column,
            'direction' => $direction
        ];
        return $this;
    }
    
    public function limit($limit) {
        $this->limit = $limit;
        return $this;
    }
    
    public function offset($offset) {
        $this->offset = $offset;
        return $this;
    }
    
    public function get() {
        $sql = $this->buildSelectQuery();
        return $this->connection->getResults($sql);
    }
    
    public function first() {
        $this->limit = 1;
        $results = $this->get();
        return $results ? $results[0] : null;
    }
    
    public function insert($data) {
        return $this->connection->insert($this->table, $data);
    }
    
    public function update($data) {
        $sets = [];
        $values = [];
        
        foreach ($data as $column => $value) {
            $sets[] = "{$column} = %s";
            $values[] = $value;
        }
        
        $sql = "UPDATE {$this->table} SET " . implode(', ', $sets);
        
        if (!empty($this->where)) {
            $sql .= $this->buildWhereClause();
            $whereValues = $this->getWhereValues();
            $values = array_merge($values, $whereValues);
        }
        
        $prepared = $this->connection->prepare($sql, $values);
        return $this->connection->query($prepared);
    }
    
    public function delete() {
        $sql = "DELETE FROM {$this->table}";
        
        if (!empty($this->where)) {
            $sql .= $this->buildWhereClause();
            $values = $this->getWhereValues();
            $prepared = $this->connection->prepare($sql, $values);
            return $this->connection->query($prepared);
        }
        
        return $this->connection->query($sql);
    }
    
    public function count() {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";
        
        if (!empty($this->where)) {
            $sql .= $this->buildWhereClause();
            $values = $this->getWhereValues();
            $prepared = $this->connection->prepare($sql, $values);
            $result = $this->connection->getResults($prepared);
            return $result ? (int)$result[0]['count'] : 0;
        }
        
        $result = $this->connection->getResults($sql);
        return $result ? (int)$result[0]['count'] : 0;
    }
    
    private function buildSelectQuery() {
        $select = empty($this->select) ? '*' : implode(', ', $this->select);
        $sql = "SELECT {$select} FROM {$this->table}";
        
        if (!empty($this->where)) {
            $sql .= $this->buildWhereClause();
        }
        
        if (!empty($this->orderBy)) {
            $orders = [];
            foreach ($this->orderBy as $order) {
                $orders[] = "{$order['column']} {$order['direction']}";
            }
            $sql .= " ORDER BY " . implode(', ', $orders);
        }
        
        if ($this->limit !== null) {
            $sql .= " LIMIT {$this->limit}";
        }
        
        if ($this->offset !== null) {
            $sql .= " OFFSET {$this->offset}";
        }
        
        return $sql;
    }
    
    private function buildWhereClause() {
        $conditions = [];
        foreach ($this->where as $where) {
            if ($where['type'] === 'or') {
                $conditions[] = "OR {$where['column']} {$where['operator']} %s";
            } else {
                $conditions[] = "AND {$where['column']} {$where['operator']} %s";
            }
        }
        
        $whereString = implode(' ', $conditions);
        if (strpos($whereString, 'OR') === 0) {
            $whereString = substr($whereString, 3);
        } elseif (strpos($whereString, 'AND') === 0) {
            $whereString = substr($whereString, 4);
        }
        
        return " WHERE " . $whereString;
    }
    
    private function getWhereValues() {
        $values = [];
        foreach ($this->where as $where) {
            $values[] = $where['value'];
        }
        return $values;
    }
}
