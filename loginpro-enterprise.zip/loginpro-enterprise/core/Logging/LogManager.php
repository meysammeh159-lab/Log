<?php
namespace LoginPro\Core\Logging;

class LogManager {
    private static $instance;
    private $logger;
    
    private function __construct() {
        $this->logger = new Logger();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public static function __callStatic($method, $arguments) {
        $instance = self::getInstance();
        if (method_exists($instance->logger, $method)) {
            return call_user_func_array([$instance->logger, $method], $arguments);
        }
        return null;
    }
    
    public function getLogger() {
        return $this->logger;
    }
}
