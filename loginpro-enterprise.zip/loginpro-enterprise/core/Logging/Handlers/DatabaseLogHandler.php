<?php
namespace LoginPro\Core\Logging\Handlers;

use LoginPro\Core\Database\Connection;

class DatabaseLogHandler {
    private $connection;
    
    public function __construct() {
        $this->connection = Connection::getInstance();
    }
    
    public function write($level, $message, array $context = []) {
        $sql = $this->connection->prepare(
            "INSERT INTO {$this->connection->table('logs')} (level, message, context, created_at) VALUES (%s, %s, %s, %s)",
            [$level, $message, json_encode($context), current_time('mysql')]
        );
        $this->connection->query($sql);
    }
}
