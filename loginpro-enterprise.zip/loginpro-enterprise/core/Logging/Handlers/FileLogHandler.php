<?php
namespace LoginPro\Core\Logging\Handlers;

class FileLogHandler {
    private $logFile;
    
    public function __construct($logFile) {
        $this->logFile = $logFile;
        $this->ensureLogDirectory();
    }
    
    private function ensureLogDirectory() {
        $dir = dirname($this->logFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
    
    public function write($level, $message, array $context = []) {
        file_put_contents($this->logFile, $message . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
