<?php
namespace LoginPro\Core\Logging;

use LoginPro\Core\Contracts\LoggerInterface;

class Logger implements LoggerInterface {
    private $handlers = [];
    private $logFile;
    
    public function __construct() {
        $this->logFile = LOGINPRO_PLUGIN_DIR . 'storage/logs/loginpro.log';
        $this->registerHandlers();
    }
    
    private function registerHandlers() {
        $this->handlers[] = new Handlers\FileLogHandler($this->logFile);
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $this->handlers[] = new Handlers\DatabaseLogHandler();
        }
    }
    
    private function write($level, $message, array $context = []) {
        $logMessage = $this->formatMessage($level, $message, $context);
        
        foreach ($this->handlers as $handler) {
            $handler->write($level, $logMessage, $context);
        }
    }
    
    private function formatMessage($level, $message, array $context = []) {
        $timestamp = current_time('mysql');
        $contextStr = !empty($context) ? json_encode($context) : '';
        return "[{$timestamp}] {$level}: {$message} {$contextStr}";
    }
    
    public function emergency($message, array $context = []) {
        $this->write('EMERGENCY', $message, $context);
    }
    
    public function alert($message, array $context = []) {
        $this->write('ALERT', $message, $context);
    }
    
    public function critical($message, array $context = []) {
        $this->write('CRITICAL', $message, $context);
    }
    
    public function error($message, array $context = []) {
        $this->write('ERROR', $message, $context);
    }
    
    public function warning($message, array $context = []) {
        $this->write('WARNING', $message, $context);
    }
    
    public function notice($message, array $context = []) {
        $this->write('NOTICE', $message, $context);
    }
    
    public function info($message, array $context = []) {
        $this->write('INFO', $message, $context);
    }
    
    public function debug($message, array $context = []) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $this->write('DEBUG', $message, $context);
        }
    }
    
    public function log($level, $message, array $context = []) {
        $this->write(strtoupper($level), $message, $context);
    }
}
