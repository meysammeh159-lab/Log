<?php
namespace LoginPro\Core\Security;

class Sanitizer {
    public static function text($input) {
        return sanitize_text_field($input);
    }
    
    public static function email($input) {
        return sanitize_email($input);
    }
    
    public static function url($input) {
        return esc_url_raw($input);
    }
    
    public static function html($input) {
        return wp_kses_post($input);
    }
    
    public static function key($input) {
        return sanitize_key($input);
    }
    
    public static function sql($input) {
        return esc_sql($input);
    }
    
    public static function array($input) {
        if (!is_array($input)) {
            return [];
        }
        return array_map([self::class, 'text'], $input);
    }
    
    public static function integer($input) {
        return intval($input);
    }
    
    public static function float($input) {
        return floatval($input);
    }
    
    public static function boolean($input) {
        return filter_var($input, FILTER_VALIDATE_BOOLEAN);
    }
}
