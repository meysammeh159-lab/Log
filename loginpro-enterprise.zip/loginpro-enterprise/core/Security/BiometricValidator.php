<?php
/**
 * Biometric Validator
 * اعتبارسنجی عمومی احراز هویت بیومتریک
 */

namespace LoginPro\Core\Security;

class BiometricValidator
{
    /**
     * بررسی پشتیبانی مرورگر از WebAuthn
     */
    public function isBrowserSupported()
    {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $supportedBrowsers = [
            'chrome', 'firefox', 'safari', 'edge', 'opera'
        ];
        
        $userAgentLower = strtolower($userAgent);
        
        foreach ($supportedBrowsers as $browser) {
            if (strpos($userAgentLower, $browser) !== false) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * بررسی پشتیبانی از Platform Authenticator
     */
    public function isPlatformAuthenticatorSupported()
    {
        // بررسی وجود WebAuthn API
        return true;
    }

    /**
     * دریافت سطح امنیت
     */
    public function getSecurityLevel($deviceType)
    {
        $levels = [
            'ios' => 'high',
            'android' => 'high',
            'windows' => 'high',
            'mac' => 'high',
            'linux' => 'medium',
            'unknown' => 'low'
        ];
        
        return $levels[$deviceType] ?? 'medium';
    }

    /**
     * دریافت توصیه‌های امنیتی
     */
    public function getSecurityRecommendations($deviceType)
    {
        $recommendations = [
            'ios' => [
                'Use Face ID or Touch ID',
                'Enable device passcode',
                'Keep iOS updated'
            ],
            'android' => [
                'Use Fingerprint or Face Unlock',
                'Enable device lock',
                'Keep Android updated'
            ],
            'windows' => [
                'Use Windows Hello',
                'Enable PIN or Password',
                'Keep Windows updated'
            ],
            'mac' => [
                'Use Touch ID or Apple Watch',
                'Enable FileVault',
                'Keep macOS updated'
            ]
        ];
        
        return $recommendations[$deviceType] ?? [
            'Use a secure device',
            'Enable device lock',
            'Keep your device updated'
        ];
    }
}