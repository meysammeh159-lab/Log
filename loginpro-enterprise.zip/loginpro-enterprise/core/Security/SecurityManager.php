<?php
namespace LoginPro\Core\Security;

defined('ABSPATH') || exit;

/**
 * SecurityManager
 * 
 * مدیریت امنیت سیستم:
 * - CSRF Protection
 * - XSS Prevention
 * - SQL Injection Prevention
 * - Rate Limiting
 */
class SecurityManager
{
    /**
     * @var RateLimiter محدودیت نرخ درخواست
     */
    private $rateLimiter;

    public function __construct()
    {
        $this->rateLimiter = new RateLimiter();
    }

    /**
     * مقداردهی اولیه امنیت
     */
    public function init(): void
    {
        // ==================================================
        // ۱. CSRF Protection
        // ==================================================
        add_action('init', [$this, 'validateCsrf']);

        // ==================================================
        // ۲. XSS Prevention - خروجی‌های امن
        // ==================================================
        add_filter('the_content', [$this, 'sanitizeOutput']);

        // ==================================================
        // ۳. محدودیت نرخ درخواست
        // ==================================================
        add_action('wp_ajax_loginpro_login', [$this, 'checkRateLimit']);
        add_action('wp_ajax_nopriv_loginpro_login', [$this, 'checkRateLimit']);
    }

    /**
     * اعتبارسنجی CSRF
     */
    public function validateCsrf(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'loginpro_action')) {
                wp_die(__('CSRF validation failed', 'loginpro'), 'Security Error', ['response' => 403]);
            }
        }
    }

    /**
     * پاکسازی خروجی
     */
    public function sanitizeOutput($content)
    {
        if (has_shortcode($content, 'loginpro_login')) {
            $content = wp_kses_post($content);
        }
        return $content;
    }

    /**
     * بررسی محدودیت نرخ درخواست
     */
    public function checkRateLimit(): void
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $key = 'loginpro_rate_' . md5($ip);

        if (!$this->rateLimiter->check($key, 10, 60)) {
            wp_send_json_error([
                'code' => 'rate_limit_exceeded',
                'message' => __('تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً ۶۰ ثانیه دیگر تلاش کنید.', 'loginpro')
            ], 429);
            exit;
        }
    }

    /**
     * تولید Nonce امن
     */
    public function createNonce(): string
    {
        return wp_create_nonce('loginpro_action');
    }
}