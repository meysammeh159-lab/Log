<?php
namespace LoginPro\Core\Security;

defined('ABSPATH') || exit;

/**
 * RateLimiter
 * 
 * مدیریت محدودیت نرخ درخواست با استفاده از Transients
 */
class RateLimiter
{
    /**
     * @var string پیشوند کلید
     */
    private $prefix = 'loginpro_rl_';

    /**
     * بررسی محدودیت
     * 
     * @param string $key کلید یکتا
     * @param int $limit حداکثر تعداد درخواست
     * @param int $window پنجره زمانی (ثانیه)
     * @return bool
     */
    public function check(string $key, int $limit, int $window): bool
    {
        $cacheKey = $this->prefix . $key;
        $current = get_transient($cacheKey);

        if ($current === false) {
            set_transient($cacheKey, 1, $window);
            return true;
        }

        if ($current >= $limit) {
            return false;
        }

        set_transient($cacheKey, $current + 1, $window);
        return true;
    }

    /**
     * بازنشانی محدودیت
     */
    public function reset(string $key): void
    {
        $cacheKey = $this->prefix . $key;
        delete_transient($cacheKey);
    }

    /**
     * دریافت تعداد درخواست‌های باقی‌مانده
     */
    public function getRemaining(string $key, int $limit): int
    {
        $cacheKey = $this->prefix . $key;
        $current = get_transient($cacheKey);

        if ($current === false) {
            return $limit;
        }

        return max(0, $limit - $current);
    }
}