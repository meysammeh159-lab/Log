<?php
namespace LoginPro\Core\Security;

class Hasher {
    public function make($value) {
        return wp_hash_password($value);
    }
    
    public function check($value, $hash) {
        return wp_check_password($value, $hash);
    }
    
    public function needsRehash($hash) {
        return false;
    }
    
    public function hash($value, $algo = 'sha256') {
        return hash($algo, $value);
    }
    
    public function hashEquals($known, $user) {
        return hash_equals($known, $user);
    }
}
