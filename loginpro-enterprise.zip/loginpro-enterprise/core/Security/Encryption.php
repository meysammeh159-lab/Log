<?php
namespace LoginPro\Core\Security;

class Encryption {
    private $key;
    private $cipher = 'AES-256-CBC';
    
    public function __construct() {
        $this->key = defined('LOGGED_IN_KEY') ? LOGGED_IN_KEY : 'default-key-please-change';
        $this->key = hash('sha256', $this->key, true);
    }
    
    public function encrypt($data) {
        $ivLength = openssl_cipher_iv_length($this->cipher);
        $iv = random_bytes($ivLength);
        $encrypted = openssl_encrypt($data, $this->cipher, $this->key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }
    
    public function decrypt($data) {
        $data = base64_decode($data);
        $ivLength = openssl_cipher_iv_length($this->cipher);
        $iv = substr($data, 0, $ivLength);
        $encrypted = substr($data, $ivLength);
        return openssl_decrypt($encrypted, $this->cipher, $this->key, 0, $iv);
    }
}
