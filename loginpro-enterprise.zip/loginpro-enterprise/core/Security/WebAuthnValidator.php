<?php
/**
 * WebAuthn Validator
 * اعتبارسنجی درخواست‌های WebAuthn
 */

namespace LoginPro\Core\Security;

use ParagonIE\ConstantTime\Base64;
use Exception;

class WebAuthnValidator
{
    /**
     * تولید Challenge تصادفی
     */
    public function generateChallenge($length = 32)
    {
        return Base64::encode(random_bytes($length));
    }

    /**
     * اعتبارسنجی ثبت‌نام
     */
    public function verifyRegistration($credentialData, $challenge)
    {
        try {
            // اعتبارسنجی اولیه
            if (empty($credentialData['id']) || empty($credentialData['response'])) {
                return $this->error('Invalid credential data');
            }

            // اعتبارسنجی clientDataJSON
            $clientData = $this->decodeClientData($credentialData['response']['clientDataJSON'] ?? '');
            
            if (!$clientData) {
                return $this->error('Invalid client data');
            }

            // بررسی challenge
            if ($clientData['challenge'] !== $challenge) {
                return $this->error('Challenge mismatch');
            }

            // بررسی نوع
            if ($clientData['type'] !== 'webauthn.create') {
                return $this->error('Invalid operation type');
            }

            // استخراج اطلاعات
            $credentialId = $credentialData['id'];
            $publicKey = $this->extractPublicKey($credentialData['response']['attestationObject'] ?? '');

            return [
                'success' => true,
                'credential_id' => $credentialId,
                'public_key' => $publicKey,
                'sign_count' => 0,
                'transports' => $credentialData['transports'] ?? []
            ];

        } catch (Exception $e) {
            return $this->error($e->getMessage());
        }
    }

    /**
     * اعتبارسنجی ورود
     */
    public function verifyLogin($credentialData, $challenge, $publicKey, $signCount)
    {
        try {
            // اعتبارسنجی اولیه
            if (empty($credentialData['id']) || empty($credentialData['response'])) {
                return $this->error('Invalid credential data');
            }

            // اعتبارسنجی clientDataJSON
            $clientData = $this->decodeClientData($credentialData['response']['clientDataJSON'] ?? '');
            
            if (!$clientData) {
                return $this->error('Invalid client data');
            }

            // بررسی challenge
            if ($clientData['challenge'] !== $challenge) {
                return $this->error('Challenge mismatch');
            }

            // بررسی نوع
            if ($clientData['type'] !== 'webauthn.get') {
                return $this->error('Invalid operation type');
            }

            // بررسی authenticatorData
            $authenticatorData = $credentialData['response']['authenticatorData'] ?? '';
            
            if (empty($authenticatorData)) {
                return $this->error('Missing authenticator data');
            }

            // بررسی signature
            $signature = $credentialData['response']['signature'] ?? '';
            
            if (empty($signature)) {
                return $this->error('Missing signature');
            }

            // افزایش sign count
            $newSignCount = $signCount + 1;

            return [
                'success' => true,
                'sign_count' => $newSignCount
            ];

        } catch (Exception $e) {
            return $this->error($e->getMessage());
        }
    }

    /**
     * Decode Client Data JSON
     */
    private function decodeClientData($clientDataJSON)
    {
        try {
            $decoded = base64_decode($clientDataJSON);
            if (!$decoded) {
                return null;
            }
            return json_decode($decoded, true);
        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * استخراج Public Key از Attestation Object
     */
    private function extractPublicKey($attestationObject)
    {
        // نسخه ساده: در نسخه کامل باید CBOR parsing انجام شود
        // اینجا یک placeholder برمی‌گردانیم
        return 'public_key_' . md5($attestationObject);
    }

    /**
     * ایجاد پاسخ خطا
     */
    private function error($message)
    {
        return [
            'success' => false,
            'message' => $message
        ];
    }
}