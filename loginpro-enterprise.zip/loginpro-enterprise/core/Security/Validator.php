<?php
namespace LoginPro\Core\Security;

class Validator {
    private $errors = [];
    
    public function validate($data, $rules) {
        $this->errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            $ruleParts = explode('|', $rule);
            
            foreach ($ruleParts as $singleRule) {
                $this->validateRule($field, $value, $singleRule);
            }
        }
        
        if (!empty($this->errors)) {
            throw new \ValidationException($this->errors);
        }
        
        return $data;
    }
    
    private function validateRule($field, $value, $rule) {
        if ($rule === 'required' && (is_null($value) || $value === '')) {
            $this->errors[$field][] = "The {$field} field is required";
        }
        
        if ($rule === 'email' && !empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field][] = "The {$field} must be a valid email address";
        }
        
        if (strpos($rule, 'min:') === 0) {
            $min = substr($rule, 4);
            if (strlen($value) < $min) {
                $this->errors[$field][] = "The {$field} must be at least {$min} characters";
            }
        }
        
        if (strpos($rule, 'max:') === 0) {
            $max = substr($rule, 4);
            if (strlen($value) > $max) {
                $this->errors[$field][] = "The {$field} may not be greater than {$max} characters";
            }
        }
        
        if ($rule === 'numeric' && !is_numeric($value)) {
            $this->errors[$field][] = "The {$field} must be a number";
        }
    }
    
    public function sanitize($data) {
        if (is_string($data)) {
            return sanitize_text_field($data);
        }
        
        if (is_array($data)) {
            return array_map([$this, 'sanitize'], $data);
        }
        
        return $data;
    }
    
    public function sanitizeEmail($email) {
        return sanitize_email($email);
    }
    
    public function sanitizeUrl($url) {
        return esc_url_raw($url);
    }
    
    public function sanitizeHtml($html) {
        return wp_kses_post($html);
    }
}
