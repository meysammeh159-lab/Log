<?php
namespace LoginPro\Core\Helpers;

class Str {
    public static function random($length = 16) {
        return bin2hex(random_bytes($length / 2));
    }
    
    public static function limit($value, $limit = 100, $end = '...') {
        if (mb_strwidth($value, 'UTF-8') <= $limit) {
            return $value;
        }
        return rtrim(mb_strimwidth($value, 0, $limit, '', 'UTF-8')) . $end;
    }
    
    public static function slug($title, $separator = '-') {
        $title = remove_accents($title);
        $title = preg_replace('/[^a-z0-9-]/', $separator, strtolower($title));
        $title = preg_replace('/[' . preg_quote($separator) . ']+/', $separator, $title);
        return trim($title, $separator);
    }
    
    public static function contains($haystack, $needle) {
        return strpos($haystack, $needle) !== false;
    }
    
    public static function startsWith($haystack, $needle) {
        return substr($haystack, 0, strlen($needle)) === $needle;
    }
    
    public static function endsWith($haystack, $needle) {
        return substr($haystack, -strlen($needle)) === $needle;
    }
    
    public static function uuid() {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}
