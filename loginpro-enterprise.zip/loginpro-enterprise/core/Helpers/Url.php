<?php
namespace LoginPro\Core\Helpers;

class Url {
    public static function current() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }
    
    public static function previous() {
        return wp_get_referer() ?: home_url();
    }
    
    public static function to($path) {
        return home_url($path);
    }
    
    public static function admin($path = '') {
        return admin_url($path);
    }
    
    public static function asset($path) {
        return LOGINPRO_PLUGIN_URL . ltrim($path, '/');
    }
    
    public static function route($name, $parameters = []) {
        $routes = [
            'login' => '/login',
            'register' => '/register',
            'dashboard' => '/dashboard',
            'profile' => '/profile',
            'logout' => '/logout',
        ];
        
        $url = $routes[$name] ?? $name;
        
        foreach ($parameters as $key => $value) {
            $url = str_replace('{' . $key . '}', $value, $url);
        }
        
        return home_url($url);
    }
    
    public static function withQuery($url, $params) {
        $query = http_build_query($params);
        $separator = strpos($url, '?') === false ? '?' : '&';
        return $url . $separator . $query;
    }
}
