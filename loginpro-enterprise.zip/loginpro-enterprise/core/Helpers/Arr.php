<?php
namespace LoginPro\Core\Helpers;

class Arr {
    public static function get($array, $key, $default = null) {
        if (!is_array($array)) {
            return $default;
        }
        
        if (isset($array[$key])) {
            return $array[$key];
        }
        
        foreach (explode('.', $key) as $segment) {
            if (!is_array($array) || !array_key_exists($segment, $array)) {
                return $default;
            }
            $array = $array[$segment];
        }
        
        return $array;
    }
    
    public static function set(&$array, $key, $value) {
        if (is_null($key)) {
            $array = $value;
            return;
        }
        
        $keys = explode('.', $key);
        while (count($keys) > 1) {
            $key = array_shift($keys);
            if (!isset($array[$key]) || !is_array($array[$key])) {
                $array[$key] = [];
            }
            $array = &$array[$key];
        }
        
        $array[array_shift($keys)] = $value;
    }
    
    public static function has($array, $key) {
        if (empty($array) || is_null($key)) {
            return false;
        }
        
        if (array_key_exists($key, $array)) {
            return true;
        }
        
        foreach (explode('.', $key) as $segment) {
            if (!is_array($array) || !array_key_exists($segment, $array)) {
                return false;
            }
            $array = $array[$segment];
        }
        
        return true;
    }
    
    public static function except($array, $keys) {
        $keys = (array)$keys;
        return array_diff_key($array, array_flip($keys));
    }
    
    public static function only($array, $keys) {
        $keys = (array)$keys;
        return array_intersect_key($array, array_flip($keys));
    }
    
    public static function pluck($array, $value, $key = null) {
        $results = [];
        foreach ($array as $item) {
            $itemValue = is_object($item) ? $item->{$value} : $item[$value];
            if (is_null($key)) {
                $results[] = $itemValue;
            } else {
                $itemKey = is_object($item) ? $item->{$key} : $item[$key];
                $results[$itemKey] = $itemValue;
            }
        }
        return $results;
    }
}
