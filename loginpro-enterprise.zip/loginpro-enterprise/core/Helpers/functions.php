<?php
if (!function_exists('loginpro_config')) {
    function loginpro_config($key, $default = null) {
        $container = \LoginPro\Bootstrap\Container::getInstance();
        return $container->make('config.' . $key, $default);
    }
}

if (!function_exists('loginpro_cache')) {
    function loginpro_cache() {
        return \LoginPro\Bootstrap\Container::getInstance()->make('cache');
    }
}

if (!function_exists('loginpro_logger')) {
    function loginpro_logger() {
        return \LoginPro\Bootstrap\Container::getInstance()->make('logger');
    }
}

if (!function_exists('loginpro_queue')) {
    function loginpro_queue() {
        return \LoginPro\Bootstrap\Container::getInstance()->make('queue');
    }
}

if (!function_exists('loginpro_db')) {
    function loginpro_db() {
        return \LoginPro\Core\Database\Connection::getInstance();
    }
}

if (!function_exists('loginpro_event')) {
    function loginpro_event($event, $payload = []) {
        $dispatcher = \LoginPro\Bootstrap\Container::getInstance()->make('events');
        if ($dispatcher) {
            $dispatcher->dispatch($event, $payload);
        }
    }
}

if (!function_exists('loginpro_encrypt')) {
    function loginpro_encrypt($data) {
        $encryption = new \LoginPro\Core\Security\Encryption();
        return $encryption->encrypt($data);
    }
}

if (!function_exists('loginpro_decrypt')) {
    function loginpro_decrypt($data) {
        $encryption = new \LoginPro\Core\Security\Encryption();
        return $encryption->decrypt($data);
    }
}
