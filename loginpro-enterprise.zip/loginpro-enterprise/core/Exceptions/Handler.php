<?php
namespace LoginPro\Core\Exceptions;

use Exception;
use LoginPro\Core\Http\Response;

class Handler {
    private static $instance;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function register() {
        set_exception_handler([$this, 'handle']);
        set_error_handler([$this, 'handleError']);
    }
    
    public function handle($exception) {
        $this->logException($exception);
        
        if ($this->isApiRequest()) {
            return Response::json([
                'success' => false,
                'error' => $exception->getMessage(),
                'code' => $exception->getCode()
            ], $this->getStatusCode($exception));
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            wp_die($exception->getMessage() . '<br><br>' . nl2br($exception->getTraceAsString()));
        } else {
            wp_die('An error occurred. Please try again later.');
        }
    }
    
    public function handleError($level, $message, $file = '', $line = 0) {
        if (error_reporting() & $level) {
            throw new \ErrorException($message, 0, $level, $file, $line);
        }
        return false;
    }
    
    private function logException($exception) {
        if (function_exists('do_action')) {
            do_action('loginpro_exception', $exception);
        }
        
        error_log(sprintf(
            '[LoginPro Exception] %s in %s on line %d' . PHP_EOL . 'Stack trace: %s' . PHP_EOL,
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine(),
            $exception->getTraceAsString()
        ));
    }
    
    private function isApiRequest() {
        return (defined('REST_REQUEST') && REST_REQUEST)
            || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);
    }
    
    private function getStatusCode($exception) {
        if ($exception instanceof HttpException) {
            return $exception->getStatusCode();
        }
        if ($exception instanceof ValidationException) {
            return 422;
        }
        return 500;
    }
}
