<?php
namespace LoginPro\Core\Exceptions;

use Exception;

class HttpException extends Exception {
    protected $statusCode;
    
    public function __construct($statusCode, $message = null, Exception $previous = null) {
        $this->statusCode = $statusCode;
        parent::__construct($message ?: 'HTTP Error', $statusCode, $previous);
    }
    
    public function getStatusCode() {
        return $this->statusCode;
    }
}
