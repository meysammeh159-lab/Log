<?php
namespace LoginPro\Core\Exceptions;

use Exception;

class ValidationException extends Exception {
    protected $errors;
    
    public function __construct($errors, $message = 'Validation failed') {
        $this->errors = $errors;
        parent::__construct($message, 422);
    }
    
    public function getErrors() {
        return $this->errors;
    }
    
    public function getFirstError() {
        if (is_array($this->errors)) {
            $first = reset($this->errors);
            return is_array($first) ? $first[0] : $first;
        }
        return $this->getMessage();
    }
}
