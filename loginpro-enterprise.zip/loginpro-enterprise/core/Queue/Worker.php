<?php
namespace LoginPro\Core\Queue;

class Worker {
    private $queueManager;
    private $shouldQuit = false;
    
    public function __construct() {
        $this->queueManager = new QueueManager();
    }
    
    public function daemon($queue = null) {
        $this->registerSignalHandlers();
        
        while (!$this->shouldQuit) {
            $processed = $this->queueManager->process();
            
            if (!$processed) {
                sleep(3);
            }
        }
    }
    
    private function registerSignalHandlers() {
        if (function_exists('pcntl_signal')) {
            pcntl_signal(SIGTERM, [$this, 'quit']);
            pcntl_signal(SIGINT, [$this, 'quit']);
        }
    }
    
    public function quit() {
        $this->shouldQuit = true;
    }
}
