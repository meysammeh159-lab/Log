<?php
namespace LoginPro\Core\Queue;

class RetryHandler {
    private $maxAttempts = 3;
    private $backoff = [60, 300, 900];
    
    public function shouldRetry($attempts) {
        return $attempts < $this->maxAttempts;
    }
    
    public function getDelay($attempts) {
        $index = min($attempts, count($this->backoff) - 1);
        return $this->backoff[$index];
    }
    
    public function calculateNextAttempt($attempts) {
        if (!$this->shouldRetry($attempts)) {
            return null;
        }
        return time() + $this->getDelay($attempts);
    }
}
