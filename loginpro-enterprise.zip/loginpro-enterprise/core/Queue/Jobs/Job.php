<?php
namespace LoginPro\Core\Queue\Jobs;

abstract class Job {
    abstract public function handle($data = []);
}
