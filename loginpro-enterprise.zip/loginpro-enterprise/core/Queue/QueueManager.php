<?php
namespace LoginPro\Core\Queue;

use LoginPro\Core\Contracts\QueueInterface;

class QueueManager implements QueueInterface {
    private $connection;
    private $table;
    
    public function __construct() {
        global $wpdb;
        $this->connection = $wpdb;
        $this->table = $wpdb->prefix . 'loginpro_queue_jobs';
    }
    
    public function push($job, $data = [], $queue = null) {
        $queue = $queue ?: 'default';
        $payload = json_encode([
            'job' => $job,
            'data' => $data
        ]);
        
        return $this->connection->insert($this->table, [
            'queue' => $queue,
            'payload' => $payload,
            'attempts' => 0,
            'available_at' => time(),
            'created_at' => time()
        ]);
    }
    
    public function pushRaw($payload, $queue = null) {
        $queue = $queue ?: 'default';
        return $this->connection->insert($this->table, [
            'queue' => $queue,
            'payload' => $payload,
            'attempts' => 0,
            'available_at' => time(),
            'created_at' => time()
        ]);
    }
    
    public function later($delay, $job, $data = [], $queue = null) {
        $queue = $queue ?: 'default';
        $payload = json_encode([
            'job' => $job,
            'data' => $data
        ]);
        
        return $this->connection->insert($this->table, [
            'queue' => $queue,
            'payload' => $payload,
            'attempts' => 0,
            'available_at' => time() + $delay,
            'created_at' => time()
        ]);
    }
    
    public function pop($queue = null) {
        $queue = $queue ?: 'default';
        $job = $this->connection->get_row($this->connection->prepare(
            "SELECT * FROM {$this->table} 
            WHERE queue = %s 
            AND available_at <= %d 
            AND reserved_at IS NULL 
            ORDER BY available_at ASC 
            LIMIT 1",
            $queue,
            time()
        ));
        
        if ($job) {
            $this->connection->update(
                $this->table,
                ['reserved_at' => time()],
                ['id' => $job->id]
            );
        }
        
        return $job;
    }
    
    public function delete($job) {
        $jobId = is_object($job) ? $job->id : $job;
        return $this->connection->delete($this->table, ['id' => $jobId]);
    }
    
    public function release($job, $delay = 0) {
        $jobId = is_object($job) ? $job->id : $job;
        $jobObj = $this->connection->get_row($this->connection->prepare(
            "SELECT * FROM {$this->table} WHERE id = %d",
            $jobId
        ));
        
        if ($jobObj) {
            return $this->connection->update(
                $this->table,
                [
                    'attempts' => $jobObj->attempts + 1,
                    'reserved_at' => null,
                    'available_at' => time() + $delay
                ],
                ['id' => $jobId]
            );
        }
        
        return false;
    }
    
    public function process() {
        $job = $this->pop();
        if (!$job) {
            return false;
        }
        
        $payload = json_decode($job->payload, true);
        $jobClass = $payload['job'];
        $jobData = $payload['data'];
        
        if (class_exists($jobClass)) {
            $instance = new $jobClass();
            if (method_exists($instance, 'handle')) {
                try {
                    $instance->handle($jobData);
                    $this->delete($job);
                    return true;
                } catch (\Exception $e) {
                    $this->release($job, 60);
                    return false;
                }
            }
        }
        
        $this->delete($job);
        return false;
    }
}
