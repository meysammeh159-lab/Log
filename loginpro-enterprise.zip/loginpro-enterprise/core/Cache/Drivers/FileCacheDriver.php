<?php
namespace LoginPro\Core\Cache\Drivers;

class FileCacheDriver {
    private $path;
    
    public function __construct() {
        $this->path = LOGINPRO_PLUGIN_DIR . 'storage/framework/cache';
        if (!is_dir($this->path)) {
            mkdir($this->path, 0755, true);
        }
    }
    
    public function get($key) {
        $file = $this->getFilePath($key);
        if (!file_exists($file)) {
            return null;
        }
        
        $raw = file_get_contents($file);
        if ($raw === false || $raw === '') {
            return null;
        }
        
        $data = unserialize($raw, ['allowed_classes' => false]);
        if ($data === false || !is_array($data) || !array_key_exists('value', $data)) {
            // Corrupted or invalid cache entry, remove it.
            $this->delete($key);
            return null;
        }
        
        if (!empty($data['expires']) && $data['expires'] < time()) {
            $this->delete($key);
            return null;
        }
        
        return $data['value'];
    }
    
    public function set($key, $value, $ttl = null) {
        $expires = $ttl ? time() + $ttl : null;
        $data = [
            'value' => $value,
            'expires' => $expires
        ];
        
        $file = $this->getFilePath($key);
        return file_put_contents($file, serialize($data)) !== false;
    }
    
    public function delete($key) {
        $file = $this->getFilePath($key);
        if (file_exists($file)) {
            return unlink($file);
        }
        return true;
    }
    
    public function has($key) {
        return file_exists($this->getFilePath($key));
    }
    
    public function clear() {
        $files = glob($this->path . '/*.cache');
        foreach ($files as $file) {
            unlink($file);
        }
        return true;
    }
    
    private function getFilePath($key) {
        return $this->path . '/' . md5($key) . '.cache';
    }
}
