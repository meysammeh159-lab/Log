<?php
namespace LoginPro\Core\Cache\Drivers;

class RedisCacheDriver {
    private $redis;
    private $prefix;
    
    public function __construct() {
        if (!class_exists('Redis')) {
            throw new \Exception('Redis extension not loaded');
        }
        
        $this->redis = new \Redis();
        $this->redis->connect('127.0.0.1', 6379);
        $this->prefix = 'loginpro:';
    }
    
    public function get($key) {
        $value = $this->redis->get($this->prefix . $key);
        if ($value === false) {
            return null;
        }
        $data = unserialize($value, ['allowed_classes' => false]);
        return $data === false && $value !== serialize(false) ? null : $data;
    }
    
    public function set($key, $value, $ttl = null) {
        $value = serialize($value);
        if ($ttl) {
            return $this->redis->setex($this->prefix . $key, $ttl, $value);
        }
        return $this->redis->set($this->prefix . $key, $value);
    }
    
    public function delete($key) {
        return $this->redis->del($this->prefix . $key) > 0;
    }
    
    public function has($key) {
        return (bool) $this->redis->exists($this->prefix . $key);
    }
    
    public function clear() {
        $keys = $this->redis->keys($this->prefix . '*');
        foreach ($keys as $key) {
            $this->redis->del($key);
        }
        return true;
    }
}
