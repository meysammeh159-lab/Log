<?php
namespace LoginPro\Core\Cache\Drivers;

class WordPressCacheDriver {
    private $group;
    
    public function __construct() {
        $this->group = 'loginpro';
    }
    
    public function get($key) {
        return wp_cache_get($key, $this->group);
    }
    
    public function set($key, $value, $ttl = null) {
        return wp_cache_set($key, $value, $this->group, $ttl);
    }
    
    public function delete($key) {
        return wp_cache_delete($key, $this->group);
    }
    
    public function has($key) {
        return wp_cache_get($key, $this->group) !== false;
    }
    
    public function clear() {
        return wp_cache_flush();
    }
}
