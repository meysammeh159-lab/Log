<?php
/**
 * Cache Manager
 * مدیریت عملیات کش
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Core\Cache;

defined('ABSPATH') || exit;

use LoginPro\Core\Contracts\CacheInterface;

/**
 * کلاس مدیریت کش
 * 
 * این کلاس به عنوان واسط بین درخواست‌ها و درایورهای کش عمل می‌کند
 */
class CacheManager {
    
    /**
     * @var CacheInterface $driver درایور کش
     */
    private $driver;
    
    /**
     * @var array $config تنظیمات کش
     */
    private $config = [];
    
    /**
     * @var string $default_driver درایور پیش‌فرض
     */
    private $default_driver = 'wordpress';
    
    /**
     * @var array $drivers لیست درایورهای موجود
     */
    private $drivers = [];
    
    /**
     * Constructor
     * 
     * @param array $config تنظیمات
     */
    public function __construct($config = []) {
        $this->config = array_merge($this->config, $config);
        $this->default_driver = $this->config['default'] ?? $this->default_driver;
        $this->load_drivers();
        $this->initialize_driver();
    }
    
    /**
     * بارگذاری درایورها
     */
    private function load_drivers() {
        $drivers = [
            'wordpress' => 'WordPressCacheDriver',
            'file' => 'FileCacheDriver',
            'redis' => 'RedisCacheDriver',
        ];
        
        foreach ($drivers as $key => $class) {
            $class_name = 'LoginPro\\Core\\Cache\\Drivers\\' . $class;
            if (class_exists($class_name)) {
                $this->drivers[$key] = $class_name;
            }
        }
    }
    
    /**
     * مقداردهی اولیه درایور
     */
    private function initialize_driver() {
        if (isset($this->drivers[$this->default_driver])) {
            $driver_class = $this->drivers[$this->default_driver];
            $this->driver = new $driver_class();
        } else {
            // اگر درایور پیش‌فرض وجود نداشت، از اولین درایور موجود استفاده کن
            $first_driver = reset($this->drivers);
            if ($first_driver) {
                $this->driver = new $first_driver();
            } else {
                throw new \Exception('No cache driver available');
            }
        }
    }
    
    /**
     * تغییر درایور کش
     * 
     * @param string $driver نام درایور
     * @return bool
     */
    public function setDriver($driver) {
        if (isset($this->drivers[$driver])) {
            $driver_class = $this->drivers[$driver];
            $this->driver = new $driver_class();
            $this->default_driver = $driver;
            return true;
        }
        return false;
    }
    
    /**
     * دریافت درایور فعلی
     * 
     * @return string
     */
    public function getDriver() {
        return $this->default_driver;
    }
    
    /**
     * دریافت لیست درایورهای موجود
     * 
     * @return array
     */
    public function getAvailableDrivers() {
        return array_keys($this->drivers);
    }
    
    /**
     * دریافت مقدار از کش
     * 
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض
     * @return mixed
     */
    public function get($key, $default = null) {
        if (!$this->driver) {
            return $default;
        }
        return $this->driver->get($key, $default);
    }
    
    /**
     * ذخیره مقدار در کش
     * 
     * @param string $key کلید
     * @param mixed $value مقدار
     * @param int $ttl زمان انقضا (ثانیه)
     * @return bool
     */
    public function set($key, $value, $ttl = 0) {
        if (!$this->driver) {
            return false;
        }
        return $this->driver->set($key, $value, $ttl);
    }
    
    /**
     * حذف مقدار از کش
     * 
     * @param string $key کلید
     * @return bool
     */
    public function delete($key) {
        if (!$this->driver) {
            return false;
        }
        return $this->driver->delete($key);
    }
    
    /**
     * بررسی وجود کلید در کش
     * 
     * @param string $key کلید
     * @return bool
     */
    public function has($key) {
        if (!$this->driver) {
            return false;
        }
        return $this->driver->has($key);
    }
    
    /**
     * پاکسازی تمام کش
     * 
     * @return bool
     */
    public function clear() {
        if (!$this->driver) {
            return false;
        }
        return $this->driver->clear();
    }
    
    /**
     * دریافت چندین مقدار
     * 
     * @param array $keys لیست کلیدها
     * @return array
     */
    public function getMultiple($keys) {
        if (!$this->driver) {
            return array_fill_keys($keys, null);
        }
        return $this->driver->getMultiple($keys);
    }
    
    /**
     * ذخیره چندین مقدار
     * 
     * @param array $values آرایه کلید => مقدار
     * @param int $ttl زمان انقضا
     * @return bool
     */
    public function setMultiple($values, $ttl = 0) {
        if (!$this->driver) {
            return false;
        }
        return $this->driver->setMultiple($values, $ttl);
    }
    
    /**
     * حذف چندین کلید
     * 
     * @param array $keys لیست کلیدها
     * @return bool
     */
    public function deleteMultiple($keys) {
        if (!$this->driver) {
            return false;
        }
        return $this->driver->deleteMultiple($keys);
    }
    
    /**
     * دریافت وضعیت کش
     * 
     * @return array
     */
    public function getStats() {
        if (!$this->driver) {
            return ['error' => 'No cache driver available'];
        }
        return $this->driver->getStats();
    }
    
    /**
     * متد جادویی برای فراخوانی مستقیم متدهای درایور
     * 
     * @param string $name نام متد
     * @param array $arguments آرگومان‌ها
     * @return mixed
     */
    public function __call($name, $arguments) {
        if ($this->driver && method_exists($this->driver, $name)) {
            return call_user_func_array([$this->driver, $name], $arguments);
        }
        throw new \Exception("Method {$name} not found in cache driver");
    }
}

// ==================================================
// ✅ تابع کمکی برای دسترسی آسان به کش
// ==================================================

if (!function_exists('loginpro_cache')) {
    /**
     * دریافت نمونه CacheManager
     * 
     * @return CacheManager
     */
    function loginpro_cache() {
        static $cache = null;
        if ($cache === null) {
            $cache = new CacheManager();
        }
        return $cache;
    }
}