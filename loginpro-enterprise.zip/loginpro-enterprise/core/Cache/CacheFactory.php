<?php
namespace LoginPro\Core\Cache;

class CacheFactory {
    public static function make($driver = null) {
        $driver = $driver ?: apply_filters('loginpro_default_cache_driver', 'file');
        return new CacheManager();
    }
}
