<?php
namespace LoginPro\Core\Http;

class Response {
    public static function json($data, $status = 200) {
        wp_send_json($data, $status);
    }
    
    public static function redirect($url, $status = 302) {
        wp_redirect($url, $status);
        exit;
    }
    
    public static function view($view, $data = []) {
        $viewPath = LOGINPRO_PLUGIN_DIR . "frontend/Views/{$view}.php";
        extract($data, EXTR_SKIP);
        if (file_exists($viewPath)) {
            include $viewPath;
        }
        return $viewPath;
    }
    
    public static function make($content, $status = 200, $headers = []) {
        foreach ($headers as $key => $value) {
            header("{$key}: {$value}");
        }
        http_response_code($status);
        echo $content;
        return new static();
    }
}
