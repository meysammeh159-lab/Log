<?php
/**
 * Base Controller Class
 * کلاس پایه برای تمام کنترلرها
 */

namespace LoginPro\Core\Http;

abstract class Controller
{
    /**
     * پاسخ JSON موفق
     */
    protected function jsonSuccess($data = null, $message = '')
    {
        wp_send_json_success($data, $message);
    }

    /**
     * پاسخ JSON خطا
     */
    protected function jsonError($message = '', $code = 400)
    {
        wp_send_json_error(['message' => $message], $code);
    }

    /**
     * بررسی nonce
     */
    protected function verifyNonce($nonce, $action)
    {
        return wp_verify_nonce($nonce, $action);
    }

    /**
     * دریافت پارامتر از درخواست
     */
    protected function getParam($key, $default = null)
    {
        return isset($_REQUEST[$key]) ? sanitize_text_field($_REQUEST[$key]) : $default;
    }

    /**
     * دریافت پارامتر POST
     */
    protected function getPost($key, $default = null)
    {
        return isset($_POST[$key]) ? sanitize_text_field($_POST[$key]) : $default;
    }

    /**
     * دریافت پارامتر GET
     */
    protected function getGet($key, $default = null)
    {
        return isset($_GET[$key]) ? sanitize_text_field($_GET[$key]) : $default;
    }

    /**
     * بررسی لاگین بودن کاربر
     */
    protected function isUserLoggedIn()
    {
        return is_user_logged_in();
    }

    /**
     * دریافت کاربر فعلی
     */
    protected function getCurrentUser()
    {
        return wp_get_current_user();
    }

    /**
     * دریافت ID کاربر فعلی
     */
    protected function getCurrentUserId()
    {
        return get_current_user_id();
    }

    /**
     * بررسی دسترسی مدیر
     */
    protected function isAdmin()
    {
        return current_user_can('manage_options');
    }
}