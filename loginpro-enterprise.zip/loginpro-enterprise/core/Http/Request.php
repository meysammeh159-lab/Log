<?php
namespace LoginPro\Core\Http;

defined('ABSPATH') || exit;

class Request {
    private array $query = [];
    private array $request = [];
    private array $server = [];
    private array $files = [];
    private array $cookies = [];
    private array $trustedProxies = [];
    
    public function __construct() {
        $this->query = $_GET;
        $this->request = $_POST;
        $this->server = $_SERVER;
        $this->files = $_FILES;
        $this->cookies = $_COOKIE;
        $this->trustedProxies = apply_filters('loginpro_trusted_proxies', ['127.0.0.1']);
    }
    
    public static function capture(): self {
        return new static();
    }
    
    public function get(string $key, $default = null) {
        return $this->query[$key] ?? $default;
    }
    
    public function post(string $key, $default = null) {
        return $this->request[$key] ?? $default;
    }
    
    public function input(string $key, $default = null) {
        return $this->request[$key] ?? $this->query[$key] ?? $default;
    }
    
    public function all(): array {
        return array_merge($this->query, $this->request);
    }
    
    public function only($keys): array {
        $results = [];
        foreach ((array)$keys as $key) {
            $results[$key] = $this->input($key);
        }
        return $results;
    }
    
    public function has(string $key): bool {
        return isset($this->request[$key]) || isset($this->query[$key]);
    }
    
    public function validate(array $rules): array {
        $errors = [];
        foreach ($rules as $field => $rule) {
            $value = $this->input($field);
            $ruleParts = explode('|', $rule);
            
            foreach ($ruleParts as $singleRule) {
                if ($singleRule === 'required' && ($value === null || $value === '')) {
                    $errors[$field] = "فیلد {$field} الزامی است";
                }
                if (strpos($singleRule, 'min:') === 0) {
                    $min = (int)substr($singleRule, 4);
                    if (strlen((string)$value) < $min) {
                        $errors[$field] = "فیلد {$field} باید حداقل {$min} کاراکتر باشد";
                    }
                }
                if (strpos($singleRule, 'max:') === 0) {
                    $max = (int)substr($singleRule, 4);
                    if (strlen((string)$value) > $max) {
                        $errors[$field] = "فیلد {$field} باید حداکثر {$max} کاراکتر باشد";
                    }
                }
                if ($singleRule === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$field] = "فیلد {$field} باید یک ایمیل معتبر باشد";
                }
                if ($singleRule === 'numeric' && !is_numeric($value)) {
                    $errors[$field] = "فیلد {$field} باید عددی باشد";
                }
            }
        }
        
        if (!empty($errors)) {
            throw new \Exception(json_encode($errors, JSON_UNESCAPED_UNICODE));
        }
        
        return $this->only(array_keys($rules));
    }
    
    public function expectsJson(): bool {
        return strpos($this->server['HTTP_ACCEPT'] ?? '', 'application/json') !== false;
    }
    
    public function method(): string {
        return $this->server['REQUEST_METHOD'] ?? 'GET';
    }
    
    /**
     * دریافت IP واقعی با پشتیبانی از Proxy
     */
    public function ip(): string {
        $ip = $this->server['REMOTE_ADDR'] ?? '0.0.0.0';
        
        // فقط اگر درخواست از پروکسی مورد اعتماد باشد، هدرها بررسی می‌شوند
        if ($this->isTrustedProxy($ip)) {
            $forwardedIp = $this->getForwardedIp();
            if ($forwardedIp) {
                return $forwardedIp;
            }
        }
        
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
    }
    
    /**
     * بررسی Trusted Proxy
     */
    private function isTrustedProxy(string $ip): bool {
        return in_array($ip, $this->trustedProxies, true);
    }
    
    /**
     * استخراج IP از هدرهای Proxy
     */
    private function getForwardedIp(): ?string {
        // X-Forwarded-For
        if (!empty($this->server['HTTP_X_FORWARDED_FOR'])) {
            $ips = array_map('trim', explode(',', $this->server['HTTP_X_FORWARDED_FOR']));
            foreach ($ips as $forwardedIp) {
                if (filter_var($forwardedIp, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $forwardedIp;
                }
            }
        }
        
        // HTTP_CLIENT_IP
        if (!empty($this->server['HTTP_CLIENT_IP'])) {
            $clientIp = $this->server['HTTP_CLIENT_IP'];
            if (filter_var($clientIp, FILTER_VALIDATE_IP)) {
                return $clientIp;
            }
        }
        
        return null;
    }
    
    public function userAgent(): string {
        return $this->server['HTTP_USER_AGENT'] ?? '';
    }
    
    public function getUri(): string {
        return $this->server['REQUEST_URI'] ?? '';
    }
    
    public function bearerToken(): ?string {
        $header = $this->server['HTTP_AUTHORIZATION'] ?? '';
        if (empty($header)) {
            $header = $this->server['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        }
        
        if (strpos($header, 'Bearer ') === 0) {
            return substr($header, 7);
        }
        
        return null;
    }
    
    public function isSecure(): bool {
        return (!empty($this->server['HTTPS']) && $this->server['HTTPS'] !== 'off')
            || (($this->server['SERVER_PORT'] ?? 80) == 443);
    }
    
    /**
     * تولید Device Fingerprint
     */
    public function deviceFingerprint(): string {
        $components = [
            $this->userAgent(),
            $this->server['HTTP_ACCEPT'] ?? '',
            $this->server['HTTP_ACCEPT_LANGUAGE'] ?? '',
            $this->server['HTTP_ACCEPT_ENCODING'] ?? '',
            $this->ip(),
        ];
        return hash('sha256', implode('|', $components));
    }
    
    /**
     * دریافت Session Token از Header یا POST
     */
    public function sessionToken(): ?string {
        return $this->input('session_token') 
            ?? $this->server['HTTP_X_SESSION_TOKEN'] 
            ?? $this->bearerToken();
    }
    
    /**
     * دریافت CSRF Token
     */
    public function csrfToken(): ?string {
        return $this->input('_csrf_token')
            ?? $this->server['HTTP_X_CSRF_TOKEN']
            ?? null;
    }
}