<?php
namespace LoginPro\Core\Http;

class Router {
    private static $routes = [];
    private static $middlewares = [];
    
    public static function get($path, $handler) {
        self::addRoute('GET', $path, $handler);
    }
    
    public static function post($path, $handler) {
        self::addRoute('POST', $path, $handler);
    }
    
    public static function put($path, $handler) {
        self::addRoute('PUT', $path, $handler);
    }
    
    public static function delete($path, $handler) {
        self::addRoute('DELETE', $path, $handler);
    }
    
    private static function addRoute($method, $path, $handler) {
        self::$routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler,
            'middleware' => []
        ];
    }
    
    public static function middleware($name, $callback) {
        self::$middlewares[$name] = $callback;
    }
    
    public static function group($middleware, $callback) {
        $callback();
    }
    
    public static function dispatch() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        foreach (self::$routes as $route) {
            if ($route['method'] === $method && self::matchPath($route['path'], $path)) {
                $handler = $route['handler'];
                
                if (is_array($handler)) {
                    $controller = new $handler[0]();
                    $method = $handler[1];
                    return call_user_func([$controller, $method], Request::capture());
                } elseif (is_callable($handler)) {
                    return $handler(Request::capture());
                }
                return;
            }
        }
        
        return self::notFound();
    }
    
    private static function matchPath($routePath, $requestPath) {
        $routePattern = preg_replace('/{([^}]+)}/', '(?P<$1>[^/]+)', $routePath);
        $routePattern = '#^' . $routePattern . '$#';
        return preg_match($routePattern, $requestPath);
    }
    
    private static function notFound() {
        status_header(404);
        wp_die('404 - Route not found', 'Not Found', ['response' => 404]);
    }
}
