<?php
namespace LoginPro\Core\Http;

class Kernel {
    protected $middleware = [
        \LoginPro\Core\Http\Middleware\CsrfMiddleware::class,
    ];
    
    protected $routeMiddleware = [
        'auth' => \LoginPro\Modules\Auth\Middleware\AuthMiddleware::class,
        'guest' => \LoginPro\Modules\Auth\Middleware\GuestMiddleware::class,
        'admin' => \LoginPro\Admin\Middleware\AdminAuthMiddleware::class,
    ];
    
    public function handle(Request $request) {
        return $request;
    }
    
    public function getMiddleware() {
        return $this->middleware;
    }
    
    public function getRouteMiddleware($name) {
        return $this->routeMiddleware[$name] ?? null;
    }
}
