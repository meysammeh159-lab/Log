<?php
/**
 * Cron Integration Loader
 * بارگذاری تمام کلاس‌های مربوط به Cron Jobs
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ بارگذاری فایل‌های مورد نیاز
// ==================================================

$cron_files = [
    'Jobs/CleanupOtpsJob.php',
    'Jobs/CleanupSessionsJob.php',
    'Jobs/CleanupLogsJob.php',
    'Jobs/SecurityCleanupJob.php',
    'Jobs/SyncUserDataJob.php',
    'Jobs/SendReportJob.php',
    'CronManager.php',
];

foreach ($cron_files as $file) {
    $file_path = __DIR__ . '/' . $file;
    if (file_exists($file_path)) {
        require_once $file_path;
    }
}

// ==================================================
// ✅ مقداردهی اولیه Cron Manager
// ==================================================

add_action('init', function() {
    if (class_exists('LoginPro_Cron_Manager')) {
        new LoginPro_Cron_Manager();
    }
}, 10);

// ==================================================
// ✅ ثبت زمان‌بندی‌های پیش‌فرض
// ==================================================

add_filter('cron_schedules', function($schedules) {
    // افزودن زمان‌بندی‌های سفارشی
    if (!isset($schedules['every_five_minutes'])) {
        $schedules['every_five_minutes'] = [
            'interval' => 300,
            'display' => __('هر ۵ دقیقه', 'loginpro')
        ];
    }
    
    if (!isset($schedules['every_hour'])) {
        $schedules['every_hour'] = [
            'interval' => 3600,
            'display' => __('هر ساعت', 'loginpro')
        ];
    }
    
    if (!isset($schedules['every_twelve_hours'])) {
        $schedules['every_twelve_hours'] = [
            'interval' => 43200,
            'display' => __('هر ۱۲ ساعت', 'loginpro')
        ];
    }
    
    return $schedules;
});

// ==================================================
// ✅ ثبت هوک‌های Cron
// ==================================================

add_action('loginpro_cron_cleanup_otps', 'loginpro_run_cleanup_otps');
add_action('loginpro_cron_cleanup_sessions', 'loginpro_run_cleanup_sessions');
add_action('loginpro_cron_cleanup_logs', 'loginpro_run_cleanup_logs');
add_action('loginpro_cron_security_cleanup', 'loginpro_run_security_cleanup');
add_action('loginpro_cron_sync_users', 'loginpro_run_sync_users');
add_action('loginpro_cron_send_report', 'loginpro_run_send_report');

// ==================================================
// ✅ توابع اجرایی Cron
// ==================================================

function loginpro_run_cleanup_otps() {
    if (class_exists('LoginPro_Cron_CleanupOtpsJob')) {
        $job = new LoginPro_Cron_CleanupOtpsJob();
        $job->execute();
    }
}

function loginpro_run_cleanup_sessions() {
    if (class_exists('LoginPro_Cron_CleanupSessionsJob')) {
        $job = new LoginPro_Cron_CleanupSessionsJob();
        $job->execute();
    }
}

function loginpro_run_cleanup_logs() {
    if (class_exists('LoginPro_Cron_CleanupLogsJob')) {
        $job = new LoginPro_Cron_CleanupLogsJob();
        $job->execute();
    }
}

function loginpro_run_security_cleanup() {
    if (class_exists('LoginPro_Cron_SecurityCleanupJob')) {
        $job = new LoginPro_Cron_SecurityCleanupJob();
        $job->execute();
    }
}

function loginpro_run_sync_users() {
    if (class_exists('LoginPro_Cron_SyncUserDataJob')) {
        $job = new LoginPro_Cron_SyncUserDataJob();
        $job->execute();
    }
}

function loginpro_run_send_report() {
    if (class_exists('LoginPro_Cron_SendReportJob')) {
        $job = new LoginPro_Cron_SendReportJob();
        $job->execute();
    }
}

// ==================================================
// ✅ فعال‌سازی/غیرفعال‌سازی Cron ها در هنگام فعال‌سازی افزونه
// ==================================================

register_activation_hook(LOGINPRO_PLUGIN_DIR . 'loginpro.php', function() {
    // زمان‌بندی‌های پیش‌فرض
    if (!wp_next_scheduled('loginpro_cron_cleanup_otps')) {
        wp_schedule_event(time(), 'every_hour', 'loginpro_cron_cleanup_otps');
    }
    
    if (!wp_next_scheduled('loginpro_cron_cleanup_sessions')) {
        wp_schedule_event(time(), 'every_twelve_hours', 'loginpro_cron_cleanup_sessions');
    }
    
    if (!wp_next_scheduled('loginpro_cron_cleanup_logs')) {
        wp_schedule_event(time(), 'daily', 'loginpro_cron_cleanup_logs');
    }
    
    if (!wp_next_scheduled('loginpro_cron_security_cleanup')) {
        wp_schedule_event(time(), 'daily', 'loginpro_cron_security_cleanup');
    }
    
    if (!wp_next_scheduled('loginpro_cron_sync_users')) {
        wp_schedule_event(time(), 'daily', 'loginpro_cron_sync_users');
    }
    
    if (!wp_next_scheduled('loginpro_cron_send_report')) {
        wp_schedule_event(time(), 'weekly', 'loginpro_cron_send_report');
    }
});

register_deactivation_hook(LOGINPRO_PLUGIN_DIR . 'loginpro.php', function() {
    // پاکسازی زمان‌بندی‌ها
    $crons = [
        'loginpro_cron_cleanup_otps',
        'loginpro_cron_cleanup_sessions',
        'loginpro_cron_cleanup_logs',
        'loginpro_cron_security_cleanup',
        'loginpro_cron_sync_users',
        'loginpro_cron_send_report'
    ];
    
    foreach ($crons as $cron) {
        if (wp_next_scheduled($cron)) {
            wp_clear_scheduled_hook($cron);
        }
    }
});

// ==================================================
// ✅ END OF FILE
// ==================================================