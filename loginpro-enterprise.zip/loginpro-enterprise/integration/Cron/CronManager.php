<?php
/**
 * Cron Manager Class
 * مدیریت و زمان‌بندی تمام Cron Jobs
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

/**
 * کلاس مدیریت Cron Jobs
 */
class LoginPro_Cron_Manager {
    
    /**
     * @var array $jobs لیست تمام Job ها
     */
    private $jobs = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->register_jobs();
        $this->schedule_jobs();
    }
    
    /**
     * ثبت تمام Job ها
     */
    private function register_jobs() {
        $this->jobs = [
            'cleanup_otps' => [
                'class' => 'LoginPro_Cron_CleanupOtpsJob',
                'schedule' => 'every_hour',
                'hook' => 'loginpro_cron_cleanup_otps',
                'enabled' => true
            ],
            'cleanup_sessions' => [
                'class' => 'LoginPro_Cron_CleanupSessionsJob',
                'schedule' => 'every_twelve_hours',
                'hook' => 'loginpro_cron_cleanup_sessions',
                'enabled' => true
            ],
            'cleanup_logs' => [
                'class' => 'LoginPro_Cron_CleanupLogsJob',
                'schedule' => 'daily',
                'hook' => 'loginpro_cron_cleanup_logs',
                'enabled' => true
            ],
            'security_cleanup' => [
                'class' => 'LoginPro_Cron_SecurityCleanupJob',
                'schedule' => 'daily',
                'hook' => 'loginpro_cron_security_cleanup',
                'enabled' => true
            ],
            'sync_users' => [
                'class' => 'LoginPro_Cron_SyncUserDataJob',
                'schedule' => 'daily',
                'hook' => 'loginpro_cron_sync_users',
                'enabled' => true
            ],
            'send_report' => [
                'class' => 'LoginPro_Cron_SendReportJob',
                'schedule' => 'weekly',
                'hook' => 'loginpro_cron_send_report',
                'enabled' => false // پیش‌فرض غیرفعال
            ]
        ];
    }
    
    /**
     * زمان‌بندی تمام Job ها
     */
    private function schedule_jobs() {
        foreach ($this->jobs as $job_id => $job_config) {
            if (!$job_config['enabled']) {
                continue;
            }
            
            if (!wp_next_scheduled($job_config['hook'])) {
                wp_schedule_event(time(), $job_config['schedule'], $job_config['hook']);
            }
        }
    }
    
    /**
     * اجرای یک Job خاص
     */
    public function run_job($job_id) {
        if (!isset($this->jobs[$job_id])) {
            return false;
        }
        
        $job_config = $this->jobs[$job_id];
        
        if (!class_exists($job_config['class'])) {
            return false;
        }
        
        $job = new $job_config['class']();
        
        if (method_exists($job, 'execute')) {
            return $job->execute();
        }
        
        return false;
    }
    
    /**
     * اجرای تمام Job ها
     */
    public function run_all_jobs() {
        $results = [];
        
        foreach ($this->jobs as $job_id => $job_config) {
            if (!$job_config['enabled']) {
                $results[$job_id] = 'disabled';
                continue;
            }
            
            $results[$job_id] = $this->run_job($job_id);
        }
        
        return $results;
    }
    
    /**
     * دریافت وضعیت یک Job
     */
    public function get_job_status($job_id) {
        if (!isset($this->jobs[$job_id])) {
            return null;
        }
        
        $job_config = $this->jobs[$job_id];
        $next_run = wp_next_scheduled($job_config['hook']);
        
        return [
            'id' => $job_id,
            'class' => $job_config['class'],
            'schedule' => $job_config['schedule'],
            'enabled' => $job_config['enabled'],
            'next_run' => $next_run ? date_i18n('Y-m-d H:i:s', $next_run) : 'not_scheduled',
            'hook' => $job_config['hook']
        ];
    }
    
    /**
     * دریافت لیست تمام Job ها با وضعیت
     */
    public function get_all_jobs_status() {
        $status = [];
        
        foreach ($this->jobs as $job_id => $job_config) {
            $status[$job_id] = $this->get_job_status($job_id);
        }
        
        return $status;
    }
    
    /**
     * فعال/غیرفعال کردن یک Job
     */
    public function toggle_job($job_id, $enabled) {
        if (!isset($this->jobs[$job_id])) {
            return false;
        }
        
        $this->jobs[$job_id]['enabled'] = (bool)$enabled;
        
        if ($enabled) {
            // زمان‌بندی مجدد
            if (!wp_next_scheduled($this->jobs[$job_id]['hook'])) {
                wp_schedule_event(time(), $this->jobs[$job_id]['schedule'], $this->jobs[$job_id]['hook']);
            }
        } else {
            // پاکسازی زمان‌بندی
            if (wp_next_scheduled($this->jobs[$job_id]['hook'])) {
                wp_clear_scheduled_hook($this->jobs[$job_id]['hook']);
            }
        }
        
        return true;
    }
}