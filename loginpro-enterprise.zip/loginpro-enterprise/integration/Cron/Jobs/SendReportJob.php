<?php
/**
 * Send Report Job
 * ارسال گزارش دوره‌ای به مدیر
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_Cron_SendReportJob {
    
    /**
     * @var array $report_recipients گیرندگان گزارش
     */
    private $report_recipients = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->report_recipients = $this->get_recipients();
    }
    
    /**
     * اجرای Job
     */
    public function execute() {
        if (empty($this->report_recipients)) {
            $this->log('No recipients for report', 'warning');
            return false;
        }
        
        // جمع‌آوری داده‌های گزارش
        $report_data = $this->collect_report_data();
        
        // ساخت گزارش
        $report_html = $this->build_report_html($report_data);
        
        // ارسال گزارش به همه گیرندگان
        $sent_count = 0;
        
        foreach ($this->report_recipients as $email) {
            if ($this->send_report_email($email, $report_html, $report_data)) {
                $sent_count++;
            }
        }
        
        $this->log(sprintf('Report sent to %d recipients', $sent_count), 'info');
        
        return $sent_count > 0;
    }
    
    /**
     * دریافت لیست گیرندگان
     */
    private function get_recipients() {
        $recipients = get_option('loginpro_report_recipients', '');
        
        if (empty($recipients)) {
            // پیش‌فرض: ایمیل مدیر
            return [get_option('admin_email')];
        }
        
        // تبدیل به آرایه
        $emails = array_map('trim', explode(',', $recipients));
        $emails = array_filter($emails, 'is_email');
        
        return $emails;
    }
    
    /**
     * جمع‌آوری داده‌های گزارش
     */
    private function collect_report_data() {
        global $wpdb;
        
        $data = [
            'period' => [
                'start' => date('Y-m-d H:i:s', strtotime('-7 days')),
                'end' => current_time('mysql')
            ],
            'users' => [],
            'logins' => [],
            'security' => [],
            'tickets' => []
        ];
        
        // آمار کاربران
        $data['users']['total'] = count_users()['total_users'];
        $data['users']['new'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered > %s",
                $data['period']['start']
            )
        );
        
        // آمار ورود
        $table_login_history = $wpdb->prefix . 'loginpro_login_history';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_login_history'");
        
        if ($table_exists) {
            $data['logins']['total'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE created_at > %s",
                    $table_login_history,
                    $data['period']['start']
                )
            );
            
            $data['logins']['successful'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE status = 'success' AND created_at > %s",
                    $table_login_history,
                    $data['period']['start']
                )
            );
            
            $data['logins']['failed'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE status = 'failed' AND created_at > %s",
                    $table_login_history,
                    $data['period']['start']
                )
            );
        }
        
        // آمار امنیتی
        $table_security = $wpdb->prefix . 'loginpro_security_events';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_security'");
        
        if ($table_exists) {
            $data['security']['total'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE created_at > %s",
                    $table_security,
                    $data['period']['start']
                )
            );
            
            $data['security']['blocked'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE type = 'blocked' AND created_at > %s",
                    $table_security,
                    $data['period']['start']
                )
            );
        }
        
        // آمار تیکت‌ها
        $table_tickets = $wpdb->prefix . 'loginpro_tickets';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_tickets'");
        
        if ($table_exists) {
            $data['tickets']['total'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE created_at > %s",
                    $table_tickets,
                    $data['period']['start']
                )
            );
            
            $data['tickets']['pending'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE status = 'pending' AND created_at > %s",
                    $table_tickets,
                    $data['period']['start']
                )
            );
            
            $data['tickets']['closed'] = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE status = 'closed' AND created_at > %s",
                    $table_tickets,
                    $data['period']['start']
                )
            );
        }
        
        return $data;
    }
    
    /**
     * ساخت HTML گزارش
     */
    private function build_report_html($data) {
        $site_name = get_bloginfo('name');
        $site_url = home_url();
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Tahoma, Arial, sans-serif; direction: rtl; padding: 20px; }
                .container { max-width: 800px; margin: 0 auto; background: #f8f9fa; border-radius: 12px; padding: 30px; }
                .header { text-align: center; padding-bottom: 20px; border-bottom: 2px solid #ef394e; }
                .header h1 { color: #ef394e; margin: 0; }
                .header p { color: #666; margin: 5px 0 0; }
                .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin: 20px 0; }
                .stat-card { background: #fff; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
                .stat-card .number { font-size: 28px; font-weight: bold; color: #ef394e; }
                .stat-card .label { font-size: 12px; color: #999; margin-top: 5px; }
                .section { margin: 20px 0; padding: 15px; background: #fff; border-radius: 8px; }
                .section h3 { margin: 0 0 10px; color: #333; border-bottom: 1px solid #eee; padding-bottom: 10px; }
                .section table { width: 100%; border-collapse: collapse; }
                .section table td { padding: 8px 5px; border-bottom: 1px solid #f5f5f5; }
                .section table .label { color: #666; }
                .section table .value { font-weight: bold; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #999; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>📊 گزارش هفتگی ' . esc_html($site_name) . '</h1>
                    <p>از ' . esc_html($data['period']['start']) . ' تا ' . esc_html($data['period']['end']) . '</p>
                </div>
                
                <div class="stats">
                    <div class="stat-card">
                        <div class="number">' . number_format($data['users']['new']) . '</div>
                        <div class="label">کاربران جدید</div>
                    </div>
                    <div class="stat-card">
                        <div class="number">' . number_format($data['users']['total']) . '</div>
                        <div class="label">کل کاربران</div>
                    </div>
                    <div class="stat-card">
                        <div class="number">' . number_format($data['logins']['total'] ?? 0) . '</div>
                        <div class="label">ورودها</div>
                    </div>
                    <div class="stat-card">
                        <div class="number">' . number_format($data['security']['blocked'] ?? 0) . '</div>
                        <div class="label">حملات مسدود شده</div>
                    </div>
                </div>
                
                <div class="section">
                    <h3>🔐 آمار ورود</h3>
                    <table>
                        <tr><td class="label">ورود موفق</td><td class="value">' . number_format($data['logins']['successful'] ?? 0) . '</td></tr>
                        <tr><td class="label">ورود ناموفق</td><td class="value">' . number_format($data['logins']['failed'] ?? 0) . '</td></tr>
                        <tr><td class="label">نرخ موفقیت</td><td class="value">' . (($data['logins']['total'] ?? 0) > 0 ? round(($data['logins']['successful'] ?? 0) / ($data['logins']['total'] ?? 1) * 100, 1) : 0) . '%</td></tr>
                    </table>
                </div>
                
                <div class="section">
                    <h3>🛡️ امنیت</h3>
                    <table>
                        <tr><td class="label">رویدادهای امنیتی</td><td class="value">' . number_format($data['security']['total'] ?? 0) . '</td></tr>
                        <tr><td class="label">حملات مسدود شده</td><td class="value">' . number_format($data['security']['blocked'] ?? 0) . '</td></tr>
                    </table>
                </div>
                
                <div class="section">
                    <h3>🎫 تیکت‌ها</h3>
                    <table>
                        <tr><td class="label">تیکت‌های جدید</td><td class="value">' . number_format($data['tickets']['total'] ?? 0) . '</td></tr>
                        <tr><td class="label">در انتظار پاسخ</td><td class="value">' . number_format($data['tickets']['pending'] ?? 0) . '</td></tr>
                        <tr><td class="label">بسته شده</td><td class="value">' . number_format($data['tickets']['closed'] ?? 0) . '</td></tr>
                    </table>
                </div>
                
                <div class="footer">
                    <p>این گزارش به صورت خودکار توسط لاگین‌پرو ارسال شده است.</p>
                    <p><a href="' . esc_url($site_url) . '">' . esc_html($site_name) . '</a></p>
                </div>
            </div>
        </body>
        </html>';
        
        return $html;
    }
    
    /**
     * ارسال ایمیل گزارش
     */
    private function send_report_email($recipient, $html, $data) {
        $subject = sprintf(__('📊 گزارش هفتگی %s', 'loginpro'), get_bloginfo('name'));
        
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>'
        ];
        
        return wp_mail($recipient, $subject, $html, $headers);
    }
    
    /**
     * ثبت لاگ
     */
    private function log($message, $level = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro Cron] [' . strtoupper($level) . '] ' . $message);
        }
    }
}