<?php
/**
 * Security Cleanup Job
 * پاکسازی رویدادهای امنیتی قدیمی
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_Cron_SecurityCleanupJob {
    
    /**
     * @var int $keep_days تعداد روزهایی که رویدادهای امنیتی نگهداری شود
     */
    private $keep_days = 90;
    
    /**
     * اجرای Job
     */
    public function execute() {
        global $wpdb;
        
        $tables = [
            $wpdb->prefix . 'loginpro_security_events',
            $wpdb->prefix . 'loginpro_failed_login_attempts',
            $wpdb->prefix . 'loginpro_login_history'
        ];
        
        $total_deleted = 0;
        
        foreach ($tables as $table) {
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
            
            if (!$table_exists) {
                continue;
            }
            
            $expiry_date = date('Y-m-d H:i:s', time() - ($this->keep_days * 86400));
            
            $deleted = $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM %i WHERE created_at < %s",
                    $table,
                    $expiry_date
                )
            );
            
            $total_deleted += $deleted;
            
            $this->log(sprintf('Deleted %d records from %s', $deleted, $table), 'info');
        }
        
        // حذف تلاش‌های ناموفق قدیمی از ترنزینت‌ها
        $this->cleanup_failed_attempts_transients();
        
        $this->log(sprintf('Security cleanup completed. Total deleted: %d records', $total_deleted), 'info');
        
        return true;
    }
    
    /**
     * پاکسازی ترنزینت‌های تلاش‌های ناموفق
     */
    private function cleanup_failed_attempts_transients() {
        global $wpdb;
        
        // حذف ترنزینت‌های منقضی شده
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM %i WHERE option_name LIKE %s AND option_value LIKE %s",
                $wpdb->options,
                '_transient_loginpro_failed_%',
                '%'
            )
        );
        
        $this->log(sprintf('Cleaned up %d failed attempts transients', $deleted), 'info');
    }
    
    /**
     * ثبت لاگ
     */
    private function log($message, $level = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro Cron] [' . strtoupper($level) . '] ' . $message);
        }
    }
}