<?php
/**
 * Cleanup Logs Job
 * پاکسازی لاگ‌های قدیمی
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_Cron_CleanupLogsJob {
    
    /**
     * @var int $keep_days تعداد روزهایی که لاگ نگهداری شود
     */
    private $keep_days = 30;
    
    /**
     * @var int $batch_size تعداد رکورد در هر بچ
     */
    private $batch_size = 1000;
    
    /**
     * اجرای Job
     */
    public function execute() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'loginpro_logs';
        
        // بررسی وجود جدول
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        
        if (!$table_exists) {
            $this->log('Table not found: ' . $table, 'warning');
            return false;
        }
        
        // محاسبه تاریخ انقضا
        $expiry_date = date('Y-m-d H:i:s', time() - ($this->keep_days * 86400));
        
        // حذف تدریجی لاگ‌های قدیمی
        $total_deleted = 0;
        $deleted = $this->batch_size;
        
        while ($deleted === $this->batch_size) {
            $deleted = $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM %i WHERE created_at < %s LIMIT %d",
                    $table,
                    $expiry_date,
                    $this->batch_size
                )
            );
            
            $total_deleted += $deleted;
            
            // جلوگیری از بار زیاد سرور
            if ($deleted === $this->batch_size) {
                sleep(1);
            }
        }
        
        $this->log(sprintf('Deleted %d old log entries (older than %d days)', 
            $total_deleted, $this->keep_days), 'info');
        
        // بهینه‌سازی جدول
        if ($total_deleted > 0) {
            $wpdb->query("OPTIMIZE TABLE $table");
            $this->log('Table optimized: ' . $table, 'info');
        }
        
        return true;
    }
    
    /**
     * ثبت لاگ
     */
    private function log($message, $level = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro Cron] [' . strtoupper($level) . '] ' . $message);
        }
    }
}