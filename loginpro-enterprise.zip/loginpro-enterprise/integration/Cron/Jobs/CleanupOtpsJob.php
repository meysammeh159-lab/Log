<?php
/**
 * Cleanup OTPs Job
 * پاکسازی کدهای OTP منقضی شده
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_Cron_CleanupOtpsJob {
    
    /**
     * @var int $expiry_hours مدت زمان نگهداری OTP (به ساعت)
     */
    private $expiry_hours = 24;
    
    /**
     * اجرای Job
     */
    public function execute() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'loginpro_otps';
        
        // بررسی وجود جدول
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        
        if (!$table_exists) {
            $this->log('Table not found: ' . $table, 'warning');
            return false;
        }
        
        // محاسبه زمان انقضا
        $expiry_time = date('Y-m-d H:i:s', time() - ($this->expiry_hours * 3600));
        
        // حذف OTP های منقضی شده
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM %i WHERE created_at < %s",
                $table,
                $expiry_time
            )
        );
        
        $this->log(sprintf('Deleted %d expired OTPs', $deleted), 'info');
        
        return true;
    }
    
    /**
     * ثبت لاگ
     */
    private function log($message, $level = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro Cron] [' . strtoupper($level) . '] ' . $message);
        }
        
        // ذخیره در دیتابیس اگر جدول وجود دارد
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_logs';
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        
        if ($table_exists) {
            $wpdb->insert(
                $table,
                [
                    'action' => 'cron_cleanup_otps',
                    'details' => $message,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%s', '%s']
            );
        }
    }
}