<?php
/**
 * Cleanup Sessions Job
 * پاکسازی نشست‌های منقضی شده
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_Cron_CleanupSessionsJob {
    
    /**
     * @var int $max_age حداکثر عمر نشست (به روز)
     */
    private $max_age = 30;
    
    /**
     * اجرای Job
     */
    public function execute() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'loginpro_sessions';
        
        // بررسی وجود جدول
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        
        if (!$table_exists) {
            $this->log('Table not found: ' . $table, 'warning');
            return false;
        }
        
        // محاسبه تاریخ انقضا
        $expiry_date = date('Y-m-d H:i:s', time() - ($this->max_age * 86400));
        
        // حذف نشست‌های منقضی شده
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM %i WHERE last_activity < %s OR created_at < %s",
                $table,
                $expiry_date,
                $expiry_date
            )
        );
        
        // همچنین نشست‌های بدون کاربر را حذف کن
        $deleted_orphan = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM %i WHERE user_id = 0 AND created_at < %s",
                $table,
                date('Y-m-d H:i:s', time() - 86400) // 24 ساعت
            )
        );
        
        $total_deleted = $deleted + $deleted_orphan;
        
        $this->log(sprintf('Deleted %d expired sessions (expired: %d, orphan: %d)', 
            $total_deleted, $deleted, $deleted_orphan), 'info');
        
        return true;
    }
    
    /**
     * ثبت لاگ
     */
    private function log($message, $level = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro Cron] [' . strtoupper($level) . '] ' . $message);
        }
    }
}