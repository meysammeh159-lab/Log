<?php
/**
 * Sync User Data Job
 * همگام‌سازی اطلاعات کاربران با سرویس‌های خارجی
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_Cron_SyncUserDataJob {
    
    /**
     * @var int $batch_size تعداد کاربران در هر بچ
     */
    private $batch_size = 50;
    
    /**
     * اجرای Job
     */
    public function execute() {
        global $wpdb;
        
        // دریافت کاربرانی که نیاز به همگام‌سازی دارند
        $users = get_users([
            'meta_key' => 'loginpro_sync_required',
            'meta_value' => '1',
            'number' => $this->batch_size,
            'fields' => ['ID', 'user_email', 'display_name']
        ]);
        
        if (empty($users)) {
            $this->log('No users need synchronization', 'info');
            return true;
        }
        
        $synced_count = 0;
        $failed_count = 0;
        
        foreach ($users as $user) {
            $result = $this->sync_user($user);
            
            if ($result) {
                $synced_count++;
                delete_user_meta($user->ID, 'loginpro_sync_required');
                update_user_meta($user->ID, 'loginpro_last_sync', current_time('mysql'));
            } else {
                $failed_count++;
            }
        }
        
        $this->log(sprintf('User sync completed: %d synced, %d failed', 
            $synced_count, $failed_count), 'info');
        
        return true;
    }
    
    /**
     * همگام‌سازی یک کاربر
     */
    private function sync_user($user) {
        try {
            // اطلاعات کاربر
            $user_data = [
                'id' => $user->ID,
                'email' => $user->user_email,
                'name' => $user->display_name,
                'mobile' => get_user_meta($user->ID, 'loginpro_mobile', true),
                'role' => implode(', ', get_userdata($user->ID)->roles),
                'registered' => get_userdata($user->ID)->user_registered
            ];
            
            // ارسال به API خارجی (در صورت نیاز)
            $this->send_to_external_api($user_data);
            
            // به‌روزرسانی متادیتا
            update_user_meta($user->ID, 'loginpro_sync_data', json_encode($user_data));
            
            return true;
            
        } catch (Exception $e) {
            $this->log('Error syncing user ' . $user->ID . ': ' . $e->getMessage(), 'error');
            return false;
        }
    }
    
    /**
     * ارسال به API خارجی
     */
    private function send_to_external_api($user_data) {
        // این یک نمونه است - در صورت نیاز به اتصال به API خارجی پیاده‌سازی کنید
        $api_url = get_option('loginpro_sync_api_url', '');
        
        if (empty($api_url)) {
            return;
        }
        
        $api_key = get_option('loginpro_sync_api_key', '');
        
        $response = wp_remote_post($api_url, [
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key
            ],
            'body' => json_encode($user_data)
        ]);
        
        if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['success']) || !$data['success']) {
            throw new Exception('API returned error: ' . ($data['message'] ?? 'Unknown error'));
        }
    }
    
    /**
     * ثبت لاگ
     */
    private function log($message, $level = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro Cron] [' . strtoupper($level) . '] ' . $message);
        }
    }
    
    /**
     * علامت‌گذاری کاربر برای همگام‌سازی
     */
    public static function mark_for_sync($user_id) {
        if ($user_id) {
            update_user_meta($user_id, 'loginpro_sync_required', '1');
            return true;
        }
        return false;
    }
}