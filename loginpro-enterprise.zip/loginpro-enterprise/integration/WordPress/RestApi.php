<?php
/**
 * REST API Class - با کلاس‌های امنیتی
 * 
 * @package LoginPro
 * @version 3.0.14
 */

namespace LoginPro\Integration\WordPress;

defined('ABSPATH') || exit;

use LoginPro\Security\NonceManager;
use LoginPro\Security\RateLimiter;

class RestApi {
    
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }
    
    public function register_routes() {
        register_rest_route('loginpro/v1', '/login', [
            'methods' => 'POST',
            'callback' => [$this, 'api_login'],
            'permission_callback' => '__return_true'
        ]);
        
        register_rest_route('loginpro/v1', '/register', [
            'methods' => 'POST',
            'callback' => [$this, 'api_register'],
            'permission_callback' => '__return_true'
        ]);
        
        register_rest_route('loginpro/v1', '/user', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_user'],
            'permission_callback' => [$this, 'check_auth']
        ]);
        
        register_rest_route('loginpro/v1', '/tickets', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_tickets'],
            'permission_callback' => [$this, 'check_auth']
        ]);
    }
    
    public function check_auth($request) {
        $nonce = $request->get_header('X-WP-Nonce');
        $user_id = get_current_user_id();
        
        if (!$nonce || !NonceManager::verify($nonce, 'rest_api', $user_id)) {
            return false;
        }
        
        return is_user_logged_in();
    }
    
    public function api_login($request) {
        try {
            $ip = RateLimiter::get_ip();
            if (!RateLimiter::quick_check('api_login_' . $ip)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'تعداد درخواست بیش از حد مجاز'
                ], 429);
            }
            
            $username = sanitize_text_field($request->get_param('username') ?? '');
            $password = $request->get_param('password') ?? '';
            
            if (empty($username) || empty($password)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'نام کاربری و رمز عبور الزامی است'
                ], 400);
            }
            
            $user = wp_authenticate($username, $password);
            
            if (is_wp_error($user)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'نام کاربری یا رمز عبور اشتباه است'
                ], 401);
            }
            
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID);
            RateLimiter::reset('api_login_' . $ip);
            
            return new \WP_REST_Response([
                'success' => true,
                'message' => 'ورود موفق',
                'data' => [
                    'id' => $user->ID,
                    'display_name' => $user->display_name,
                    'email' => $user->user_email
                ]
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'خطا: ' . $e->getMessage()
            ], 500);
        }
    }
    
    public function api_register($request) {
        try {
            $ip = RateLimiter::get_ip();
            if (!RateLimiter::quick_check('api_register_' . $ip)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'تعداد درخواست بیش از حد مجاز'
                ], 429);
            }
            
            $username = sanitize_user($request->get_param('username') ?? '');
            $email = sanitize_email($request->get_param('email') ?? '');
            $password = $request->get_param('password') ?? '';
            
            if (empty($username) || empty($email) || empty($password)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'تمام فیلدها الزامی هستند'
                ], 400);
            }
            
            if (username_exists($username)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'نام کاربری قبلاً ثبت شده است'
                ], 400);
            }
            
            if (email_exists($email)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'ایمیل قبلاً ثبت شده است'
                ], 400);
            }
            
            if (strlen($password) < 6) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => 'رمز عبور باید حداقل 6 کاراکتر باشد'
                ], 400);
            }
            
            $user_id = wp_create_user($username, $password, $email);
            
            if (is_wp_error($user_id)) {
                return new \WP_REST_Response([
                    'success' => false,
                    'message' => $user_id->get_error_message()
                ], 400);
            }
            
            $user = get_userdata($user_id);
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id);
            RateLimiter::reset('api_register_' . $ip);
            
            return new \WP_REST_Response([
                'success' => true,
                'message' => 'ثبت نام موفق',
                'data' => [
                    'id' => $user->ID,
                    'display_name' => $user->display_name,
                    'email' => $user->user_email
                ]
            ], 201);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'خطا: ' . $e->getMessage()
            ], 500);
        }
    }
    
    public function api_get_user($request) {
        try {
            $user = wp_get_current_user();
            
            return new \WP_REST_Response([
                'success' => true,
                'data' => [
                    'id' => $user->ID,
                    'display_name' => $user->display_name,
                    'email' => $user->user_email,
                    'mobile' => get_user_meta($user->ID, 'loginpro_mobile', true)
                ]
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'خطا: ' . $e->getMessage()
            ], 500);
        }
    }
    
    public function api_get_tickets($request) {
        try {
            $user = wp_get_current_user();
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            $tickets = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE user_id = %d ORDER BY created_at DESC",
                $user->ID
            ));
            
            return new \WP_REST_Response([
                'success' => true,
                'data' => $tickets
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'خطا: ' . $e->getMessage()
            ], 500);
        }
    }
}

if (class_exists('LoginPro\Integration\WordPress\RestApi')) {
    new \LoginPro\Integration\WordPress\RestApi();
}