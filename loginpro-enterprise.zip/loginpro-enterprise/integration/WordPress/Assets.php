<?php

namespace LoginPro\Integration\WordPress;

defined('ABSPATH') || exit;


/**
 * Assets Manager
 *
 * مدیریت CSS و JS فرانت‌اند LoginPro
 */
class Assets
{

    public function enqueue(): void
    {

        if (!$this->shouldLoad()) {
            return;
        }



        /*
         * CSS
         */

        $cssFile = LOGINPRO_PATH . 'assets/css/loginpro.css';

        if (file_exists($cssFile)) {

            wp_enqueue_style(
                'loginpro-style',
                LOGINPRO_URL . 'assets/css/loginpro.css',
                [],
                filemtime($cssFile)
            );

        }




        /*
         * Frontend JS
         */

        $jsFile = LOGINPRO_PATH . 'assets/js/loginpro.js';

if (file_exists($jsFile)) {

    wp_enqueue_script(
        'loginpro-frontend',
        LOGINPRO_URL . 'assets/js/loginpro.js',
        [],
        filemtime($jsFile),
        true
    );


    wp_localize_script(
        'loginpro-frontend',
        'loginproConfig',
        [
            'ajaxUrl' => admin_url('admin-ajax.php'),

            'nonce' => wp_create_nonce(
                'loginpro_ajax_nonce'
            ),

            'strings' => [
                'error' =>
                    'خطایی رخ داد.',
                'otpSent' =>
                    'کد تایید ارسال شد.',
                'success' =>
                    'عملیات موفق بود.'
            ]
        ]
    );
}


            wp_localize_script(
                'loginpro-frontend',
                'LoginProConfig',
                [

                    'ajaxUrl' => admin_url(
                        'admin-ajax.php'
                    ),


                    'nonce' => wp_create_nonce(
                        'loginpro_nonce'
                    ),


                    'otpLength' => (int) get_option(
                        'loginpro_otp_length',
                        6
                    ),


                    'resendTime' => (int) get_option(
                        'loginpro_otp_resend_time',
                        60
                    ),


                    'isLoggedIn' => is_user_logged_in(),


                    'strings' => [

                        'loginSuccess' =>
                            __('ورود موفق بود.', 'loginpro'),


                        'loginFailed' =>
                            __('اطلاعات ورود صحیح نیست.', 'loginpro'),


                        'serverError' =>
                            __('خطای ارتباط با سرور.', 'loginpro'),

                    ]

                ]
            );

        }

    }




    private function shouldLoad(): bool
    {

        global $post;



        $loginPageId =
            (int) get_option(
                'loginpro_login_page_id',
                0
            );


        if (
            $loginPageId &&
            is_page($loginPageId)
        ) {

            return true;

        }



        if (
            isset($post) &&
            is_a($post, 'WP_Post') &&
            !empty($post->post_content)
        ) {


            $shortcodes = [

                'loginpro_login',
                'loginpro_register',
                'loginpro_reset_password',
                'loginpro_profile'

            ];



            foreach ($shortcodes as $shortcode) {


                if (
                    has_shortcode(
                        $post->post_content,
                        $shortcode
                    )
                ) {

                    return true;

                }

            }

        }



        $specialPages = [

            'login',
            'register',
            'profile',
            'reset-password'

        ];



        foreach ($specialPages as $slug) {


            if (
                is_page($slug)
            ) {

                return true;

            }

        }



        return false;

    }

}