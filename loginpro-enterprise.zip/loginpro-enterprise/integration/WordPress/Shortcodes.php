<?php
/**
 * Shortcodes Integration Class
 * 
 * @package LoginPro
 * @version 3.0.14
 */

namespace LoginPro\Integration\WordPress;

defined('ABSPATH') || exit;

class Shortcodes {
    
    public function __construct() {
        add_action('init', [$this, 'register_shortcodes']);
    }
    
    public function register_shortcodes() {
        // شورت‌کدهای اصلی در فایل loginpro.php ثبت شده‌اند
        // این کلاس برای توسعه‌های آینده نگهداری می‌شود
    }
}

if (class_exists('LoginPro\Integration\WordPress\Shortcodes')) {
    new \LoginPro\Integration\WordPress\Shortcodes();
}