<?php
/**
 * Admin Menu Class
 * 
 * @package LoginPro
 * @version 3.0.14
 */

namespace LoginPro\Integration\WordPress;

defined('ABSPATH') || exit;

class AdminMenu {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('لاگین‌پرو', 'loginpro'),
            __('لاگین‌پرو', 'loginpro'),
            'manage_options',
            'loginpro',
            [$this, 'render_dashboard_page'],
            'dashicons-lock',
            30
        );
    }
    
    public function render_dashboard_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('شما دسترسی لازم را ندارید', 'loginpro'));
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('داشبورد لاگین‌پرو', 'loginpro'); ?></h1>
            <p><?php esc_html_e('به پنل مدیریت لاگین‌پرو خوش آمدید.', 'loginpro'); ?></p>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-top:20px;">
                <div style="background:#fff;padding:20px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.05);">
                    <h3><?php esc_html_e('📊 آمار', 'loginpro'); ?></h3>
                    <p><?php esc_html_e('تعداد کاربران ثبت نام شده:', 'loginpro'); ?> <?php echo count_users()['total_users']; ?></p>
                </div>
                <div style="background:#fff;padding:20px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.05);">
                    <h3><?php esc_html_e('🔐 امنیت', 'loginpro'); ?></h3>
                    <p><?php esc_html_e('وضعیت: فعال', 'loginpro'); ?></p>
                </div>
                <div style="background:#fff;padding:20px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.05);">
                    <h3><?php esc_html_e('📝 تیکت‌ها', 'loginpro'); ?></h3>
                    <p><?php esc_html_e('تیکت‌های باز:', 'loginpro'); ?> 
                        <?php 
                        global $wpdb;
                        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}loginpro_tickets WHERE status != 'closed'");
                        echo intval($count);
                        ?>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }
}

if (class_exists('LoginPro\Integration\WordPress\AdminMenu')) {
    new \LoginPro\Integration\WordPress\AdminMenu();
}