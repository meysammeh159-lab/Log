<?php
/**
 * Cron Manager Class
 * 
 * @package LoginPro
 * @version 3.0.14
 */

namespace LoginPro\Integration\WordPress;

defined('ABSPATH') || exit;

class CronManager {
    
    public function __construct() {
        add_action('init', [$this, 'schedule_cron_jobs']);
        add_action('loginpro_cleanup_otps', [$this, 'cleanup_otps']);
        add_action('loginpro_cleanup_sessions', [$this, 'cleanup_sessions']);
        add_action('loginpro_cleanup_logs', [$this, 'cleanup_logs']);
        add_action('loginpro_security_cleanup', [$this, 'security_cleanup']);
    }
    
    public function schedule_cron_jobs() {
        if (!wp_next_scheduled('loginpro_cleanup_otps')) {
            wp_schedule_event(time(), 'hourly', 'loginpro_cleanup_otps');
        }
        
        if (!wp_next_scheduled('loginpro_cleanup_sessions')) {
            wp_schedule_event(time(), 'twicedaily', 'loginpro_cleanup_sessions');
        }
        
        if (!wp_next_scheduled('loginpro_cleanup_logs')) {
            wp_schedule_event(time(), 'daily', 'loginpro_cleanup_logs');
        }
        
        if (!wp_next_scheduled('loginpro_security_cleanup')) {
            wp_schedule_event(time(), 'daily', 'loginpro_security_cleanup');
        }
    }
    
    public function cleanup_otps() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_otps';
        $expiry = time() - (intval(get_option('loginpro_otp_expiry', 300)) + 3600);
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE created_at < %s",
            date('Y-m-d H:i:s', $expiry)
        ));
    }
    
    public function cleanup_sessions() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_sessions';
        $expiry = time() - 86400; // 24 ساعت
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE last_activity < %s",
            date('Y-m-d H:i:s', $expiry)
        ));
    }
    
    public function cleanup_logs() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_logs';
        $expiry = time() - 30 * 86400; // 30 روز
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE created_at < %s",
            date('Y-m-d H:i:s', $expiry)
        ));
    }
    
    public function security_cleanup() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_security_events';
        $expiry = time() - 90 * 86400; // 90 روز
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE created_at < %s",
            date('Y-m-d H:i:s', $expiry)
        ));
    }
}

if (class_exists('LoginPro\Integration\WordPress\CronManager')) {
    new \LoginPro\Integration\WordPress\CronManager();
}