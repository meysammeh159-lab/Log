<?php
/**
 * WooCommerce Order Service
 * سرویس‌های مربوط به سفارشات
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_WooCommerce_Order_Service {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('woocommerce_order_status_completed', [$this, 'handle_order_completed'], 10, 2);
        add_action('woocommerce_order_status_cancelled', [$this, 'handle_order_cancelled'], 10, 2);
        add_action('woocommerce_order_status_failed', [$this, 'handle_order_failed'], 10, 2);
        add_action('woocommerce_new_order', [$this, 'handle_new_order'], 10, 1);
    }
    
    /**
     * پردازش سفارش جدید
     */
    public function handle_new_order($order_id) {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return;
        }
        
        // ذخیره اطلاعات کاربر در متادیتا سفارش
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $mobile = get_user_meta($user_id, 'loginpro_mobile', true);
            
            if ($mobile) {
                $order->update_meta_data('_billing_mobile', $mobile);
                $order->save();
            }
        }
        
        // ثبت لاگ سفارش جدید
        $this->log_order_activity($order_id, 'new_order', [
            'user_id' => get_current_user_id(),
            'total' => $order->get_total(),
            'status' => $order->get_status()
        ]);
    }
    
    /**
     * پردازش سفارش تکمیل شده
     */
    public function handle_order_completed($order_id, $order) {
        // ثبت لاگ تکمیل سفارش
        $this->log_order_activity($order_id, 'completed', [
            'user_id' => $order->get_customer_id(),
            'total' => $order->get_total()
        ]);
        
        // به‌روزرسانی اطلاعات کاربر
        $this->update_user_from_order($order);
    }
    
    /**
     * پردازش سفارش لغو شده
     */
    public function handle_order_cancelled($order_id, $order) {
        $this->log_order_activity($order_id, 'cancelled', [
            'user_id' => $order->get_customer_id()
        ]);
    }
    
    /**
     * پردازش سفارش ناموفق
     */
    public function handle_order_failed($order_id, $order) {
        $this->log_order_activity($order_id, 'failed', [
            'user_id' => $order->get_customer_id()
        ]);
    }
    
    /**
     * به‌روزرسانی اطلاعات کاربر از سفارش
     */
    private function update_user_from_order($order) {
        $user_id = $order->get_customer_id();
        
        if (!$user_id) {
            return;
        }
        
        $mobile = $order->get_meta('_billing_mobile');
        if ($mobile) {
            update_user_meta($user_id, 'billing_mobile', $mobile);
            update_user_meta($user_id, 'loginpro_mobile', $mobile);
        }
    }
    
    /**
     * ثبت لاگ فعالیت سفارش
     */
    private function log_order_activity($order_id, $action, $data = []) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'loginpro_logs';
        
        // بررسی وجود جدول
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        
        if (!$table_exists) {
            return;
        }
        
        $wpdb->insert(
            $table,
            [
                'user_id' => $data['user_id'] ?? 0,
                'action' => 'woocommerce_' . $action,
                'details' => json_encode([
                    'order_id' => $order_id,
                    'data' => $data
                ]),
                'created_at' => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%s']
        );
    }
    
    /**
     * دریافت سابقه سفارشات کاربر
     */
    public function get_user_orders($user_id, $limit = 10) {
        $args = [
            'customer_id' => $user_id,
            'limit' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'return' => 'objects'
        ];
        
        return wc_get_orders($args);
    }
    
    /**
     * دریافت آمار خرید کاربر
     */
    public function get_user_stats($user_id) {
        $orders = wc_get_orders([
            'customer_id' => $user_id,
            'limit' => -1,
            'return' => 'ids'
        ]);
        
        $total_orders = count($orders);
        $total_spent = 0;
        
        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);
            if ($order && $order->get_status() === 'completed') {
                $total_spent += $order->get_total();
            }
        }
        
        return [
            'total_orders' => $total_orders,
            'total_spent' => $total_spent,
            'avg_order_value' => $total_orders > 0 ? $total_spent / $total_orders : 0
        ];
    }
}