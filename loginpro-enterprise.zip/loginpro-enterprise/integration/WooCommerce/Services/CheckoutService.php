<?php
/**
 * WooCommerce Checkout Service
 * سرویس‌های مربوط به صفحه تسویه حساب
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_WooCommerce_Checkout_Service {
    
    /**
     * @var array $errors خطاهای اعتبارسنجی
     */
    private $errors = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('woocommerce_checkout_process', [$this, 'validate_fields']);
        add_action('woocommerce_checkout_update_order_review', [$this, 'process_checkout'], 10, 1);
    }
    
    /**
     * اعتبارسنجی فیلدهای تسویه حساب
     */
    public function validate_fields() {
        // بررسی شماره موبایل
        if (isset($_POST['billing_mobile']) && !empty($_POST['billing_mobile'])) {
            $mobile = sanitize_text_field($_POST['billing_mobile']);
            $mobile = preg_replace('/[^0-9]/', '', $mobile);
            
            if (!preg_match('/^09[0-9]{9}$/', $mobile) && !preg_match('/^9[0-9]{9}$/', $mobile)) {
                wc_add_notice(
                    __('لطفاً شماره موبایل معتبر وارد کنید (09123456789)', 'loginpro'),
                    'error'
                );
                $this->errors[] = 'mobile_invalid';
            }
        }
        
        // بررسی ایمیل
        if (isset($_POST['billing_email']) && !empty($_POST['billing_email'])) {
            $email = sanitize_email($_POST['billing_email']);
            if (!is_email($email)) {
                wc_add_notice(
                    __('لطفاً یک ایمیل معتبر وارد کنید', 'loginpro'),
                    'error'
                );
                $this->errors[] = 'email_invalid';
            }
        }
    }
    
    /**
     * پردازش تسویه حساب
     */
    public function process_checkout($posted_data) {
        // به‌روزرسانی اطلاعات کاربر با اطلاعات تسویه حساب
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $data = json_decode($posted_data, true);
            
            if (isset($data['billing_mobile']) && !empty($data['billing_mobile'])) {
                update_user_meta($user_id, 'billing_mobile', sanitize_text_field($data['billing_mobile']));
                update_user_meta($user_id, 'loginpro_mobile', sanitize_text_field($data['billing_mobile']));
            }
            
            if (isset($data['billing_email']) && !empty($data['billing_email'])) {
                $email = sanitize_email($data['billing_email']);
                if (is_email($email) && $email !== wp_get_current_user()->user_email) {
                    wp_update_user([
                        'ID' => $user_id,
                        'user_email' => $email
                    ]);
                }
            }
        }
    }
    
    /**
     * دریافت خطاها
     */
    public function get_errors() {
        return $this->errors;
    }
    
    /**
     * بررسی وجود خطا
     */
    public function has_errors() {
        return !empty($this->errors);
    }
}