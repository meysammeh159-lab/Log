<?php
/**
 * WooCommerce Cart Hooks
 * هوک‌های مربوط به سبد خرید
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

class LoginPro_WooCommerce_Cart_Hooks {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('woocommerce_before_cart_table', [$this, 'show_login_notice'], 5);
        add_action('woocommerce_cart_is_empty', [$this, 'show_empty_cart_actions']);
        add_filter('woocommerce_add_to_cart_redirect', [$this, 'redirect_after_add_to_cart'], 10, 1);
        add_action('woocommerce_cart_updated', [$this, 'handle_cart_update']);
    }
    
    /**
     * نمایش پیام ورود در سبد خرید
     */
    public function show_login_notice() {
        if (!is_user_logged_in()) {
            $login_page = get_permalink(get_option('loginpro_login_page_id', 0));
            ?>
            <div class="woocommerce-info" style="margin-bottom:20px;">
                <span>
                    <?php esc_html_e('برای ذخیره سبد خرید و ادامه خرید، وارد شوید.', 'loginpro'); ?>
                </span>
                <a href="<?php echo esc_url($login_page); ?>" style="float:right;background:#ef394e;color:#fff;padding:5px 15px;border-radius:6px;text-decoration:none;">
                    <?php esc_html_e('ورود / ثبت نام', 'loginpro'); ?>
                </a>
            </div>
            <?php
        }
    }
    
    /**
     * نمایش اقدامات در سبد خرید خالی
     */
    public function show_empty_cart_actions() {
        if (!is_user_logged_in()) {
            $login_page = get_permalink(get_option('loginpro_login_page_id', 0));
            ?>
            <div style="text-align:center;padding:30px 0;">
                <p style="margin-bottom:15px;">
                    <?php esc_html_e('برای شروع خرید، وارد شوید یا ثبت نام کنید.', 'loginpro'); ?>
                </p>
                <a href="<?php echo esc_url($login_page); ?>" style="display:inline-block;background:#ef394e;color:#fff;padding:10px 30px;border-radius:8px;text-decoration:none;">
                    <?php esc_html_e('ورود / ثبت نام', 'loginpro'); ?>
                </a>
            </div>
            <?php
        } else {
            ?>
            <div style="text-align:center;padding:30px 0;">
                <p style="margin-bottom:15px;">
                    <?php esc_html_e('سبد خرید شما خالی است.', 'loginpro'); ?>
                </p>
                <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" style="display:inline-block;background:#ef394e;color:#fff;padding:10px 30px;border-radius:8px;text-decoration:none;">
                    <?php esc_html_e('مشاهده محصولات', 'loginpro'); ?>
                </a>
            </div>
            <?php
        }
    }
    
    /**
     * ریدایرکت بعد از افزودن به سبد خرید
     */
    public function redirect_after_add_to_cart($url) {
        $redirect_option = get_option('loginpro_woo_redirect_after_add', 'cart');
        
        if ($redirect_option === 'checkout') {
            return wc_get_checkout_url();
        } elseif ($redirect_option === 'continue') {
            return $url;
        }
        
        return $url;
    }
    
    /**
     * پردازش به‌روزرسانی سبد خرید
     */
    public function handle_cart_update() {
        $cart = WC()->cart;
        
        if (!$cart) {
            return;
        }
        
        // ذخیره سبد خرید برای کاربران لاگین شده
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $cart_data = $this->get_cart_data($cart);
            
            update_user_meta($user_id, '_loginpro_saved_cart', $cart_data);
        }
    }
    
    /**
     * دریافت داده‌های سبد خرید
     */
    private function get_cart_data($cart) {
        $data = [];
        
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $data[] = [
                'product_id' => $cart_item['product_id'],
                'quantity' => $cart_item['quantity'],
                'variation_id' => $cart_item['variation_id'] ?? 0,
                'variation' => $cart_item['variation'] ?? []
            ];
        }
        
        return $data;
    }
    
    /**
     * بازیابی سبد خرید ذخیره شده
     */
    public function restore_saved_cart() {
        if (!is_user_logged_in()) {
            return;
        }
        
        $user_id = get_current_user_id();
        $saved_cart = get_user_meta($user_id, '_loginpro_saved_cart', true);
        
        if (!$saved_cart || !is_array($saved_cart)) {
            return;
        }
        
        $cart = WC()->cart;
        $cart->empty_cart();
        
        foreach ($saved_cart as $item) {
            $cart->add_to_cart(
                $item['product_id'],
                $item['quantity'],
                $item['variation_id'] ?? 0,
                $item['variation'] ?? []
            );
        }
        
        delete_user_meta($user_id, '_loginpro_saved_cart');
    }
}