<?php
/**
 * LoginPro WooCommerce Integration Class
 * یکپارچه‌سازی سیستم احراز هویت لاگین‌پرو با ووکامرس
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

use LoginPro\Security\NonceManager;
use LoginPro\Security\PermissionChecker;
use LoginPro\Security\RateLimiter;

/**
 * کلاس اصلی یکپارچه‌سازی با ووکامرس
 */
class LoginPro_WooCommerce_Integration {
    
    /**
     * @var CheckoutService $checkout_service
     */
    private $checkout_service;
    
    /**
     * @var OrderService $order_service
     */
    private $order_service;
    
    /**
     * @var CartHooks $cart_hooks
     */
    private $cart_hooks;
    
    /**
     * Constructor
     */
    public function __construct() {
        // بارگذاری سرویس‌ها
        $this->checkout_service = new LoginPro_WooCommerce_Checkout_Service();
        $this->order_service = new LoginPro_WooCommerce_Order_Service();
        $this->cart_hooks = new LoginPro_WooCommerce_Cart_Hooks();
        
        // ثبت هوک‌ها
        $this->register_hooks();
    }
    
    /**
     * ثبت تمام هوک‌های مورد نیاز
     */
    private function register_hooks() {
        // ✅ نمایش فرم لاگین در صفحه تسویه حساب
        add_action('woocommerce_before_checkout_form', [$this, 'render_login_form'], 10);
        
        // ✅ افزودن فیلد موبایل به فرم تسویه حساب
        add_filter('woocommerce_checkout_fields', [$this, 'add_mobile_field']);
        
        // ✅ ذخیره شماره موبایل در سفارش
        add_action('woocommerce_checkout_update_order_meta', [$this, 'save_mobile_field'], 10, 2);
        
        // ✅ نمایش شماره موبایل در ادمین
        add_action('woocommerce_admin_order_data_after_shipping_address', [$this, 'display_mobile_in_admin']);
        
        // ✅ اعتبارسنجی شماره موبایل
        add_action('woocommerce_checkout_process', [$this, 'validate_mobile_field']);
        
        // ✅ افزودن شورت‌کد لاگین به صفحات ووکامرس
        add_shortcode('loginpro_woocommerce_login', [$this, 'render_shortcode_login']);
        
        // ✅ بررسی دسترسی به تسویه حساب برای کاربران لاگین نشده
        add_action('template_redirect', [$this, 'redirect_to_login_if_not_logged_in']);
        
        // ✅ افزودن دکمه ورود به صفحه سبد خرید
        add_action('woocommerce_before_cart', [$this, 'add_login_button_to_cart']);
        
        // ✅ تغییر لینک ورود در ووکامرس به شورت‌کد لاگین‌پرو
        add_filter('woocommerce_login_redirect', [$this, 'modify_login_redirect'], 10, 2);
        add_filter('woocommerce_registration_redirect', [$this, 'modify_registration_redirect'], 10, 1);
    }
    
    // ============================================
    // ✅ متدهای عمومی
    // ============================================
    
    /**
     * نمایش فرم لاگین در صفحه تسویه حساب
     */
    public function render_login_form() {
        if (is_user_logged_in()) {
            return;
        }
        
        $nonce = NonceManager::create('woocommerce_login', 0);
        
        ?>
        <div class="loginpro-woo-login-wrapper" style="background:#f8f9fa;padding:20px;border-radius:12px;margin-bottom:20px;">
            <h4 style="margin:0 0 10px;"><?php esc_html_e('👋 قبلاً ثبت نام کرده‌اید؟', 'loginpro'); ?></h4>
            <p style="margin:0 0 15px;color:#666;font-size:14px;">
                <?php esc_html_e('برای تسویه حساب سریع‌تر وارد شوید.', 'loginpro'); ?>
            </p>
            
            <div id="woo-login-message" style="display:none;margin-bottom:10px;padding:10px;border-radius:8px;"></div>
            
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <input type="text" id="woo-login-identifier" placeholder="<?php esc_attr_e('ایمیل یا نام کاربری', 'loginpro'); ?>" 
                       style="flex:1;min-width:200px;height:42px;padding:0 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;">
                <input type="password" id="woo-login-password" placeholder="<?php esc_attr_e('رمز عبور', 'loginpro'); ?>" 
                       style="flex:1;min-width:200px;height:42px;padding:0 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;">
                <button id="woo-login-btn" data-nonce="<?php echo esc_attr($nonce); ?>" 
                        style="background:#ef394e;color:#fff;border:none;border-radius:8px;padding:0 25px;cursor:pointer;font-size:14px;">
                    <?php esc_html_e('ورود', 'loginpro'); ?>
                </button>
            </div>
            
            <div style="margin-top:10px;font-size:13px;">
                <a href="#" id="woo-show-register" style="color:#ef394e;text-decoration:none;">
                    <?php esc_html_e('📝 ثبت نام جدید', 'loginpro'); ?>
                </a>
                <span style="margin:0 8px;color:#ddd;">|</span>
                <a href="#" id="woo-show-forgot" style="color:#ef394e;text-decoration:none;">
                    <?php esc_html_e('🔑 فراموشی رمز عبور', 'loginpro'); ?>
                </a>
            </div>
        </div>
        
        <style>
        #woo-login-identifier:focus, #woo-login-password:focus {
            border-color: #ef394e;
            outline: none;
            box-shadow: 0 0 0 2px rgba(239,57,78,0.2);
        }
        .loginpro-woo-login-wrapper {
            border: 1px solid #e8e8e8;
        }
        </style>
        
        <script type="text/javascript">
        (function() {
            'use strict';
            var btn = document.getElementById('woo-login-btn');
            var msg = document.getElementById('woo-login-message');
            
            if (btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    var identifier = document.getElementById('woo-login-identifier').value.trim();
                    var password = document.getElementById('woo-login-password').value;
                    var nonce = btn.getAttribute('data-nonce');
                    
                    if (!identifier || !password) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('لطفاً تمام فیلدها را پر کنید', 'loginpro')); ?>';
                        return;
                    }
                    
                    btn.disabled = true;
                    btn.textContent = '<?php echo esc_js(__('در حال ورود...', 'loginpro')); ?>';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_woo_login');
                    formData.append('_nonce', nonce);
                    formData.append('identifier', identifier);
                    formData.append('password', password);
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#f0fff4';
                            msg.style.color = '#28a745';
                            msg.style.border = '1px solid #c3e6cb';
                            msg.textContent = '✅ ' + response.data.message;
                            
                            if (response.data.redirect) {
                                setTimeout(function() {
                                    window.location.href = response.data.redirect;
                                }, 1000);
                            } else {
                                location.reload();
                            }
                        } else {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#fff5f5';
                            msg.style.color = '#dc3545';
                            msg.style.border = '1px solid #f5c6cb';
                            msg.textContent = '❌ ' + response.data.message;
                            btn.disabled = false;
                            btn.textContent = '<?php echo esc_js(__('ورود', 'loginpro')); ?>';
                        }
                    })
                    .catch(function(error) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('خطا در ارتباط با سرور', 'loginpro')); ?>: ' + error.message;
                        btn.disabled = false;
                        btn.textContent = '<?php echo esc_js(__('ورود', 'loginpro')); ?>';
                    });
                });
            }
            
            // Enter key support
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    var target = e.target;
                    if (target.id === 'woo-login-identifier' || target.id === 'woo-login-password') {
                        e.preventDefault();
                        var btn = document.getElementById('woo-login-btn');
                        if (btn) btn.click();
                    }
                }
            });
            
            // Show register link
            var showRegister = document.getElementById('woo-show-register');
            if (showRegister) {
                showRegister.addEventListener('click', function(e) {
                    e.preventDefault();
                    var registerUrl = '<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))); ?>';
                    window.location.href = registerUrl;
                });
            }
            
            // Show forgot password
            var showForgot = document.getElementById('woo-show-forgot');
            if (showForgot) {
                showForgot.addEventListener('click', function(e) {
                    e.preventDefault();
                    var forgotUrl = '<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))); ?>?lost_password=1';
                    window.location.href = forgotUrl;
                });
            }
        })();
        </script>
        <?php
    }
    
    /**
     * افزودن فیلد موبایل به فرم تسویه حساب
     */
    public function add_mobile_field($fields) {
        $fields['billing']['billing_mobile'] = [
            'label' => __('شماره موبایل', 'loginpro'),
            'required' => true,
            'class' => ['form-row-wide'],
            'clear' => true,
            'priority' => 25,
            'type' => 'tel',
            'validate' => ['phone'],
            'placeholder' => __('09xxxxxxxxx', 'loginpro'),
        ];
        
        return $fields;
    }
    
    /**
     * ذخیره شماره موبایل در سفارش
     */
    public function save_mobile_field($order_id, $posted) {
        if (isset($posted['billing_mobile'])) {
            update_post_meta($order_id, '_billing_mobile', sanitize_text_field($posted['billing_mobile']));
            
            // ذخیره در متادیتا کاربر اگر لاگین است
            if (is_user_logged_in()) {
                $user_id = get_current_user_id();
                update_user_meta($user_id, 'billing_mobile', sanitize_text_field($posted['billing_mobile']));
                update_user_meta($user_id, 'loginpro_mobile', sanitize_text_field($posted['billing_mobile']));
            }
        }
    }
    
    /**
     * نمایش شماره موبایل در ادمین
     */
    public function display_mobile_in_admin($order) {
        $mobile = get_post_meta($order->get_id(), '_billing_mobile', true);
        if ($mobile) {
            echo '<p><strong>' . esc_html__('شماره موبایل:', 'loginpro') . '</strong> ' . esc_html($mobile) . '</p>';
        }
    }
    
    /**
     * اعتبارسنجی شماره موبایل
     */
    public function validate_mobile_field() {
        $mobile = isset($_POST['billing_mobile']) ? sanitize_text_field($_POST['billing_mobile']) : '';
        
        if (!empty($mobile)) {
            // نرمال‌سازی شماره موبایل
            $mobile = preg_replace('/[^0-9]/', '', $mobile);
            if (!preg_match('/^09[0-9]{9}$/', $mobile) && !preg_match('/^9[0-9]{9}$/', $mobile)) {
                wc_add_notice(
                    __('لطفاً شماره موبایل معتبر وارد کنید (09123456789)', 'loginpro'),
                    'error'
                );
            }
        }
    }
    
    /**
     * شورت‌کد لاگین برای ووکامرس
     */
    public function render_shortcode_login($atts) {
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            return '<p style="text-align:center;">' . sprintf(
                __('👋 خوش آمدید %s', 'loginpro'),
                esc_html($user->display_name)
            ) . '</p>';
        }
        
        return do_shortcode('[loginpro_login]');
    }
    
    /**
     * ریدایرکت به صفحه لاگین اگر کاربر لاگین نیست
     */
    public function redirect_to_login_if_not_logged_in() {
        // فقط در صفحه تسویه حساب و سبد خرید
        if (is_checkout() || is_cart()) {
            if (!is_user_logged_in()) {
                // اجازه دسترسی به تسویه حساب با مهمان اگر تنظیمات اجازه دهد
                if (get_option('woocommerce_enable_guest_checkout', 'yes') === 'yes') {
                    return;
                }
                
                wp_safe_redirect(get_permalink(get_option('loginpro_login_page_id', 0)));
                exit;
            }
        }
    }
    
    /**
     * افزودن دکمه ورود به صفحه سبد خرید
     */
    public function add_login_button_to_cart() {
        if (!is_user_logged_in()) {
            $login_url = get_permalink(get_option('loginpro_login_page_id', 0));
            ?>
            <div style="background:#f8f9fa;padding:15px;border-radius:12px;text-align:center;margin-bottom:20px;">
                <p style="margin:0 0 10px;color:#666;">
                    <?php esc_html_e('برای ذخیره سبد خرید خود، وارد شوید.', 'loginpro'); ?>
                </p>
                <a href="<?php echo esc_url($login_url); ?>" style="display:inline-block;background:#ef394e;color:#fff;padding:8px 20px;border-radius:8px;text-decoration:none;">
                    <?php esc_html_e('ورود / ثبت نام', 'loginpro'); ?>
                </a>
            </div>
            <?php
        }
    }
    
    /**
     * تغییر لینک ریدایرکت لاگین
     */
    public function modify_login_redirect($redirect, $user) {
        $login_page = get_option('loginpro_login_page_id', 0);
        if ($login_page) {
            return get_permalink($login_page);
        }
        return $redirect;
    }
    
    /**
     * تغییر لینک ریدایرکت ثبت نام
     */
    public function modify_registration_redirect($redirect) {
        $profile_page = get_option('loginpro_profile_page_id', 0);
        if ($profile_page) {
            return get_permalink($profile_page);
        }
        return $redirect;
    }
}

// ==================================================
// ✅ AJAX Handler برای لاگین در تسویه حساب
// ==================================================

add_action('wp_ajax_nopriv_loginpro_woo_login', function() {
    try {
        $user_id = 0;
        
        if (!NonceManager::check_request('woocommerce_login', 'POST', $user_id)) {
            wp_send_json_error(['message' => __('درخواست نامعتبر', 'loginpro')], 403);
            return;
        }
        
        $identifier = sanitize_text_field($_POST['identifier'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($identifier) || empty($password)) {
            wp_send_json_error(['message' => __('لطفاً تمام فیلدها را پر کنید', 'loginpro')]);
            return;
        }
        
        $user = false;
        
        if (is_email($identifier)) {
            $user = get_user_by('email', $identifier);
        } else {
            $user = get_user_by('login', $identifier);
        }
        
        if (!$user) {
            wp_send_json_error(['message' => __('کاربر یافت نشد', 'loginpro')]);
            return;
        }
        
        if (!wp_check_password($password, $user->user_pass, $user->ID)) {
            wp_send_json_error(['message' => __('رمز عبور اشتباه است', 'loginpro')]);
            return;
        }
        
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        do_action('wp_login', $user->user_login, $user);
        
        $redirect = wc_get_checkout_url();
        
        wp_send_json_success([
            'message' => __('ورود موفق', 'loginpro'),
            'redirect' => $redirect
        ]);
        
    } catch (Exception $e) {
        wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
    }
});