<?php
/**
 * WooCommerce Integration Loader
 * بارگذاری تمام کلاس‌های مربوط به WooCommerce
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ بررسی وجود WooCommerce
// ==================================================

if (!class_exists('WooCommerce')) {
    // اگر ووکامرس نصب نیست، فقط یک اعلان نشان بده
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <?php esc_html_e('⚠️ افزونه لاگین‌پرو: برای استفاده از قابلیت‌های ووکامرس، لطفاً افزونه WooCommerce را نصب و فعال کنید.', 'loginpro'); ?>
            </p>
        </div>
        <?php
    });
    return;
}

// ==================================================
// ✅ بارگذاری فایل‌های مورد نیاز
// ==================================================

$woocommerce_files = [
    'Services/CheckoutService.php',
    'Services/OrderService.php',
    'Hooks/CartHooks.php',
    'LoginPro_WooCommerce_Integration.php',
];

foreach ($woocommerce_files as $file) {
    $file_path = __DIR__ . '/' . $file;
    if (file_exists($file_path)) {
        require_once $file_path;
    }
}

// ==================================================
// ✅ مقداردهی اولیه کلاس‌ها
// ==================================================

add_action('init', function() {
    if (class_exists('LoginPro_WooCommerce_Integration')) {
        new LoginPro_WooCommerce_Integration();
    }
}, 20);

// ==================================================
// ✅ تنظیمات پیش‌فرض ووکامرس برای لاگین‌پرو
// ==================================================

add_action('admin_init', function() {
    // تنظیمات پیش‌فرض برای صفحات ووکامرس
    if (!get_option('loginpro_woo_settings_initialized')) {
        
        // تنظیم صفحه لاگین
        if (!get_option('loginpro_login_page_id')) {
            // ایجاد صفحه لاگین
            $login_page = [
                'post_title' => 'ورود',
                'post_content' => '[loginpro_login]',
                'post_status' => 'publish',
                'post_type' => 'page',
            ];
            $page_id = wp_insert_post($login_page);
            if ($page_id) {
                update_option('loginpro_login_page_id', $page_id);
            }
        }
        
        // تنظیم صفحه پروفایل
        if (!get_option('loginpro_profile_page_id')) {
            $profile_page = [
                'post_title' => 'پروفایل کاربری',
                'post_content' => '[loginpro_profile]',
                'post_status' => 'publish',
                'post_type' => 'page',
            ];
            $page_id = wp_insert_post($profile_page);
            if ($page_id) {
                update_option('loginpro_profile_page_id', $page_id);
            }
        }
        
        // تنظیم صفحه امنیت
        if (!get_option('loginpro_security_page_id')) {
            $security_page = [
                'post_title' => 'امنیت حساب کاربری',
                'post_content' => '[loginpro_security]',
                'post_status' => 'publish',
                'post_type' => 'page',
            ];
            $page_id = wp_insert_post($security_page);
            if ($page_id) {
                update_option('loginpro_security_page_id', $page_id);
            }
        }
        
        update_option('loginpro_woo_settings_initialized', true);
    }
});

// ==================================================
// ✅ تغییر لینک‌های ورود و خروج ووکامرس
// ==================================================

add_filter('woocommerce_login_redirect', function($redirect, $user) {
    $login_page = get_permalink(get_option('loginpro_login_page_id', 0));
    if ($login_page) {
        return $login_page;
    }
    return $redirect;
}, 10, 2);

add_filter('woocommerce_registration_redirect', function($redirect) {
    $profile_page = get_permalink(get_option('loginpro_profile_page_id', 0));
    if ($profile_page) {
        return $profile_page;
    }
    return $redirect;
});

add_filter('woocommerce_logout_url', function($url) {
    $login_page = get_permalink(get_option('loginpro_login_page_id', 0));
    if ($login_page) {
        return wp_logout_url($login_page);
    }
    return $url;
});

// ==================================================
// ✅ END OF FILE
// ==================================================