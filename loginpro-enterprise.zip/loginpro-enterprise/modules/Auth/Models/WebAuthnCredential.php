<?php
/**
 * WebAuthn Credential Model
 * مدیریت کلیدهای احراز هویت بیومتریک
 */

namespace LoginPro\Modules\Auth\Models;

use LoginPro\Core\Database\Model;
use WP_User;

class WebAuthnCredential extends Model
{
    /**
     * نام جدول
     */
    protected $table = 'loginpro_webauthn_credentials';

    /**
     * فیلدهای قابل پر کردن
     */
    protected $fillable = [
        'user_id',
        'credential_id',
        'public_key',
        'sign_count',
        'transports',
        'device_name',
        'device_type',
        'user_agent',
        'last_used',
        'is_active'
    ];

    /**
     * دریافت کلیدهای یک کاربر
     */
    public function getByUserId($userId)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} 
                WHERE user_id = %d AND is_active = 1 
                ORDER BY created_at DESC",
                $userId
            )
        );
    }

    /**
     * دریافت کلید با credential_id
     */
    public function getByCredentialId($credentialId)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE credential_id = %s AND is_active = 1",
                $credentialId
            )
        );
    }

    /**
     * دریافت تعداد کلیدهای یک کاربر
     */
    public function countByUserId($userId)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_active = 1",
                $userId
            )
        );
    }

    /**
     * بررسی وجود کلید برای کاربر
     */
    public function hasCredentials($userId)
    {
        return $this->countByUserId($userId) > 0;
    }

    /**
     * ایجاد کلید جدید
     */
    public function create($data)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        // استانداردسازی داده‌ها
        $data['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        $data['created_at'] = current_time('mysql');
        $data['is_active'] = 1;
        
        return $wpdb->insert($table, $data);
    }

    /**
     * به‌روزرسانی sign count
     */
    public function updateSignCount($id, $signCount)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        return $wpdb->update(
            $table,
            [
                'sign_count' => $signCount,
                'last_used' => current_time('mysql')
            ],
            ['id' => $id]
        );
    }

    /**
     * غیرفعال کردن کلید (حذف نرم)
     */
    public function deactivate($id, $userId)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        return $wpdb->update(
            $table,
            ['is_active' => 0],
            ['id' => $id, 'user_id' => $userId]
        );
    }

    /**
     * حذف فیزیکی کلید
     */
    public function deleteByUser($id, $userId)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        return $wpdb->delete(
            $table,
            ['id' => $id, 'user_id' => $userId]
        );
    }

    /**
     * حذف تمام کلیدهای یک کاربر
     */
    public function deleteAllByUser($userId)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        
        return $wpdb->delete(
            $table,
            ['user_id' => $userId]
        );
    }

    /**
     * تشخیص نوع دستگاه از User-Agent
     */
    public function detectDeviceType($userAgent = null)
    {
        if (!$userAgent) {
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        }
        
        $userAgent = strtolower($userAgent);
        
        if (strpos($userAgent, 'iphone') !== false || strpos($userAgent, 'ipad') !== false) {
            return 'ios';
        } elseif (strpos($userAgent, 'android') !== false) {
            return 'android';
        } elseif (strpos($userAgent, 'windows') !== false) {
            return 'windows';
        } elseif (strpos($userAgent, 'macintosh') !== false) {
            return 'mac';
        } elseif (strpos($userAgent, 'linux') !== false) {
            return 'linux';
        }
        
        return 'unknown';
    }

    /**
     * گرفتن نام زیبا برای دستگاه
     */
    public function getDeviceFriendlyName($deviceType)
    {
        $names = [
            'ios' => '🍎 Apple (iPhone/iPad)',
            'android' => '🤖 Android',
            'windows' => '💻 Windows',
            'mac' => '🍏 Mac',
            'linux' => '🐧 Linux',
            'unknown' => '❓ Unknown Device'
        ];
        
        return $names[$deviceType] ?? $deviceType;
    }
}