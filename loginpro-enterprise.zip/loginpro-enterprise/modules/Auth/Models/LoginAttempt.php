<?php
namespace LoginPro\Modules\Auth\Models;

use LoginPro\Core\Database\Model;

class LoginAttempt extends Model {
    protected static $table = 'login_history';
    
    public function record($userId, $status, $ip, $userAgent) {
        return $this->query()->insert([
            'user_id' => $userId,
            'status' => $status,
            'ip_address' => $ip,
            'user_agent' => $userAgent,
            'created_at' => current_time('mysql')
        ]);
    }
    
    public function getAttempts($userId, $hours = 24) {
        return $this->query()
            ->where('user_id', $userId)
            ->where('created_at', '>', date('Y-m-d H:i:s', time() - ($hours * 3600)))
            ->get();
    }
    
    public function getFailedAttempts($ip, $minutes = 15) {
        $results = $this->query()
            ->where('ip_address', $ip)
            ->where('status', 'failed')
            ->where('created_at', '>', date('Y-m-d H:i:s', time() - ($minutes * 60)))
            ->get();
        
        return count($results);
    }
    
    public function getLastLogin($userId) {
        return $this->query()
            ->where('user_id', $userId)
            ->where('status', 'success')
            ->orderBy('created_at', 'DESC')
            ->limit(1)
            ->first();
    }
    
    public function cleanup($days = 30) {
        return $this->query()
            ->where('created_at', '<', date('Y-m-d H:i:s', time() - ($days * 86400)))
            ->delete();
    }
}
