<?php
namespace LoginPro\Modules\Auth\Services;

class MagicLinkService {
    
    public function generate($userId, $redirect = '') {
        $token = wp_generate_password(64, false);
        $expires = time() + 3600;
        
        $linkData = [
            'user_id' => $userId,
            'redirect' => $redirect,
            'expires' => $expires
        ];
        
        set_transient('loginpro_magic_link_' . $token, $linkData, 3600);
        
        return add_query_arg([
            'magic_token' => $token,
            'action' => 'magic_login'
        ], home_url());
    }
    
    public function verify($token) {
        $data = get_transient('loginpro_magic_link_' . $token);
        
        if (!$data || $data['expires'] < time()) {
            return false;
        }
        
        delete_transient('loginpro_magic_link_' . $token);
        
        return $data;
    }
    
    public function send($email, $redirect = '') {
        $user = get_user_by('email', $email);
        
        if (!$user) {
            return [
                'success' => false,
                'message' => 'No user found with this email'
            ];
        }
        
        $magicLink = $this->generate($user->ID, $redirect);
        
        $subject = 'Your Magic Login Link';
        $message = $this->getEmailTemplate($magicLink, $user->display_name);
        
        wp_mail($email, $subject, $message, ['Content-Type: text/html; charset=UTF-8']);
        
        return [
            'success' => true,
            'message' => 'Magic link sent to your email'
        ];
    }
    
    private function getEmailTemplate($link, $name) {
        return '<html>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
            <h2>Login Without Password</h2>
            <p>Hello ' . $name . ',</p>
            <p>Click the button below to log in to your account. This link will expire in 1 hour.</p>
            <a href="' . $link . '" style="background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Login Now</a>
            <p>If you didn't request this, please ignore this email.</p>
        </body>
        </html>';
    }
    
    public function processMagicLogin($token) {
        $data = $this->verify($token);
        
        if (!$data) {
            wp_die('Invalid or expired magic link', 'Login Error', ['response' => 400]);
        }
        
        wp_set_current_user($data['user_id']);
        wp_set_auth_cookie($data['user_id'], true);
        
        $redirect = $data['redirect'] ?: home_url('/dashboard');
        wp_redirect($redirect);
        exit;
    }
}
