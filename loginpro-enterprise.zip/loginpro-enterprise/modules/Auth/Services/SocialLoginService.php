<?php
namespace LoginPro\Modules\Auth\Services;

class SocialLoginService {
    
    public function authenticate($provider, $accessToken) {
        switch ($provider) {
            case 'google':
                return $this->authenticateGoogle($accessToken);
            case 'facebook':
                return $this->authenticateFacebook($accessToken);
            default:
                return ['success' => false, 'message' => 'Unsupported provider'];
        }
    }
    
    private function authenticateGoogle($accessToken) {
        $userInfo = $this->getGoogleUserInfo($accessToken);
        
        if (!$userInfo || !isset($userInfo['email'])) {
            return ['success' => false, 'message' => 'Invalid Google token'];
        }
        
        $user = get_user_by('email', $userInfo['email']);
        
        if (!$user) {
            $username = $this->generateUsername($userInfo['email']);
            $userId = wp_create_user($username, wp_generate_password(), $userInfo['email']);
            
            if (is_wp_error($userId)) {
                return ['success' => false, 'message' => $userId->get_error_message()];
            }
            
            update_user_meta($userId, 'first_name', $userInfo['given_name'] ?? '');
            update_user_meta($userId, 'last_name', $userInfo['family_name'] ?? '');
            update_user_meta($userId, 'loginpro_google_id', $userInfo['id']);
            update_user_meta($userId, 'registered_via', 'google');
            
            $user = get_user_by('id', $userId);
        }
        
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        
        return ['success' => true, 'user' => $user];
    }
    
    private function authenticateFacebook($accessToken) {
        $userInfo = $this->getFacebookUserInfo($accessToken);
        
        if (!$userInfo || !isset($userInfo['email'])) {
            return ['success' => false, 'message' => 'Invalid Facebook token'];
        }
        
        $user = get_user_by('email', $userInfo['email']);
        
        if (!$user) {
            $username = $this->generateUsername($userInfo['email']);
            $userId = wp_create_user($username, wp_generate_password(), $userInfo['email']);
            
            if (is_wp_error($userId)) {
                return ['success' => false, 'message' => $userId->get_error_message()];
            }
            
            $nameParts = explode(' ', $userInfo['name'] ?? '', 2);
            update_user_meta($userId, 'first_name', $nameParts[0] ?? '');
            update_user_meta($userId, 'last_name', $nameParts[1] ?? '');
            update_user_meta($userId, 'loginpro_facebook_id', $userInfo['id']);
            update_user_meta($userId, 'registered_via', 'facebook');
            
            $user = get_user_by('id', $userId);
        }
        
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        
        return ['success' => true, 'user' => $user];
    }
    
    private function getGoogleUserInfo($accessToken) {
        $url = 'https://www.googleapis.com/oauth2/v2/userinfo';
        $response = wp_remote_get($url, [
            'headers' => ['Authorization' => 'Bearer ' . $accessToken]
        ]);
        
        if (is_wp_error($response)) {
            return null;
        }
        
        return json_decode(wp_remote_retrieve_body($response), true);
    }
    
    private function getFacebookUserInfo($accessToken) {
        $url = 'https://graph.facebook.com/me?fields=id,name,email&access_token=' . $accessToken;
        $response = wp_remote_get($url);
        
        if (is_wp_error($response)) {
            return null;
        }
        
        return json_decode(wp_remote_retrieve_body($response), true);
    }
    
    private function generateUsername($email) {
        $username = explode('@', $email)[0];
        $original = $username;
        $counter = 1;
        
        while (username_exists($username)) {
            $username = $original . $counter;
            $counter++;
        }
        
        return $username;
    }
}
