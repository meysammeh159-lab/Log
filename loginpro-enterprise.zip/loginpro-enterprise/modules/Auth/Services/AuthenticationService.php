<?php
namespace LoginPro\Modules\Auth\Services;

use LoginPro\Modules\Security\Services\BruteForceService;
use LoginPro\Modules\OTP\Services\OtpService;
use LoginPro\Core\Session\SessionManager;

class AuthenticationService {
    private $bruteForce;
    private $otpService;
    private $sessionManager;
    
    public function __construct() {
        $this->bruteForce = new BruteForceService();
        $this->otpService = new \LoginPro\Modules\OTP\Services\OtpService();
        //$this->sessionManager = new SessionManager();
    }
    
    public function authenticate($username, $password, $rememberMe = false) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        if ($this->bruteForce->isBlocked($ip)) {
            return [
                'success' => false,
                'message' => 'Too many attempts. Please try again later.',
                'blocked_until' => $this->bruteForce->getBlockedUntil($ip)
            ];
        }
        
        $user = wp_authenticate($username, $password);
        
        if (is_wp_error($user)) {
            $this->bruteForce->recordAttempt($ip, false);
            return [
                'success' => false,
                'message' => $user->get_error_message(),
                'attempts_left' => $this->bruteForce->getRemainingAttempts($ip)
            ];
        }
        
        $requires2fa = $this->requiresTwoFactor($user->ID);
        
        if ($requires2fa) {
            $otp = $this->otpService->generate($user->ID, 'login');
            $this->otpService->send($user->ID, $otp, 'login');
            
            $_SESSION['loginpro_2fa_required'] = [
                'user_id' => $user->ID,
                'timestamp' => time()
            ];
            
            return [
                'success' => true,
                'requires_2fa' => true,
                'message' => 'OTP sent to your registered mobile/email'
            ];
        }
        
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $rememberMe);
        
        $this->bruteForce->recordAttempt($ip, true);
        $this->sessionManager->create($user->ID);
        
        do_action('loginpro_user_logged_in', $user->ID);
        
        return [
            'success' => true,
            'requires_2fa' => false,
            'user' => $user
        ];
    }
    
    public function logout() {
        $userId = get_current_user_id();
        
        if ($userId) {
            $this->sessionManager->destroy($userId);
            do_action('loginpro_user_logged_out', $userId);
        }
        
        wp_logout();
    }
    
    private function requiresTwoFactor($userId) {
        $enabled = get_user_meta($userId, 'loginpro_2fa_enabled', true);
        return $enabled === 'yes';
    }
}
