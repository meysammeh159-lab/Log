<?php
namespace LoginPro\Modules\Auth\Services;

defined('ABSPATH') || exit;

use LoginPro\Core\Http\Request;
use LoginPro\Modules\OTP\Services\OtpService;

class AuthService
{
    private Request $request;
    private OtpService $otpService;
    
    public function __construct() {
        $this->request = Request::capture();
        $this->otpService = new OtpService();
    }
    
    public function authenticateWithOtp(string $mobile, string $code, string $token): array {
        $verify = $this->otpService->verifyOtp($mobile, $code, $token);
        if (!$verify || !($verify['success'] ?? false)) {
            return ['success' => false, 'message' => 'کد نامعتبر یا منقضی شده.'];
        }
        
        $mobile = $verify['mobile'];
        $user = $this->findUserByMobile($mobile);
        
        if (!$user) {
            $username = 'u_' . bin2hex(random_bytes(8));
            $userId = wp_insert_user([
                'user_login' => $username,
                'user_email' => $username . '@user.loginpro',
                'display_name' => 'کاربر ' . substr($mobile, -4),
                'user_pass' => wp_generate_password(24, true, true),
                'role' => 'subscriber',
            ]);
            if (is_wp_error($userId)) return ['success' => false, 'message' => 'خطا در ثبت‌نام.'];
            update_user_meta($userId, 'loginpro_mobile', $mobile);
            $user = get_user_by('ID', $userId);
        }
        
        $this->loginUser($user);
        return ['success' => true, 'message' => 'ورود موفق', 'redirect' => home_url()];
    }
    
    public function authenticate(string $username, string $password): array {
        $user = wp_authenticate($username, $password);
        if (is_wp_error($user)) return ['success' => false, 'message' => 'اطلاعات نادرست است.'];
        $this->loginUser($user);
        return ['success' => true, 'message' => 'ورود موفق', 'redirect' => home_url()];
    }
    
    public function completeProfile(int $userId, array $data): array {
        $userdata = ['ID' => $userId];
        if (!empty($data['name'])) $userdata['display_name'] = sanitize_text_field($data['name']);
        if (!empty($data['email']) && is_email($data['email'])) $userdata['user_email'] = sanitize_email($data['email']);
        $updated = wp_update_user($userdata);
        if (is_wp_error($updated)) return ['success' => false, 'message' => $updated->get_error_message()];
        if (!empty($data['password']) && strlen($data['password']) >= 8) wp_set_password($data['password'], $userId);
        return ['success' => true, 'message' => 'پروفایل به‌روزرسانی شد.'];
    }
    
    public function sendResetLink(string $email): array {
        $user = get_user_by('email', $email);
        if (!$user) return ['success' => true, 'message' => 'اگر ایمیل ثبت شده باشد، لینک ارسال می‌شود.'];
        $key = get_password_reset_key($user);
        if (is_wp_error($key)) return ['success' => false, 'message' => 'خطا در ارسال.'];
        $url = network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user->user_login));
        wp_mail($email, 'بازنشانی رمز عبور', "لینک: $url");
        return ['success' => true, 'message' => 'لینک ارسال شد.'];
    }
    
    public function findUserByMobile(string $mobile): ?\WP_User {
        $users = get_users(['meta_key' => 'loginpro_mobile', 'meta_value' => $mobile, 'number' => 1, 'fields' => 'ID']);
        return !empty($users) ? get_user_by('ID', $users[0]) : null;
    }
    
    private function loginUser(\WP_User $user): void {
        wp_clear_auth_cookie();
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        do_action('wp_login', $user->user_login, $user);
    }
}