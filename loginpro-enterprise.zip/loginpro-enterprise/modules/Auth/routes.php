<?php
/**
 * مسیرهای ماژول Auth
 * 
 * @package LoginPro
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// ============================================
// اکشن‌های AJAX برای OTP
// ============================================

/**
 * درخواست ارسال کد OTP
 */
add_action('wp_ajax_loginpro_request_otp', 'loginpro_request_otp_callback');
add_action('wp_ajax_nopriv_loginpro_request_otp', 'loginpro_request_otp_callback');

function loginpro_request_otp_callback() {
    // بررسی Nonce
    if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_ajax_nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی']);
    }
    
    $controller = new \LoginPro\Modules\Auth\Controllers\OtpController();
    $controller->requestOtp();
}

/**
 * تأیید کد OTP
 */
add_action('wp_ajax_loginpro_verify_otp', 'loginpro_verify_otp_callback');
add_action('wp_ajax_nopriv_loginpro_verify_otp', 'loginpro_verify_otp_callback');

function loginpro_verify_otp_callback() {
    if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_ajax_nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی']);
    }
    
    $controller = new \LoginPro\Modules\Auth\Controllers\OtpController();
    $controller->verifyOtp();
}

/**
 * ارسال مجدد کد OTP
 */
add_action('wp_ajax_loginpro_resend_otp', 'loginpro_resend_otp_callback');
add_action('wp_ajax_nopriv_loginpro_resend_otp', 'loginpro_resend_otp_callback');

function loginpro_resend_otp_callback() {
    if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_ajax_nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی']);
    }
    
    $controller = new \LoginPro\Modules\Auth\Controllers\OtpController();
    $controller->resendOtp();
}