<?php
/**
 * WebAuthn Login View
 * دکمه ورود با احراز هویت بیومتریک
 */

defined('ABSPATH') || exit;

$nonce = wp_create_nonce('loginpro_webauthn');
$userId = get_current_user_id();
?>

<div class="loginpro-webauthn-login-container">
    <button type="button" id="webauthn-login-btn" class="loginpro-webauthn-button">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
        </svg>
        <span>ورود با اثر انگشت / Face ID</span>
    </button>
    
    <div id="webauthn-login-status" class="loginpro-status" style="display: none;"></div>
</div>

<style>
.loginpro-webauthn-login-container {
    text-align: center;
    margin: 15px 0;
}
.loginpro-webauthn-button {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 30px;
    background: #1a1a2e;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    font-weight: 500;
    transition: all 0.3s ease;
}
.loginpro-webauthn-button:hover {
    background: #2d2d4a;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
}
.loginpro-webauthn-button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}
.loginpro-webauthn-button svg {
    fill: none;
    stroke: currentColor;
}
.loginpro-status {
    margin-top: 10px;
    padding: 8px 15px;
    border-radius: 6px;
    font-size: 14px;
}
.loginpro-status.success {
    background: #d4edda;
    color: #155724;
}
.loginpro-status.error {
    background: #f8d7da;
    color: #721c24;
}
.loginpro-status.loading {
    background: #cce5ff;
    color: #004085;
}
</style>

<script>
jQuery(document).ready(function($) {
    var nonce = '<?php echo $nonce; ?>';
    var userId = <?php echo $userId ?: 0; ?>;
    var status = $('#webauthn-login-status');
    var btn = $('#webauthn-login-btn');
    
    btn.on('click', function() {
        status.removeClass('success error loading').hide();
        btn.prop('disabled', true).html('⏳ در حال آماده‌سازی...');
        
        // دریافت گزینه‌های ورود
        $.post(ajaxurl, {
            action: 'loginpro_webauthn_login_options',
            user_id: userId,
            _nonce: nonce
        }, function(response) {
            if (!response.success) {
                status.addClass('error').html('❌ ' + response.data.message).show();
                btn.prop('disabled', false).html('<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg><span>ورود با اثر انگشت / Face ID</span>');
                return;
            }
            
            var options = response.data.options;
            
            // بررسی وجود credentials
            if (!options.allowCredentials || options.allowCredentials.length === 0) {
                status.addClass('error').html('❌ هیچ دستگاه بیومتریکی ثبت نشده است. لطفاً از طریق رمز عبور وارد شوید.').show();
                btn.prop('disabled', false).html('<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg><span>ورود با اثر انگشت / Face ID</span>');
                return;
            }
            
            // شروع WebAuthn
            var challenge = Uint8Array.from(atob(options.challenge), function(c) {
                return c.charCodeAt(0);
            });
            
            var publicKey = {
                challenge: challenge,
                rpId: options.rpId,
                allowCredentials: options.allowCredentials.map(function(cred) {
                    return {
                        type: cred.type,
                        id: Uint8Array.from(atob(cred.id), function(c) {
                            return c.charCodeAt(0);
                        }),
                        transports: cred.transports || []
                    };
                }),
                timeout: options.timeout || 60000,
                userVerification: options.userVerification || 'required'
            };
            
            navigator.credentials.get({ publicKey: publicKey })
            .then(function(credential) {
                var responseData = {
                    id: credential.id,
                    type: credential.type,
                    response: {
                        clientDataJSON: btoa(String.fromCharCode.apply(null, new Uint8Array(credential.response.clientDataJSON))),
                        authenticatorData: btoa(String.fromCharCode.apply(null, new Uint8Array(credential.response.authenticatorData))),
                        signature: btoa(String.fromCharCode.apply(null, new Uint8Array(credential.response.signature))),
                        userHandle: credential.response.userHandle ? btoa(String.fromCharCode.apply(null, new Uint8Array(credential.response.userHandle))) : null
                    }
                };
                
                status.addClass('loading').html('⏳ در حال تأیید...').show();
                
                return $.post(ajaxurl, {
                    action: 'loginpro_webauthn_verify_login',
                    credential: JSON.stringify(responseData),
                    _nonce: nonce
                });
            })
            .then(function(verifyResponse) {
                if (verifyResponse.success) {
                    status.removeClass('loading').addClass('success').html('✅ ' + verifyResponse.data.message).show();
                    
                    // ریدایرکت
                    if (verifyResponse.data.redirect) {
                        setTimeout(function() {
                            window.location.href = verifyResponse.data.redirect;
                        }, 1000);
                    } else {
                        window.location.reload();
                    }
                } else {
                    status.removeClass('loading').addClass('error').html('❌ ' + verifyResponse.data.message).show();
                    btn.prop('disabled', false).html('<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg><span>ورود با اثر انگشت / Face ID</span>');
                }
            })
            .catch(function(error) {
                status.removeClass('loading').addClass('error').html('❌ خطا: ' + error.message).show();
                btn.prop('disabled', false).html('<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg><span>ورود با اثر انگشت / Face ID</span>');
            });
        }).fail(function() {
            status.addClass('error').html('❌ خطا در ارتباط با سرور').show();
            btn.prop('disabled', false).html('<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg><span>ورود با اثر انگشت / Face ID</span>');
        });
    });
});
</script>