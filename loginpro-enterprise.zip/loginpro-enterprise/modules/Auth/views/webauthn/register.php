<?php
/**
 * WebAuthn Registration View
 * فرم ثبت دستگاه بیومتریک
 */

defined('ABSPATH') || exit;

if (!is_user_logged_in()) {
    echo '<p>لطفاً ابتدا وارد شوید.</p>';
    return;
}

$user = wp_get_current_user();
$nonce = wp_create_nonce('loginpro_webauthn');
?>

<div class="loginpro-webauthn-register-container">
    <h3>🔐 ثبت دستگاه برای احراز هویت بیومتریک</h3>
    
    <div class="loginpro-webauthn-info">
        <p>
            با ثبت دستگاه، می‌توانید با استفاده از 
            <strong>اثر انگشت</strong>، 
            <strong>Face ID</strong> یا 
            <strong>Windows Hello</strong> 
            وارد شوید.
        </p>
        <ul>
            <li>✅ امنیت بالا بدون نیاز به رمز عبور</li>
            <li>✅ ورود سریع و آسان</li>
            <li>✅ اطلاعات شما در دستگاه ذخیره می‌شود</li>
        </ul>
    </div>

    <div class="loginpro-webauthn-form">
        <div class="form-group">
            <label for="device_name">نام دستگاه (اختیاری)</label>
            <input type="text" id="device_name" class="regular-text" 
                   placeholder="مثال: گوشی من" value="">
        </div>
        
        <button type="button" id="webauthn-start-register" class="button button-primary button-large">
            🚀 شروع ثبت دستگاه
        </button>
        
        <div id="webauthn-register-status" class="loginpro-status" style="display: none;"></div>
    </div>

    <div id="webauthn-registered-devices">
        <h4>دستگاه‌های ثبت‌شده</h4>
        <div id="webauthn-device-list">
            <span class="spinner"></span> در حال بارگذاری...
        </div>
    </div>
</div>

<style>
.loginpro-webauthn-register-container {
    max-width: 600px;
    margin: 20px 0;
    padding: 20px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.loginpro-webauthn-info {
    background: #f0f7ff;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
}
.loginpro-webauthn-info ul {
    margin: 10px 0;
    padding-right: 20px;
}
.loginpro-webauthn-info ul li {
    margin-bottom: 5px;
}
.form-group {
    margin-bottom: 15px;
}
.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 5px;
    color: #333;
}
.form-group input {
    width: 100%;
    max-width: 400px;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
}
#webauthn-start-register {
    background: #2271b1 !important;
    border-color: #2271b1 !important;
    color: #fff !important;
    padding: 10px 30px;
}
#webauthn-start-register:hover {
    background: #135e96 !important;
}
.loginpro-status {
    margin-top: 15px;
    padding: 10px 15px;
    border-radius: 6px;
}
.loginpro-status.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}
.loginpro-status.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
.loginpro-status.loading {
    background: #cce5ff;
    color: #004085;
    border: 1px solid #b8daff;
}
#webauthn-device-list {
    margin-top: 10px;
}
.device-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 12px;
    background: #f8f9fa;
    border-radius: 6px;
    margin-bottom: 5px;
}
.device-item .device-name {
    font-weight: 500;
}
.device-item .device-date {
    font-size: 12px;
    color: #999;
}
.device-item .delete-device {
    background: #dc3545;
    color: #fff;
    border: none;
    padding: 4px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}
.device-item .delete-device:hover {
    background: #b02a37;
}
.spinner {
    float: none;
    margin: 0 10px 0 0;
}
</style>

<script>
jQuery(document).ready(function($) {
    var nonce = '<?php echo $nonce; ?>';
    var status = $('#webauthn-register-status');
    var deviceList = $('#webauthn-device-list');
    
    // بارگذاری دستگاه‌های ثبت‌شده
    function loadDevices() {
        $.post(ajaxurl, {
            action: 'loginpro_webauthn_list',
            _nonce: nonce
        }, function(response) {
            if (response.success && response.data.credentials) {
                var credentials = response.data.credentials;
                var html = '';
                
                if (credentials.length === 0) {
                    html = '<p style="color: #999;">هیچ دستگاهی ثبت نشده است.</p>';
                } else {
                    credentials.forEach(function(cred) {
                        html += '<div class="device-item">';
                        html += '<div><span class="device-name">' + cred.device_name + '</span>';
                        html += ' <span class="device-date">(' + cred.created_at + ')</span></div>';
                        html += '<button class="delete-device" data-id="' + cred.id + '">❌ حذف</button>';
                        html += '</div>';
                    });
                }
                
                deviceList.html(html);
            } else {
                deviceList.html('<p style="color: #dc3545;">خطا در بارگذاری دستگاه‌ها</p>');
            }
        });
    }
    
    loadDevices();
    
    // ثبت دستگاه
    $('#webauthn-start-register').on('click', function() {
        var btn = $(this);
        var deviceName = $('#device_name').val().trim() || 'My Device';
        
        btn.prop('disabled', true).text('⏳ در حال آماده‌سازی...');
        status.removeClass('success error loading').hide();
        
        $.post(ajaxurl, {
            action: 'loginpro_webauthn_register',
            device_name: deviceName,
            _nonce: nonce
        }, function(response) {
            if (!response.success) {
                status.addClass('error').html('❌ ' + response.data.message).show();
                btn.prop('disabled', false).text('🚀 شروع ثبت دستگاه');
                return;
            }
            
            var options = response.data.options;
            
            // شروع WebAuthn
            var challenge = Uint8Array.from(atob(options.challenge), function(c) {
                return c.charCodeAt(0);
            });
            
            var userId = Uint8Array.from(atob(options.user.id), function(c) {
                return c.charCodeAt(0);
            });
            
            var publicKey = {
                challenge: challenge,
                rp: options.rp,
                user: {
                    id: userId,
                    name: options.user.name,
                    displayName: options.user.displayName
                },
                pubKeyCredParams: options.pubKeyCredParams,
                authenticatorSelection: options.authenticatorSelection,
                excludeCredentials: options.excludeCredentials || [],
                timeout: options.timeout || 60000,
                attestation: options.attestation || 'none'
            };
            
            navigator.credentials.create({ publicKey: publicKey })
            .then(function(credential) {
                var responseData = {
                    id: credential.id,
                    type: credential.type,
                    transports: credential.transports || [],
                    response: {
                        clientDataJSON: btoa(String.fromCharCode.apply(null, new Uint8Array(credential.response.clientDataJSON))),
                        attestationObject: btoa(String.fromCharCode.apply(null, new Uint8Array(credential.response.attestationObject)))
                    }
                };
                
                return $.post(ajaxurl, {
                    action: 'loginpro_webauthn_verify_register',
                    credential: JSON.stringify(responseData),
                    _nonce: nonce
                });
            })
            .then(function(verifyResponse) {
                if (verifyResponse.success) {
                    status.addClass('success').html('✅ ' + verifyResponse.data.message).show();
                    loadDevices();
                    btn.prop('disabled', false).text('✅ ثبت شد');
                    $('#device_name').val('');
                } else {
                    status.addClass('error').html('❌ ' + verifyResponse.data.message).show();
                    btn.prop('disabled', false).text('🚀 شروع ثبت دستگاه');
                }
            })
            .catch(function(error) {
                status.addClass('error').html('❌ خطا: ' + error.message).show();
                btn.prop('disabled', false).text('🚀 شروع ثبت دستگاه');
            });
        }).fail(function() {
            status.addClass('error').html('❌ خطا در ارتباط با سرور').show();
            btn.prop('disabled', false).text('🚀 شروع ثبت دستگاه');
        });
    });
    
    // حذف دستگاه
    $(document).on('click', '.delete-device', function() {
        if (!confirm('آیا از حذف این دستگاه مطمئن هستید؟')) return;
        
        var id = $(this).data('id');
        var btn = $(this);
        
        btn.prop('disabled', true).text('⏳');
        
        $.post(ajaxurl, {
            action: 'loginpro_webauthn_delete',
            id: id,
            _nonce: nonce
        }, function(response) {
            if (response.success) {
                loadDevices();
                status.addClass('success').html('✅ ' + response.data.message).show();
                setTimeout(function() { status.fadeOut(); }, 3000);
            } else {
                alert('❌ ' + response.data.message);
                btn.prop('disabled', false).text('❌ حذف');
            }
        });
    });
});
</script>