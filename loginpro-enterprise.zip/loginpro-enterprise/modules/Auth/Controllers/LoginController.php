<?php
namespace LoginPro\Modules\Auth\Controllers;

defined('ABSPATH') || exit;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Modules\Auth\Services\AuthService;

class LoginController
{
    private Request $request;
    private AuthService $authService;
    
    public function __construct() {
        $this->request = Request::capture();
        $this->authService = new AuthService();
    }
    
    /**
     * Login with Password
     * 
     * AJAX Action: loginpro_login_password
     */
    public function handleLogin(): void {
        try {
            if (!$this->verifyNonce()) return;
            
            $identifier = sanitize_text_field(wp_unslash($_POST['identifier'] ?? ''));
            $password = $_POST['password'] ?? '';
            
            if (empty($identifier) || empty($password)) {
                Response::json(['success' => false, 'message' => 'لطفاً تمام فیلدها را پر کنید.']);
                return;
            }
            
            $result = $this->authService->authenticate($identifier, $password);
            
            if ($result['success']) {
                Response::json($result);
            } else {
                Response::json(['success' => false, 'message' => $result['message']]);
            }
            
        } catch (\Exception $e) {
            error_log('[LoginPro] Login Error: ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'خطای سیستمی رخ داده است.']);
        }
    }
    
    /**
     * Register with Username/Email/Password
     * 
     * AJAX Action: loginpro_register
     */
    public function handleRegister(): void {
        try {
            if (!$this->verifyNonce()) return;
            
            $username = sanitize_user(wp_unslash($_POST['username'] ?? ''));
            $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
            $password = $_POST['password'] ?? '';
            $displayName = sanitize_text_field(wp_unslash($_POST['display_name'] ?? ''));
            
            if (empty($username) || empty($email) || empty($password)) {
                Response::json(['success' => false, 'message' => 'لطفاً تمام فیلدها را پر کنید.']);
                return;
            }
            
            if (strlen($password) < 8) {
                Response::json(['success' => false, 'message' => 'رمز عبور باید حداقل ۸ کاراکتر باشد.']);
                return;
            }
            
            $result = $this->authService->register($username, $email, $password, $displayName);
            
            if ($result['success']) {
                Response::json($result);
            } else {
                Response::json(['success' => false, 'message' => $result['message']]);
            }
            
        } catch (\Exception $e) {
            error_log('[LoginPro] Register Error: ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'خطای سیستمی رخ داده است.']);
        }
    }
    
    /**
     * Reset Password
     * 
     * AJAX Action: loginpro_reset_password
     */
    public function handleResetPassword(): void {
        try {
            if (!$this->verifyNonce()) return;
            
            $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
            
            if (empty($email) || !is_email($email)) {
                Response::json(['success' => false, 'message' => 'لطفاً یک ایمیل معتبر وارد کنید.']);
                return;
            }
            
            $result = $this->authService->sendResetLink($email);
            Response::json($result);
            
        } catch (\Exception $e) {
            error_log('[LoginPro] ResetPassword Error: ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'خطای سیستمی رخ داده است.']);
        }
    }
    
    private function verifyNonce(): bool {
        $nonce = $_POST['_nonce'] ?? $_POST['_wpnonce'] ?? '';
        
        if (!wp_verify_nonce($nonce, 'loginpro_ajax_nonce')) {
            Response::json(['success' => false, 'message' => 'درخواست نامعتبر است.']);
            return false;
        }
        
        return true;
    }
}