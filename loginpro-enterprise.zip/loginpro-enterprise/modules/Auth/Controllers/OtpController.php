<?php
namespace LoginPro\Modules\Auth\Controllers;

defined('ABSPATH') || exit;

use LoginPro\Modules\OTP\Services\OtpService;
use LoginPro\Core\Http\Request;

// ✅ بارگذاری مستقیم
require_once LOGINPRO_PLUGIN_DIR . 'modules/OTP/Services/OtpDispatcherService.php';

class OtpController
{
    private OtpService $otpService;
    private $dispatcher;
    private Request $request;
    
    public function __construct() {
        $this->otpService = new OtpService();
        
        if (class_exists('LoginPro\\Modules\\OTP\\Services\\OtpDispatcherService')) {
            $this->dispatcher = new \LoginPro\Modules\OTP\Services\OtpDispatcherService();
        } else {
            $this->dispatcher = null;
        }
        
        $this->request = Request::capture();
    }
    
     public function handleCheckIdentifier(): void {
    try {
        $nonce = $this->request->post('_nonce', '');
        if (!wp_verify_nonce($nonce, 'loginpro_ajax_nonce')) {
            error_log('[OTP] Nonce verification failed');
            $this->jsonResponse(false, 'خطای امنیتی');
            return;
        }
        
        $identifier = $this->request->post('identifier', '');
        $type = $this->request->post('type', 'login');
        
        error_log('=== handleCheckIdentifier ===');
        error_log('Identifier: ' . $identifier);
        
        if (empty($identifier)) {
            $this->jsonResponse(false, 'شماره موبایل را وارد کنید');
            return;
        }
        
        $isMobile = preg_match('/^09[0-9]{9}$/', $identifier) || 
                    (strlen($identifier) === 11 && substr($identifier, 0, 1) === '0');
        
        if ($isMobile) {
            $normalizedMobile = $this->otpService->normalizeMobile($identifier);
            
            if (!$this->otpService->isValidMobile($normalizedMobile)) {
                $this->jsonResponse(false, 'شماره موبایل نامعتبر است');
                return;
            }
            
            $otpData = $this->otpService->generateForMobile($normalizedMobile);
            
            if ($otpData === false) {
                $this->jsonResponse(false, 'تعداد درخواست بیش از حد مجاز است');
                return;
            }
            
            $code = $otpData['code'];
            $token = $otpData['session_token'];
            
            error_log('[LoginPro] Generated OTP: ' . $code . ' for mobile: ' . $normalizedMobile);
            
            // ============================================
            // ✅ ارسال مستقیم با SmsManager (اجباری)
            // ============================================
            error_log('[LoginPro] ===== DIRECT SMS TEST =====');
            
            $smsManager = \LoginPro\Modules\Providers\Sms\SmsManager::getInstance();
            error_log('[LoginPro] SmsManager loaded: ' . get_class($smsManager));
            
            $activeProvider = $smsManager->getActiveProvider();
            if ($activeProvider) {
                error_log('[LoginPro] Provider: ' . $activeProvider::getName());
                error_log('[LoginPro] Configured: ' . ($activeProvider->isConfigured() ? '✅' : '❌'));
            } else {
                error_log('[LoginPro] ❌ No active provider');
                $this->jsonResponse(false, 'درگاه پیامکی فعال نیست');
                return;
            }
            
            // ارسال مستقیم
            $result = $smsManager->sendOtp($normalizedMobile, $code);
            error_log('[LoginPro] sendOtp result: ' . print_r($result, true));
            
            // بررسی نتیجه
            $sent = false;
            if (is_array($result)) {
                if (isset($result['success']) && $result['success'] === true) {
                    $sent = true;
                } elseif (isset($result['status']) && $result['status'] === 'success') {
                    $sent = true;
                } elseif (isset($result['message_id']) || isset($result['id']) || isset($result['bulk_id'])) {
                    $sent = true;
                } elseif (!empty($result) && !isset($result['error'])) {
                    $sent = true;
                }
            } elseif (is_numeric($result) || (is_string($result) && strlen($result) > 0)) {
                $sent = true;
            } elseif (is_bool($result) && $result === true) {
                $sent = true;
            }
            
            error_log('[LoginPro] Final sent status: ' . ($sent ? 'true' : 'false'));
            
            if ($sent) {
                $this->jsonResponse(true, 'کد تایید با موفقیت ارسال شد', [
                    'token' => $token,
                    'mobile' => $normalizedMobile,
                    'expires_in' => 120,
                    'is_mobile' => true
                ]);
            } else {
                $errorMsg = isset($result['message']) ? $result['message'] : 'خطا در ارسال';
                $this->jsonResponse(false, 'خطا در ارسال کد تایید: ' . $errorMsg, [
                    'debug_code' => $code,
                    'mobile' => $normalizedMobile,
                    'result' => $result
                ]);
            }
        } else {
            $user = get_user_by('email', $identifier);
            if (!$user) {
                $user = get_user_by('login', $identifier);
            }
            
            if (!$user) {
                $this->jsonResponse(false, 'کاربری با این اطلاعات یافت نشد');
                return;
            }
            
            $this->jsonResponse(true, 'کد تایید به ایمیل شما ارسال شد', [
                'token' => 'email_' . bin2hex(random_bytes(16)),
                'email' => $user->user_email,
                'is_mobile' => false
            ]);
        }
        
    } catch (\Exception $e) {
        error_log('[LoginPro] Exception: ' . $e->getMessage());
        $this->jsonResponse(false, 'خطای سیستمی: ' . $e->getMessage());
    }
}
    
    public function handleVerifyOtp(): void {
        try {
            $nonce = $this->request->post('_nonce', '');
            if (!wp_verify_nonce($nonce, 'loginpro_ajax_nonce')) {
                $this->jsonResponse(false, 'خطای امنیتی');
                return;
            }
            
            $mobile = $this->request->post('mobile', '');
            $code = $this->request->post('code', '');
            $token = $this->request->post('token', '');
            
            if (empty($mobile) || empty($code) || empty($token)) {
                $this->jsonResponse(false, 'اطلاعات ناقص است');
                return;
            }
            
            $result = $this->otpService->verifyOtp($mobile, $code, $token);
            
            if ($result === false) {
                $this->jsonResponse(false, 'کد تایید نامعتبر یا منقضی شده است');
                return;
            }
            
            if ($result['is_new_user']) {
                $userId = $this->createUserFromMobile($result['mobile']);
                if ($userId) {
                    $result['user_id'] = $userId;
                    $result['is_new_user'] = true;
                } else {
                    $this->jsonResponse(false, 'خطا در ایجاد حساب کاربری');
                    return;
                }
            }
            
            wp_set_auth_cookie($result['user_id'], true);
            wp_set_current_user($result['user_id']);
            
            $user = get_userdata($result['user_id']);
            if ($user) {
                do_action('wp_login', $user->user_login, $user);
            }
            
            $this->jsonResponse(true, 'ورود با موفقیت انجام شد', [
                'user_id' => $result['user_id'],
                'is_new' => $result['is_new_user'],
                'redirect' => $this->getRedirectUrl($result['user_id'])
            ]);
            
        } catch (\Exception $e) {
            error_log('handleVerifyOtp Exception: ' . $e->getMessage());
            $this->jsonResponse(false, 'خطای سیستمی: ' . $e->getMessage());
        }
    }
    
    public function handleResendOtp(): void {
        try {
            $nonce = $this->request->post('_nonce', '');
            if (!wp_verify_nonce($nonce, 'loginpro_ajax_nonce')) {
                $this->jsonResponse(false, 'خطای امنیتی');
                return;
            }
            
            $mobile = $this->request->post('mobile', '');
            $type = $this->request->post('type', 'login');
            
            if (empty($mobile)) {
                $this->jsonResponse(false, 'شماره موبایل را وارد کنید');
                return;
            }
            
            $normalizedMobile = $this->otpService->normalizeMobile($mobile);
            
            $otpData = $this->otpService->resendOtp($normalizedMobile);
            
            if ($otpData === false) {
                $this->jsonResponse(false, 'تعداد ارسال مجدد بیش از حد مجاز است');
                return;
            }
            
            $sent = false;
            if ($this->dispatcher !== null) {
                $sent = $this->dispatcher->sendViaSms($normalizedMobile, $otpData['code'], $type);
            }
            
            if ($sent) {
                $this->jsonResponse(true, 'کد تایید مجدداً ارسال شد', [
                    'token' => $otpData['session_token'],
                    'mobile' => $normalizedMobile
                ]);
            } else {
                $this->jsonResponse(false, 'خطا در ارسال مجدد کد');
            }
            
        } catch (\Exception $e) {
            error_log('handleResendOtp Exception: ' . $e->getMessage());
            $this->jsonResponse(false, 'خطای سیستمی');
        }
    }
    
    public function requestOtp(): void {
        $this->handleCheckIdentifier();
    }
    
    public function verifyOtp(): void {
        $this->handleVerifyOtp();
    }
    
    public function resendOtp(): void {
        $this->handleResendOtp();
    }
    
    private function createUserFromMobile(string $mobile): int|false {
        $username = 'user_' . $mobile;
        $email = $mobile . '@temp.loginpro.local';
        
        $existing = get_user_by('login', $username);
        if ($existing) {
            return $existing->ID;
        }
        
        $existingEmail = get_user_by('email', $email);
        if ($existingEmail) {
            return $existingEmail->ID;
        }
        
        $userId = wp_create_user($username, wp_generate_password(), $email);
        
        if (is_wp_error($userId)) {
            error_log('User creation failed: ' . $userId->get_error_message());
            return false;
        }
        
        update_user_meta($userId, 'mobile_number', $mobile);
        update_user_meta($userId, 'mobile_verified', 'yes');
        
        return $userId;
    }
    
    private function getRedirectUrl(int $userId): string {
        $redirect = $this->request->post('redirect_to', '');
        
        if (!empty($redirect)) {
            return $redirect;
        }
        
        $default = get_option('loginpro_redirect_after_login', '');
        
        if (!empty($default)) {
            return $default;
        }
        
        return home_url();
    }
    
    private function jsonResponse(bool $success, string $message, array $data = []): void {
        wp_send_json([
            'success' => $success,
            'message' => $message,
            'data' => $data
        ]);
    }
}