<?php
namespace LoginPro\Modules\Auth;

defined('ABSPATH') || exit;

class Module {
    
    public function init() {
        $this->registerHooks();
        $this->loadRoutes();
    }
    
    private function registerHooks() {
        // هوک‌های مربوط به احراز هویت
        add_filter('authenticate', [$this, 'handleOtpLogin'], 20, 3);
    }
    
    private function loadRoutes() {
        $routesFile = __DIR__ . '/routes.php';
        if (file_exists($routesFile)) {
            require_once $routesFile;
        }
    }
    
    /**
     * مدیریت ورود با OTP
     */
    public function handleOtpLogin($user, $username, $password) {
        // اگر OTP ارسال شده، پردازش توسط کنترلر انجام می‌شود
        if (isset($_POST['loginpro_otp_login']) && $_POST['loginpro_otp_login'] === '1') {
            return null;
        }
        
        return $user;
    }
}