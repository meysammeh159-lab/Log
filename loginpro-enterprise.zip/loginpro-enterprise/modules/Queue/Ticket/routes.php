<?php
/**
 * Ticket Module Routes
 * مسیرهای مربوط به ماژول تیکت
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

use LoginPro\Security\NonceManager;
use LoginPro\Security\PermissionChecker;

// ==================================================
// ✅ REST API Routes
// ==================================================

add_action('rest_api_init', function() {
    register_rest_route('loginpro/v1', '/tickets', [
        'methods' => 'GET',
        'callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'لطفاً وارد شوید'
                ], 401);
            }
            
            $user_id = get_current_user_id();
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $tickets = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM %i WHERE user_id = %d ORDER BY created_at DESC",
                    $table,
                    $user_id
                )
            );
            
            return new WP_REST_Response([
                'success' => true,
                'data' => $tickets
            ], 200);
        },
        'permission_callback' => '__return_true'
    ]);
    
    register_rest_route('loginpro/v1', '/tickets', [
        'methods' => 'POST',
        'callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'لطفاً وارد شوید'
                ], 401);
            }
            
            $user_id = get_current_user_id();
            $subject = sanitize_text_field($request->get_param('subject') ?? '');
            $message = wp_kses_post($request->get_param('message') ?? '');
            
            if (empty($subject) || empty($message)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'لطفاً تمام فیلدها را پر کنید'
                ], 400);
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $result = $wpdb->insert(
                $table,
                [
                    'user_id' => $user_id,
                    'subject' => $subject,
                    'message' => $message,
                    'status' => 'pending',
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql')
                ],
                ['%d', '%s', '%s', '%s', '%s', '%s']
            );
            
            if ($result) {
                return new WP_REST_Response([
                    'success' => true,
                    'message' => 'تیکت با موفقیت ارسال شد',
                    'ticket_id' => $wpdb->insert_id
                ], 201);
            } else {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'خطا در ذخیره تیکت'
                ], 500);
            }
        },
        'permission_callback' => '__return_true'
    ]);
});