<?php
/**
 * Ticket Module
 * مدیریت تیکت‌های پشتیبانی
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Modules\Ticket;

use Exception;

defined('ABSPATH') || exit;

use LoginPro\Security\NonceManager;
use LoginPro\Security\PermissionChecker;
use LoginPro\Security\FileValidator;
use LoginPro\Security\RateLimiter;

/**
 * کلاس اصلی ماژول Ticket
 */
class Module {
    
    /**
     * @var string $module_name نام ماژول
     */
    private $module_name = 'ticket';
    
    /**
     * @var array $config تنظیمات ماژول
     */
    private $config = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->load_config();
        $this->register_hooks();
        $this->register_shortcodes();
    }
    
    /**
     * بارگذاری تنظیمات
     */
    private function load_config() {
        $this->config = [
            'max_attachments' => get_option('loginpro_ticket_max_attachments', 3),
            'max_file_size' => get_option('loginpro_ticket_max_file_size', 5242880),
            'allowed_types' => get_option('loginpro_ticket_allowed_types', 'jpg,jpeg,png,gif,pdf,doc,docx,txt'),
            'auto_close_days' => get_option('loginpro_ticket_auto_close_days', 7),
        ];
    }
    
    /**
     * ثبت هوک‌ها
     */
    private function register_hooks() {
        add_action('init', [$this, 'init']);
        add_action('wp_ajax_loginpro_ticket_submit', [$this, 'ajax_submit_ticket']);
        add_action('wp_ajax_loginpro_ticket_get', [$this, 'ajax_get_tickets']);
        add_action('wp_ajax_loginpro_ticket_reply', [$this, 'ajax_reply_ticket']);
        add_action('wp_ajax_loginpro_ticket_close', [$this, 'ajax_close_ticket']);
        add_action('wp_ajax_loginpro_ticket_delete', [$this, 'ajax_delete_ticket']);
        
        // Cron برای بستن خودکار تیکت‌ها
        add_action('loginpro_ticket_auto_close', [$this, 'auto_close_tickets']);
    }
    
    /**
     * ثبت شورت‌کدها
     */
    private function register_shortcodes() {
        add_shortcode('loginpro_ticket_form', [$this, 'render_ticket_form']);
        add_shortcode('loginpro_ticket_list', [$this, 'render_ticket_list']);
    }
    
    /**
     * مقداردهی اولیه
     */
    public function init() {
        // زمان‌بندی بستن خودکار تیکت‌ها
        if (!wp_next_scheduled('loginpro_ticket_auto_close')) {
            wp_schedule_event(time(), 'daily', 'loginpro_ticket_auto_close');
        }
    }
    
    /**
     * رندر فرم تیکت
     */
    public function render_ticket_form($atts = []) {
        if (!is_user_logged_in()) {
            return '<p class="loginpro-not-logged-in">' . sprintf(
                __('لطفاً <a href="%s">وارد شوید</a>', 'loginpro'),
                esc_url(wp_login_url())
            ) . '</p>';
        }
        
        $user_id = get_current_user_id();
        $nonce = NonceManager::create('submit_ticket', $user_id);
        
        ob_start();
        ?>
        <div class="loginpro-ticket-form" data-nonce="<?php echo esc_attr($nonce); ?>">
            <h3><?php esc_html_e('📝 ارسال تیکت پشتیبانی', 'loginpro'); ?></h3>
            <div id="ticket-message" style="display:none;margin-bottom:15px;padding:12px;border-radius:8px;"></div>
            
            <div class="form-group" style="margin-bottom:15px;">
                <label for="ticket-subject" style="display:block;margin-bottom:5px;font-weight:500;">
                    <?php esc_html_e('موضوع', 'loginpro'); ?>
                </label>
                <input type="text" id="ticket-subject" placeholder="<?php esc_attr_e('موضوع تیکت', 'loginpro'); ?>" 
                       style="width:100%;height:45px;padding:0 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;" 
                       maxlength="200">
            </div>
            
            <div class="form-group" style="margin-bottom:15px;">
                <label for="ticket-message" style="display:block;margin-bottom:5px;font-weight:500;">
                    <?php esc_html_e('متن پیام', 'loginpro'); ?>
                </label>
                <textarea id="ticket-message" placeholder="<?php esc_attr_e('متن تیکت خود را وارد کنید', 'loginpro'); ?>" 
                          style="width:100%;min-height:150px;padding:10px 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;font-family:inherit;" 
                          maxlength="5000"></textarea>
            </div>
            
            <div class="form-group" style="margin-bottom:15px;">
                <label style="display:block;margin-bottom:5px;font-weight:500;">
                    <?php esc_html_e('پیوست‌ها (اختیاری)', 'loginpro'); ?>
                </label>
                <div id="attachment-container">
                    <div class="attachment-row" style="display:flex;gap:10px;margin-bottom:8px;">
                        <input type="file" class="ticket-attachment" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.txt" 
                               style="flex:1;padding:5px;">
                        <button type="button" class="remove-attachment" style="background:#dc3545;color:#fff;border:none;border-radius:6px;padding:0 12px;cursor:pointer;display:none;">×</button>
                    </div>
                </div>
                <button type="button" id="add-attachment" style="background:transparent;color:#ef394e;border:1px dashed #ef394e;border-radius:8px;padding:8px 15px;cursor:pointer;font-size:13px;">
                    ➕ <?php esc_html_e('افزودن پیوست', 'loginpro'); ?>
                </button>
                <p style="font-size:12px;color:#999;margin-top:5px;">
                    <?php echo sprintf(
                        esc_html__('فرمت‌های مجاز: %s (حداکثر %s)', 'loginpro'),
                        esc_html($this->config['allowed_types']),
                        $this->format_size($this->config['max_file_size'])
                    ); ?>
                </p>
            </div>
            
            <button id="submit-ticket-btn" class="loginpro-primary-btn" 
                    style="width:100%;height:48px;background:#ef394e;color:#fff;border:none;border-radius:12px;cursor:pointer;font-size:16px;font-weight:500;transition:all 0.3s ease;">
                <?php esc_html_e('ارسال تیکت', 'loginpro'); ?>
            </button>
        </div>
        
        <script type="text/javascript">
        (function() {
            'use strict';
            var form = document.querySelector('.loginpro-ticket-form');
            if (!form) return;
            
            var nonce = form.getAttribute('data-nonce');
            var btn = document.getElementById('submit-ticket-btn');
            var msg = document.getElementById('ticket-message');
            var maxAttachments = <?php echo intval($this->config['max_attachments']); ?>;
            var maxFileSize = <?php echo intval($this->config['max_file_size']); ?>;
            
            // افزودن پیوست
            document.getElementById('add-attachment').addEventListener('click', function() {
                var rows = document.querySelectorAll('.attachment-row');
                if (rows.length >= maxAttachments) {
                    msg.style.display = 'block';
                    msg.style.backgroundColor = '#fff5f5';
                    msg.style.color = '#dc3545';
                    msg.style.border = '1px solid #f5c6cb';
                    msg.textContent = '❌ <?php echo esc_js(__('حداکثر تعداد پیوست مجاز', 'loginpro')); ?>: ' + maxAttachments;
                    return;
                }
                
                var container = document.getElementById('attachment-container');
                var newRow = document.createElement('div');
                newRow.className = 'attachment-row';
                newRow.style.cssText = 'display:flex;gap:10px;margin-bottom:8px;';
                newRow.innerHTML = `
                    <input type="file" class="ticket-attachment" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.txt" style="flex:1;padding:5px;">
                    <button type="button" class="remove-attachment" style="background:#dc3545;color:#fff;border:none;border-radius:6px;padding:0 12px;cursor:pointer;">×</button>
                `;
                container.appendChild(newRow);
                
                // حذف پیوست
                newRow.querySelector('.remove-attachment').addEventListener('click', function() {
                    newRow.remove();
                });
            });
            
            // حذف پیوست‌های اولیه
            document.querySelectorAll('.remove-attachment').forEach(function(btn) {
                btn.style.display = 'none';
            });
            
            // ارسال تیکت
            if (btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    var subject = document.getElementById('ticket-subject').value.trim();
                    var message = document.getElementById('ticket-message').value.trim();
                    var files = document.querySelectorAll('.ticket-attachment');
                    
                    if (!subject) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('لطفاً موضوع تیکت را وارد کنید', 'loginpro')); ?>';
                        return;
                    }
                    
                    if (!message) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('لطفاً متن تیکت را وارد کنید', 'loginpro')); ?>';
                        return;
                    }
                    
                    // بررسی حجم فایل‌ها
                    var totalSize = 0;
                    for (var i = 0; i < files.length; i++) {
                        if (files[i].files[0]) {
                            totalSize += files[i].files[0].size;
                            if (files[i].files[0].size > maxFileSize) {
                                msg.style.display = 'block';
                                msg.style.backgroundColor = '#fff5f5';
                                msg.style.color = '#dc3545';
                                msg.style.border = '1px solid #f5c6cb';
                                msg.textContent = '❌ <?php echo esc_js(__('حجم فایل بیش از حد مجاز است', 'loginpro')); ?>';
                                return;
                            }
                        }
                    }
                    
                    btn.disabled = true;
                    btn.textContent = '<?php echo esc_js(__('در حال ارسال...', 'loginpro')); ?>';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_ticket_submit');
                    formData.append('_nonce', nonce);
                    formData.append('subject', subject);
                    formData.append('message', message);
                    
                    for (var i = 0; i < files.length; i++) {
                        if (files[i].files[0]) {
                            formData.append('attachments[]', files[i].files[0]);
                        }
                    }
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#f0fff4';
                            msg.style.color = '#28a745';
                            msg.style.border = '1px solid #c3e6cb';
                            msg.textContent = '✅ ' + response.data.message;
                            document.getElementById('ticket-subject').value = '';
                            document.getElementById('ticket-message').value = '';
                            document.querySelectorAll('.ticket-attachment').forEach(function(input) {
                                input.value = '';
                            });
                        } else {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#fff5f5';
                            msg.style.color = '#dc3545';
                            msg.style.border = '1px solid #f5c6cb';
                            msg.textContent = '❌ ' + response.data.message;
                        }
                        btn.disabled = false;
                        btn.textContent = '<?php echo esc_js(__('ارسال تیکت', 'loginpro')); ?>';
                    })
                    .catch(function(error) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('خطا در ارتباط با سرور', 'loginpro')); ?>: ' + error.message;
                        btn.disabled = false;
                        btn.textContent = '<?php echo esc_js(__('ارسال تیکت', 'loginpro')); ?>';
                    });
                });
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * رندر لیست تیکت‌ها
     */
    public function render_ticket_list($atts = []) {
        if (!is_user_logged_in()) {
            return '<p class="loginpro-not-logged-in">' . sprintf(
                __('لطفاً <a href="%s">وارد شوید</a>', 'loginpro'),
                esc_url(wp_login_url())
            ) . '</p>';
        }
        
        $user_id = get_current_user_id();
        $nonce = NonceManager::create('get_tickets', $user_id);
        
        ob_start();
        ?>
        <div class="loginpro-ticket-list" data-nonce="<?php echo esc_attr($nonce); ?>">
            <h3><?php esc_html_e('🎫 لیست تیکت‌ها', 'loginpro'); ?></h3>
            <div id="ticket-list-message" style="display:none;margin-bottom:15px;padding:12px;border-radius:8px;"></div>
            <div id="ticket-list-container">
                <?php echo $this->get_user_tickets_html($user_id); ?>
            </div>
        </div>
        
        <script type="text/javascript">
        (function() {
            'use strict';
            var container = document.querySelector('.loginpro-ticket-list');
            if (!container) return;
            
            var nonce = container.getAttribute('data-nonce');
            var msg = document.getElementById('ticket-list-message');
            
            // تابع بارگذاری مجدد تیکت‌ها
            window.loadTickets = function() {
                var formData = new FormData();
                formData.append('action', 'loginpro_ticket_get');
                formData.append('_nonce', nonce);
                
                fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(res) { return res.json(); })
                .then(function(response) {
                    var container = document.getElementById('ticket-list-container');
                    if (response.success) {
                        container.innerHTML = response.data.html;
                    } else {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ ' + response.data.message;
                    }
                })
                .catch(function(error) {
                    console.error('Error loading tickets:', error);
                });
            };
            
            // حذف تیکت
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('delete-ticket-btn')) {
                    e.preventDefault();
                    var ticketId = e.target.getAttribute('data-ticket-id');
                    var ticketNonce = e.target.getAttribute('data-nonce');
                    
                    if (!confirm('<?php echo esc_js(__('آیا از حذف این تیکت اطمینان دارید؟', 'loginpro')); ?>')) return;
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_ticket_delete');
                    formData.append('_nonce', ticketNonce);
                    formData.append('ticket_id', ticketId);
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            window.loadTickets();
                        } else {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#fff5f5';
                            msg.style.color = '#dc3545';
                            msg.style.border = '1px solid #f5c6cb';
                            msg.textContent = '❌ ' + response.data.message;
                        }
                    })
                    .catch(function(error) {
                        console.error('Error deleting ticket:', error);
                    });
                }
            });
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * دریافت HTML لیست تیکت‌های کاربر
     */
    private function get_user_tickets_html($user_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        
        $tickets = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM %i WHERE user_id = %d ORDER BY created_at DESC",
                $table,
                $user_id
            )
        );
        
        if (empty($tickets)) {
            return '<p style="color:#999;">' . esc_html__('هیچ تیکتی ثبت نشده است.', 'loginpro') . '</p>';
        }
        
        $html = '<table style="width:100%;border-collapse:collapse;font-size:14px;">
            <thead>
                <tr style="background:#f8f9fa;">
                    <th style="padding:10px;text-align:right;">' . esc_html__('موضوع', 'loginpro') . '</th>
                    <th style="padding:10px;text-align:right;">' . esc_html__('وضعیت', 'loginpro') . '</th>
                    <th style="padding:10px;text-align:right;">' . esc_html__('تاریخ', 'loginpro') . '</th>
                    <th style="padding:10px;text-align:right;">' . esc_html__('عملیات', 'loginpro') . '</th>
                </tr>
            </thead>
            <tbody>';
        
        foreach ($tickets as $ticket) {
            $nonce = NonceManager::create('delete_ticket_' . $ticket->id, $user_id);
            $status_color = $this->get_status_color($ticket->status);
            
            $html .= '<tr style="border-bottom:1px solid #eee;">
                <td style="padding:10px;">' . esc_html($ticket->subject) . '</td>
                <td style="padding:10px;">
                    <span style="display:inline-block;padding:2px 10px;border-radius:12px;background:' . esc_attr($status_color) . ';color:#fff;font-size:12px;">
                        ' . esc_html($this->get_status_label($ticket->status)) . '
                    </span>
                </td>
                <td style="padding:10px;">' . esc_html(date_i18n('j F Y', strtotime($ticket->created_at))) . '</td>
                <td style="padding:10px;">
                    <button class="delete-ticket-btn" data-ticket-id="' . esc_attr($ticket->id) . '" data-nonce="' . esc_attr($nonce) . '" 
                            style="background:#dc3545;color:#fff;border:none;padding:4px 12px;border-radius:6px;cursor:pointer;">
                        ' . esc_html__('حذف', 'loginpro') . '
                    </button>
                </td>
            </tr>';
        }
        
        $html .= '</tbody></table>';
        return $html;
    }
    
    /**
     * دریافت رنگ وضعیت
     */
    private function get_status_color($status) {
        $colors = [
            'pending' => '#ffc107',
            'open' => '#17a2b8',
            'closed' => '#28a745',
        ];
        return isset($colors[$status]) ? $colors[$status] : '#6c757d';
    }
    
    /**
     * دریافت برچسب وضعیت
     */
    private function get_status_label($status) {
        $labels = [
            'pending' => __('در انتظار', 'loginpro'),
            'open' => __('باز', 'loginpro'),
            'closed' => __('بسته شده', 'loginpro'),
        ];
        return isset($labels[$status]) ? $labels[$status] : $status;
    }
    
    /**
     * Ajax: ارسال تیکت
     */
    public function ajax_submit_ticket() {
        try {
            $user_id = get_current_user_id();
            
            if (!NonceManager::check_request('submit_ticket', 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'لطفاً وارد شوید'], 401);
                return;
            }
            
            $subject = sanitize_text_field($_POST['subject'] ?? '');
            $message = wp_kses_post($_POST['message'] ?? '');
            
            if (empty($subject) || empty($message)) {
                wp_send_json_error(['message' => 'لطفاً تمام فیلدها را پر کنید']);
                return;
            }
            
            if (strlen($subject) > 200) {
                wp_send_json_error(['message' => 'موضوع بیش از حد طولانی است']);
                return;
            }
            
            if (strlen($message) > 5000) {
                wp_send_json_error(['message' => 'متن پیام بیش از حد طولانی است']);
                return;
            }
            
            // پردازش پیوست‌ها
            $attachments = [];
            if (isset($_FILES['attachments'])) {
                $files = $this->process_attachments($_FILES['attachments']);
                if (is_array($files)) {
                    $attachments = $files;
                } elseif (is_wp_error($files)) {
                    wp_send_json_error(['message' => $files->get_error_message()]);
                    return;
                }
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $result = $wpdb->insert(
                $table,
                [
                    'user_id' => $user_id,
                    'subject' => $subject,
                    'message' => $message,
                    'status' => 'pending',
                    'attachments' => maybe_serialize($attachments),
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql')
                ],
                ['%d', '%s', '%s', '%s', '%s', '%s', '%s']
            );
            
            if ($result) {
                do_action('loginpro_ticket_submitted', $wpdb->insert_id, $user_id);
                wp_send_json_success(['message' => 'تیکت با موفقیت ارسال شد']);
            } else {
                wp_send_json_error(['message' => 'خطا در ذخیره تیکت']);
            }
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    /**
     * پردازش پیوست‌ها
     */
    private function process_attachments($files) {
        $attachments = [];
        $validator = new FileValidator([
            'max_size' => $this->config['max_file_size'],
            'allowed_types' => $this->get_allowed_types_array()
        ]);
        
        $max_files = intval($this->config['max_attachments']);
        $upload_dir = wp_upload_dir();
        $ticket_dir = $upload_dir['path'] . '/tickets/';
        
        if (!file_exists($ticket_dir)) {
            wp_mkdir_p($ticket_dir);
        }
        
        $file_count = 0;
        foreach ($files['tmp_name'] as $key => $tmp_name) {
            if ($file_count >= $max_files) {
                break;
            }
            
            if ($files['error'][$key] !== UPLOAD_ERR_OK) {
                continue;
            }
            
            $file = [
                'name' => $files['name'][$key],
                'tmp_name' => $tmp_name,
                'size' => $files['size'][$key],
                'error' => $files['error'][$key]
            ];
            
            $result = $validator->validate($file);
            if (!$result['valid']) {
                continue;
            }
            
            $safe_name = $result['name'];
            $file_path = $ticket_dir . $safe_name;
            
            if (move_uploaded_file($tmp_name, $file_path)) {
                $attachments[] = [
                    'name' => $safe_name,
                    'original' => $files['name'][$key],
                    'size' => $files['size'][$key],
                    'mime' => $result['mime_type'],
                    'path' => str_replace($upload_dir['basedir'], '', $file_path)
                ];
                $file_count++;
            }
        }
        
        return $attachments;
    }
    
    /**
     * دریافت لیست انواع مجاز
     */
    private function get_allowed_types_array() {
        $types = explode(',', $this->config['allowed_types']);
        $allowed = [];
        
        $mime_map = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'txt' => 'text/plain',
        ];
        
        foreach ($types as $type) {
            $type = trim($type);
            if (isset($mime_map[$type])) {
                $allowed[$type] = $mime_map[$type];
            }
        }
        
        return $allowed;
    }
    
    /**
     * Ajax: دریافت تیکت‌ها
     */
    public function ajax_get_tickets() {
        try {
            $user_id = get_current_user_id();
            
            if (!NonceManager::check_request('get_tickets', 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'لطفاً وارد شوید'], 401);
                return;
            }
            
            $html = $this->get_user_tickets_html($user_id);
            wp_send_json_success(['html' => $html]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    /**
     * Ajax: پاسخ به تیکت
     */
    public function ajax_reply_ticket() {
        // پیاده‌سازی...
    }
    
    /**
     * Ajax: بستن تیکت
     */
    public function ajax_close_ticket() {
        // پیاده‌سازی...
    }
    
    /**
     * Ajax: حذف تیکت
     */
    public function ajax_delete_ticket() {
        try {
            $user_id = get_current_user_id();
            $ticket_id = intval($_POST['ticket_id'] ?? 0);
            
            if (!NonceManager::check_request('delete_ticket_' . $ticket_id, 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'لطفاً وارد شوید'], 401);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $deleted = $wpdb->delete(
                $table,
                ['id' => $ticket_id, 'user_id' => $user_id],
                ['%d', '%d']
            );
            
            if ($deleted) {
                wp_send_json_success(['message' => 'تیکت با موفقیت حذف شد']);
            } else {
                wp_send_json_error(['message' => 'خطا در حذف تیکت']);
            }
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    /**
     * بستن خودکار تیکت‌ها
     */
    public function auto_close_tickets() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        
        $days = intval($this->config['auto_close_days']);
        $closed_date = date('Y-m-d H:i:s', time() - ($days * 86400));
        
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE %i SET status = 'closed', updated_at = %s 
                 WHERE status IN ('pending', 'open') AND updated_at < %s",
                $table,
                current_time('mysql'),
                $closed_date
            )
        );
    }
    
    /**
     * فرمت کردن سایز
     */
    private function format_size($bytes) {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' B';
        }
    }
}

// ==================================================
// ✅ مقداردهی اولیه ماژول
// ==================================================

if (class_exists('LoginPro\Modules\Ticket\Module')) {
    new \LoginPro\Modules\Ticket\Module();
}