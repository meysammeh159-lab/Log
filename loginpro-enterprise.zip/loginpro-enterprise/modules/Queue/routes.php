<?php
/**
 * Queue Module Routes
 * مسیرهای مربوط به ماژول صف
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

use LoginPro\Security\NonceManager;
use LoginPro\Security\PermissionChecker;

// ==================================================
// ✅ REST API Routes
// ==================================================

add_action('rest_api_init', function() {
    register_rest_route('loginpro/v1', '/queue/stats', [
        'methods' => 'GET',
        'callback' => function($request) {
            if (!current_user_can('manage_options')) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'دسترسی غیرمجاز'
                ], 403);
            }
            
            if (class_exists('LoginPro\Modules\Queue\Module')) {
                $module = new \LoginPro\Modules\Queue\Module();
                $stats = $module->get_stats();
                return new WP_REST_Response([
                    'success' => true,
                    'data' => $stats
                ], 200);
            }
            
            return new WP_REST_Response([
                'success' => false,
                'message' => 'ماژول صف فعال نیست'
            ], 404);
        },
        'permission_callback' => '__return_true'
    ]);
    
    register_rest_route('loginpro/v1', '/queue/jobs', [
        'methods' => 'GET',
        'callback' => function($request) {
            if (!current_user_can('manage_options')) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'دسترسی غیرمجاز'
                ], 403);
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_queue_jobs';
            $limit = intval($request->get_param('limit') ?: 50);
            $status = sanitize_text_field($request->get_param('status') ?: '');
            
            $where = '';
            if (!empty($status)) {
                $where = $wpdb->prepare(" WHERE status = %s", $status);
            }
            
            $jobs = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM %i $where ORDER BY created_at DESC LIMIT %d",
                    $table,
                    $limit
                )
            );
            
            return new WP_REST_Response([
                'success' => true,
                'data' => $jobs
            ], 200);
        },
        'permission_callback' => '__return_true'
    ]);
});

// ==================================================
// ✅ Ajax Routes
// ==================================================

add_action('wp_ajax_loginpro_queue_process', function() {
    try {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'دسترسی غیرمجاز'], 403);
            return;
        }
        
        if (class_exists('LoginPro\Modules\Queue\Module')) {
            $module = new \LoginPro\Modules\Queue\Module();
            $module->process_queue();
            wp_send_json_success(['message' => 'صف با موفقیت پردازش شد']);
        } else {
            wp_send_json_error(['message' => 'ماژول صف فعال نیست'], 404);
        }
    } catch (Exception $e) {
        wp_send_json_error(['message' => $e->getMessage()], 500);
    }
});

add_action('wp_ajax_loginpro_queue_add', function() {
    try {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'دسترسی غیرمجاز'], 403);
            return;
        }
        
        $callback = sanitize_text_field($_POST['callback'] ?? '');
        $args = isset($_POST['args']) ? json_decode(stripslashes($_POST['args']), true) : [];
        $priority = intval($_POST['priority'] ?? 0);
        
        if (empty($callback)) {
            wp_send_json_error(['message' => 'تابع callback مشخص نشده است']);
            return;
        }
        
        if (class_exists('LoginPro\Modules\Queue\Module')) {
            $module = new \LoginPro\Modules\Queue\Module();
            $job_id = $module->add_job($callback, $args, $priority);
            
            if ($job_id) {
                wp_send_json_success([
                    'message' => 'کار با موفقیت به صف اضافه شد',
                    'job_id' => $job_id
                ]);
            } else {
                wp_send_json_error(['message' => 'خطا در افزودن کار به صف']);
            }
        } else {
            wp_send_json_error(['message' => 'ماژول صف فعال نیست'], 404);
        }
    } catch (Exception $e) {
        wp_send_json_error(['message' => $e->getMessage()], 500);
    }
});