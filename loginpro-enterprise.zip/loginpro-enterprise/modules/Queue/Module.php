<?php
/**
 * Queue Module
 * مدیریت صف‌های پردازش و عملیات‌های ناهمگام
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Modules\Queue;

use Exception;

defined('ABSPATH') || exit;

/**
 * کلاس اصلی ماژول Queue
 */
class Module {
    
    /**
     * @var string $module_name نام ماژول
     */
    private $module_name = 'queue';
    
    /**
     * @var array $config تنظیمات ماژول
     */
    private $config = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->load_config();
        $this->register_hooks();
    }
    
    /**
     * بارگذاری تنظیمات
     */
    private function load_config() {
        $this->config = [
            'max_attempts' => get_option('loginpro_queue_max_attempts', 3),
            'retry_delay' => get_option('loginpro_queue_retry_delay', 300),
            'batch_size' => get_option('loginpro_queue_batch_size', 50),
            'timeout' => get_option('loginpro_queue_timeout', 300),
        ];
    }
    
    /**
     * ثبت هوک‌ها
     */
    private function register_hooks() {
        add_action('init', [$this, 'init']);
        add_action('loginpro_queue_process', [$this, 'process_queue']);
        add_action('loginpro_queue_retry', [$this, 'retry_failed_jobs']);
    }
    
    /**
     * مقداردهی اولیه
     */
    public function init() {
        // بررسی و پردازش صف
        if (!wp_next_scheduled('loginpro_queue_process')) {
            wp_schedule_event(time(), 'every_five_minutes', 'loginpro_queue_process');
        }
        
        // بررسی و تکرار کارهای ناموفق
        if (!wp_next_scheduled('loginpro_queue_retry')) {
            wp_schedule_event(time(), 'hourly', 'loginpro_queue_retry');
        }
    }
    
    /**
     * پردازش صف
     */
    public function process_queue() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_queue_jobs';
        
        // دریافت کارهای آماده پردازش
        $jobs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM %i WHERE status = 'pending' AND scheduled_at <= %s ORDER BY priority DESC, created_at ASC LIMIT %d",
                $table,
                current_time('mysql'),
                $this->config['batch_size']
            )
        );
        
        if (empty($jobs)) {
            return;
        }
        
        foreach ($jobs as $job) {
            $this->process_job($job);
        }
    }
    
    /**
     * پردازش یک کار
     */
    private function process_job($job) {
        try {
            // به‌روزرسانی وضعیت به در حال پردازش
            $this->update_job_status($job->id, 'processing');
            
            // اجرای کار
            $result = $this->execute_job($job);
            
            if ($result === true) {
                $this->update_job_status($job->id, 'completed');
                do_action('loginpro_queue_job_completed', $job->id, $job);
            } else {
                $this->handle_job_failure($job, $result);
            }
            
        } catch (Exception $e) {
            $this->handle_job_failure($job, $e->getMessage());
        }
    }
    
    /**
     * اجرای کار
     */
    private function execute_job($job) {
        $data = maybe_unserialize($job->data);
        
        if (empty($data) || !isset($data['callback'])) {
            return 'Invalid job data';
        }
        
        $callback = $data['callback'];
        $args = isset($data['args']) ? $data['args'] : [];
        
        if (is_callable($callback)) {
            return call_user_func_array($callback, $args);
        }
        
        return 'Callback not callable';
    }
    
    /**
     * مدیریت خطای کار
     */
    private function handle_job_failure($job, $error) {
        $attempts = intval($job->attempts) + 1;
        
        if ($attempts >= $this->config['max_attempts']) {
            $this->update_job_status($job->id, 'failed', $error);
            do_action('loginpro_queue_job_failed', $job->id, $job, $error);
        } else {
            $this->update_job_status($job->id, 'pending', $error, $attempts);
            
            // زمان‌بندی مجدد
            $retry_time = date('Y-m-d H:i:s', time() + $this->config['retry_delay']);
            $this->schedule_retry($job->id, $retry_time);
        }
    }
    
    /**
     * به‌روزرسانی وضعیت کار
     */
    private function update_job_status($job_id, $status, $error = '', $attempts = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_queue_jobs';
        
        $data = [
            'status' => $status,
            'updated_at' => current_time('mysql')
        ];
        
        if ($attempts !== null) {
            $data['attempts'] = $attempts;
        }
        
        if (!empty($error)) {
            $data['error'] = substr($error, 0, 500);
        }
        
        if ($status === 'completed' || $status === 'failed') {
            $data['completed_at'] = current_time('mysql');
        }
        
        $wpdb->update($table, $data, ['id' => $job_id]);
    }
    
    /**
     * زمان‌بندی مجدد کار
     */
    private function schedule_retry($job_id, $scheduled_at) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_queue_jobs';
        
        $wpdb->update(
            $table,
            ['scheduled_at' => $scheduled_at],
            ['id' => $job_id]
        );
    }
    
    /**
     * تلاش مجدد برای کارهای ناموفق
     */
    public function retry_failed_jobs() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_queue_jobs';
        
        $jobs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM %i WHERE status = 'failed' AND attempts < %d AND scheduled_at <= %s",
                $table,
                $this->config['max_attempts'],
                current_time('mysql')
            )
        );
        
        foreach ($jobs as $job) {
            $this->update_job_status($job->id, 'pending', '', $job->attempts);
            $this->schedule_retry($job->id, current_time('mysql'));
        }
    }
    
    /**
     * افزودن کار به صف
     */
    public function add_job($callback, $args = [], $priority = 0, $scheduled_at = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_queue_jobs';
        
        if ($scheduled_at === null) {
            $scheduled_at = current_time('mysql');
        }
        
        $data = [
            'callback' => $callback,
            'args' => $args
        ];
        
        $result = $wpdb->insert(
            $table,
            [
                'data' => maybe_serialize($data),
                'priority' => intval($priority),
                'status' => 'pending',
                'attempts' => 0,
                'scheduled_at' => $scheduled_at,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ],
            ['%s', '%d', '%s', '%d', '%s', '%s', '%s']
        );
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    /**
     * دریافت آمار صف
     */
    public function get_stats() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_queue_jobs';
        
        $stats = [
            'pending' => 0,
            'processing' => 0,
            'completed' => 0,
            'failed' => 0,
            'total' => 0
        ];
        
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT status, COUNT(*) as count FROM %i GROUP BY status",
                $table
            )
        );
        
        foreach ($results as $row) {
            $stats[$row->status] = intval($row->count);
            $stats['total'] += intval($row->count);
        }
        
        return $stats;
    }
}

// ==================================================
// ✅ مقداردهی اولیه ماژول
// ==================================================

if (class_exists('LoginPro\Modules\Queue\Module')) {
    new \LoginPro\Modules\Queue\Module();
}