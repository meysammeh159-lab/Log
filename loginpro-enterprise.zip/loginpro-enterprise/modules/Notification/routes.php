<?php
/**
 * Notification Module Routes
 * مسیرهای مربوط به ماژول اعلان‌ها
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ REST API Routes
// ==================================================

add_action('rest_api_init', function() {
    register_rest_route('loginpro/v1', '/notifications', [
        'methods' => 'GET',
        'callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'لطفاً وارد شوید'
                ], 401);
            }
            
            $user_id = get_current_user_id();
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_notifications';
            
            $notifications = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM %i WHERE user_id = %d ORDER BY created_at DESC LIMIT 20",
                    $table,
                    $user_id
                )
            );
            
            return new WP_REST_Response([
                'success' => true,
                'data' => $notifications
            ], 200);
        },
        'permission_callback' => '__return_true'
    ]);
    
    register_rest_route('loginpro/v1', '/notifications/read', [
        'methods' => 'POST',
        'callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'لطفاً وارد شوید'
                ], 401);
            }
            
            $user_id = get_current_user_id();
            $notification_id = intval($request->get_param('id') ?? 0);
            
            if (!$notification_id) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'شناسه اعلان نامعتبر'
                ], 400);
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_notifications';
            
            $updated = $wpdb->update(
                $table,
                ['is_read' => 1],
                ['id' => $notification_id, 'user_id' => $user_id],
                ['%d'],
                ['%d', '%d']
            );
            
            if ($updated !== false) {
                return new WP_REST_Response([
                    'success' => true,
                    'message' => 'اعلان به عنوان خوانده شده علامت‌گذاری شد'
                ], 200);
            } else {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'خطا در علامت‌گذاری اعلان'
                ], 500);
            }
        },
        'permission_callback' => '__return_true'
    ]);
    
    register_rest_route('loginpro/v1', '/notifications/count', [
        'methods' => 'GET',
        'callback' => function($request) {
            if (!is_user_logged_in()) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'لطفاً وارد شوید'
                ], 401);
            }
            
            $user_id = get_current_user_id();
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_notifications';
            
            $count = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE user_id = %d AND is_read = 0",
                    $table,
                    $user_id
                )
            );
            
            return new WP_REST_Response([
                'success' => true,
                'data' => ['count' => intval($count)]
            ], 200);
        },
        'permission_callback' => '__return_true'
    ]);
});