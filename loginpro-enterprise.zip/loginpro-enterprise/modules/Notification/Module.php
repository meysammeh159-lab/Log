<?php
/**
 * Notification Module
 * مدیریت اعلان‌ها و پیام‌ها
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Modules\Notification;

use Exception;

defined('ABSPATH') || exit;

use LoginPro\Security\NonceManager;
use LoginPro\Security\PermissionChecker;

/**
 * کلاس اصلی ماژول Notification
 */
class Module {
    
    /**
     * @var string $module_name نام ماژول
     */
    private $module_name = 'notification';
    
    /**
     * @var array $channels کانال‌های ارسال
     */
    private $channels = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->load_config();
        $this->register_hooks();
        $this->register_shortcodes();
    }
    
    /**
     * بارگذاری تنظیمات
     */
    private function load_config() {
        $this->channels = [
            'email' => [
                'enabled' => get_option('loginpro_notification_email_enabled', true),
                'from_name' => get_option('loginpro_notification_from_name', get_bloginfo('name')),
                'from_email' => get_option('loginpro_notification_from_email', get_option('admin_email')),
            ],
            'sms' => [
                'enabled' => get_option('loginpro_notification_sms_enabled', false),
            ],
            'whatsapp' => [
                'enabled' => get_option('loginpro_notification_whatsapp_enabled', false),
            ],
            'push' => [
                'enabled' => get_option('loginpro_notification_push_enabled', false),
            ],
        ];
    }
    
    /**
     * ثبت هوک‌ها
     */
    private function register_hooks() {
        // هوک‌های رویدادها
        add_action('loginpro_user_registered', [$this, 'send_welcome_notification'], 10, 2);
        add_action('loginpro_password_changed', [$this, 'send_password_changed_notification'], 10, 1);
        add_action('loginpro_ticket_submitted', [$this, 'send_ticket_notification'], 10, 2);
        add_action('loginpro_login_success', [$this, 'send_login_notification'], 10, 2);
        add_action('loginpro_security_event', [$this, 'send_security_notification'], 10, 2);
        
        // Ajax
        add_action('wp_ajax_loginpro_send_notification', [$this, 'ajax_send_notification']);
        add_action('wp_ajax_loginpro_get_notifications', [$this, 'ajax_get_notifications']);
        add_action('wp_ajax_loginpro_mark_notification_read', [$this, 'ajax_mark_notification_read']);
    }
    
    /**
     * ثبت شورت‌کدها
     */
    private function register_shortcodes() {
        add_shortcode('loginpro_notifications', [$this, 'render_notifications']);
    }
    
    /**
     * ارسال اعلان خوش‌آمدگویی
     */
    public function send_welcome_notification($user_id, $user_data) {
        $user = get_userdata($user_id);
        if (!$user) return;
        
        $subject = sprintf(__('به %s خوش آمدید', 'loginpro'), get_bloginfo('name'));
        $message = sprintf(
            __('سلام %s،' . "\n\n" . 'به سایت %s خوش آمدید.' . "\n\n" . 'امیدواریم از حضورتان لذت ببرید.', 'loginpro'),
            $user->display_name,
            get_bloginfo('name')
        );
        
        $this->send_notification($user_id, 'welcome', $subject, $message);
    }
    
    /**
     * ارسال اعلان تغییر رمز عبور
     */
    public function send_password_changed_notification($user_id) {
        $user = get_userdata($user_id);
        if (!$user) return;
        
        $subject = __('تغییر رمز عبور', 'loginpro');
        $message = sprintf(
            __('سلام %s،' . "\n\n" . 'رمز عبور حساب کاربری شما با موفقیت تغییر کرد.' . "\n\n" . 'اگر شما این تغییر را انجام نداده‌اید، لطفاً بلافاصله با ما تماس بگیرید.', 'loginpro'),
            $user->display_name
        );
        
        $this->send_notification($user_id, 'password_changed', $subject, $message);
    }
    
    /**
     * ارسال اعلان تیکت
     */
    public function send_ticket_notification($ticket_id, $user_id) {
        $user = get_userdata($user_id);
        if (!$user) return;
        
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        $ticket = $wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE id = %d", $table, $ticket_id));
        
        if (!$ticket) return;
        
        $subject = sprintf(__('تیکت جدید: %s', 'loginpro'), $ticket->subject);
        $message = sprintf(
            __('سلام %s،' . "\n\n" . 'تیکت شما با موضوع "%s" با موفقیت ثبت شد.' . "\n\n" . 'شماره پیگیری: %d' . "\n\n" . 'به زودی پاسخ شما ارسال خواهد شد.', 'loginpro'),
            $user->display_name,
            $ticket->subject,
            $ticket->id
        );
        
        $this->send_notification($user_id, 'ticket', $subject, $message);
        
        // ارسال به مدیر
        $admin_email = get_option('admin_email');
        $admin_subject = sprintf(__('تیکت جدید از %s', 'loginpro'), $user->display_name);
        $admin_message = sprintf(
            __('کاربر %s یک تیکت جدید ثبت کرده است.' . "\n\n" . 'موضوع: %s' . "\n\n" . 'متن: %s', 'loginpro'),
            $user->display_name,
            $ticket->subject,
            $ticket->message
        );
        
        $this->send_email($admin_email, $admin_subject, $admin_message);
    }
    
    /**
     * ارسال اعلان ورود
     */
    public function send_login_notification($user_id, $ip) {
        $user = get_userdata($user_id);
        if (!$user) return;
        
        $subject = __('ورود جدید به حساب کاربری', 'loginpro');
        $message = sprintf(
            __('سلام %s،' . "\n\n" . 'ورود جدیدی به حساب کاربری شما از آدرس IP: %s انجام شده است.' . "\n\n" . 'اگر شما نیستید، لطفاً بلافاصله رمز عبور خود را تغییر دهید.', 'loginpro'),
            $user->display_name,
            $ip
        );
        
        $this->send_notification($user_id, 'login', $subject, $message);
    }
    
    /**
     * ارسال اعلان امنیتی
     */
    public function send_security_notification($user_id, $event_data) {
        $user = get_userdata($user_id);
        if (!$user) return;
        
        $subject = __('هشدار امنیتی', 'loginpro');
        $message = sprintf(
            __('سلام %s،' . "\n\n" . 'یک رویداد امنیتی در حساب کاربری شما ثبت شده است:' . "\n\n" . '%s', 'loginpro'),
            $user->display_name,
            json_encode($event_data, JSON_PRETTY_PRINT)
        );
        
        $this->send_notification($user_id, 'security', $subject, $message);
    }
    
    /**
     * ارسال اعلان به کاربر
     */
    public function send_notification($user_id, $type, $subject, $message) {
        $user = get_userdata($user_id);
        if (!$user) return;
        
        // ذخیره در دیتابیس
        $this->save_notification($user_id, $type, $subject, $message);
        
        // ارسال ایمیل
        if ($this->is_channel_enabled('email')) {
            $this->send_email($user->user_email, $subject, $message);
        }
        
        // ارسال SMS (اگر فعال باشد)
        if ($this->is_channel_enabled('sms')) {
            $mobile = get_user_meta($user_id, 'loginpro_mobile', true);
            if ($mobile) {
                $this->send_sms($mobile, $message);
            }
        }
    }
    
    /**
     * ذخیره اعلان در دیتابیس
     */
    private function save_notification($user_id, $type, $subject, $message) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_notifications';
        
        // ایجاد جدول اگر وجود ندارد
        $this->create_table_if_not_exists();
        
        $wpdb->insert(
            $table,
            [
                'user_id' => $user_id,
                'type' => $type,
                'subject' => $subject,
                'message' => $message,
                'is_read' => 0,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%s', '%d', '%s']
        );
    }
    
    /**
     * ایجاد جدول اعلان‌ها
     */
    private function create_table_if_not_exists() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_notifications';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") == $table) {
            return;
        }
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            type varchar(50) NOT NULL,
            subject varchar(200) NOT NULL,
            message text NOT NULL,
            is_read tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY type (type),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * ارسال ایمیل
     */
    private function send_email($to, $subject, $message) {
        $headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . $this->channels['email']['from_name'] . ' <' . $this->channels['email']['from_email'] . '>'
        ];
        
        return wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * ارسال SMS
     */
    private function send_sms($to, $message) {
        // اینجا باید از سرویس SMS استفاده شود
        // فعلاً فقط لاگ می‌شود
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[LoginPro Notification] SMS to $to: $message");
        }
        return true;
    }
    
    /**
     * بررسی فعال بودن کانال
     */
    private function is_channel_enabled($channel) {
        return isset($this->channels[$channel]['enabled']) && $this->channels[$channel]['enabled'];
    }
    
    /**
     * رندر اعلان‌ها
     */
    public function render_notifications($atts = []) {
        if (!is_user_logged_in()) {
            return '<p class="loginpro-not-logged-in">' . sprintf(
                __('لطفاً <a href="%s">وارد شوید</a>', 'loginpro'),
                esc_url(wp_login_url())
            ) . '</p>';
        }
        
        $user_id = get_current_user_id();
        $nonce = NonceManager::create('get_notifications', $user_id);
        
        ob_start();
        ?>
        <div class="loginpro-notifications" data-nonce="<?php echo esc_attr($nonce); ?>">
            <h3><?php esc_html_e('📨 اعلان‌ها', 'loginpro'); ?></h3>
            <div id="notification-list">
                <?php echo $this->get_user_notifications_html($user_id); ?>
            </div>
        </div>
        
        <script type="text/javascript">
        (function() {
            'use strict';
            var container = document.querySelector('.loginpro-notifications');
            if (!container) return;
            
            var nonce = container.getAttribute('data-nonce');
            
            // بارگذاری مجدد اعلان‌ها
            window.loadNotifications = function() {
                var formData = new FormData();
                formData.append('action', 'loginpro_get_notifications');
                formData.append('_nonce', nonce);
                
                fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(res) { return res.json(); })
                .then(function(response) {
                    var container = document.getElementById('notification-list');
                    if (response.success) {
                        container.innerHTML = response.data.html;
                    }
                })
                .catch(function(error) {
                    console.error('Error loading notifications:', error);
                });
            };
            
            // علامت‌گذاری به عنوان خوانده شده
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('mark-read-btn')) {
                    e.preventDefault();
                    var notificationId = e.target.getAttribute('data-id');
                    var notificationNonce = e.target.getAttribute('data-nonce');
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_mark_notification_read');
                    formData.append('_nonce', notificationNonce);
                    formData.append('notification_id', notificationId);
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            window.loadNotifications();
                        }
                    })
                    .catch(function(error) {
                        console.error('Error marking notification read:', error);
                    });
                }
            });
            
            // بارگذاری اولیه
            window.loadNotifications();
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * دریافت HTML اعلان‌های کاربر
     */
    private function get_user_notifications_html($user_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_notifications';
        
        $notifications = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM %i WHERE user_id = %d ORDER BY created_at DESC LIMIT 20",
                $table,
                $user_id
            )
        );
        
        if (empty($notifications)) {
            return '<p style="color:#999;">' . esc_html__('هیچ اعلانی وجود ندارد.', 'loginpro') . '</p>';
        }
        
        $html = '<ul style="list-style:none;padding:0;margin:0;">';
        
        foreach ($notifications as $notification) {
            $nonce = NonceManager::create('mark_notification_read_' . $notification->id, $user_id);
            $bg_color = $notification->is_read ? '#f8f9fa' : '#ffffff';
            $border_color = $notification->is_read ? 'transparent' : '#ef394e';
            
            $html .= '<li style="padding:12px 15px;margin-bottom:8px;background:' . $bg_color . ';border-radius:8px;border-right:3px solid ' . $border_color . ';">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <div>
                        <strong style="font-size:14px;">' . esc_html($notification->subject) . '</strong>
                        <p style="margin:5px 0 0;font-size:13px;color:#666;">' . esc_html(wp_trim_words($notification->message, 15)) . '</p>
                        <span style="font-size:11px;color:#999;">' . esc_html(date_i18n('j F Y H:i', strtotime($notification->created_at))) . '</span>
                    </div>
                    ' . (!$notification->is_read ? '<button class="mark-read-btn" data-id="' . esc_attr($notification->id) . '" data-nonce="' . esc_attr($nonce) . '" style="background:#ef394e;color:#fff;border:none;border-radius:6px;padding:4px 12px;cursor:pointer;font-size:12px;">خوانده شد</button>' : '<span style="font-size:12px;color:#999;">خوانده شده</span>') . '
                </div>
            </li>';
        }
        
        $html .= '</ul>';
        return $html;
    }
    
    /**
     * Ajax: دریافت اعلان‌ها
     */
    public function ajax_get_notifications() {
        try {
            $user_id = get_current_user_id();
            
            if (!NonceManager::check_request('get_notifications', 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'لطفاً وارد شوید'], 401);
                return;
            }
            
            $html = $this->get_user_notifications_html($user_id);
            wp_send_json_success(['html' => $html]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    /**
     * Ajax: علامت‌گذاری اعلان به عنوان خوانده شده
     */
    public function ajax_mark_notification_read() {
        try {
            $user_id = get_current_user_id();
            $notification_id = intval($_POST['notification_id'] ?? 0);
            
            if (!NonceManager::check_request('mark_notification_read_' . $notification_id, 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'لطفاً وارد شوید'], 401);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_notifications';
            
            $updated = $wpdb->update(
                $table,
                ['is_read' => 1],
                ['id' => $notification_id, 'user_id' => $user_id],
                ['%d'],
                ['%d', '%d']
            );
            
            if ($updated !== false) {
                wp_send_json_success(['message' => 'اعلان به عنوان خوانده شده علامت‌گذاری شد']);
            } else {
                wp_send_json_error(['message' => 'خطا در علامت‌گذاری اعلان']);
            }
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    /**
     * Ajax: ارسال اعلان
     */
    public function ajax_send_notification() {
        try {
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'دسترسی غیرمجاز'], 403);
                return;
            }
            
            $user_id = intval($_POST['user_id'] ?? 0);
            $type = sanitize_text_field($_POST['type'] ?? '');
            $subject = sanitize_text_field($_POST['subject'] ?? '');
            $message = wp_kses_post($_POST['message'] ?? '');
            
            if (!$user_id || empty($type) || empty($subject) || empty($message)) {
                wp_send_json_error(['message' => 'لطفاً تمام فیلدها را پر کنید']);
                return;
            }
            
            $this->send_notification($user_id, $type, $subject, $message);
            
            wp_send_json_success(['message' => 'اعلان با موفقیت ارسال شد']);
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
}

// ==================================================
// ✅ مقداردهی اولیه ماژول
// ==================================================

if (class_exists('LoginPro\Modules\Notification\Module')) {
    new \LoginPro\Modules\Notification\Module();
}