<?php
use LoginPro\Core\Http\Router;

Router::get('security/events', [\LoginPro\Modules\Security\Controllers\SecurityController::class, 'getEvents']);
Router::get('security/score', [\LoginPro\Modules\Security\Controllers\SecurityController::class, 'getSecurityScore']);
