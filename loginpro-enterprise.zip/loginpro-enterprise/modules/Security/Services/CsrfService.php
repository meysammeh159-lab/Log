<?php
namespace LoginPro\Modules\Security\Services;

class CsrfService {
    
    public function generateToken() {
        if (!session_id()) {
            session_start();
        }
        
        if (empty($_SESSION['loginpro_csrf_token'])) {
            $_SESSION['loginpro_csrf_token'] = bin2hex(random_bytes(32));
        }
        
        return $_SESSION['loginpro_csrf_token'];
    }
    
    public function verifyToken($token) {
        if (!session_id()) {
            session_start();
        }
        
        if (empty($_SESSION['loginpro_csrf_token'])) {
            return false;
        }
        
        return hash_equals($_SESSION['loginpro_csrf_token'], $token);
    }
    
    public function getTokenField() {
        $token = $this->generateToken();
        return '<input type="hidden" name="csrf_token" value="' . esc_attr($token) . '">';
    }
    
    public function validateRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
            if (!$token || !$this->verifyToken($token)) {
                wp_die('CSRF token validation failed', 'Security Error', ['response' => 403]);
            }
        }
        return true;
    }
    
    public function refreshToken() {
        if (session_id()) {
            $_SESSION['loginpro_csrf_token'] = bin2hex(random_bytes(32));
        }
    }
}
