<?php
namespace LoginPro\Modules\Security\Services;

class CaptchaService {
    
    public function validate($token, $action = null) {
        $provider = get_option('loginpro_captcha_provider', 'none');
        
        if ($provider === 'none' || empty($token)) {
            return true;
        }
        
        switch ($provider) {
            case 'recaptcha':
                return $this->validateRecaptcha($token, $action);
            case 'hcaptcha':
                return $this->validateHcaptcha($token);
            case 'turnstile':
                return $this->validateTurnstile($token);
            default:
                return true;
        }
    }
    
    private function validateRecaptcha($token, $action) {
        $secret = get_option('loginpro_recaptcha_secret_key');
        
        if (!$secret) {
            return true;
        }
        
        $response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', [
            'body' => [
                'secret' => $secret,
                'response' => $token
            ]
        ]);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!$body['success']) {
            return false;
        }
        
        if ($action && isset($body['action']) && $body['action'] !== $action) {
            return false;
        }
        
        if (isset($body['score']) && $body['score'] < 0.5) {
            return false;
        }
        
        return true;
    }
    
    private function validateHcaptcha($token) {
        $secret = get_option('loginpro_hcaptcha_secret_key');
        
        if (!$secret) {
            return true;
        }
        
        $response = wp_remote_post('https://hcaptcha.com/siteverify', [
            'body' => [
                'secret' => $secret,
                'response' => $token
            ]
        ]);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['success'] === true;
    }
    
    private function validateTurnstile($token) {
        $secret = get_option('loginpro_turnstile_secret_key');
        
        if (!$secret) {
            return true;
        }
        
        $response = wp_remote_post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
            'body' => [
                'secret' => $secret,
                'response' => $token
            ]
        ]);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['success'] === true;
    }
    
    public function getSiteKey() {
        $provider = get_option('loginpro_captcha_provider', 'none');
        
        switch ($provider) {
            case 'recaptcha':
                return get_option('loginpro_recaptcha_site_key');
            case 'hcaptcha':
                return get_option('loginpro_hcaptcha_site_key');
            case 'turnstile':
                return get_option('loginpro_turnstile_site_key');
            default:
                return null;
        }
    }
    
    public function getProvider() {
        return get_option('loginpro_captcha_provider', 'none');
    }
    
    public function isEnabled() {
        $provider = $this->getProvider();
        return $provider !== 'none' && !empty($this->getSiteKey());
    }
}
