<?php
namespace LoginPro\Modules\Security\Services;

use LoginPro\Modules\Security\Models\SecurityEvent;

class SecurityAuditService {
    private $eventModel;
    
    public function __construct() {
        $this->eventModel = new SecurityEvent();
    }
    
    public function log($userId, $event, $severity = 'info', $details = []) {
        $data = [
            'user_id' => $userId,
            'event' => $event,
            'severity' => $severity,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'details' => json_encode($details),
            'created_at' => current_time('mysql')
        ];
        
        return $this->eventModel->query()->insert($data);
    }
    
    public function getUserEvents($userId, $limit = 50) {
        return $this->eventModel->query()
            ->where('user_id', $userId)
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }
    
    public function getEvents($filters = [], $limit = 100) {
        $query = $this->eventModel->query();
        
        if (isset($filters['user_id'])) {
            $query->where('user_id', $filters['user_id']);
        }
        if (isset($filters['event'])) {
            $query->where('event', $filters['event']);
        }
        if (isset($filters['severity'])) {
            $query->where('severity', $filters['severity']);
        }
        if (isset($filters['from_date'])) {
            $query->where('created_at', '>=', $filters['from_date']);
        }
        if (isset($filters['to_date'])) {
            $query->where('created_at', '<=', $filters['to_date']);
        }
        
        return $query->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }
    
    public function getFailedLogins($userId = null, $hours = 24) {
        $query = $this->eventModel->query()
            ->where('event', 'login_failed')
            ->where('created_at', '>', date('Y-m-d H:i:s', time() - ($hours * 3600)));
        
        if ($userId) {
            $query->where('user_id', $userId);
        }
        
        return $query->get();
    }
    
    public function cleanup($days = 30) {
        $expiryDate = date('Y-m-d H:i:s', time() - ($days * 86400));
        
        return $this->eventModel->query()
            ->where('created_at', '<', $expiryDate)
            ->delete();
    }
}
