<?php
namespace LoginPro\Modules\Security\Services;

use LoginPro\Modules\User\Models\UserDevice;

class DeviceTrackingService {
    private $deviceModel;
    
    public function __construct() {
        $this->deviceModel = new UserDevice();
    }
    
    public function track($userId) {
        $fingerprint = $this->getDeviceFingerprint();
        $device = $this->deviceModel->getByFingerprint($userId, $fingerprint);
        
        $deviceData = [
            'user_id' => $userId,
            'fingerprint' => $fingerprint,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'last_active' => current_time('mysql'),
            'device_name' => $this->getDeviceName(),
            'device_type' => $this->getDeviceType(),
            'browser' => $this->getBrowser(),
            'os' => $this->getOperatingSystem()
        ];
        
        if ($device) {
            $this->deviceModel->update($device['id'], $deviceData);
            $this->deviceModel->updateLastActive($device['id']);
            return $device['id'];
        }
        
        $deviceData['first_seen'] = current_time('mysql');
        $deviceData['is_trusted'] = 0;
        
        return $this->deviceModel->query()->insert($deviceData);
    }
    
    public function isTrustedDevice($userId) {
        $fingerprint = $this->getDeviceFingerprint();
        $device = $this->deviceModel->getByFingerprint($userId, $fingerprint);
        
        return $device && $device['is_trusted'] == 1;
    }
    
    public function trustDevice($deviceId, $userId) {
        return $this->deviceModel->trustDevice($deviceId, $userId);
    }
    
    public function revokeDevice($deviceId, $userId) {
        return $this->deviceModel->revoke($deviceId, $userId);
    }
    
    public function revokeAllOtherDevices($userId, $currentDeviceId) {
        return $this->deviceModel->revokeAllExcept($userId, $currentDeviceId);
    }
    
    public function getUserDevices($userId) {
        return $this->deviceModel->getByUser($userId);
    }
    
    private function getDeviceFingerprint() {
        $data = [
            $_SERVER['HTTP_USER_AGENT'] ?? '',
            $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
            $_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''
        ];
        
        return hash('sha256', implode('|', $data));
    }
    
    private function getDeviceName() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (strpos($userAgent, 'Windows') !== false) return 'Windows PC';
        if (strpos($userAgent, 'Mac') !== false) return 'Mac';
        if (strpos($userAgent, 'iPhone') !== false) return 'iPhone';
        if (strpos($userAgent, 'iPad') !== false) return 'iPad';
        if (strpos($userAgent, 'Android') !== false) return 'Android Device';
        return 'Unknown Device';
    }
    
    private function getDeviceType() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (strpos($userAgent, 'Mobile') !== false) return 'mobile';
        if (strpos($userAgent, 'Tablet') !== false) return 'tablet';
        return 'desktop';
    }
    
    private function getBrowser() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (strpos($userAgent, 'Chrome') !== false) return 'Chrome';
        if (strpos($userAgent, 'Firefox') !== false) return 'Firefox';
        if (strpos($userAgent, 'Safari') !== false) return 'Safari';
        if (strpos($userAgent, 'Edge') !== false) return 'Edge';
        if (strpos($userAgent, 'MSIE') !== false || strpos($userAgent, 'Trident') !== false) return 'Internet Explorer';
        return 'Unknown';
    }
    
    private function getOperatingSystem() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (strpos($userAgent, 'Windows') !== false) return 'Windows';
        if (strpos($userAgent, 'Mac OS X') !== false) return 'macOS';
        if (strpos($userAgent, 'Linux') !== false) return 'Linux';
        if (strpos($userAgent, 'Android') !== false) return 'Android';
        if (strpos($userAgent, 'iOS') !== false) return 'iOS';
        return 'Unknown';
    }
}
