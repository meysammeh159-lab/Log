<?php
namespace LoginPro\Modules\Security\Services;

class BruteForceService {
    private $transientPrefix = 'loginpro_bf_';
    private $maxAttempts;
    private $lockoutTime;
    
    public function __construct() {
        $this->maxAttempts = get_option('loginpro_bruteforce_max_attempts', 5);
        $this->lockoutTime = get_option('loginpro_bruteforce_lockout_time', 900);
    }
    
    public function isBlocked($ip) {
        if ($this->isWhitelisted($ip)) {
            return false;
        }

        $key = $this->transientPrefix . $ip;
        $blocked = get_transient($key . '_blocked');
        
        if ($blocked) {
            return true;
        }
        
        $attempts = $this->getAttempts($ip);
        return $attempts >= $this->maxAttempts;
    }
    
    public function getBlockedUntil($ip) {
        $key = $this->transientPrefix . $ip . '_blocked';
        $timeout = get_option('_transient_timeout_' . $key);
        return $timeout ?: null;
    }
    
    public function getRemainingAttempts($ip) {
        if ($this->isBlocked($ip)) {
            return 0;
        }
        
        $attempts = $this->getAttempts($ip);
        return max(0, $this->maxAttempts - $attempts);
    }
    
    public function recordAttempt($ip, $success = false) {
        if ($this->isWhitelisted($ip)) {
            return;
        }

        if ($success) {
            $this->clearAttempts($ip);
            return;
        }
        
        $key = $this->transientPrefix . $ip;
        $attempts = $this->getAttempts($ip);
        $attempts++;
        
        set_transient($key, $attempts, $this->lockoutTime);
        
        if ($attempts >= $this->maxAttempts) {
            set_transient($key . '_blocked', true, $this->lockoutTime);
            do_action('loginpro_ip_blocked', $ip, $attempts);
        }
    }
    
    private function getAttempts($ip) {
        $key = $this->transientPrefix . $ip;
        $attempts = get_transient($key);
        return $attempts ?: 0;
    }
    
    private function clearAttempts($ip) {
        $key = $this->transientPrefix . $ip;
        delete_transient($key);
        delete_transient($key . '_blocked');
    }
    
    public function resetAttempts($ip) {
        $this->clearAttempts($ip);
    }
    
    public function whitelistIp($ip) {
        $whitelist = get_option('loginpro_bruteforce_whitelist', []);
        if (!in_array($ip, $whitelist)) {
            $whitelist[] = $ip;
            update_option('loginpro_bruteforce_whitelist', $whitelist);
        }
    }
    
    public function isWhitelisted($ip) {
        $whitelist = get_option('loginpro_bruteforce_whitelist', []);
        return in_array($ip, $whitelist);
    }
}
