<?php
namespace LoginPro\Modules\Security\Services;

class RateLimitService {
    private $transientPrefix = 'loginpro_rl_';
    
    public function check($key, $limit, $window = 60) {
        $cacheKey = $this->transientPrefix . $key;
        $current = get_transient($cacheKey);
        
        if ($current === false) {
            set_transient($cacheKey, 1, $window);
            return true;
        }
        
        if ($current >= $limit) {
            return false;
        }
        
        set_transient($cacheKey, $current + 1, $window);
        return true;
    }
    
    public function getRemaining($key, $limit) {
        $cacheKey = $this->transientPrefix . $key;
        $current = get_transient($cacheKey);
        
        if ($current === false) {
            return $limit;
        }
        
        return max(0, $limit - $current);
    }
    
    public function getResetTime($key) {
        $cacheKey = $this->transientPrefix . $key;
        $timeout = get_option('_transient_timeout_' . $cacheKey);
        
        return $timeout ?: time();
    }
    
    public function increment($key, $window = 60) {
        $cacheKey = $this->transientPrefix . $key;
        $current = get_transient($cacheKey);
        
        if ($current === false) {
            set_transient($cacheKey, 1, $window);
            return 1;
        }
        
        set_transient($cacheKey, $current + 1, $window);
        return $current + 1;
    }
    
    public function reset($key) {
        $cacheKey = $this->transientPrefix . $key;
        delete_transient($cacheKey);
    }
}
