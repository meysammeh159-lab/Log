<?php
namespace LoginPro\Modules\Security\Services;

class FraudDetectionService {
    private $rules = [];
    
    public function __construct() {
        $this->loadRules();
    }
    
    private function loadRules() {
        $this->rules = [
            'unusual_location' => true,
            'unusual_time' => true,
            'multiple_failed_attempts' => true,
            'tor_exit_node' => get_option('loginpro_block_tor', false),
            'proxy_detection' => get_option('loginpro_block_proxy', false)
        ];
    }
    
    public function analyze($userId, $context = []) {
        $riskScore = 0;
        $flags = [];
        
        if ($this->rules['unusual_location']) {
            $locationRisk = $this->checkUnusualLocation($userId, $context);
            $riskScore += $locationRisk['score'];
            if ($locationRisk['flagged']) {
                $flags[] = 'unusual_location';
            }
        }
        
        if ($this->rules['unusual_time']) {
            $timeRisk = $this->checkUnusualTime($userId);
            $riskScore += $timeRisk['score'];
            if ($timeRisk['flagged']) {
                $flags[] = 'unusual_time';
            }
        }
        
        if ($this->rules['multiple_failed_attempts']) {
            $attemptRisk = $this->checkFailedAttempts($userId);
            $riskScore += $attemptRisk['score'];
            if ($attemptRisk['flagged']) {
                $flags[] = 'multiple_failed_attempts';
            }
        }
        
        if ($this->rules['tor_exit_node'] && $this->isTorExitNode()) {
            $riskScore += 50;
            $flags[] = 'tor_exit_node';
        }
        
        if ($this->rules['proxy_detection'] && $this->isProxy()) {
            $riskScore += 40;
            $flags[] = 'proxy_detection';
        }
        
        $riskLevel = $this->getRiskLevel($riskScore);
        
        return [
            'risk_score' => min(100, $riskScore),
            'risk_level' => $riskLevel,
            'flags' => $flags,
            'requires_2fa' => $riskScore > 50,
            'requires_block' => $riskScore > 80,
            'recommendations' => $this->getRecommendations($riskLevel, $flags)
        ];
    }
    
    private function checkUnusualLocation($userId, $context) {
        $lastLogin = $this->getLastLoginLocation($userId);
        $currentLocation = $this->getCurrentLocation();
        
        if (!$lastLogin || !$currentLocation) {
            return ['score' => 0, 'flagged' => false];
        }
        
        $distance = $this->calculateDistance(
            $lastLogin['lat'], $lastLogin['lng'],
            $currentLocation['lat'], $currentLocation['lng']
        );
        
        if ($distance > 1000) {
            return ['score' => 50, 'flagged' => true];
        } elseif ($distance > 500) {
            return ['score' => 30, 'flagged' => true];
        } elseif ($distance > 100) {
            return ['score' => 15, 'flagged' => true];
        }
        
        return ['score' => 0, 'flagged' => false];
    }
    
    private function checkUnusualTime($userId) {
        $hour = (int)date('H');
        $userTimezone = get_user_meta($userId, 'timezone', true);
        
        if ($userTimezone) {
            try {
                $hour = (int)date('H', strtotime('now ' . $userTimezone));
            } catch (\Exception $e) {
                // Use local time
            }
        }
        
        if ($hour >= 0 && $hour < 5) {
            return ['score' => 15, 'flagged' => true];
        } elseif ($hour >= 23 || $hour <= 6) {
            return ['score' => 10, 'flagged' => true];
        }
        
        return ['score' => 0, 'flagged' => false];
    }
    
    private function checkFailedAttempts($userId) {
        $audit = new SecurityAuditService();
        $failedAttempts = $audit->getFailedLogins($userId, 1);
        
        $count = count($failedAttempts);
        if ($count >= 10) {
            return ['score' => 50, 'flagged' => true];
        } elseif ($count >= 5) {
            return ['score' => 25, 'flagged' => true];
        } elseif ($count >= 3) {
            return ['score' => 10, 'flagged' => true];
        }
        
        return ['score' => 0, 'flagged' => false];
    }
    
    private function getRiskLevel($score) {
        if ($score >= 80) return 'critical';
        if ($score >= 60) return 'high';
        if ($score >= 30) return 'medium';
        if ($score >= 10) return 'low';
        return 'none';
    }
    
    private function getRecommendations($level, $flags) {
        $recommendations = [];
        
        if ($level === 'critical' || $level === 'high') {
            $recommendations[] = 'Enable two-factor authentication';
            $recommendations[] = 'Review your recent account activity';
            $recommendations[] = 'Consider changing your password';
        }
        
        if (in_array('unusual_location', $flags)) {
            $recommendations[] = 'Review devices connected to your account';
        }
        
        if (in_array('multiple_failed_attempts', $flags)) {
            $recommendations[] = 'Strengthen your password';
        }
        
        return $recommendations;
    }
    
    private function getLastLoginLocation($userId) {
        global $wpdb;
        
        $login = $wpdb->get_row($wpdb->prepare(
            "SELECT ip_address, created_at FROM {$wpdb->prefix}loginpro_login_history 
            WHERE user_id = %d AND status = 'success' 
            ORDER BY created_at DESC LIMIT 1",
            $userId
        ), ARRAY_A);
        
        if ($login && !empty($login['ip_address'])) {
            return $this->ipToLocation($login['ip_address']);
        }
        
        return null;
    }
    
    private function getCurrentLocation() {
        return $this->ipToLocation($_SERVER['REMOTE_ADDR'] ?? '');
    }
    
    private function ipToLocation($ip) {
        if (empty($ip) || $ip === '127.0.0.1' || $ip === '::1') {
            return null;
        }
        
        $response = wp_remote_get("http://ip-api.com/json/{$ip}", ['timeout' => 5]);
        
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if ($data && $data['status'] === 'success') {
                return [
                    'lat' => (float)$data['lat'],
                    'lng' => (float)$data['lon'],
                    'country' => $data['countryCode'],
                    'city' => $data['city']
                ];
            }
        }
        
        return null;
    }
    
    private function calculateDistance($lat1, $lon1, $lat2, $lon2) {
        if (!$lat1 || !$lon1 || !$lat2 || !$lon2) {
            return 0;
        }
        
        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + 
                cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos(min(max($dist, -1), 1));
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        return $miles * 1.609344;
    }
    
    private function isTorExitNode() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if (empty($ip)) return false;
        
        $response = wp_remote_get("https://check.torproject.org/api/ip/{$ip}", ['timeout' => 5]);
        
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            return isset($data['IsTor']) && $data['IsTor'];
        }
        
        return false;
    }
    
    private function isProxy() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if (empty($ip)) return false;
        
        $response = wp_remote_get("http://ip-api.com/json/{$ip}", ['timeout' => 5]);
        
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            $proxyTypes = ['proxy', 'hosting', 'tor'];
            return isset($data['proxy']) && in_array($data['proxy'], $proxyTypes);
        }
        
        return false;
    }
}
