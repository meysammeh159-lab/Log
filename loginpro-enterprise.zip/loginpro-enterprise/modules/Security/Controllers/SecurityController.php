<?php
namespace LoginPro\Modules\Security\Controllers;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Modules\Security\Services\SecurityAuditService;

class SecurityController {
    private $auditService;
    
    public function __construct() {
        $this->auditService = new SecurityAuditService();
    }
    
    public function getEvents(Request $request) {
        $userId = get_current_user_id();
        $limit = $request->get('limit', 50);
        $events = $this->auditService->getUserEvents($userId, $limit);
        
        return Response::json([
            'success' => true,
            'data' => $events
        ]);
    }
    
    public function getSecurityScore(Request $request) {
        $userId = get_current_user_id();
        $score = $this->calculateSecurityScore($userId);
        
        return Response::json([
            'success' => true,
            'data' => $score
        ]);
    }
    
    private function calculateSecurityScore($userId) {
        $score = 0;
        $total = 5;
        
        if (get_user_meta($userId, 'loginpro_2fa_enabled', true) === 'yes') {
            $score++;
        }
        
        $user = get_user_by('id', $userId);
        if ($this->isStrongPassword($user->user_pass)) {
            $score++;
        }
        
        if (get_user_meta($userId, 'email_verified', true) === 'yes') {
            $score++;
        }
        
        if (get_user_meta($userId, 'mobile_verified', true) === 'yes') {
            $score++;
        }
        
        $loginHistory = $this->auditService->getFailedLogins($userId, 24);
        if (count($loginHistory) < 5) {
            $score++;
        }
        
        return [
            'score' => $score,
            'total' => $total,
            'percentage' => ($score / $total) * 100,
            'level' => $this->getScoreLevel($score)
        ];
    }
    
    private function isStrongPassword($hash) {
        return strlen($hash) > 8;
    }
    
    private function getScoreLevel($score) {
        if ($score >= 4) return 'excellent';
        if ($score >= 3) return 'good';
        if ($score >= 2) return 'fair';
        return 'poor';
    }
}
