<?php
namespace LoginPro\Modules\Security;

class Module {
    public function init() {
        $this->registerHooks();
        $this->loadRoutes();
    }
    
    private function registerHooks() {
        add_action('loginpro_user_logged_in', [$this, 'onUserLogin'], 10, 1);
        add_action('loginpro_ip_blocked', [$this, 'onIpBlocked'], 10, 2);
        add_action('loginpro_hourly_cleanup', [$this, 'cleanup']);
    }
    
    private function loadRoutes() {
        $routesFile = __DIR__ . '/routes.php';
        if (file_exists($routesFile)) {
            include $routesFile;
        }
    }
    
    public function onUserLogin($userId) {
        $deviceService = new Services\DeviceTrackingService();
        $deviceService->track($userId);
        
        $auditService = new Services\SecurityAuditService();
        $auditService->log($userId, 'user_login', 'info', [
            'ip' => $_SERVER['REMOTE_ADDR'] ?? ''
        ]);
    }
    
    public function onIpBlocked($ip, $attempts) {
        $model = new Models\BruteForceLog();
        $model->record($ip, $attempts);
    }
    
    public function cleanup() {
        $auditService = new Services\SecurityAuditService();
        $auditService->cleanup(30);
    }
}
