<?php
namespace LoginPro\Modules\Security\Models;

use LoginPro\Core\Database\Model;

class BruteForceLog extends Model {
    protected static $table = 'security_events';
    
    public function record($ip, $attempts) {
        return $this->query()->insert([
            'event' => 'bruteforce_detected',
            'severity' => 'warning',
            'ip_address' => $ip,
            'details' => json_encode(['attempts' => $attempts]),
            'created_at' => current_time('mysql')
        ]);
    }
    
    public function getBlockedIps($hours = 24) {
        return $this->query()
            ->select('ip_address', 'COUNT(*) as attempts')
            ->where('event', 'bruteforce_detected')
            ->where('created_at', '>', date('Y-m-d H:i:s', time() - ($hours * 3600)))
            ->groupBy('ip_address')
            ->having('attempts', '>=', 5)
            ->get();
    }
}
