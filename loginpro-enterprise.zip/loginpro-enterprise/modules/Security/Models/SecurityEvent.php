<?php
namespace LoginPro\Modules\Security\Models;

use LoginPro\Core\Database\Model;

class SecurityEvent extends Model {
    protected static $table = 'security_events';
    
    public function getBySeverity($severity, $limit = 100) {
        return $this->query()
            ->where('severity', $severity)
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }
    
    public function getByEvent($event, $limit = 100) {
        return $this->query()
            ->where('event', $event)
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }
    
    public function getRecent($hours = 24, $limit = 100) {
        return $this->query()
            ->where('created_at', '>', date('Y-m-d H:i:s', time() - ($hours * 3600)))
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }
    
    public function getStats($days = 7) {
        return $this->query()
            ->select('severity', 'COUNT(*) as count')
            ->where('created_at', '>', date('Y-m-d H:i:s', time() - ($days * 86400)))
            ->groupBy('severity')
            ->get();
    }
}
