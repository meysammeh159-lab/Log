<?php
/**
 * WooCommerce Module
 * یکپارچه‌سازی با ووکامرس
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Modules\WooCommerce;

use Exception;

defined('ABSPATH') || exit;

use LoginPro\Security\NonceManager;
use LoginPro\Security\PermissionChecker;

/**
 * کلاس اصلی ماژول WooCommerce
 */
class Module {
    
    /**
     * @var string $module_name نام ماژول
     */
    private $module_name = 'woocommerce';
    
    /**
     * Constructor
     */
    public function __construct() {
        if (!$this->is_woocommerce_active()) {
            return;
        }
        
        $this->register_hooks();
        $this->register_shortcodes();
    }
    
    /**
     * بررسی فعال بودن ووکامرس
     */
    private function is_woocommerce_active() {
        return class_exists('WooCommerce');
    }
    
    /**
     * ثبت هوک‌ها
     */
    private function register_hooks() {
        // فرم لاگین در تسویه حساب
        add_action('woocommerce_before_checkout_form', [$this, 'render_login_form'], 10);
        
        // افزودن فیلد موبایل
        add_filter('woocommerce_checkout_fields', [$this, 'add_mobile_field']);
        
        // ذخیره فیلد موبایل
        add_action('woocommerce_checkout_update_order_meta', [$this, 'save_mobile_field'], 10, 2);
        
        // نمایش موبایل در ادمین
        add_action('woocommerce_admin_order_data_after_shipping_address', [$this, 'display_mobile_in_admin']);
        
        // اعتبارسنجی موبایل
        add_action('woocommerce_checkout_process', [$this, 'validate_mobile_field']);
        
        // Ajax لاگین
        add_action('wp_ajax_nopriv_loginpro_woo_login', [$this, 'ajax_woo_login']);
    }
    
    /**
     * ثبت شورت‌کدها
     */
    private function register_shortcodes() {
        add_shortcode('loginpro_woo_login', [$this, 'render_shortcode_login']);
    }
    
    /**
     * رندر فرم لاگین در تسویه حساب
     */
    public function render_login_form() {
        if (is_user_logged_in()) {
            return;
        }
        
        $nonce = NonceManager::create('woo_login', 0);
        ?>
        <div class="loginpro-woo-login-wrapper" style="background:#f8f9fa;padding:20px;border-radius:12px;margin-bottom:20px;">
            <h4 style="margin:0 0 10px;"><?php esc_html_e('👋 قبلاً ثبت نام کرده‌اید؟', 'loginpro'); ?></h4>
            <p style="margin:0 0 15px;color:#666;font-size:14px;">
                <?php esc_html_e('برای تسویه حساب سریع‌تر وارد شوید.', 'loginpro'); ?>
            </p>
            
            <div id="woo-login-message" style="display:none;margin-bottom:10px;padding:10px;border-radius:8px;"></div>
            
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <input type="text" id="woo-login-identifier" placeholder="<?php esc_attr_e('ایمیل یا نام کاربری', 'loginpro'); ?>" 
                       style="flex:1;min-width:200px;height:42px;padding:0 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;">
                <input type="password" id="woo-login-password" placeholder="<?php esc_attr_e('رمز عبور', 'loginpro'); ?>" 
                       style="flex:1;min-width:200px;height:42px;padding:0 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;">
                <button id="woo-login-btn" data-nonce="<?php echo esc_attr($nonce); ?>" 
                        style="background:#ef394e;color:#fff;border:none;border-radius:8px;padding:0 25px;cursor:pointer;font-size:14px;">
                    <?php esc_html_e('ورود', 'loginpro'); ?>
                </button>
            </div>
            
            <div style="margin-top:10px;font-size:13px;">
                <a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))); ?>" style="color:#ef394e;text-decoration:none;">
                    📝 <?php esc_html_e('ثبت نام جدید', 'loginpro'); ?>
                </a>
            </div>
        </div>
        
        <script type="text/javascript">
        (function() {
            'use strict';
            var btn = document.getElementById('woo-login-btn');
            var msg = document.getElementById('woo-login-message');
            
            if (btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    var identifier = document.getElementById('woo-login-identifier').value.trim();
                    var password = document.getElementById('woo-login-password').value;
                    var nonce = btn.getAttribute('data-nonce');
                    
                    if (!identifier || !password) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('لطفاً تمام فیلدها را پر کنید', 'loginpro')); ?>';
                        return;
                    }
                    
                    btn.disabled = true;
                    btn.textContent = '<?php echo esc_js(__('در حال ورود...', 'loginpro')); ?>';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_woo_login');
                    formData.append('_nonce', nonce);
                    formData.append('identifier', identifier);
                    formData.append('password', password);
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#f0fff4';
                            msg.style.color = '#28a745';
                            msg.style.border = '1px solid #c3e6cb';
                            msg.textContent = '✅ ' + response.data.message;
                            if (response.data.redirect) {
                                setTimeout(function() {
                                    window.location.href = response.data.redirect;
                                }, 1000);
                            } else {
                                location.reload();
                            }
                        } else {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#fff5f5';
                            msg.style.color = '#dc3545';
                            msg.style.border = '1px solid #f5c6cb';
                            msg.textContent = '❌ ' + response.data.message;
                            btn.disabled = false;
                            btn.textContent = '<?php echo esc_js(__('ورود', 'loginpro')); ?>';
                        }
                    })
                    .catch(function(error) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('خطا در ارتباط با سرور', 'loginpro')); ?>: ' + error.message;
                        btn.disabled = false;
                        btn.textContent = '<?php echo esc_js(__('ورود', 'loginpro')); ?>';
                    });
                });
            }
            
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    var target = e.target;
                    if (target.id === 'woo-login-identifier' || target.id === 'woo-login-password') {
                        e.preventDefault();
                        var btn = document.getElementById('woo-login-btn');
                        if (btn) btn.click();
                    }
                }
            });
        })();
        </script>
        <?php
    }
    
    /**
     * افزودن فیلد موبایل به تسویه حساب
     */
    public function add_mobile_field($fields) {
        $fields['billing']['billing_mobile'] = [
            'label' => __('شماره موبایل', 'loginpro'),
            'required' => true,
            'class' => ['form-row-wide'],
            'clear' => true,
            'priority' => 25,
            'type' => 'tel',
            'validate' => ['phone'],
            'placeholder' => __('09xxxxxxxxx', 'loginpro'),
        ];
        
        return $fields;
    }
    
    /**
     * ذخیره شماره موبایل
     */
    public function save_mobile_field($order_id, $posted) {
        if (isset($posted['billing_mobile'])) {
            update_post_meta($order_id, '_billing_mobile', sanitize_text_field($posted['billing_mobile']));
            
            if (is_user_logged_in()) {
                $user_id = get_current_user_id();
                update_user_meta($user_id, 'billing_mobile', sanitize_text_field($posted['billing_mobile']));
                update_user_meta($user_id, 'loginpro_mobile', sanitize_text_field($posted['billing_mobile']));
            }
        }
    }
    
    /**
     * نمایش موبایل در ادمین
     */
    public function display_mobile_in_admin($order) {
        $mobile = get_post_meta($order->get_id(), '_billing_mobile', true);
        if ($mobile) {
            echo '<p><strong>' . esc_html__('شماره موبایل:', 'loginpro') . '</strong> ' . esc_html($mobile) . '</p>';
        }
    }
    
    /**
     * اعتبارسنجی فیلد موبایل
     */
    public function validate_mobile_field() {
        $mobile = isset($_POST['billing_mobile']) ? sanitize_text_field($_POST['billing_mobile']) : '';
        
        if (!empty($mobile)) {
            $mobile = preg_replace('/[^0-9]/', '', $mobile);
            if (!preg_match('/^09[0-9]{9}$/', $mobile) && !preg_match('/^9[0-9]{9}$/', $mobile)) {
                wc_add_notice(
                    __('لطفاً شماره موبایل معتبر وارد کنید (09123456789)', 'loginpro'),
                    'error'
                );
            }
        }
    }
    
    /**
     * رندر شورت‌کد لاگین
     */
    public function render_shortcode_login($atts) {
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            return '<p style="text-align:center;">👋 ' . sprintf(esc_html__('خوش آمدید %s', 'loginpro'), esc_html($user->display_name)) . '</p>';
        }
        return do_shortcode('[loginpro_login]');
    }
    
    /**
     * Ajax لاگین
     */
    public function ajax_woo_login() {
        try {
            $user_id = 0;
            
            if (!NonceManager::check_request('woo_login', 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            $identifier = sanitize_text_field($_POST['identifier'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($identifier) || empty($password)) {
                wp_send_json_error(['message' => 'لطفاً تمام فیلدها را پر کنید']);
                return;
            }
            
            $user = false;
            
            if (is_email($identifier)) {
                $user = get_user_by('email', $identifier);
            } else {
                $user = get_user_by('login', $identifier);
            }
            
            if (!$user) {
                wp_send_json_error(['message' => 'کاربر یافت نشد']);
                return;
            }
            
            if (!wp_check_password($password, $user->user_pass, $user->ID)) {
                wp_send_json_error(['message' => 'رمز عبور اشتباه است']);
                return;
            }
            
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID);
            do_action('wp_login', $user->user_login, $user);
            
            wp_send_json_success([
                'message' => 'ورود موفق',
                'redirect' => wc_get_checkout_url()
            ]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
}

// ==================================================
// ✅ مقداردهی اولیه ماژول
// ==================================================

if (class_exists('LoginPro\Modules\WooCommerce\Module')) {
    new \LoginPro\Modules\WooCommerce\Module();
}