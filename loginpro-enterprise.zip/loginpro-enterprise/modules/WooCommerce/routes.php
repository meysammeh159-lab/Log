<?php
/**
 * WooCommerce Module Routes
 * مسیرهای مربوط به ماژول ووکامرس
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ تغییر لینک‌های ورود/خروج ووکامرس
// ==================================================

add_filter('woocommerce_login_redirect', function($redirect, $user) {
    $login_page = get_permalink(get_option('loginpro_login_page_id', 0));
    if ($login_page) {
        return $login_page;
    }
    return $redirect;
}, 10, 2);

add_filter('woocommerce_registration_redirect', function($redirect) {
    $profile_page = get_permalink(get_option('loginpro_profile_page_id', 0));
    if ($profile_page) {
        return $profile_page;
    }
    return $redirect;
});

add_filter('woocommerce_logout_url', function($url) {
    $login_page = get_permalink(get_option('loginpro_login_page_id', 0));
    if ($login_page) {
        return wp_logout_url($login_page);
    }
    return $url;
});

// ==================================================
// ✅ تنظیمات پیش‌فرض
// ==================================================

add_action('admin_init', function() {
    if (!get_option('loginpro_woo_settings_initialized')) {
        // ایجاد صفحه لاگین
        if (!get_option('loginpro_login_page_id')) {
            $login_page = [
                'post_title' => 'ورود',
                'post_content' => '[loginpro_login]',
                'post_status' => 'publish',
                'post_type' => 'page',
            ];
            $page_id = wp_insert_post($login_page);
            if ($page_id) {
                update_option('loginpro_login_page_id', $page_id);
            }
        }
        
        update_option('loginpro_woo_settings_initialized', true);
    }
});