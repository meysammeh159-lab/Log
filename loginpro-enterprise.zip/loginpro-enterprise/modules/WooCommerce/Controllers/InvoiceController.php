<?php
namespace LoginPro\WooCommerce\Controllers;

defined('ABSPATH') || exit;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;

class InvoiceController
{
    private Request $request;
    
    public function __construct() {
        $this->request = Request::capture();
    }
    
    /**
     * Get Invoice
     * 
     * AJAX Action: loginpro_get_invoice
     */
    public function handleGetInvoice(): void {
        try {
            if (!$this->verifyNonce()) return;
            
            if (!is_user_logged_in()) {
                Response::json(['success' => false, 'message' => 'لطفاً ابتدا وارد شوید.']);
                return;
            }
            
            $orderId = intval($_POST['order_id'] ?? 0);
            
            if (!$orderId) {
                Response::json(['success' => false, 'message' => 'شماره سفارش نامعتبر است.']);
                return;
            }
            
            // بررسی وجود ووکامرس
            if (!function_exists('wc_get_order')) {
                Response::json(['success' => false, 'message' => 'سیستم فروشگاهی در دسترس نیست.']);
                return;
            }
            
            $order = wc_get_order($orderId);
            
            if (!$order) {
                Response::json(['success' => false, 'message' => 'سفارش یافت نشد.']);
                return;
            }
            
            // بررسی مالکیت سفارش
            if ($order->get_customer_id() !== get_current_user_id()) {
                Response::json(['success' => false, 'message' => 'شما دسترسی به این سفارش ندارید.']);
                return;
            }
            
            // بررسی وضعیت سفارش
            $allowedStatuses = apply_filters('loginpro_invoice_statuses', ['completed', 'processing', 'on-hold']);
            if (!in_array($order->get_status(), $allowedStatuses, true)) {
                Response::json(['success' => false, 'message' => 'فاکتور این سفارش در وضعیت فعلی قابل مشاهده نیست.']);
                return;
            }
            
            $html = $this->renderInvoiceHtml($order);
            
            Response::json(['success' => true, 'html' => $html]);
            
        } catch (\Exception $e) {
            error_log('[LoginPro] Invoice Error: ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'خطای سیستمی رخ داده است.']);
        }
    }
    
    private function renderInvoiceHtml(\WC_Order $order): string {
        ob_start();
        ?>
        <div class="loginpro-invoice" style="font-family: inherit; direction: rtl; text-align: right;">
            <h2 style="margin-bottom: 15px;"><?php esc_html_e('فاکتور فروش', 'loginpro'); ?></h2>
            <p><strong><?php esc_html_e('شماره سفارش:', 'loginpro'); ?></strong> #<?php echo esc_html($order->get_order_number()); ?></p>
            <p><strong><?php esc_html_e('تاریخ:', 'loginpro'); ?></strong> <?php echo esc_html($order->get_date_created()->date_i18n('Y-m-d H:i')); ?></p>
            <p><strong><?php esc_html_e('وضعیت:', 'loginpro'); ?></strong> <?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></p>
            <hr style="margin: 15px 0;">
            <table width="100%" cellpadding="8" style="border-collapse: collapse;">
                <thead>
                    <tr style="background: #f5f5f5;">
                        <th align="right" style="padding: 8px;"><?php esc_html_e('محصول', 'loginpro'); ?></th>
                        <th align="center" style="padding: 8px;"><?php esc_html_e('تعداد', 'loginpro'); ?></th>
                        <th align="left" style="padding: 8px;"><?php esc_html_e('قیمت', 'loginpro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order->get_items() as $item): ?>
                    <tr>
                        <td align="right" style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($item->get_name()); ?></td>
                        <td align="center" style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($item->get_quantity()); ?></td>
                        <td align="left" style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo wp_kses_post(wc_price($item->get_total())); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2" align="left" style="padding: 10px 8px;"><strong><?php esc_html_e('جمع کل:', 'loginpro'); ?></strong></td>
                        <td align="left" style="padding: 10px 8px;"><strong><?php echo wp_kses_post($order->get_formatted_order_total()); ?></strong></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function verifyNonce(): bool {
        $nonce = $_POST['_nonce'] ?? $_POST['_wpnonce'] ?? '';
        
        if (!wp_verify_nonce($nonce, 'loginpro_ajax_nonce')) {
            Response::json(['success' => false, 'message' => 'درخواست نامعتبر است.']);
            return false;
        }
        
        return true;
    }
}