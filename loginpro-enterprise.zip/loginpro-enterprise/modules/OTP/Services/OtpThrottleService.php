<?php
/**
 * OTP Throttle Service
 * مدیریت محدودیت‌های ارسال و تأیید OTP
 */

namespace LoginPro\Modules\OTP\Services;

class OtpThrottleService
{
    /**
     * @var int حداکثر تلاش
     */
    private $maxAttempts;

    /**
     * @var int مدت زمان قفل (دقیقه)
     */
    private $lockoutMinutes;

    /**
     * @var string پیشوند کلیدها
     */
    private $prefix = 'otp_throttle_';

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->maxAttempts = get_option('loginpro_otp_max_attempts', 5);
        $this->lockoutMinutes = get_option('loginpro_otp_lockout_minutes', 15);
    }

    /**
     * بررسی وضعیت محدودیت
     */
    public function check($identifier)
    {
        $key = $this->prefix . 'attempts_' . md5($identifier);
        $blockKey = $this->prefix . 'blocked_' . md5($identifier);

        // بررسی قفل
        $blocked = get_transient($blockKey);
        if ($blocked !== false) {
            $remaining = $this->lockoutMinutes * 60 - (time() - $blocked);
            if ($remaining > 0) {
                return [
                    'success' => false,
                    'message' => sprintf(
                        'تعداد تلاش‌ها بیش از حد مجاز است. %d ثانیه دیگر تلاش کنید.',
                        ceil($remaining)
                    ),
                    'locked' => true,
                    'remaining' => $remaining
                ];
            }
            // رفع قفل بعد از زمان
            delete_transient($blockKey);
            delete_transient($key);
        }

        // دریافت تعداد تلاش‌ها
        $attempts = (int) get_transient($key);

        if ($attempts >= $this->maxAttempts) {
            // قفل کردن
            set_transient($blockKey, time(), $this->lockoutMinutes * 60);
            return [
                'success' => false,
                'message' => sprintf(
                    'تعداد تلاش‌ها بیش از حد مجاز است. %d دقیقه دیگر تلاش کنید.',
                    $this->lockoutMinutes
                ),
                'locked' => true,
                'remaining' => $this->lockoutMinutes * 60
            ];
        }

        return [
            'success' => true,
            'attempts' => $attempts,
            'max_attempts' => $this->maxAttempts,
            'remaining_attempts' => $this->maxAttempts - $attempts
        ];
    }

    /**
     * افزایش تعداد تلاش‌ها
     */
    public function increment($identifier)
    {
        $key = $this->prefix . 'attempts_' . md5($identifier);
        $attempts = (int) get_transient($key);
        $attempts++;

        set_transient($key, $attempts, 3600);

        return $attempts;
    }

    /**
     * بازنشانی تعداد تلاش‌ها
     */
    public function reset($identifier)
    {
        $key = $this->prefix . 'attempts_' . md5($identifier);
        $blockKey = $this->prefix . 'blocked_' . md5($identifier);

        delete_transient($key);
        delete_transient($blockKey);
    }

    /**
     * دریافت وضعیت کامل
     */
    public function getStatus($identifier)
    {
        $key = $this->prefix . 'attempts_' . md5($identifier);
        $blockKey = $this->prefix . 'blocked_' . md5($identifier);

        $attempts = (int) get_transient($key);
        $blocked = get_transient($blockKey);

        return [
            'attempts' => $attempts,
            'max_attempts' => $this->maxAttempts,
            'is_blocked' => $blocked !== false,
            'blocked_until' => $blocked ? $blocked + ($this->lockoutMinutes * 60) : null
        ];
    }

    /**
     * تنظیم حداکثر تلاش
     */
    public function setMaxAttempts($maxAttempts)
    {
        $this->maxAttempts = max(1, intval($maxAttempts));
        update_option('loginpro_otp_max_attempts', $this->maxAttempts);
    }

    /**
     * تنظیم مدت زمان قفل
     */
    public function setLockoutMinutes($minutes)
    {
        $this->lockoutMinutes = max(1, intval($minutes));
        update_option('loginpro_otp_lockout_minutes', $this->lockoutMinutes);
    }
}