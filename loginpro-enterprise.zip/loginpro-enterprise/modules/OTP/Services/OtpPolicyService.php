<?php
namespace LoginPro\Modules\OTP\Services;

class OtpPolicyService {
    
    public function getPreferredMethod($userId, $type) {
        $method = get_user_meta($userId, 'loginpro_otp_method', true);
        
        if (!$method) {
            $method = get_option('loginpro_default_otp_method', 'auto');
        }
        
        if ($method === 'auto') {
            return $this->autoSelectMethod($userId);
        }
        
        return $method;
    }
    
    private function autoSelectMethod($userId) {
        $mobile = get_user_meta($userId, 'mobile_number', true);
        $mobileVerified = get_user_meta($userId, 'mobile_verified', true);
        
        if ($mobile && $mobileVerified === 'yes') {
            return 'sms';
        }
        
        $user = get_user_by('id', $userId);
        if ($user && $user->user_email) {
            return 'email';
        }
        
        return 'none';
    }
    
    public function getCodeLength($type) {
        $lengths = [
            'login' => 6,
            'register' => 6,
            'password_reset' => 6,
            'verification' => 6
        ];
        
        return apply_filters('loginpro_otp_length', $lengths[$type] ?? 6, $type);
    }
    
    public function getExpiryTime($type) {
        $expiry = [
            'login' => 300,
            'register' => 600,
            'password_reset' => 300,
            'verification' => 900
        ];
        
        return apply_filters('loginpro_otp_expiry', $expiry[$type] ?? 300, $type);
    }
    
    public function getMaxAttempts($type) {
        $maxAttempts = [
            'login' => 5,
            'register' => 5,
            'password_reset' => 3,
            'verification' => 10
        ];
        
        return apply_filters('loginpro_otp_max_attempts', $maxAttempts[$type] ?? 5, $type);
    }
    
    public function getResendCooldown($type) {
        $cooldown = [
            'login' => 60,
            'register' => 60,
            'password_reset' => 60,
            'verification' => 30
        ];
        
        return apply_filters('loginpro_otp_resend_cooldown', $cooldown[$type] ?? 60, $type);
    }
}
