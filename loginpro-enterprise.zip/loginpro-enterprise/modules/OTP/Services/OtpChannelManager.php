<?php
/**
 * OTP Channel Manager
 * مدیریت کانال‌های ارسال OTP (SMS, Email, WhatsApp, Firebase)
 */

namespace LoginPro\Modules\OTP\Services;

use LoginPro\Modules\Providers\Sms\SmsManager;
use LoginPro\Modules\Providers\WhatsApp\WhatsAppManager;

class OtpChannelManager
{
    /**
     * @var array کانال‌های فعال
     */
    private $activeChannels = [];

    /**
     * @var string کانال پیش‌فرض
     */
    private $defaultChannel;

    /**
     * @var SmsManager
     */
    private $smsManager;

    /**
     * @var WhatsAppManager
     */
    private $whatsAppManager;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->smsManager = new SmsManager();
        $this->whatsAppManager = new WhatsAppManager();
        $this->loadActiveChannels();
    }

    /**
     * بارگذاری کانال‌های فعال
     */
    private function loadActiveChannels()
    {
        $channels = get_option('loginpro_otp_channels', ['sms', 'email']);
        
        $this->activeChannels = array_filter($channels, function($channel) {
            return $this->isChannelAvailable($channel);
        });

        $this->defaultChannel = get_option('loginpro_otp_default_channel', 'sms');
        
        if (!in_array($this->defaultChannel, $this->activeChannels)) {
            $this->defaultChannel = $this->activeChannels[0] ?? 'sms';
        }
    }

    /**
     * بررسی در دسترس بودن کانال
     */
    public function isChannelAvailable($channel)
    {
        switch ($channel) {
            case 'sms':
                return $this->smsManager->getActiveProvider() !== null;
            case 'whatsapp':
                return $this->whatsAppManager->isConfigured();
            case 'email':
                return true; // ایمیل همیشه در دسترس است
            case 'firebase':
                return $this->smsManager->isProviderAvailable('firebase');
            default:
                return false;
        }
    }

    /**
     * دریافت کانال‌های فعال
     */
    public function getActiveChannels()
    {
        return $this->activeChannels;
    }

    /**
     * دریافت کانال پیش‌فرض
     */
    public function getDefaultChannel()
    {
        return $this->defaultChannel;
    }

    /**
     * دریافت اولویت کانال‌ها
     */
    public function getChannelPriority($identifier = null)
    {
        $priority = get_option('loginpro_otp_channel_priority', ['sms', 'whatsapp', 'email', 'firebase']);
        
        // فیلتر کانال‌های موجود
        return array_filter($priority, function($channel) {
            return in_array($channel, $this->activeChannels);
        });
    }

    /**
     * ارسال OTP از طریق کانال مشخص
     */
    public function send($identifier, $code, $channel = null)
    {
        if (!$channel) {
            $channel = $this->defaultChannel;
        }

        if (!in_array($channel, $this->activeChannels)) {
            return [
                'success' => false,
                'message' => 'کانال انتخاب شده در دسترس نیست',
                'channel' => $channel
            ];
        }

        switch ($channel) {
            case 'sms':
                return $this->sendSms($identifier, $code);
            case 'whatsapp':
                return $this->sendWhatsApp($identifier, $code);
            case 'email':
                return $this->sendEmail($identifier, $code);
            case 'firebase':
                return $this->sendFirebase($identifier, $code);
            default:
                return [
                    'success' => false,
                    'message' => 'کانال نامعتبر',
                    'channel' => $channel
                ];
        }
    }

    /**
     * ارسال از طریق SMS
     */
    private function sendSms($mobile, $code)
    {
        $provider = $this->smsManager->getActiveProvider();
        if (!$provider) {
            return [
                'success' => false,
                'message' => 'درگاه SMS پیکربندی نشده است',
                'channel' => 'sms'
            ];
        }

        return $provider->sendOtp($mobile, $code);
    }

    /**
     * ارسال از طریق WhatsApp
     */
    private function sendWhatsApp($mobile, $code)
    {
        if (!$this->whatsAppManager->isConfigured()) {
            return [
                'success' => false,
                'message' => 'WhatsApp پیکربندی نشده است',
                'channel' => 'whatsapp'
            ];
        }

        return $this->whatsAppManager->sendOtp($mobile, $code);
    }

    /**
     * ارسال از طریق ایمیل
     */
    private function sendEmail($email, $code)
    {
        $subject = get_option('loginpro_otp_email_subject', 'کد تأیید شما');
        $template = get_option('loginpro_otp_email_template', 
            '<h2>کد تأیید شما</h2><p>کد تأیید شما: <strong>{code}</strong></p><p>این کد تا 5 دقیقه معتبر است.</p>'
        );

        $message = str_replace('{code}', $code, $template);
        $message = str_replace('{site_name}', get_bloginfo('name'), $message);
        $message = str_replace('{site_url}', home_url(), $message);

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        $sent = wp_mail($email, $subject, $message, $headers);

        if ($sent) {
            return [
                'success' => true,
                'message' => 'کد تأیید به ایمیل شما ارسال شد',
                'channel' => 'email'
            ];
        }

        return [
            'success' => false,
            'message' => 'خطا در ارسال ایمیل',
            'channel' => 'email'
        ];
    }

    /**
     * ارسال از طریق Firebase
     */
    private function sendFirebase($mobile, $code)
    {
        $provider = $this->smsManager->getProvider('firebase');
        if (!$provider || !$provider->isConfigured()) {
            return [
                'success' => false,
                'message' => 'Firebase پیکربندی نشده است',
                'channel' => 'firebase'
            ];
        }

        return $provider->sendOtp($mobile, $code);
    }

    /**
     * تلاش با کانال‌های مختلف (Fallback)
     */
    public function sendWithFallback($identifier, $code, $channels = null)
    {
        if (!$channels) {
            $channels = $this->getChannelPriority();
        }

        $errors = [];
        
        foreach ($channels as $channel) {
            $result = $this->send($identifier, $code, $channel);
            
            if ($result['success']) {
                return $result;
            }
            
            $errors[$channel] = $result['message'];
        }

        return [
            'success' => false,
            'message' => 'ارسال از طریق تمام کانال‌ها ناموفق بود: ' . implode(' | ', $errors),
            'errors' => $errors
        ];
    }
}