<?php
/**
 * OTP Resend Service
 * مدیریت ارسال مجدد OTP با تایمر
 */

namespace LoginPro\Modules\OTP\Services;

class OtpResendService
{
    /**
     * @var int زمان انتظار بین ارسال‌ها (ثانیه)
     */
    private $resendDelay;

    /**
     * @var int حداکثر تعداد ارسال مجدد
     */
    private $maxResends;

    /**
     * @var string پیشوند کلیدها
     */
    private $prefix = 'otp_resend_';

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->resendDelay = get_option('loginpro_otp_resend_delay', 60);
        $this->maxResends = get_option('loginpro_otp_max_resends', 5);
    }

    /**
     * بررسی امکان ارسال مجدد
     */
    public function canResend($identifier)
    {
        $key = $this->prefix . 'last_' . md5($identifier);
        $countKey = $this->prefix . 'count_' . md5($identifier);

        // بررسی تعداد ارسال مجدد
        $resendCount = (int) get_transient($countKey);
        if ($resendCount >= $this->maxResends) {
            return [
                'success' => false,
                'message' => 'تعداد ارسال مجدد بیش از حد مجاز است. لطفاً بعداً تلاش کنید.',
                'max_reached' => true
            ];
        }

        // بررسی زمان
        $lastResend = get_transient($key);
        if ($lastResend !== false) {
            $timeLeft = $this->resendDelay - (time() - $lastResend);
            if ($timeLeft > 0) {
                return [
                    'success' => false,
                    'message' => sprintf(
                        'لطفاً %d ثانیه دیگر صبر کنید.',
                        ceil($timeLeft)
                    ),
                    'wait' => ceil($timeLeft)
                ];
            }
        }

        return [
            'success' => true,
            'remaining' => $this->maxResends - $resendCount
        ];
    }

    /**
     * ثبت ارسال مجدد
     */
    public function markSent($identifier)
    {
        $key = $this->prefix . 'last_' . md5($identifier);
        $countKey = $this->prefix . 'count_' . md5($identifier);

        set_transient($key, time(), $this->resendDelay);
        
        $count = (int) get_transient($countKey);
        $count++;
        set_transient($countKey, $count, 3600);
    }

    /**
     * بازنشانی ارسال مجدد
     */
    public function reset($identifier)
    {
        $key = $this->prefix . 'last_' . md5($identifier);
        $countKey = $this->prefix . 'count_' . md5($identifier);

        delete_transient($key);
        delete_transient($countKey);
    }

    /**
     * دریافت وضعیت ارسال مجدد
     */
    public function getStatus($identifier)
    {
        $key = $this->prefix . 'last_' . md5($identifier);
        $countKey = $this->prefix . 'count_' . md5($identifier);

        $lastResend = get_transient($key);
        $resendCount = (int) get_transient($countKey);

        return [
            'can_resend' => $lastResend === false || (time() - $lastResend) >= $this->resendDelay,
            'resend_count' => $resendCount,
            'max_resends' => $this->maxResends,
            'remaining' => $this->maxResends - $resendCount,
            'wait_time' => $lastResend ? $this->resendDelay - (time() - $lastResend) : 0
        ];
    }

    /**
     * تنظیم زمان انتظار
     */
    public function setResendDelay($seconds)
    {
        $this->resendDelay = max(30, intval($seconds));
        update_option('loginpro_otp_resend_delay', $this->resendDelay);
    }

    /**
     * تنظیم حداکثر تعداد ارسال مجدد
     */
    public function setMaxResends($count)
    {
        $this->maxResends = max(1, intval($count));
        update_option('loginpro_otp_max_resends', $this->maxResends);
    }
}