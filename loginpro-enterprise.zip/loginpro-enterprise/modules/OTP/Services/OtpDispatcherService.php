<?php
namespace LoginPro\Modules\OTP\Services;

defined('ABSPATH') || exit;

use LoginPro\Modules\Providers\Sms\SmsManager;

class OtpDispatcherService {
    private $smsManager;
    
    public function __construct() {
        $this->smsManager = SmsManager::getInstance();
    }
    
    public function sendViaSms($mobile, $code, $type) {
        try {
            $activeProvider = $this->smsManager->getActiveProvider();
            
            if (!$activeProvider) {
                return false;
            }
            
            if (!$activeProvider->isConfigured()) {
                return false;
            }
            
            $result = $this->smsManager->sendOtp($mobile, $code);
            
            if (is_array($result) && isset($result['success']) && $result['success'] === true) {
                return true;
            }
            
            // ✅ اگر result عدد یا string بود (message_id)
            if (is_numeric($result) || (is_string($result) && strlen($result) > 0)) {
                return true;
            }
            
            return false;
            
        } catch (\Exception $e) {
            return false;
        }
    }
}