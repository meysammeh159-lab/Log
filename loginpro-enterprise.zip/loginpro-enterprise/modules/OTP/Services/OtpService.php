<?php
namespace LoginPro\Modules\OTP\Services;

defined('ABSPATH') || exit;

use LoginPro\Modules\Providers\Sms\SmsManager;
use LoginPro\Core\Http\Request;

class OtpService
{
    private SmsManager $smsManager;
    private Request $request;
    
    public function __construct() {
        $this->smsManager = SmsManager::getInstance();
        $this->request = Request::capture();
    }
    
    public function normalizeMobile(string $mobile): string {
        $mobile = preg_replace('/[^0-9]/', '', $mobile);
        $mobile = ltrim($mobile, '0');
        if (substr($mobile, 0, 2) === '98') $mobile = '0' . substr($mobile, 2);
        if (strlen($mobile) === 10 && $mobile[0] === '9') $mobile = '0' . $mobile;
        return $mobile;
    }
    
    public function isValidMobile(string $mobile): bool {
        return (bool) preg_match('/^09[0-9]{9}$/', $this->normalizeMobile($mobile));
    }
    
         public function generateForMobile(string $mobile): array|false {
    $mobile = $this->normalizeMobile($mobile);
    $rateKey = 'lp_rate_' . md5($mobile . $this->request->ip());
    $attempts = (int) get_transient($rateKey);
    if ($attempts >= 5) return false;
    set_transient($rateKey, $attempts + 1, 300);
    
    // ✅ جلوگیری از ارسال مجدد در 30 ثانیه
    $cooldownKey = 'lp_otp_cooldown_' . md5($mobile);
    if (get_transient($cooldownKey) !== false) {
        return false;
    }
    set_transient($cooldownKey, 1, 30);
    
    $code = sprintf('%06d', random_int(0, 999999));
    $hash = hash_hmac('sha256', $code, wp_salt('nonce'));
    $token = bin2hex(random_bytes(16));
    
    set_transient(
        'lp_otp_' . md5($mobile . $token),
        [
            'mobile'        => $mobile,
            'hash'          => $hash,
            'session_token' => $token,
            'used'          => false,
            'created'       => time(),
            'attempts'      => 0
        ],
        180
    );
    
    return ['code' => $code, 'session_token' => $token];
}
    
    public function verifyOtp(string $mobile, string $code, string $token): array|false
    {
        $mobile = $this->normalizeMobile($mobile);

        $key = 'lp_otp_' . md5($mobile . $token);
        $data = get_transient($key);

        if (!$data) {
            return false;
        }

        if (!empty($data['used'])) {
            return false;
        }

        if ((time() - (int)$data['created']) > 120) {
            delete_transient($key);
            return false;
        }

        $hash = hash_hmac('sha256', $code, wp_salt('nonce'));

        if (!hash_equals($data['hash'], $hash)) {
            return false;
        }

        $data['used'] = true;
        set_transient($key, $data, 300);

        $user = get_user_by('login', $mobile);

        if (!$user) {
            $user = get_user_by('email', $mobile);
        }

        $isNewUser = false;
        $userId = 0;

        if ($user instanceof \WP_User) {
            $userId = (int) $user->ID;
        } else {
            $isNewUser = true;
        }

        return [
            'success'      => true,
            'mobile'       => $mobile,
            'user_id'      => $userId,
            'is_new_user'  => $isNewUser,
        ];
    }
    
    public function resendOtp(string $mobile): array|false {
        $rateKey = 'lp_resend_' . md5($this->normalizeMobile($mobile) . $this->request->ip());
        if ((int) get_transient($rateKey) >= 2) return false;
        set_transient($rateKey, (int) get_transient($rateKey) + 1, 120);
        return $this->generateForMobile($mobile);
    }
}