<?php
namespace LoginPro\Modules\OTP;

defined('ABSPATH') || exit;

class Module {
    
    public function init() {
        $this->registerHooks();
        $this->loadRoutes();
    }
    
    private function registerHooks() {
        add_action('loginpro_otp_verified', [$this, 'onOtpVerified'], 10, 2);
        add_action('loginpro_hourly_cleanup', [$this, 'cleanup']);
    }
    
    private function loadRoutes() {
        // بارگذاری فایل routes ماژول Auth
        $authRoutesFile = LOGINPRO_PLUGIN_DIR . 'modules/Auth/routes.php';
        if (file_exists($authRoutesFile)) {
            require_once $authRoutesFile;
        }
        
        // بارگذاری فایل routes خود ماژول OTP
        $otpRoutesFile = __DIR__ . '/routes.php';
        if (file_exists($otpRoutesFile)) {
            require_once $otpRoutesFile;
        }
    }
    
    public function onOtpVerified($userId, $type) {
        if ($type === 'verification') {
            update_user_meta($userId, 'email_verified', 'yes');
        }
    }
    
    public function cleanup() {
        $model = new Models\OtpCode();
        $model->cleanup(24);
        $model->expireOldCodes();
    }
}