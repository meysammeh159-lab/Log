<?php
/**
 * مسیرهای ماژول OTP
 * 
 * @package LoginPro
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// اکشن‌های AJAX برای ماژول OTP (در صورت نیاز به اکشن‌های اضافی)
add_action('wp_ajax_loginpro_otp_cleanup', 'loginpro_otp_cleanup_callback');

function loginpro_otp_cleanup_callback() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز']);
    }
    
    $model = new \LoginPro\Modules\OTP\Models\OtpCode();
    $deleted = $model->cleanup(24);
    
    wp_send_json_success([
        'message' => 'پاکسازی با موفقیت انجام شد',
        'deleted' => $deleted
    ]);
}