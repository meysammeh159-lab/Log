<?php
namespace LoginPro\Modules\OTP\Models;

use LoginPro\Core\Database\Model;

class OtpCode extends Model {
    protected static $table = 'otps';
    
    public function cleanup($hours = 24) {
        $expiryTime = date('Y-m-d H:i:s', time() - ($hours * 3600));
        
        return $this->query()
            ->where('created_at', '<', $expiryTime)
            ->orWhere('expires_at', '<', current_time('mysql'))
            ->delete();
    }
    
    public function getActiveByUser($userId, $type = null) {
        $query = $this->query()
            ->where('user_id', $userId)
            ->where('status', 'pending')
            ->where('expires_at', '>', current_time('mysql'));
        
        if ($type) {
            $query->where('type', $type);
        }
        
        return $query->orderBy('created_at', 'DESC')->get();
    }
    
    public function expireOldCodes() {
        return $this->query()
            ->where('expires_at', '<', current_time('mysql'))
            ->where('status', 'pending')
            ->update(['status' => 'expired']);
    }
    
    public function getStats($userId = null) {
        $query = $this->query()
            ->select('type', 'COUNT(*) as total', 'SUM(CASE WHEN status = \"verified\" THEN 1 ELSE 0 END) as verified')
            ->where('created_at', '>', date('Y-m-d H:i:s', time() - (7 * 86400)));
        
        if ($userId) {
            $query->where('user_id', $userId);
        }
        
        return $query->groupBy('type')->get();
    }
}
