<?php
/**
 * OTP Log Model
 * ذخیره و مدیریت لاگ‌های OTP
 */

namespace LoginPro\Modules\OTP\Models;

use LoginPro\Core\Database\Model;

class OtpLog extends Model
{
    /**
     * @var string نام جدول
     */
    protected $table = 'loginpro_otp_logs';

    /**
     * @var array فیلدهای قابل پر کردن
     */
    protected $fillable = [
        'identifier',
        'code_hash',
        'channel',
        'status',
        'ip_address',
        'user_agent',
        'user_id',
        'created_at'
    ];

    /**
     * Constructor - ایجاد جدول در صورت نیاز
     */
    public function __construct()
    {
        parent::__construct();
        $this->createTableIfNotExists();
    }

    /**
     * ایجاد جدول در صورت وجود نداشتن
     */
    private function createTableIfNotExists()
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            identifier varchar(255) NOT NULL,
            code_hash varchar(64) NOT NULL,
            channel varchar(50) NOT NULL DEFAULT 'sms',
            status varchar(50) NOT NULL DEFAULT 'sent',
            ip_address varchar(45) NOT NULL,
            user_agent text,
            user_id bigint(20) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY identifier (identifier),
            KEY channel (channel),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * ثبت لاگ جدید
     */
    public function log($identifier, $code, $channel = 'sms', $status = 'sent', $userId = null)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;

        return $wpdb->insert($table, [
            'identifier' => $identifier,
            'code_hash' => hash('sha256', $code),
            'channel' => $channel,
            'status' => $status,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'user_id' => $userId ?: get_current_user_id(),
            'created_at' => current_time('mysql')
        ]);
    }

    /**
     * به‌روزرسانی وضعیت
     */
    public function updateStatus($id, $status)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;

        return $wpdb->update(
            $table,
            ['status' => $status],
            ['id' => $id]
        );
    }

    /**
     * دریافت لاگ‌های یک شناسه
     */
    public function getByIdentifier($identifier, $limit = 10)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} 
                WHERE identifier = %s 
                ORDER BY created_at DESC 
                LIMIT %d",
                $identifier,
                $limit
            )
        );
    }

    /**
     * دریافت لاگ‌های یک کاربر
     */
    public function getByUser($userId, $limit = 20)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} 
                WHERE user_id = %d 
                ORDER BY created_at DESC 
                LIMIT %d",
                $userId,
                $limit
            )
        );
    }

    /**
     * دریافت آمار OTP
     */
    public function getStats($identifier = null)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;

        $where = $identifier ? $wpdb->prepare("WHERE identifier = %s", $identifier) : '';

        $stats = [
            'total' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} {$where}"),
            'sent' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} {$where} AND status = 'sent'"),
            'verified' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} {$where} AND status = 'verified'"),
            'failed' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} {$where} AND status = 'failed'"),
        ];

        // آمار بر اساس کانال
        if (!$identifier) {
            $channels = $wpdb->get_results(
                "SELECT channel, COUNT(*) as count FROM {$table} GROUP BY channel"
            );
            $stats['channels'] = [];
            foreach ($channels as $row) {
                $stats['channels'][$row->channel] = (int) $row->count;
            }
        }

        return $stats;
    }

    /**
     * پاک کردن لاگ‌های قدیمی
     */
    public function cleanOldLogs($days = 30)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table;

        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));

        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE created_at < %s",
                $date
            )
        );
    }
}