<?php
namespace LoginPro\Modules\User\Services;

class UserService {
    
    public function getUser($userId) {
        return get_userdata($userId);
    }
    
    public function getAllUsers($args = []) {
        $defaults = [
            'number' => 20,
            'offset' => 0,
            'orderby' => 'registered',
            'order' => 'DESC'
        ];
        
        $args = wp_parse_args($args, $defaults);
        return get_users($args);
    }
    
    public function updateUserMeta($userId, $metaKey, $metaValue) {
        return update_user_meta($userId, $metaKey, $metaValue);
    }
    
    public function getUserMeta($userId, $metaKey, $default = null) {
        $value = get_user_meta($userId, $metaKey, true);
        return $value ?: $default;
    }
    
    public function deleteUser($userId, $reassign = null) {
        require_once ABSPATH . 'wp-admin/includes/user.php';
        return wp_delete_user($userId, $reassign);
    }
    
    public function searchUsers($search, $limit = 10) {
        $args = [
            'search' => '*' . $search . '*',
            'search_columns' => ['user_login', 'user_email', 'display_name'],
            'number' => $limit
        ];
        
        return get_users($args);
    }
    
    public function getUsersByRole($role, $limit = 100) {
        $args = [
            'role' => $role,
            'number' => $limit
        ];
        
        return get_users($args);
    }
    
    public function getUserCount() {
        $count = count_users();
        return $count['total_users'];
    }
}
