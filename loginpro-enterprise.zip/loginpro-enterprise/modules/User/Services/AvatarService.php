<?php
namespace LoginPro\Modules\User\Services;

class AvatarService {
    
    public function getAvatar($userId, $size = 96) {
        $avatarId = get_user_meta($userId, 'loginpro_avatar_id', true);
        
        if ($avatarId) {
            $url = wp_get_attachment_url($avatarId);
            if ($url) {
                return $url;
            }
        }
        
        return $this->getGravatar(get_userdata($userId)->user_email, $size);
    }
    
    public function uploadAvatar($userId, $file) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        
        $attachmentId = media_handle_upload('avatar', 0);
        
        if (is_wp_error($attachmentId)) {
            return [
                'success' => false,
                'message' => $attachmentId->get_error_message()
            ];
        }
        
        $oldAvatar = get_user_meta($userId, 'loginpro_avatar_id', true);
        if ($oldAvatar) {
            wp_delete_attachment($oldAvatar, true);
        }
        
        update_user_meta($userId, 'loginpro_avatar_id', $attachmentId);
        
        return [
            'success' => true,
            'url' => wp_get_attachment_url($attachmentId)
        ];
    }
    
    public function getGravatar($email, $size = 96) {
        $hash = md5(strtolower(trim($email)));
        $default = urlencode(get_avatar_url(0, ['size' => $size]));
        return "https://www.gravatar.com/avatar/{$hash}?s={$size}&d={$default}";
    }
    
    public function deleteAvatar($userId) {
        $avatarId = get_user_meta($userId, 'loginpro_avatar_id', true);
        if ($avatarId) {
            wp_delete_attachment($avatarId, true);
            delete_user_meta($userId, 'loginpro_avatar_id');
            return true;
        }
        return false;
    }
}
