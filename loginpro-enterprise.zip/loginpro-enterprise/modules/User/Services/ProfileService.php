<?php
namespace LoginPro\Modules\User\Services;

use LoginPro\Core\Security\Sanitizer;

class ProfileService {
    private $userService;
    
    public function __construct() {
        $this->userService = new UserService();
    }
    
    public function updateProfile($userId, $data) {
        $userData = ['ID' => $userId];
        
        if (isset($data['first_name'])) {
            $userData['first_name'] = Sanitizer::text($data['first_name']);
        }
        if (isset($data['last_name'])) {
            $userData['last_name'] = Sanitizer::text($data['last_name']);
        }
        if (isset($data['display_name'])) {
            $userData['display_name'] = Sanitizer::text($data['display_name']);
        }
        if (isset($data['email'])) {
            $userData['user_email'] = Sanitizer::email($data['email']);
        }
        
        if (count($userData) > 1) {
            $result = wp_update_user($userData);
            if (is_wp_error($result)) {
                return ['success' => false, 'message' => $result->get_error_message()];
            }
        }
        
        if (isset($data['bio'])) {
            update_user_meta($userId, 'description', Sanitizer::html($data['bio']));
        }
        if (isset($data['mobile'])) {
            update_user_meta($userId, 'mobile_number', Sanitizer::text($data['mobile']));
        }
        if (isset($data['timezone'])) {
            update_user_meta($userId, 'timezone', Sanitizer::text($data['timezone']));
        }
        
        return [
            'success' => true,
            'data' => $this->getUserData($userId)
        ];
    }
    
    public function getUserData($userId) {
        $user = get_userdata($userId);
        
        return [
            'id' => $userId,
            'username' => $user->user_login,
            'email' => $user->user_email,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'display_name' => $user->display_name,
            'bio' => get_user_meta($userId, 'description', true),
            'mobile' => get_user_meta($userId, 'mobile_number', true),
            'timezone' => get_user_meta($userId, 'timezone', true),
            'avatar' => get_avatar_url($userId)
        ];
    }
    
    public function updateAvatar($userId, $attachmentId) {
        $oldAvatar = get_user_meta($userId, 'loginpro_avatar_id', true);
        if ($oldAvatar) {
            wp_delete_attachment($oldAvatar, true);
        }
        
        update_user_meta($userId, 'loginpro_avatar_id', $attachmentId);
        
        return wp_get_attachment_url($attachmentId);
    }
}
