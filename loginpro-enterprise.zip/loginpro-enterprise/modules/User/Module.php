<?php
namespace LoginPro\Modules\User;

class Module {
    public function init() {
        $this->registerHooks();
        $this->loadRoutes();
    }
    
    private function registerHooks() {
        add_action('profile_update', [$this, 'onProfileUpdate'], 10, 2);
        add_action('user_register', [$this, 'onUserRegister'], 10, 1);
        add_action('loginpro_user_logged_in', [$this, 'onUserLogin'], 10, 1);
    }
    
    private function loadRoutes() {
        $routesFile = __DIR__ . '/routes.php';
        if (file_exists($routesFile)) {
            include $routesFile;
        }
    }
    
    public function onProfileUpdate($userId, $oldUserData) {
        $model = new Models\User();
        $model->syncFromWordPress($userId);
    }
    
    public function onUserRegister($userId) {
        $model = new Models\User();
        $model->syncFromWordPress($userId);
        
        update_user_meta($userId, 'registered_via', 'wordpress');
    }
    
    public function onUserLogin($userId) {
        $repository = new Repositories\UserRepository();
        $repository->updateLastLogin($userId);
    }
}
