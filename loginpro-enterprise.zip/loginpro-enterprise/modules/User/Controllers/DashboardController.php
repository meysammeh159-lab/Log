<?php
namespace LoginPro\Modules\User\Controllers;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;

class DashboardController {
    
    public function index(Request $request) {
        $userId = get_current_user_id();
        
        $data = [
            'user' => [
                'id' => $userId,
                'name' => wp_get_current_user()->display_name,
                'avatar' => get_avatar_url($userId),
                'role' => implode(', ', wp_get_current_user()->roles)
            ],
            'stats' => $this->getUserStats($userId),
            'recent_activity' => $this->getRecentActivity($userId),
            'security_score' => $this->getSecurityScore($userId)
        ];
        
        if ($request->expectsJson()) {
            return Response::json($data);
        }
        
        include LOGINPRO_PLUGIN_DIR . 'frontend/Views/dashboard/index.php';
    }
    
    private function getUserStats($userId) {
        global $wpdb;
        
        $stats = [
            'total_logins' => (int)$wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}loginpro_login_history WHERE user_id = %d",
                $userId
            )),
            'total_devices' => (int)$wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}loginpro_devices WHERE user_id = %d",
                $userId
            )),
            'last_login' => $wpdb->get_var($wpdb->prepare(
                "SELECT created_at FROM {$wpdb->prefix}loginpro_login_history WHERE user_id = %d AND status = 'success' ORDER BY created_at DESC LIMIT 1",
                $userId
            ))
        ];
        
        return $stats;
    }
    
    private function getRecentActivity($userId) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}loginpro_login_history 
            WHERE user_id = %d 
            ORDER BY created_at DESC 
            LIMIT 10",
            $userId
        ), ARRAY_A);
    }
    
    private function getSecurityScore($userId) {
        $score = 0;
        $total = 5;
        
        if (get_user_meta($userId, 'loginpro_2fa_enabled', true) === 'yes') {
            $score++;
        }
        
        $user = get_user_by('id', $userId);
        if (strlen($user->user_pass) > 8) {
            $score++;
        }
        
        if (get_user_meta($userId, 'email_verified', true) === 'yes') {
            $score++;
        }
        
        if (get_user_meta($userId, 'mobile_verified', true) === 'yes') {
            $score++;
        }
        
        $devices = $this->getUserStats($userId)['total_devices'];
        if ($devices <= 3) {
            $score++;
        }
        
        return [
            'score' => $score,
            'total' => $total,
            'percentage' => ($score / $total) * 100
        ];
    }
}
