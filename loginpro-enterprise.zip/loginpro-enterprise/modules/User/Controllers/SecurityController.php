<?php
namespace LoginPro\Modules\User\Controllers;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Core\Security\Hasher;

class SecurityController {
    private $hasher;
    
    public function __construct() {
        $this->hasher = new Hasher();
    }
    
    public function changePassword(Request $request) {
        $userId = get_current_user_id();
        $data = $request->validate([
            'current_password' => 'required|string',
            'new_password' => 'required|string|min:8'
        ]);
        
        $user = get_user_by('id', $userId);
        
        if (!wp_check_password($data['current_password'], $user->user_pass, $userId)) {
            return Response::json([
                'success' => false,
                'message' => 'Current password is incorrect'
            ], 400);
        }
        
        wp_set_password($data['new_password'], $userId);
        
        do_action('loginpro_password_changed', $userId);
        
        return Response::json([
            'success' => true,
            'message' => 'Password changed successfully'
        ]);
    }
    
    public function devices(Request $request) {
        global $wpdb;
        $userId = get_current_user_id();
        
        $devices = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}loginpro_devices 
            WHERE user_id = %d 
            ORDER BY last_active DESC",
            $userId
        ), ARRAY_A);
        
        if ($request->expectsJson()) {
            return Response::json(['success' => true, 'data' => $devices]);
        }
        
        include LOGINPRO_PLUGIN_DIR . 'frontend/Views/dashboard/devices.php';
    }
    
    public function revokeDevice(Request $request, $id) {
        global $wpdb;
        $userId = get_current_user_id();
        
        $result = $wpdb->delete(
            $wpdb->prefix . 'loginpro_devices',
            ['id' => $id, 'user_id' => $userId]
        );
        
        if ($result) {
            return Response::json([
                'success' => true,
                'message' => 'Device revoked successfully'
            ]);
        }
        
        return Response::json([
            'success' => false,
            'message' => 'Device not found'
        ], 404);
    }
    
    public function loginHistory(Request $request) {
        global $wpdb;
        $userId = get_current_user_id();
        
        $history = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}loginpro_login_history 
            WHERE user_id = %d 
            ORDER BY created_at DESC 
            LIMIT 50",
            $userId
        ), ARRAY_A);
        
        if ($request->expectsJson()) {
            return Response::json(['success' => true, 'data' => $history]);
        }
        
        include LOGINPRO_PLUGIN_DIR . 'frontend/Views/dashboard/login-history.php';
    }
    
    public function sessions(Request $request) {
        global $wpdb;
        $userId = get_current_user_id();
        
        $sessions = $wpdb->get_results($wpdb->prepare(
            "SELECT id, ip_address, user_agent, last_activity 
            FROM {$wpdb->prefix}loginpro_sessions 
            WHERE user_id = %d 
            ORDER BY last_activity DESC",
            $userId
        ), ARRAY_A);
        
        return Response::json(['success' => true, 'data' => $sessions]);
    }
    
    public function destroySession(Request $request, $sessionId) {
        global $wpdb;
        $userId = get_current_user_id();
        
        $result = $wpdb->delete(
            $wpdb->prefix . 'loginpro_sessions',
            ['id' => $sessionId, 'user_id' => $userId]
        );
        
        if ($result) {
            return Response::json([
                'success' => true,
                'message' => 'Session terminated successfully'
            ]);
        }
        
        return Response::json([
            'success' => false,
            'message' => 'Session not found'
        ], 404);
    }
}
