<?php
namespace LoginPro\User\Controllers;

defined('ABSPATH') || exit;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Modules\Auth\Services\AuthService;

class ProfileController
{
    private Request $request;
    private AuthService $authService;
    
    public function __construct() {
        $this->request = Request::capture();
        $this->authService = new AuthService();
    }
    
    /**
     * Complete Profile
     * 
     * AJAX Action: loginpro_complete_profile
     */
    public function handleCompleteProfile(): void {
        try {
            if (!$this->verifyNonce()) return;
            
            // احراز هویت - فقط کاربر لاگین شده
            if (!is_user_logged_in()) {
                Response::json(['success' => false, 'message' => 'لطفاً ابتدا وارد شوید.']);
                return;
            }
            
            $userId = get_current_user_id();
            
            $data = [
                'name' => sanitize_text_field(wp_unslash($_POST['name'] ?? '')),
                'email' => sanitize_email(wp_unslash($_POST['email'] ?? '')),
                'password' => $_POST['password'] ?? '',
                'preferred_username' => sanitize_user(wp_unslash($_POST['preferred_username'] ?? $_POST['username'] ?? '')),
                'mobile' => sanitize_text_field(wp_unslash($_POST['identifier'] ?? $_POST['mobile'] ?? '')),
            ];
            
            if (empty($data['name'])) {
                Response::json(['success' => false, 'message' => 'لطفاً نام خود را وارد کنید.']);
                return;
            }
            
            $result = $this->authService->completeProfile($userId, $data);
            
            if ($result['success']) {
                Response::json($result);
            } else {
                Response::json(['success' => false, 'message' => $result['message']]);
            }
            
        } catch (\Exception $e) {
            error_log('[LoginPro] CompleteProfile Error: ' . $e->getMessage());
            Response::json(['success' => false, 'message' => 'خطای سیستمی رخ داده است.']);
        }
    }
    
    private function verifyNonce(): bool {
        $nonce = $_POST['_nonce'] ?? $_POST['_wpnonce'] ?? '';
        
        if (!wp_verify_nonce($nonce, 'loginpro_ajax_nonce')) {
            Response::json(['success' => false, 'message' => 'درخواست نامعتبر است.']);
            return false;
        }
        
        return true;
    }
}