<?php
namespace LoginPro\Modules\User\Models;

use LoginPro\Core\Database\Model;

class User extends Model {
    protected static $table = 'users';
    protected static $primaryKey = 'user_id';
    
    public function syncFromWordPress($userId) {
        $wpUser = get_userdata($userId);
        if (!$wpUser) {
            return false;
        }
        
        $existing = $this->query()
            ->where('user_id', $userId)
            ->first();
        
        $data = [
            'user_id' => $userId,
            'mobile_number' => get_user_meta($userId, 'mobile_number', true),
            'mobile_verified' => (int)(get_user_meta($userId, 'mobile_verified', true) === 'yes'),
            'email_verified' => (int)(get_user_meta($userId, 'email_verified', true) === 'yes'),
            'two_factor_enabled' => (int)(get_user_meta($userId, 'loginpro_2fa_enabled', true) === 'yes')
        ];
        
        if ($existing) {
            return $this->query()->where('user_id', $userId)->update($data);
        }
        
        return $this->query()->insert($data);
    }
}
