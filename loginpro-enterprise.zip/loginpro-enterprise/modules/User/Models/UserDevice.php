<?php
namespace LoginPro\Modules\User\Models;

use LoginPro\Core\Database\Model;

class UserDevice extends Model {
    protected static $table = 'devices';
    
    public function getByUser($userId) {
        return $this->query()
            ->where('user_id', $userId)
            ->orderBy('last_active', 'DESC')
            ->get();
    }
    
    public function getByFingerprint($userId, $fingerprint) {
        return $this->query()
            ->where('user_id', $userId)
            ->where('fingerprint', $fingerprint)
            ->first();
    }
    
    public function updateLastActive($deviceId) {
        return $this->query()
            ->where('id', $deviceId)
            ->update(['last_active' => current_time('mysql')]);
    }
    
    public function trustDevice($deviceId, $userId) {
        return $this->query()
            ->where('id', $deviceId)
            ->where('user_id', $userId)
            ->update(['is_trusted' => 1]);
    }
    
    public function revoke($deviceId, $userId) {
        return $this->query()
            ->where('id', $deviceId)
            ->where('user_id', $userId)
            ->delete();
    }
    
    public function revokeAllExcept($userId, $currentDeviceId) {
        return $this->query()
            ->where('user_id', $userId)
            ->where('id', '!=', $currentDeviceId)
            ->delete();
    }
}
