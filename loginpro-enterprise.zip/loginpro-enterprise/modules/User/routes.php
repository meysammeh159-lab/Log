<?php
use LoginPro\Core\Http\Router;

Router::get('dashboard', [\LoginPro\Modules\User\Controllers\DashboardController::class, 'index']);
Router::get('profile', [\LoginPro\Modules\User\Controllers\ProfileController::class, 'show']);
Router::post('profile', [\LoginPro\Modules\User\Controllers\ProfileController::class, 'update']);
Router::post('change-password', [\LoginPro\Modules\User\Controllers\SecurityController::class, 'changePassword']);
Router::get('devices', [\LoginPro\Modules\User\Controllers\SecurityController::class, 'devices']);
Router::delete('device/{id}', [\LoginPro\Modules\User\Controllers\SecurityController::class, 'revokeDevice']);
Router::get('login-history', [\LoginPro\Modules\User\Controllers\SecurityController::class, 'loginHistory']);
Router::get('sessions', [\LoginPro\Modules\User\Controllers\SecurityController::class, 'sessions']);
Router::delete('session/{id}', [\LoginPro\Modules\User\Controllers\SecurityController::class, 'destroySession']);
