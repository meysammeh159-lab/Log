<?php
namespace LoginPro\Modules\User\Repositories;

use LoginPro\Core\Database\Repositories\BaseRepository;

class UserRepository extends BaseRepository {
    
    protected function getTableName() {
        return 'users';
    }
    
    public function findByEmail($email) {
        return $this->query()
            ->select('user_id')
            ->where('user_email', $email)
            ->first();
    }
    
    public function findByMobile($mobile) {
        return $this->query()
            ->select('user_id')
            ->where('mobile_number', $mobile)
            ->first();
    }
    
    public function getWithTwoFactor() {
        return $this->query()
            ->where('two_factor_enabled', 1)
            ->get();
    }
    
    public function updateLastLogin($userId) {
        return $this->update($userId, [
            'last_login_at' => current_time('mysql'),
            'last_login_ip' => $_SERVER['REMOTE_ADDR'] ?? ''
        ]);
    }
}
