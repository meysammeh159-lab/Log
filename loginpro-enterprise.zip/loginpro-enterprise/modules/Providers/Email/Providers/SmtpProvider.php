<?php
namespace LoginPro\Modules\Providers\Email\Providers;

use LoginPro\Modules\Providers\Contracts\EmailProviderInterface;

class SmtpProvider implements EmailProviderInterface {
    private $host;
    private $port;
    private $username;
    private $password;
    private $encryption;
    private $fromEmail;
    private $fromName;
    
    public function __construct() {
        $this->host = get_option('loginpro_smtp_host', '');
        $this->port = get_option('loginpro_smtp_port', 587);
        $this->username = get_option('loginpro_smtp_username', '');
        $this->password = get_option('loginpro_smtp_password', '');
        $this->encryption = get_option('loginpro_smtp_encryption', 'tls');
        $this->fromEmail = get_option('loginpro_smtp_from_email', '');
        $this->fromName = get_option('loginpro_smtp_from_name', 'LoginPro');
        
        $this->configureWordPressMail();
    }
    
    private function configureWordPressMail() {
        if (!empty($this->host)) {
            add_action('phpmailer_init', function($phpmailer) {
                $phpmailer->isSMTP();
                $phpmailer->Host = $this->host;
                $phpmailer->Port = $this->port;
                $phpmailer->SMTPAuth = !empty($this->username);
                $phpmailer->Username = $this->username;
                $phpmailer->Password = $this->password;
                $phpmailer->SMTPSecure = $this->encryption ?: '';
                $phpmailer->From = $this->fromEmail ?: get_option('admin_email');
                $phpmailer->FromName = $this->fromName;
            });
        }
    }
    
    public function send($to, $subject, $message, $headers = []) {
        $defaultHeaders = ['Content-Type: text/html; charset=UTF-8'];
        $headers = array_merge($defaultHeaders, $headers);
        
        return wp_mail($to, $subject, $message, $headers);
    }
    
    public function sendBatch($emails) {
        $success = true;
        foreach ($emails as $email) {
            if (!$this->send($email['to'], $email['subject'], $email['message'], $email['headers'] ?? [])) {
                $success = false;
            }
        }
        return $success;
    }
}
