<?php
namespace LoginPro\Modules\Providers\Email;

class EmailManager {
    private $provider;
    
    public function __construct() {
        $providerName = get_option('loginpro_email_provider', 'smtp');
        $this->provider = $this->createProvider($providerName);
    }
    
    private function createProvider($name) {
        switch ($name) {
            case 'smtp':
                return new Providers\SmtpProvider();
            case 'sendgrid':
                return new Providers\SendGridProvider();
            case 'mailgun':
                return new Providers\MailgunProvider();
            default:
                return new Providers\SmtpProvider();
        }
    }
    
    public function send($to, $subject, $message, $headers = []) {
        if (empty($to) || empty($subject) || empty($message)) {
            return false;
        }
        return $this->provider->send($to, $subject, $message, $headers);
    }
    
    public function sendBatch($emails) {
        return $this->provider->sendBatch($emails);
    }
}
