<?php
namespace LoginPro\Modules\Providers;

class Module {
    public function init() {
        $this->registerHooks();
    }
    
    private function registerHooks() {
        add_filter('loginpro_sms_providers', [$this, 'registerSmsProviders']);
        add_filter('loginpro_email_providers', [$this, 'registerEmailProviders']);
        add_filter('loginpro_whatsapp_providers', [$this, 'registerWhatsAppProviders']);
    }
    
    public function registerSmsProviders($providers) {
        $providers['kavenegar'] = 'Kavenegar';
        $providers['melipayamak'] = 'MeliPayamak';
        $providers['twilio'] = 'Twilio';
        return $providers;
    }
    
    public function registerEmailProviders($providers) {
        $providers['smtp'] = 'SMTP';
        $providers['sendgrid'] = 'SendGrid';
        $providers['mailgun'] = 'Mailgun';
        return $providers;
    }
    
    public function registerWhatsAppProviders($providers) {
        $providers['meta'] = 'Meta Cloud API';
        $providers['twilio'] = 'Twilio WhatsApp';
        return $providers;
    }
}
