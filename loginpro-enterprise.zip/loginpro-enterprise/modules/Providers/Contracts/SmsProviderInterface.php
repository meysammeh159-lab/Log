<?php
namespace LoginPro\Modules\Providers\Contracts;

defined('ABSPATH') || exit;

interface SmsProviderInterface
{
    /**
     * دریافت نام درگاه
     */
    public static function getName(): string;
    
    /**
     * دریافت slug درگاه
     */
    public static function getSlug(): string;
    
    /**
     * دریافت توضیحات درگاه
     */
    public static function getDescription(): string;
    
    /**
     * بررسی پیکربندی درگاه
     */
    public function isConfigured(): bool;
    
    /**
     * دریافت فیلدهای تنظیمات
     */
    public static function getSettingsFields(): array;
    
    /**
     * ذخیره تنظیمات
     */
    public function saveSettings(array $data): void;
    
    /**
     * دریافت نام درگاه
     */
    public function getProviderName(): string;
    
    /**
     * اعتبارسنجی شماره موبایل
     */
    public function validateNumber(string $mobile): bool;
    
    /**
     * ارسال پیامک
     * 
     * @param array $data ['mobile' => string, 'message' => string]
     * @return array ['success' => bool, 'message' => string, 'data' => mixed]
     */
    public function send(array $data): array;
    
    /**
     * ارسال کد تایید (OTP)
     * 
     * @param string $mobile شماره موبایل
     * @param string $code کد تایید
     * @return array ['success' => bool, 'message' => string]
     */
    public function sendOtp(string $mobile, string $code): array;
}