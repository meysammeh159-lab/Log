<?php
namespace LoginPro\Modules\Providers\Contracts;

interface WhatsAppProviderInterface {
    public function send($to, $message);
    public function sendTemplate($to, $template, $components = []);
}
