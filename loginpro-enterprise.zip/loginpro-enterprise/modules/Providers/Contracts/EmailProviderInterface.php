<?php
namespace LoginPro\Modules\Providers\Contracts;

defined('ABSPATH') || exit;

interface SmsProviderInterface
{
    /**
     * دریافت نام درگاه
     */
    public static function getName(): string;
    
    /**
     * دریافت اسلاگ (شناسه یکتا)
     */
    public static function getSlug(): string;
    
    /**
     * دریافت توضیحات
     */
    public static function getDescription(): string;
    
    /**
     * بررسی تنظیمات درگاه
     */
    public function isConfigured(): bool;
    
    /**
     * دریافت فیلدهای تنظیمات
     */
    public static function getSettingsFields(): array;
    
    /**
     * ذخیره تنظیمات
     */
    public function saveSettings(array $data): void;
    
    /**
     * ارسال پیامک
     */
    public function send(string $mobile, string $message): array;
    
    /**
     * ارسال کد OTP
     */
    public function sendOtp(string $mobile, string $otp): array;
}