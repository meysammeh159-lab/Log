<?php
/**
 * Meta Cloud API WhatsApp Provider
 * درگاه WhatsApp Business API متا
 */

namespace LoginPro\Modules\Providers\WhatsApp;

class MetaCloudApiProvider implements WhatsAppProviderInterface
{
    /**
     * @var string توکن دسترسی
     */
    private $accessToken;

    /**
     * @var string شناسه شماره تلفن
     */
    private $phoneNumberId;

    /**
     * @var string شناسه حساب بیزینس
     */
    private $businessAccountId;

    /**
     * @var string الگوی پیام
     */
    private $messageTemplate;

    /**
     * @var string پیشوند تنظیمات
     */
    private $optionsPrefix = 'loginpro_whatsapp_meta_';

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->accessToken = get_option($this->optionsPrefix . 'access_token', '');
        $this->phoneNumberId = get_option($this->optionsPrefix . 'phone_number_id', '');
        $this->businessAccountId = get_option($this->optionsPrefix . 'business_account_id', '');
        $this->messageTemplate = get_option(
            $this->optionsPrefix . 'message_template',
            'کاربر گرامی، کد تایید شما: %OTP%'
        );
    }

    /**
     * {@inheritdoc}
     */
    public static function getName(): string
    {
        return '📱 WhatsApp Business (Meta Cloud API)';
    }

    /**
     * {@inheritdoc}
     */
    public static function getSlug(): string
    {
        return 'meta';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDescription(): string
    {
        return 'ارسال پیام از طریق WhatsApp Business API رسمی متا';
    }

    /**
     * {@inheritdoc}
     */
    public function isConfigured(): bool
    {
        return !empty($this->accessToken) && !empty($this->phoneNumberId);
    }

    /**
     * {@inheritdoc}
     */
    public static function getSettingsFields(): array
    {
        return [
            'access_token' => [
                'type' => 'text',
                'label' => 'Access Token',
                'placeholder' => 'EAxxxxxxxxxxxxxxxx',
                'required' => true,
                'description' => 'توکن دسترسی بلندمدت از Meta Business Suite'
            ],
            'phone_number_id' => [
                'type' => 'text',
                'label' => 'Phone Number ID',
                'placeholder' => '123456789012345',
                'required' => true,
                'description' => 'شناسه شماره تلفن ثبت شده در Meta Business'
            ],
            'business_account_id' => [
                'type' => 'text',
                'label' => 'Business Account ID (اختیاری)',
                'placeholder' => '123456789012345',
                'required' => false,
                'description' => 'شناسه حساب بیزینس Meta'
            ],
            'message_template' => [
                'type' => 'textarea',
                'label' => 'Message Template',
                'placeholder' => 'کاربر گرامی، کد تایید شما: %OTP%',
                'required' => false,
                'description' => 'متغیرها: %OTP% - {NAME} - {DOMAIN}'
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function saveSettings(array $data): void
    {
        if (isset($data['access_token'])) {
            update_option($this->optionsPrefix . 'access_token', sanitize_text_field($data['access_token']));
            $this->accessToken = sanitize_text_field($data['access_token']);
        }
        if (isset($data['phone_number_id'])) {
            update_option($this->optionsPrefix . 'phone_number_id', sanitize_text_field($data['phone_number_id']));
            $this->phoneNumberId = sanitize_text_field($data['phone_number_id']);
        }
        if (isset($data['business_account_id'])) {
            update_option($this->optionsPrefix . 'business_account_id', sanitize_text_field($data['business_account_id']));
            $this->businessAccountId = sanitize_text_field($data['business_account_id']);
        }
        if (isset($data['message_template'])) {
            update_option($this->optionsPrefix . 'message_template', wp_kses_post($data['message_template']));
            $this->messageTemplate = wp_kses_post($data['message_template']);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function send(string $mobile, string $message): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'WhatsApp پیکربندی نشده است'
            ];
        }

        // استانداردسازی شماره
        $mobile = $this->normalizePhone($mobile);

        $url = "https://graph.facebook.com/v18.0/{$this->phoneNumberId}/messages";

        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $mobile,
            'type' => 'text',
            'text' => [
                'body' => $message
            ]
        ];

        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->accessToken,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($data),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => 'خطا در اتصال: ' . $response->get_error_message()
            ];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (isset($body['messages']) && !empty($body['messages'])) {
            return [
                'success' => true,
                'message' => 'پیام WhatsApp با موفقیت ارسال شد',
                'message_id' => $body['messages'][0]['id'] ?? null
            ];
        }

        return [
            'success' => false,
            'message' => $body['error']['message'] ?? 'خطا در ارسال پیام WhatsApp'
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function sendOtp(string $mobile, string $otp): array
    {
        $message = str_replace('%OTP%', $otp, $this->messageTemplate);
        $message = str_replace('{NAME}', get_bloginfo('name'), $message);
        $message = str_replace('{DOMAIN}', parse_url(home_url(), PHP_URL_HOST), $message);

        return $this->send($mobile, $message);
    }

    /**
     * {@inheritdoc}
     */
    public function testConnection(): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'WhatsApp پیکربندی نشده است'
            ];
        }

        $url = "https://graph.facebook.com/v18.0/{$this->phoneNumberId}";

        $response = wp_remote_get($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->accessToken
            ],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => 'خطا در اتصال: ' . $response->get_error_message()
            ];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (isset($body['id'])) {
            return [
                'success' => true,
                'message' => '✅ اتصال به WhatsApp Business برقرار است',
                'phone_number' => $body['display_phone_number'] ?? null
            ];
        }

        return [
            'success' => false,
            'message' => $body['error']['message'] ?? 'خطا در تست اتصال'
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getMessageTemplate(): string
    {
        return $this->messageTemplate;
    }

    /**
     * {@inheritdoc}
     */
    public function setMessageTemplate(string $template): void
    {
        $this->messageTemplate = $template;
        update_option($this->optionsPrefix . 'message_template', $template);
    }

    /**
     * استانداردسازی شماره موبایل
     */
    private function normalizePhone($mobile)
    {
        $mobile = preg_replace('/[^0-9]/', '', $mobile);
        if (substr($mobile, 0, 2) === '98') {
            $mobile = substr($mobile, 2);
        }
        $mobile = ltrim($mobile, '0');
        return '98' . $mobile;
    }
}