<?php
/**
 * WhatsApp Provider Interface
 * اینترفیس استاندارد برای درگاه‌های WhatsApp
 */

namespace LoginPro\Modules\Providers\WhatsApp;

interface WhatsAppProviderInterface
{
    /**
     * دریافت نام درگاه
     */
    public static function getName(): string;

    /**
     * دریافت شناسه یکتا
     */
    public static function getSlug(): string;

    /**
     * دریافت توضیحات
     */
    public static function getDescription(): string;

    /**
     * بررسی پیکربندی
     */
    public function isConfigured(): bool;

    /**
     * دریافت فیلدهای تنظیمات
     */
    public static function getSettingsFields(): array;

    /**
     * ذخیره تنظیمات
     */
    public function saveSettings(array $data): void;

    /**
     * ارسال پیام معمولی
     */
    public function send(string $mobile, string $message): array;

    /**
     * ارسال کد تایید (OTP)
     */
    public function sendOtp(string $mobile, string $otp): array;

    /**
     * دریافت وضعیت اتصال
     */
    public function testConnection(): array;

    /**
     * دریافت الگوی پیام
     */
    public function getMessageTemplate(): string;

    /**
     * تنظیم الگوی پیام
     */
    public function setMessageTemplate(string $template): void;
}