<?php
namespace LoginPro\Modules\Providers\WhatsApp;

class WhatsAppManager {
    private $provider;
    
    public function __construct() {
        $providerName = get_option('loginpro_whatsapp_provider', 'meta');
        $this->provider = $this->createProvider($providerName);
    }
    
    private function createProvider($name) {
        switch ($name) {
            case 'meta':
                return new Providers\MetaCloudApiProvider();
            case 'twilio':
                return new Providers\TwilioWhatsAppProvider();
            default:
                return new Providers\MetaCloudApiProvider();
        }
    }
    
    public function send($to, $message) {
        if (empty($to) || empty($message)) {
            return false;
        }
        return $this->provider->send($to, $message);
    }
    
    public function sendTemplate($to, $template, $components = []) {
        return $this->provider->sendTemplate($to, $template, $components);
    }
}
