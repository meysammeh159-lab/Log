<?php
namespace LoginPro\Modules\Providers\WhatsApp\Providers;

use LoginPro\Modules\Providers\Contracts\WhatsAppProviderInterface;

class MetaCloudApiProvider implements WhatsAppProviderInterface {
    private $accessToken;
    private $phoneNumberId;
    private $from;
    
    public function __construct() {
        $this->accessToken = get_option('loginpro_meta_access_token', '');
        $this->phoneNumberId = get_option('loginpro_meta_phone_id', '');
        $this->from = get_option('loginpro_meta_from_number', '');
    }
    
    public function send($to, $message) {
        if (!$this->accessToken || !$this->phoneNumberId) {
            return false;
        }
        
        $url = "https://graph.facebook.com/v17.0/{$this->phoneNumberId}/messages";
        $response = wp_remote_post($url, [
            'timeout' => 10,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->accessToken,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'messaging_product' => 'whatsapp',
                'to' => $to,
                'type' => 'text',
                'text' => ['body' => $message]
            ])
        ]);
        
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            return isset($body['messages'][0]['id']);
        }
        
        return false;
    }
    
    public function sendTemplate($to, $template, $components = []) {
        if (!$this->accessToken || !$this->phoneNumberId) {
            return false;
        }
        
        $url = "https://graph.facebook.com/v17.0/{$this->phoneNumberId}/messages";
        $body = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'template',
            'template' => [
                'name' => $template,
                'language' => ['code' => 'en']
            ]
        ];
        
        if (!empty($components)) {
            $body['template']['components'] = $components;
        }
        
        $response = wp_remote_post($url, [
            'timeout' => 10,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->accessToken,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($body)
        ]);
        
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            return isset($body['messages'][0]['id']);
        }
        
        return false;
    }
}
