<?php
namespace LoginPro\Modules\Providers\Sms;

defined('ABSPATH') || exit;

class SmsManager
{
    private static $instance = null;
    private $providers = [];
    private $activeProvider = null;
    private $optionsPrefix = 'loginpro_sms_';

    private function __construct()
    {
        $this->discoverProviders();
        $this->loadActiveProvider();
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function discoverProviders()
    {
        $this->providers = [];

        $interfaceFile = LOGINPRO_PLUGIN_DIR . 'modules/Providers/Contracts/SmsProviderInterface.php';
        if (file_exists($interfaceFile)) {
            require_once $interfaceFile;
        } else {
            error_log('LoginPro SmsManager: Interface not found: ' . $interfaceFile);
            return;
        }

        $searchPaths = [
            LOGINPRO_PLUGIN_DIR . 'modules/Providers/Sms/',
        ];

        $providerFiles = [];
        foreach ($searchPaths as $path) {
            if (!is_dir($path)) continue;
            $files = glob($path . '*Provider.php');
            foreach ($files as $file) {
                $bn = basename($file);
                if ($bn === 'SmsManager.php' || $bn === 'SmsProviderManager.php' || $bn === 'SmsProviderInterface.php') continue;
                $providerFiles[] = $file;
            }
        }

        $providerFiles = array_unique($providerFiles);
        $interface = 'LoginPro\\Modules\\Providers\\Contracts\\SmsProviderInterface';

        foreach ($providerFiles as $file) {
            $className = 'LoginPro\\Modules\\Providers\\Sms\\' . basename($file, '.php');
            if (!class_exists($className)) require_once $file;
            if (!class_exists($className)) continue;

            if (in_array($interface, class_implements($className))) {
                try {
                    $slug = $className::getSlug();
                    $this->providers[$slug] = $className;
                } catch (\Exception $e) {
                    error_log('LoginPro SmsManager: Error - ' . $e->getMessage());
                }
            }
        }
    }

    private function loadActiveProvider()
    {
        $activeSlug = get_option($this->optionsPrefix . 'active_provider', '');

        if (!empty($activeSlug) && isset($this->providers[$activeSlug])) {
            $className = $this->providers[$activeSlug];
            $this->activeProvider = new $className();
        } elseif (!empty($this->providers)) {
            $firstSlug = array_key_first($this->providers);
            if ($firstSlug) {
                update_option($this->optionsPrefix . 'active_provider', $firstSlug);
                $className = $this->providers[$firstSlug];
                $this->activeProvider = new $className();
            }
        }
    }

    public function getAvailableProviders()
    {
        $list = [];
        foreach ($this->providers as $slug => $className) {
            try {
                $p = new $className();
                $list[] = [
                    'slug'           => $slug,
                    'name'           => $className::getName(),
                    'description'    => $className::getDescription(),
                    'is_active'      => ($this->activeProvider && $this->activeProvider::getSlug() === $slug),
                    'is_configured'  => $p->isConfigured(),
                    'settings_fields' => $className::getSettingsFields()
                ];
            } catch (\Exception $e) {}
        }
        return $list;
    }

    public function activateProvider($slug)
    {
        if (!isset($this->providers[$slug])) return false;
        update_option($this->optionsPrefix . 'active_provider', $slug);
        $className = $this->providers[$slug];
        $this->activeProvider = new $className();
        return true;
    }

    public function saveProviderSettings($slug, $data)
    {
        if (!isset($this->providers[$slug])) return false;
        $className = $this->providers[$slug];
        $p = new $className();
        $p->saveSettings($data);
        if ($this->activeProvider && $this->activeProvider::getSlug() === $slug) {
            $this->activeProvider = new $className();
        }
        return true;
    }

    public function getActiveProvider() { return $this->activeProvider; }
    public function getActiveProviderSlug() { return $this->activeProvider ? $this->activeProvider::getSlug() : null; }
    public function getActiveProviderName() { return $this->activeProvider ? $this->activeProvider::getName() : null; }
    public function getProviders() { return $this->providers; }
    public function getProvider($slug) { return $this->providers[$slug] ?? null; }

    public function send($mobile, $message)
    {
        if (!$this->activeProvider) {
            return ['success' => false, 'message' => 'هیچ درگاه پیامکی فعال نیست'];
        }
        try {
            return $this->activeProvider->send([
                'mobile' => $mobile,
                'message' => $message
            ]);
        } catch (\Exception $e) {
            error_log('LoginPro SMS Error: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function sendOtp($mobile, $otp)
    {
        if (!$this->activeProvider) {
            return ['success' => false, 'message' => 'هیچ درگاه پیامکی فعال نیست'];
        }
        
        // ✅ بررسی پیکربندی
        if (!$this->activeProvider->isConfigured()) {
            return ['success' => false, 'message' => 'درگاه پیامکی پیکربندی نشده است'];
        }
        
        try {
            $result = $this->activeProvider->sendOtp($mobile, $otp);
            
            // ✅ ارسال result به صورت استاندارد
            if (is_bool($result)) {
                return ['success' => $result, 'message' => $result ? 'ارسال موفق' : 'ارسال ناموفق'];
            }
            
            if (is_array($result)) {
                return $result;
            }
            
            return ['success' => true, 'message' => 'ارسال موفق'];
            
        } catch (\Exception $e) {
            error_log('LoginPro SMS Error: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function refreshProviders()
    {
        $this->providers = [];
        $this->activeProvider = null;
        $this->discoverProviders();
        $this->loadActiveProvider();
    }

    private function __clone() {}
}