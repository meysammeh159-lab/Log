<?php
namespace LoginPro\Modules\Providers\Sms;

use LoginPro\Modules\Providers\Contracts\SmsProviderInterface;

defined('ABSPATH') || exit;

class KavenegarProvider implements SmsProviderInterface
{
    private $api_key;
    private $sender;
    private $optionsPrefix = 'loginpro_sms_kavenegar_';

    public function __construct()
    {
        $this->api_key = get_option($this->optionsPrefix . 'api_key', '');
        $this->sender = get_option($this->optionsPrefix . 'sender', '1000596446');
    }

    public static function getSlug(): string
    {
        return 'kavenegar';
    }

    public static function getName(): string
    {
        return 'کاوه‌نگار';
    }

    public static function getDescription(): string
    {
        return 'درگاه پیامکی کاوه‌نگار';
    }

    public static function getSettingsFields(): array
    {
        return [
            'api_key' => [
                'type' => 'text',
                'label' => 'API Key',
                'required' => true
            ],
            'sender' => [
                'type' => 'text',
                'label' => 'شماره فرستنده',
                'required' => true
            ]
        ];
    }

    public function isConfigured(): bool
    {
        return !empty($this->api_key) && !empty($this->sender);
    }

    public function saveSettings(array $data): void
    {
        if (isset($data['api_key'])) {
            update_option($this->optionsPrefix . 'api_key', sanitize_text_field($data['api_key']));
            $this->api_key = sanitize_text_field($data['api_key']);
        }
        if (isset($data['sender'])) {
            update_option($this->optionsPrefix . 'sender', sanitize_text_field($data['sender']));
            $this->sender = sanitize_text_field($data['sender']);
        }
    }

    public function getProviderName(): string
    {
        return self::getName();
    }

    public function send(array $data): array
    {
        $mobile = $data['mobile'] ?? '';
        $message = $data['message'] ?? '';

        if (empty($mobile) || empty($message)) {
            error_log('Kavenegar: Mobile or message is empty');
            return ['success' => false, 'message' => 'شماره یا پیام خالی است'];
        }

        if (!$this->isConfigured()) {
            error_log('Kavenegar: Not configured');
            return ['success' => false, 'message' => 'درگاه کاوه‌نگار پیکربندی نشده است'];
        }

        $url = 'https://api.kavenegar.com/v1/' . $this->api_key . '/sms/send.json';
        
        $body = [
            'sender' => $this->sender,
            'receptor' => $mobile,
            'message' => $message
        ];

        error_log('Kavenegar Request: ' . json_encode($body));

        $response = wp_remote_post($url, [
            'body' => $body,
            'timeout' => 8  // ✅ کاهش تایم‌اوت از 30 به 8 ثانیه
        ]);

        if (is_wp_error($response)) {
            error_log('Kavenegar WP Error: ' . $response->get_error_message());
            return ['success' => false, 'message' => $response->get_error_message()];
        }

        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);

        error_log('Kavenegar Response: ' . $body);

        if (isset($result['return']['status']) && $result['return']['status'] === 200) {
            return ['success' => true, 'message' => 'ارسال موفق', 'data' => $result];
        }

        $errorMsg = $result['return']['message'] ?? 'خطای نامشخص';
        return ['success' => false, 'message' => $errorMsg];
    }

    public function sendOtp(string $mobile, string $code): array
    {
        $message = 'کد تایید شما: ' . $code;
        return $this->send([
            'mobile' => $mobile,
            'message' => $message
        ]);
    }

    public function validateNumber(string $mobile): bool
    {
        return preg_match('/^09[0-9]{9}$/', $mobile) === 1;
    }
}