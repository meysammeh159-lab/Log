<?php
namespace LoginPro\Modules\Providers\Sms;

defined('ABSPATH') || exit;

class SmsProviderManager
{
    private static $instance = null;
    private $providers = [];
    
    private function __construct() {
        $this->discoverProviders();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function discoverProviders() {
        // لیست درگاه‌ها بر اساس کشور
        $this->providers = [
            'IR' => [
                'default' => 'kavenegar',
                'providers' => [
                    'kavenegar' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\KavenegarProvider',
                        'name' => 'Kavenegar',
                        'required_fields' => ['api_key', 'sender'],
                    ],
                    'smsir' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\SmsIrProvider',
                        'name' => 'SMS.ir',
                        'required_fields' => ['api_key', 'line_number'],
                    ],
                ]
            ],
            'US' => [
                'default' => 'twilio',
                'providers' => [
                    'twilio' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\TwilioProvider',
                        'name' => 'Twilio',
                        'required_fields' => ['account_sid', 'auth_token', 'from_number'],
                    ],
                    'nexmo' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\NexmoProvider',
                        'name' => 'Nexmo/Vonage',
                        'required_fields' => ['api_key', 'api_secret', 'from_number'],
                    ],
                ]
            ],
            'GB' => [
                'default' => 'twilio',
                'providers' => [
                    'twilio' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\TwilioProvider',
                        'name' => 'Twilio',
                        'required_fields' => ['account_sid', 'auth_token', 'from_number'],
                    ],
                    'nexmo' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\NexmoProvider',
                        'name' => 'Nexmo/Vonage',
                        'required_fields' => ['api_key', 'api_secret', 'from_number'],
                    ],
                ]
            ],
            'TR' => [
                'default' => 'twilio',
                'providers' => [
                    'twilio' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\TwilioProvider',
                        'name' => 'Twilio',
                        'required_fields' => ['account_sid', 'auth_token', 'from_number'],
                    ],
                ]
            ],
            'RU' => [
                'default' => 'nexmo',
                'providers' => [
                    'nexmo' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\NexmoProvider',
                        'name' => 'Nexmo/Vonage',
                        'required_fields' => ['api_key', 'api_secret', 'from_number'],
                    ],
                ]
            ],
            'AE' => [
                'default' => 'twilio',
                'providers' => [
                    'twilio' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\TwilioProvider',
                        'name' => 'Twilio',
                        'required_fields' => ['account_sid', 'auth_token', 'from_number'],
                    ],
                ]
            ],
            'SA' => [
                'default' => 'twilio',
                'providers' => [
                    'twilio' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\TwilioProvider',
                        'name' => 'Twilio',
                        'required_fields' => ['account_sid', 'auth_token', 'from_number'],
                    ],
                ]
            ],
            'DE' => [
                'default' => 'twilio',
                'providers' => [
                    'twilio' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\TwilioProvider',
                        'name' => 'Twilio',
                        'required_fields' => ['account_sid', 'auth_token', 'from_number'],
                    ],
                ]
            ],
            'FR' => [
                'default' => 'twilio',
                'providers' => [
                    'twilio' => [
                        'class' => 'LoginPro\Modules\Providers\Sms\TwilioProvider',
                        'name' => 'Twilio',
                        'required_fields' => ['account_sid', 'auth_token', 'from_number'],
                    ],
                ]
            ],
        ];
    }
    
    public function getProviderForCountry($country_code = null) {
        if ($country_code === null) {
            $country_code = $this->getUserCountry();
        }
        
        if (!isset($this->providers[$country_code])) {
            $country_code = 'IR';
        }
        
        $country_config = $this->providers[$country_code];
        $default_provider = $country_config['default'];
        
        $user_provider = get_user_meta(get_current_user_id(), 'loginpro_sms_provider_' . $country_code, true);
        
        if ($user_provider && isset($country_config['providers'][$user_provider])) {
            $provider_key = $user_provider;
        } else {
            $provider_key = $default_provider;
        }
        
        $provider_config = $country_config['providers'][$provider_key];
        $provider_class = $provider_config['class'];
        
        if (class_exists($provider_class)) {
            $settings = $this->getProviderSettings($country_code, $provider_key);
            return new $provider_class($settings);
        }
        
        return null;
    }
    
    public function getProviderSettings($country_code, $provider_key) {
        $settings = [];
        $country_config = $this->providers[$country_code];
        $provider_config = $country_config['providers'][$provider_key];
        
        foreach ($provider_config['required_fields'] as $field) {
            $option_key = 'loginpro_sms_' . $country_code . '_' . $provider_key . '_' . $field;
            $settings[$field] = get_option($option_key, '');
        }
        
        return $settings;
    }
    
    public function getUserCountry() {
        $user_id = get_current_user_id();
        $country = get_user_meta($user_id, 'loginpro_country', true);
        
        if ($country) {
            return $country;
        }
        
        return get_option('loginpro_default_country', 'IR');
    }
    
    public function getProvidersForCountry($country_code) {
        if (!isset($this->providers[$country_code])) {
            $country_code = 'IR';
        }
        
        $result = [];
        foreach ($this->providers[$country_code]['providers'] as $key => $config) {
            $result[$key] = $config['name'];
        }
        
        return $result;
    }
    
    public function getSupportedCountries() {
        return array_keys($this->providers);
    }
    
    public function isCountrySupported($country_code) {
        return isset($this->providers[$country_code]);
    }
    
    public function detectCountryFromPhone($phone) {
        $country_codes = [
            '98' => 'IR',
            '1' => 'US',
            '44' => 'GB',
            '90' => 'TR',
            '7' => 'RU',
            '971' => 'AE',
            '966' => 'SA',
            '49' => 'DE',
            '33' => 'FR',
        ];
        
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        if (substr($phone, 0, 1) === '0') {
            $phone = substr($phone, 1);
        }
        
        for ($i = 3; $i >= 1; $i--) {
            $code = substr($phone, 0, $i);
            if (isset($country_codes[$code])) {
                return $country_codes[$code];
            }
        }
        
        return get_option('loginpro_default_country', 'IR');
    }
}