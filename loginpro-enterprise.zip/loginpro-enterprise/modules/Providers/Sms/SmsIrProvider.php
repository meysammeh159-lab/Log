<?php
namespace LoginPro\Modules\Providers\Sms;

use LoginPro\Modules\Providers\Contracts\SmsProviderInterface;

defined('ABSPATH') || exit;

class SmsIrProvider implements SmsProviderInterface
{
    private $apiKey;
    private $lineNumber;
    private $templateId;
    private $messageTemplate;
    private $optionsPrefix = 'loginpro_sms_smsir_';
    
    public function __construct()
    {
        $this->apiKey = get_option($this->optionsPrefix . 'api_key', '');
        $this->lineNumber = get_option($this->optionsPrefix . 'line_number', '');
        $this->templateId = get_option($this->optionsPrefix . 'template_id', '');
        $this->messageTemplate = get_option($this->optionsPrefix . 'message_template', 'کاربر گرامی {NAME}، کد تایید شما: %OTP%');
    }
    
    public static function getName(): string
    {
        return 'SMS.ir - ایده پردازان';
    }
    
    public static function getSlug(): string
    {
        return 'smsir';
    }
    
    public static function getDescription(): string
    {
        return 'درگاه پیامک SMS.ir با قابلیت ارسال کد اعتبارسنجی با اولویت بالا (Verify)';
    }
    
    public function isConfigured(): bool
    {
        return !empty($this->apiKey) && !empty($this->lineNumber) && !empty($this->templateId);
    }
    
    public static function getSettingsFields(): array
    {
        return [
            'api_key' => [
                'type' => 'password',
                'label' => 'کلید API (x-api-key)',
                'required' => true,
                'description' => 'از پنل SMS.ir بخش API کلید خود را دریافت کنید'
            ],
            'line_number' => [
                'type' => 'text',
                'label' => 'شماره ارسال کننده (lineNumber)',
                'required' => true,
                'description' => 'شماره خط ارسال‌دهنده که در پنل SMS.ir مشاهده می‌کنید'
            ],
            'template_id' => [
                'type' => 'number',
                'label' => 'شناسه قالب (TemplateId)',
                'required' => true,
                'description' => 'شناسه قالب ارسال سریع (Verify) که در پنل SMS.ir ساخته‌اید'
            ],
            'message_template' => [
                'type' => 'textarea',
                'label' => 'الگوی پیام (برای روش معمولی)',
                'required' => false,
                'description' => 'در صورت عدم استفاده از قالب ارسال سریع، این الگو استفاده می‌شود'
            ]
        ];
    }
    
    public function saveSettings(array $data): void
    {
        if (isset($data['api_key'])) {
            $this->apiKey = trim($data['api_key']);
            update_option($this->optionsPrefix . 'api_key', $this->apiKey);
        }
        if (isset($data['line_number'])) {
            $this->lineNumber = trim($data['line_number']);
            update_option($this->optionsPrefix . 'line_number', $this->lineNumber);
        }
        if (isset($data['template_id'])) {
            $this->templateId = trim($data['template_id']);
            update_option($this->optionsPrefix . 'template_id', $this->templateId);
        }
        if (isset($data['message_template'])) {
            $this->messageTemplate = $data['message_template'];
            update_option($this->optionsPrefix . 'message_template', $this->messageTemplate);
        }
    }
    
    public function getProviderName(): string
    {
        return self::getName();
    }
    
    public function validateNumber(string $mobile): bool
    {
        return preg_match('/^09[0-9]{9}$/', $mobile) === 1;
    }
    
    private function formatMobile(string $mobile): string
    {
        $mobile = preg_replace('/[^0-9]/', '', $mobile);
        if (substr($mobile, 0, 2) === '98') {
            $mobile = substr($mobile, 2);
        }
        if (substr($mobile, 0, 1) === '0') {
            $mobile = substr($mobile, 1);
        }
        return $mobile;
    }
    
    /**
     * ارسال پیامک معمولی (Bulk)
     */
    public function send(array $data): array
    {
        $mobile = $data['mobile'] ?? '';
        $message = $data['message'] ?? '';
        
        if (empty($mobile) || empty($message)) {
            error_log('SMS.ir: Mobile or message is empty');
            return ['success' => false, 'message' => 'شماره یا پیام خالی است'];
        }
        
        if (!$this->isConfigured()) {
            return ['success' => false, 'message' => 'درگاه SMS.ir پیکربندی نشده است'];
        }
        
        $mobile = $this->formatMobile($mobile);
        
        $url = 'https://api.sms.ir/v1/send/bulk';
        $body = [
            'lineNumber' => (int) $this->lineNumber,
            'messageText' => $message,
            'mobiles' => [$mobile],
            'sendDateTime' => null
        ];
        
        error_log('SMS.ir Bulk Request: ' . json_encode($body));
        
        $response = wp_remote_post($url, [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'x-api-key' => $this->apiKey
            ],
            'body' => json_encode($body, JSON_UNESCAPED_UNICODE),
            'timeout' => 10
        ]);
        
        if (is_wp_error($response)) {
            error_log('SMS.ir Error: ' . $response->get_error_message());
            return ['success' => false, 'message' => $response->get_error_message()];
        }
        
        $httpCode = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        error_log('SMS.ir Bulk Response: ' . $body);
        
        if ($httpCode === 200 && isset($result['status']) && $result['status'] === 1) {
            return ['success' => true, 'message' => 'ارسال موفق', 'data' => $result];
        }
        
        $errorMsg = $result['message'] ?? 'خطای نامشخص';
        return ['success' => false, 'message' => $errorMsg];
    }
    
    /**
     * ✅ ارسال کد تایید با متد VERIFY (اولویت بالا)
     * طبق مستندات SMS.ir:
     * - URL: https://api.sms.ir/v1/send/verify
     * - Method: POST
     * - Headers: x-api-key, Content-Type: application/json
     * - Body: { mobile, templateId, parameters: [{ name, value }] }
     */
    public function sendOtp(string $mobile, string $code): array
    {
        $mobile = $this->formatMobile($mobile);
        
        error_log('SMS.ir sendOtp (Verify): mobile=' . $mobile . ', code=' . $code . ', templateId=' . $this->templateId);
        
        // ✅ اگر templateId دارد، از متد VERIFY استفاده کن (اولویت بالا)
        if (!empty($this->templateId) && is_numeric($this->templateId)) {
            $url = 'https://api.sms.ir/v1/send/verify';
            
            // ✅ پارامترهای قالب طبق مستندات
            $parameters = [];
            
            // ✅ پارامتر OTP (کد تایید) - اجباری
            $parameters[] = [
                'name' => 'OTP',
                'value' => $code
            ];
            
            // ✅ پارامتر NAME (نام سایت)
            $siteName = get_bloginfo('name');
            if (!empty($siteName)) {
                $parameters[] = [
                    'name' => 'NAME',
                    'value' => $siteName
                ];
            }
            
            // ✅ پارامتر DOMAIN (دامنه سایت)
            $domain = parse_url(home_url(), PHP_URL_HOST);
            if (!empty($domain)) {
                $parameters[] = [
                    'name' => 'DOMAIN',
                    'value' => $domain
                ];
            }
            
            // ✅ پارامتر SITE (نام سایت برای قالب‌های دیگر)
            if (!empty($siteName)) {
                $parameters[] = [
                    'name' => 'SITE',
                    'value' => $siteName
                ];
            }
            
            // ✅ پارامتر CODE (برای قالب‌هایی که از CODE استفاده می‌کنند)
            $parameters[] = [
                'name' => 'CODE',
                'value' => $code
            ];
            
            // ✅ ساخت بدنه درخواست طبق مستندات
            $body = [
                'mobile' => $mobile,
                'templateId' => (int) $this->templateId,
                'parameters' => $parameters
            ];
            
            error_log('SMS.ir Verify Request Body: ' . json_encode($body, JSON_UNESCAPED_UNICODE));
            
            // ✅ ارسال درخواست
            $response = wp_remote_post($url, [
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                    'x-api-key' => $this->apiKey
                ],
                'body' => json_encode($body, JSON_UNESCAPED_UNICODE),
                'timeout' => 10
            ]);
            
            if (is_wp_error($response)) {
                error_log('SMS.ir Verify Error: ' . $response->get_error_message());
                return ['success' => false, 'message' => $response->get_error_message()];
            }
            
            $httpCode = wp_remote_retrieve_response_code($response);
            $responseBody = wp_remote_retrieve_body($response);
            $result = json_decode($responseBody, true);
            
            error_log('SMS.ir Verify Response (HTTP ' . $httpCode . '): ' . $responseBody);
            
            // ✅ بررسی پاسخ طبق مستندات
            // status: 1 = موفق, 0 = ناموفق
            if ($httpCode === 200 && isset($result['status']) && $result['status'] === 1) {
                return [
                    'success' => true,
                    'message' => 'کد تایید ارسال شد',
                    'data' => $result['data'] ?? []
                ];
            }
            
            // ✅ خطای برگشتی از API
            $errorMsg = $result['message'] ?? 'خطای نامشخص در ارسال Verify';
            error_log('SMS.ir Verify Error: ' . $errorMsg);
            
            // ✅ اگر خطای 422 بود (Validation Error)
            if ($httpCode === 422 && isset($result['errors'])) {
                $errors = [];
                foreach ($result['errors'] as $field => $msgs) {
                    $errors[] = $field . ': ' . implode(', ', $msgs);
                }
                $errorMsg = 'خطای اعتبارسنجی: ' . implode(' | ', $errors);
            }
            
            // ✅ اگر خطای 400 بود (Bad Request)
            if ($httpCode === 400) {
                $errorMsg = 'خطای درخواست: ' . ($result['message'] ?? 'اطلاعات ارسال شده نامعتبر است');
            }
            
            // ✅ اگر خطای 401 بود (Unauthorized)
            if ($httpCode === 401) {
                $errorMsg = 'خطای احراز هویت: کلید API نامعتبر است';
            }
            
            return ['success' => false, 'message' => $errorMsg];
        }
        
        // ✅ اگر templateId ندارد، از روش معمولی استفاده کن (Bulk)
        error_log('SMS.ir: No templateId, using bulk send');
        
        $message = $this->messageTemplate;
        $message = str_replace('%OTP%', $code, $message);
        $message = str_replace('{NAME}', get_bloginfo('name'), $message);
        $message = str_replace('{DOMAIN}', parse_url(home_url(), PHP_URL_HOST), $message);
        $message = str_replace('{SITE}', get_bloginfo('name'), $message);
        $message = str_replace('{CODE}', $code, $message);
        
        if (empty(trim($message))) {
            $message = 'کد تایید شما: ' . $code;
        }
        
        return $this->send([
            'mobile' => $mobile,
            'message' => $message
        ]);
    }
}