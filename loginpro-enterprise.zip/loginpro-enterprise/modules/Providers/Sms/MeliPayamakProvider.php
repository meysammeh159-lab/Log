<?php
namespace LoginPro\Modules\Providers\Sms;

use LoginPro\Modules\Providers\Contracts\SmsProviderInterface;

defined('ABSPATH') || exit;

class MeliPayamakProvider implements SmsProviderInterface
{
    private $username;
    private $password; // ✅ اینجا APIKey ذخیره می‌شود
    private $from;
    private $optionsPrefix = 'loginpro_sms_melipayamak_';

    public function __construct()
    {
        $this->username = get_option($this->optionsPrefix . 'username', '');
        $this->password = get_option($this->optionsPrefix . 'password', ''); // ✅ APIKey
        $this->from = get_option($this->optionsPrefix . 'from', '');
    }

    public static function getSlug(): string
    {
        return 'melipayamak';
    }

    public static function getName(): string
    {
        return 'ملی پیامک - MeliPayamak';
    }

    public static function getDescription(): string
    {
        return 'درگاه پیامکی ملی پیامک - ارسال کد یکبار مصرف (با APIKey)';
    }

    public static function getSettingsFields(): array
    {
        return [
            'username' => [
                'type' => 'text',
                'label' => 'نام کاربری',
                'required' => true,
                'description' => 'کد کاربری پنل پیامکی'
            ],
            'password' => [
                'type' => 'password',
                'label' => 'APIKey',
                'required' => true,
                'description' => 'APIKey از پنل ملی پیامک (به جای رمز عبور)'
            ],
            'from' => [
                'type' => 'text',
                'label' => 'شماره ارسال کننده',
                'required' => true,
                'description' => 'سرشماره اختصاصی از بخش تنظیمات → شماره‌ها'
            ]
        ];
    }

    public function isConfigured(): bool
    {
        return !empty($this->username) && !empty($this->password) && !empty($this->from);
    }

    public function saveSettings(array $data): void
    {
        if (isset($data['username'])) {
            $this->username = trim($data['username']);
            update_option($this->optionsPrefix . 'username', $this->username);
        }
        if (isset($data['password'])) {
            $this->password = trim($data['password']);
            update_option($this->optionsPrefix . 'password', $this->password);
        }
        if (isset($data['from'])) {
            $this->from = trim($data['from']);
            update_option($this->optionsPrefix . 'from', $this->from);
        }
    }

    public function getProviderName(): string
    {
        return self::getName();
    }

    public function validateNumber(string $mobile): bool
    {
        return preg_match('/^09[0-9]{9}$/', $mobile) === 1;
    }

    private function formatMobile(string $mobile): string
    {
        $mobile = preg_replace('/[^0-9]/', '', $mobile);
        if (substr($mobile, 0, 2) === '98') {
            $mobile = '0' . substr($mobile, 2);
        }
        if (substr($mobile, 0, 1) === '0') {
            $mobile = substr($mobile, 1);
        }
        if (strlen($mobile) === 10 && $mobile[0] === '9') {
            $mobile = '0' . $mobile;
        }
        return $mobile;
    }

    public function send(array $data): array
    {
        $mobile = $data['mobile'] ?? '';
        $message = $data['message'] ?? '';

        if (empty($mobile) || empty($message)) {
            return ['success' => false, 'message' => 'شماره یا پیام خالی است'];
        }

        if (!$this->isConfigured()) {
            return ['success' => false, 'message' => 'درگاه ملی پیامک پیکربندی نشده است'];
        }

        $mobile = $this->formatMobile($mobile);

        if (!function_exists('curl_init')) {
            return ['success' => false, 'message' => 'cURL در سرور فعال نیست'];
        }

        // ✅ آدرس‌های مختلف
        $urls = [
            'http://185.165.118.55/post/send.asmx',
            'http://api.payamak-panel.com/post/send.asmx'
        ];
        
        $lastError = '';
        
        foreach ($urls as $url) {
            $result = $this->sendToUrl($url, $mobile, $message);
            if ($result['success']) {
                return $result;
            }
            $lastError = $result['message'];
            error_log('MeliPayamak: Failed with ' . $url . ': ' . $lastError);
        }
        
        return ['success' => false, 'message' => $lastError];
    }

    private function sendToUrl($url, $mobile, $message)
    {
        // ✅ ساخت بدنه SOAP با APIKey
        $xml = '<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
            <soap:Body>
                <SendSimpleSMS2 xmlns="http://tempuri.org/">
                    <username>' . htmlspecialchars($this->username, ENT_XML1) . '</username>
                    <password>' . htmlspecialchars($this->password, ENT_XML1) . '</password>
                    <from>' . htmlspecialchars($this->from, ENT_XML1) . '</from>
                    <to>' . htmlspecialchars($mobile, ENT_XML1) . '</to>
                    <text>' . htmlspecialchars($message, ENT_XML1) . '</text>
                    <isflash>false</isflash>
                    <udh></udh>
                    <recId>0</recId>
                    <status></status>
                </SendSimpleSMS2>
            </soap:Body>
        </soap:Envelope>';
        
        $headers = [
            'Content-Type: text/xml; charset=utf-8',
            'SOAPAction: http://tempuri.org/SendSimpleSMS2',
            'Content-Length: ' . strlen($xml)
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; LoginPro)');
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        error_log('MeliPayamak URL: ' . $url);
        error_log('MeliPayamak HTTP Code: ' . $httpCode);
        error_log('MeliPayamak Response: ' . $response);
        
        if ($error) {
            return ['success' => false, 'message' => 'خطای اتصال: ' . $error];
        }
        
        if ($httpCode !== 200) {
            $errorMsg = $this->extractSoapError($response);
            return ['success' => false, 'message' => 'خطای HTTP ' . $httpCode . ': ' . $errorMsg];
        }
        
        // ✅ پردازش پاسخ
        return $this->parseSoapResponse($response);
    }

    private function extractSoapError($response)
    {
        try {
            if (preg_match('/<faultstring>(.*?)<\/faultstring>/', $response, $matches)) {
                return trim($matches[1]);
            }
            if (preg_match('/<error>(.*?)<\/error>/', $response, $matches)) {
                return trim($matches[1]);
            }
            if (preg_match('/<message>(.*?)<\/message>/', $response, $matches)) {
                return trim($matches[1]);
            }
            return 'خطای ناشناخته از سرور';
        } catch (\Exception $e) {
            return 'خطا در پردازش پاسخ: ' . $e->getMessage();
        }
    }

    private function parseSoapResponse($response)
    {
        try {
            $dom = new \DOMDocument();
            $dom->loadXML($response);
            
            $xpath = new \DOMXPath($dom);
            $xpath->registerNamespace('soap', 'http://schemas.xmlsoap.org/soap/envelope/');
            $xpath->registerNamespace('ns', 'http://tempuri.org/');
            
            $nodes = $xpath->query('//ns:SendSimpleSMS2Result');
            
            if ($nodes->length > 0) {
                $resultCode = (int)$nodes->item(0)->textContent;
                
                // ✅ بررسی کد خطا
                if ($resultCode > 0) {
                    return [
                        'success' => true,
                        'message' => 'ارسال موفق',
                        'data' => ['message_id' => $resultCode]
                    ];
                }
                
                // ❌ خطاهای ارسال
                $errorCodes = [
                    '-1' => 'خطای داخلی سیستم',
                    '-2' => 'نام کاربری یا APIKey اشتباه است',
                    '-3' => 'شماره فرستنده نامعتبر است',
                    '-4' => 'شماره گیرنده نامعتبر است',
                    '-5' => 'متن پیام خالی است',
                    '-6' => 'اعتبار کافی نیست',
                    '-7' => 'خطا در ارسال پیامک',
                    '-8' => 'شماره گیرنده در لیست سیاه است',
                    '-9' => 'متن پیام دارای کلمات ممنوعه است',
                    '0' => 'خطای نامشخص'
                ];
                
                $errorMessage = $errorCodes[(string)$resultCode] ?? 'خطای نامشخص (کد: ' . $resultCode . ')';
                return ['success' => false, 'message' => $errorMessage];
            }
            
            return ['success' => false, 'message' => 'پاسخ نامعتبر از سرور'];
            
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'خطا در پردازش پاسخ: ' . $e->getMessage()];
        }
    }

    public function sendOtp(string $mobile, string $code): array
    {
        $mobile = $this->formatMobile($mobile);
        $siteName = get_bloginfo('name');
        $message = "کد تایید شما: " . $code . "\n" . $siteName;

        return $this->send([
            'mobile' => $mobile,
            'message' => $message
        ]);
    }

    /**
     * ✅ دریافت اعتبار حساب
     */
    public function getCredit(): array
    {
        if (!$this->isConfigured()) {
            return ['success' => false, 'message' => 'درگاه پیکربندی نشده است'];
        }

        if (!function_exists('curl_init')) {
            return ['success' => false, 'message' => 'cURL در سرور فعال نیست'];
        }

        $urls = [
            'http://185.165.118.55/post/send.asmx',
            'http://api.payamak-panel.com/post/send.asmx'
        ];

        foreach ($urls as $url) {
            $result = $this->getCreditFromUrl($url);
            if ($result['success']) {
                return $result;
            }
        }

        return ['success' => false, 'message' => 'خطا در دریافت اعتبار'];
    }

    /**
     * ✅ دریافت اعتبار از یک URL
     */
    private function getCreditFromUrl($url)
    {
        $xml = '<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
            <soap:Body>
                <GetCredit xmlns="http://tempuri.org/">
                    <username>' . htmlspecialchars($this->username, ENT_XML1) . '</username>
                    <password>' . htmlspecialchars($this->password, ENT_XML1) . '</password>
                </GetCredit>
            </soap:Body>
        </soap:Envelope>';
        
        $headers = [
            'Content-Type: text/xml; charset=utf-8',
            'SOAPAction: http://tempuri.org/GetCredit',
            'Content-Length: ' . strlen($xml)
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return ['success' => false, 'message' => 'خطای اتصال: ' . $error];
        }
        
        if ($httpCode !== 200) {
            return ['success' => false, 'message' => 'خطای HTTP: ' . $httpCode];
        }
        
        // ✅ پردازش پاسخ
        try {
            $dom = new \DOMDocument();
            $dom->loadXML($response);
            
            $xpath = new \DOMXPath($dom);
            $xpath->registerNamespace('soap', 'http://schemas.xmlsoap.org/soap/envelope/');
            $xpath->registerNamespace('ns', 'http://tempuri.org/');
            
            $nodes = $xpath->query('//ns:GetCreditResult');
            
            if ($nodes->length > 0) {
                $credit = (float)$nodes->item(0)->textContent;
                return ['success' => true, 'credit' => $credit];
            }
            
            return ['success' => false, 'message' => 'پاسخ نامعتبر'];
            
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'خطا در پردازش: ' . $e->getMessage()];
        }
    }
}