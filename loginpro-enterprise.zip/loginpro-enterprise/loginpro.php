<?php
/**
 * Plugin Name: لاگین پرو - LoginPro
 * Plugin URI: https://ivs.ir/loginpro
 * Description: ✨ سیستم احراز هویت سازمانی لاگین پرو - ورود و ثبت‌نام هوشمند با کد تایید
 * Version: 3.0.0
 * Author: IVS Team
 * Text Domain: loginpro
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ ثابت‌های اصلی
// ==================================================
define('LOGINPRO_VERSION', '3.0.0');
define('LOGINPRO_PLUGIN_FILE', __FILE__);
define('LOGINPRO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LOGINPRO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('LOGINPRO_INCLUDES_DIR', LOGINPRO_PLUGIN_DIR . 'includes/');
define('LOGINPRO_ADMIN_DIR', LOGINPRO_PLUGIN_DIR . 'admin/');
define('LOGINPRO_CUSTOM_DIR', LOGINPRO_PLUGIN_DIR . 'custom/');
define('LOGINPRO_ASSETS_DIR', LOGINPRO_PLUGIN_DIR . 'assets/');

// ==================================================
// ✅ فعال‌سازی/غیرفعال‌سازی
// ==================================================
register_activation_hook(LOGINPRO_PLUGIN_FILE, 'loginpro_activate');
register_deactivation_hook(LOGINPRO_PLUGIN_FILE, 'loginpro_deactivate');

function loginpro_activate() {
    loginpro_create_tables();
    loginpro_set_default_options();
    loginpro_create_pages();
    flush_rewrite_rules();
}

function loginpro_deactivate() {
    flush_rewrite_rules();
}

// ==================================================
// ✅ بارگذاری فایل‌ها
// ==================================================
require_once LOGINPRO_INCLUDES_DIR . 'helpers.php';
require_once LOGINPRO_PLUGIN_DIR . 'includes/ajax-variables.php';
require_once __DIR__ . '/ajax-handler.php';

// ==================================================
// ✅ بارگذاری Controllerها و Serviceها (ترتیب مهم است)
// ==================================================
$files = [
    // Core
    'core/Http/Request.php',
    'core/Http/Response.php',
    
    // Provider Interface
    'modules/Providers/Contracts/SmsProviderInterface.php',
    
    // SMS Providers
    'modules/Providers/Sms/SmsManager.php',
    'modules/Providers/Sms/KavenegarProvider.php',
    'modules/Providers/Sms/SmsIrProvider.php',
    'modules/Providers/Sms/MeliPayamakProvider.php',
    
    // OTP Services
    'modules/OTP/Services/OtpService.php',
    'modules/OTP/Services/OtpDispatcherService.php',
    
    // Auth Services & Controllers
    'modules/Auth/Services/AuthService.php',
    'modules/Auth/Controllers/OtpController.php',
    'modules/Auth/Controllers/LoginController.php',
    
    // User & WooCommerce
    'modules/User/Controllers/ProfileController.php',
    'modules/WooCommerce/Controllers/InvoiceController.php',
];

foreach ($files as $file) {
    $path = LOGINPRO_PLUGIN_DIR . $file;
    if (file_exists($path)) {
        require_once $path;
    } else {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro] File not found: ' . $path);
        }
    }
}
// ✅ بارگذاری مستقیم OtpController برای اطمینان
require_once LOGINPRO_PLUGIN_DIR . 'modules/Auth/Controllers/OtpController.php';

// ==================================================
// ✅ ثبت اکشن‌های AJAX - روش مستقیم و مطمئن
// ==================================================
add_action('init', function() {
    // بارگذاری کنترلرها
    require_once LOGINPRO_PLUGIN_DIR . 'modules/Auth/Controllers/OtpController.php';
    require_once LOGINPRO_PLUGIN_DIR . 'modules/Auth/Controllers/LoginController.php';
    require_once LOGINPRO_PLUGIN_DIR . 'modules/User/Controllers/ProfileController.php';
    
    // ============================================
    // OTP Controller - ثبت مستقیم
    // ============================================
    if (class_exists('LoginPro\\Modules\\Auth\\Controllers\\OtpController')) {
        $otp = new \LoginPro\Modules\Auth\Controllers\OtpController();
        
        add_action('wp_ajax_loginpro_check_identifier', [$otp, 'handleCheckIdentifier']);
        add_action('wp_ajax_nopriv_loginpro_check_identifier', [$otp, 'handleCheckIdentifier']);
        
        add_action('wp_ajax_loginpro_verify_otp', [$otp, 'handleVerifyOtp']);
        add_action('wp_ajax_nopriv_loginpro_verify_otp', [$otp, 'handleVerifyOtp']);
        
        add_action('wp_ajax_loginpro_resend_otp', [$otp, 'handleResendOtp']);
        add_action('wp_ajax_nopriv_loginpro_resend_otp', [$otp, 'handleResendOtp']);
        
        error_log('[LoginPro] ✅ OTP AJAX actions registered');
    } else {
        error_log('[LoginPro] ❌ OtpController not found');
    }
    
    // ============================================
    // Login Controller
    // ============================================
    if (class_exists('LoginPro\\Modules\\Auth\\Controllers\\LoginController')) {
        $login = new \LoginPro\Modules\Auth\Controllers\LoginController();
        
        add_action('wp_ajax_loginpro_login_password', [$login, 'handleLogin']);
        add_action('wp_ajax_nopriv_loginpro_login_password', [$login, 'handleLogin']);
        
        add_action('wp_ajax_loginpro_register', [$login, 'handleRegister']);
        add_action('wp_ajax_nopriv_loginpro_register', [$login, 'handleRegister']);
        
        add_action('wp_ajax_loginpro_reset_password', [$login, 'handleResetPassword']);
        add_action('wp_ajax_nopriv_loginpro_reset_password', [$login, 'handleResetPassword']);
        
        error_log('[LoginPro] ✅ Login AJAX actions registered');
    }
    
    // ============================================
    // Profile Controller
    // ============================================
    if (class_exists('LoginPro\\User\\Controllers\\ProfileController')) {
        $profile = new \LoginPro\User\Controllers\ProfileController();
        add_action('wp_ajax_loginpro_complete_profile', [$profile, 'handleCompleteProfile']);
        add_action('wp_ajax_nopriv_loginpro_complete_profile', [$profile, 'handleCompleteProfile']);
    }
    
    // ============================================
    // WooCommerce Controller
    // ============================================
    if (function_exists('wc_get_order') && class_exists('LoginPro\\WooCommerce\\Controllers\\InvoiceController')) {
        $invoice = new \LoginPro\WooCommerce\Controllers\InvoiceController();
        add_action('wp_ajax_loginpro_get_invoice', [$invoice, 'handleGetInvoice']);
    }
}, 1);

// ==================================================
// ✅ ادامه کدهای قبلی (بدون تغییر)
// ==================================================

// شورت‌کدها و توابع سفارشی
if (!is_admin() || wp_doing_ajax()) {
    require_once LOGINPRO_CUSTOM_DIR . 'custom-functions.php';
}

if (!is_admin()) {
    $login_file = LOGINPRO_CUSTOM_DIR . 'loginpro-custom-login.php';
    if (file_exists($login_file)) {
        require_once $login_file;
    }
}

// ==================================================
// ✅ تنظیم خودکار SMS Provider
// ==================================================
add_action('admin_init', 'loginpro_auto_setup_sms');

function loginpro_auto_setup_sms() {
    if (get_option('loginpro_sms_configured')) return;
    if (!class_exists('\\LoginPro\\Modules\\Providers\\Sms\\SmsManager')) return;
    
    $sms = \LoginPro\Modules\Providers\Sms\SmsManager::getInstance();
    $providers = $sms->getAvailableProviders();
    
    if (empty($providers)) return;
    
    $first = $providers[0];
    $sms->activateProvider($first['slug']);
    update_option('loginpro_sms_configured', true);
    
    add_action('admin_notices', function() use ($first) {
        echo '<div class="notice notice-success"><p>';
        echo '✅ <strong>لاگین پرو:</strong> درگاه پیامکی <strong>' . esc_html($first['name']) . '</strong> فعال شد. ';
        echo '<a href="' . admin_url('admin.php?page=loginpro-sms') . '">تنظیم API Key</a>';
        echo '</p></div>';
    });
}

// ==================================================
// ✅ بارگذاری فونت‌ها و اسکریپت‌ها
// ==================================================
add_action('wp_enqueue_scripts', 'loginpro_enqueue_fonts', 1);
add_action('admin_enqueue_scripts', 'loginpro_admin_enqueue_fonts', 1);

function loginpro_enqueue_fonts() {
    $font_style = LOGINPRO_ASSETS_DIR . 'fonts/font-styles.css';
    if (file_exists($font_style)) {
        wp_enqueue_style('loginpro-fonts', LOGINPRO_PLUGIN_URL . 'assets/fonts/font-styles.css', [], LOGINPRO_VERSION);
    }
}

function loginpro_admin_enqueue_fonts() {
    $font_style = LOGINPRO_ASSETS_DIR . 'fonts/font-styles.css';
    if (file_exists($font_style)) {
        wp_enqueue_style('loginpro-fonts', LOGINPRO_PLUGIN_URL . 'assets/fonts/font-styles.css', [], LOGINPRO_VERSION);
    }
}

add_action('plugins_loaded', 'loginpro_load_textdomain');

function loginpro_load_textdomain() {
    load_plugin_textdomain('loginpro', false, dirname(plugin_basename(LOGINPRO_PLUGIN_FILE)) . '/languages');
}

add_action('wp_enqueue_scripts', 'loginpro_enqueue_scripts');

function loginpro_enqueue_scripts() {
    // ✅ برای تست: همیشه بارگذاری کن
    $force_load = true;
    
    $is_login_page = is_page('login') || is_page('profile') || 
                     (strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false);
    
    // ✅ اگر صفحه لاگین نیست و کاربر لاگین نیست و force_load فعال نیست، برگرد
    if (!$is_login_page && !is_user_logged_in() && !$force_load) {
        return;
    }
    
    // ✅ همیشه jQuery را بارگذاری کن
    wp_enqueue_script('jquery');
    
    // ✅ بارگذاری فایل JS
    $js_file = LOGINPRO_ASSETS_DIR . 'js/loginpro.js';
    if (file_exists($js_file)) {
        wp_enqueue_script(
            'loginpro-scripts', 
            LOGINPRO_PLUGIN_URL . 'assets/js/loginpro.js', 
            ['jquery'], 
            LOGINPRO_VERSION, 
            true
        );
        
        // ✅ محلی‌سازی - این باید بعد از wp_enqueue_script باشد
        wp_localize_script('loginpro-scripts', 'loginpro_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('loginpro_ajax_nonce'),
            'plugin_url' => LOGINPRO_PLUGIN_URL,
        ]);
        
        error_log('[LoginPro] loginpro-scripts enqueued successfully');
    } else {
        error_log('[LoginPro] JS file not found: ' . $js_file);
    }
    
}

add_action('admin_enqueue_scripts', 'loginpro_admin_enqueue_scripts');

function loginpro_admin_enqueue_scripts($hook) {
    if (strpos($hook, 'loginpro') === false && $hook !== 'toplevel_page_loginpro') {
        return;
    }
    
    wp_enqueue_script('jquery');
    
    $admin_js = LOGINPRO_ASSETS_DIR . 'js/admin.js';
    if (file_exists($admin_js)) {
        wp_enqueue_script('loginpro-admin-scripts', LOGINPRO_PLUGIN_URL . 'assets/js/admin.js', ['jquery'], LOGINPRO_VERSION, true);
    }
    
    $admin_css = LOGINPRO_ASSETS_DIR . 'css/admin.css';
    if (file_exists($admin_css)) {
        wp_enqueue_style('loginpro-admin-styles', LOGINPRO_PLUGIN_URL . 'assets/css/admin.css', [], LOGINPRO_VERSION);
    }
}

// ==================================================
// ✅ دکمه تنظیمات در صفحه پلاگین‌ها
// ==================================================
add_filter('plugin_action_links_' . plugin_basename(LOGINPRO_PLUGIN_FILE), 'loginpro_add_action_links');

function loginpro_add_action_links($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=loginpro') . '">⚙️ تنظیمات</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// ==================================================
// ✅ ایجاد جدول‌ها
// ==================================================
function loginpro_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    $tickets_table = $wpdb->prefix . 'loginpro_tickets';
    $sql_tickets = "CREATE TABLE IF NOT EXISTS $tickets_table (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        title VARCHAR(255) NOT NULL,
        message LONGTEXT NOT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'pending',
        priority VARCHAR(20) NOT NULL DEFAULT 'normal',
        category VARCHAR(50) NOT NULL DEFAULT 'general',
        attachment VARCHAR(500) DEFAULT '',
        reply LONGTEXT,
        reply_date DATETIME,
        rating TINYINT UNSIGNED DEFAULT 0,
        created_at DATETIME NOT NULL,
        updated_at DATETIME,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status)
    ) $charset_collate;";
    
    $messages_table = $wpdb->prefix . 'loginpro_ticket_messages';
    $sql_messages = "CREATE TABLE IF NOT EXISTS $messages_table (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        message LONGTEXT NOT NULL,
        is_admin TINYINT(1) NOT NULL DEFAULT 0,
        attachment VARCHAR(500) DEFAULT '',
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY ticket_id (ticket_id)
    ) $charset_collate;";
    
    $user_messages_table = $wpdb->prefix . 'loginpro_messages';
    $sql_user_messages = "CREATE TABLE IF NOT EXISTS $user_messages_table (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        subject VARCHAR(255) NOT NULL,
        message LONGTEXT NOT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        date DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";
    
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql_tickets);
    dbDelta($sql_messages);
    dbDelta($sql_user_messages);
}

// ==================================================
// ✅ تنظیمات پیش‌فرض
// ==================================================
function loginpro_set_default_options() {
    $defaults = [
        'loginpro_primary_color' => '#ef394e',
        'loginpro_secondary_color' => '#c62828',
        'loginpro_hover_color' => '#c62828',
        'loginpro_background_color' => '#f5f7fa',
        'loginpro_font_family' => 'IRANSans, Tahoma, sans-serif',
        'loginpro_border_radius' => 24,
        'loginpro_form_width' => '400px',
        'loginpro_button_style' => 'rounded',
        'loginpro_otp_length' => 6,
        'loginpro_modal_close_on_click' => 1,
        'loginpro_modal_close_on_esc' => 1,
        'loginpro_show_password_reset' => 1,
        'loginpro_show_social_login' => 0,
        'loginpro_login_page_layout' => 'centered',
        'loginpro_text_title' => 'ورود',
        'loginpro_text_subtitle' => 'شماره موبایل، ایمیل یا نام کاربری خود را وارد کنید',
        'loginpro_text_help_identifier' => 'شماره موبایل، ایمیل یا نام کاربری',
        'loginpro_text_continue_btn' => 'بررسی',
        'loginpro_text_password_title' => 'ورود با رمز عبور',
        'loginpro_text_help_password' => 'رمز عبور خود را وارد کنید',
        'loginpro_text_login_btn' => 'ورود',
        'loginpro_text_otp_title' => 'کد تایید',
        'loginpro_text_verify_btn' => 'تایید و ورود',
        'loginpro_text_forgot_password' => 'فراموشی رمز عبور',
        'loginpro_text_header_title' => 'لاگین پرو',
        'loginpro_text_otp_login_message' => 'کد تایید برای شما ارسال شد.',
        'loginpro_modal_btn_text' => 'ورود / ثبت‌نام',
        'loginpro_modal_btn_logged_text' => 'پنل کاربری',
        'loginpro_modal_btn_icon' => '🔐',
        'loginpro_modal_btn_logged_icon' => '👤',
        'loginpro_modal_btn_bg_color' => '#ef394e',
        'loginpro_modal_btn_text_color' => '#ffffff',
        'loginpro_modal_btn_border_radius' => 8,
        'loginpro_modal_btn_padding' => '8px 20px',
        'loginpro_modal_btn_font_size' => 14,
    ];
    
    foreach ($defaults as $key => $value) {
        if (!get_option($key)) {
            update_option($key, $value);
        }
    }
    
    if (!get_option('loginpro_user_dashboard_tabs')) {
        update_option('loginpro_user_dashboard_tabs', [
            'account_details', 'messages', 'addresses', 'orders', 'downloads', 'tickets', 'logout'
        ]);
    }
}

// ==================================================
// ✅ ایجاد صفحات
// ==================================================
function loginpro_create_pages() {
    if (!get_option('loginpro_profile_page_id')) {
        $profile_page = wp_insert_post([
            'post_title'   => 'پروفایل کاربری',
            'post_content' => '[loginpro_user]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_name'    => 'profile'
        ]);
        if ($profile_page) {
            update_option('loginpro_profile_page_id', $profile_page);
        }
    }
    
    if (!get_option('loginpro_login_page_id')) {
        $login_page = wp_insert_post([
            'post_title'   => 'ورود',
            'post_content' => '<!-- صفحه لاگین به صورت خودکار توسط LoginPro مدیریت می‌شود -->',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_name'    => 'login'
        ]);
        if ($login_page) {
            update_option('loginpro_login_page_id', $login_page);
        }
    }
}

// ==================================================
// ✅ منوی کامل ادمین
// ==================================================
add_action('admin_menu', 'loginpro_register_admin_menus');

function loginpro_register_admin_menus() {
    $admin_files = ['DashboardPage.php', 'AppearancePage.php', 'PagesSettingsPage.php', 'SmsProvidersPage.php', 'TicketSystem.php', 'MessageAdmin.php', 'OtpSettingsPage.php'];
    foreach ($admin_files as $file) {
        $file_path = LOGINPRO_ADMIN_DIR . $file;
        if (file_exists($file_path)) require_once $file_path;
    }
    
    add_menu_page(__('داشبورد لاگین پرو', 'loginpro'), '🚀 لاگین پرو', 'manage_options', 'loginpro', 'loginpro_render_dashboard', 'dashicons-shield-alt', 56);
    add_submenu_page('loginpro', __('پیشخوان', 'loginpro'), '📊 پیشخوان', 'manage_options', 'loginpro', 'loginpro_render_dashboard');
    add_submenu_page('loginpro', __('تنظیمات رنگ', 'loginpro'), '🎨 تنظیمات رنگ', 'manage_options', 'loginpro-appearance', 'loginpro_render_appearance');
    add_submenu_page('loginpro', __('تنظیمات صفحات', 'loginpro'), '📄 تنظیمات صفحات', 'manage_options', 'loginpro-pages', 'loginpro_render_pages');
    add_submenu_page('loginpro', __('تنظیمات پیامک', 'loginpro'), '✉️ تنظیمات پیامک', 'manage_options', 'loginpro-sms', 'loginpro_render_sms');
    add_submenu_page('loginpro', __('تنظیمات OTP', 'loginpro'), '🔐 تنظیمات OTP', 'manage_options', 'loginpro-otp', 'loginpro_render_otp');
    add_submenu_page('loginpro', __('مدیریت تیکت‌ها', 'loginpro'), '🎫 تیکت‌ها', 'manage_options', 'loginpro-tickets', 'loginpro_render_tickets');
    add_submenu_page('loginpro', __('مدیریت پیام‌ها', 'loginpro'), '📨 پیام‌ها', 'manage_options', 'loginpro-messages', 'loginpro_render_messages');
}

// ==================================================
// ✅ رندر صفحات ادمین
// ==================================================
function loginpro_render_dashboard() {
    if (class_exists('LoginPro\Admin\DashboardPage')) {
        try {
            $page = new \LoginPro\Admin\DashboardPage();
            if (method_exists($page, 'renderPage')) { $page->renderPage(); return; }
            if (method_exists($page, 'render')) { $page->render(); return; }
        } catch (Exception $e) {}
    }
    ?>
    <div class="wrap"><h1>🚀 پیشخوان لاگین پرو</h1>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:20px;margin-top:20px;">
        <div style="background:#fff;padding:20px;border-radius:12px;border:1px solid #e0e0e0;"><h3 style="margin:0 0 10px;color:#ef394e;">🎨 تنظیمات رنگ</h3><p style="color:#666;font-size:13px;">تغییر رنگ‌های اصلی، ثانویه و استایل فرم</p><a href="<?php echo admin_url('admin.php?page=loginpro-appearance'); ?>" class="button button-primary">ورود</a></div>
        <div style="background:#fff;padding:20px;border-radius:12px;border:1px solid #e0e0e0;"><h3 style="margin:0 0 10px;color:#17a2b8;">📄 تنظیمات صفحات</h3><p style="color:#666;font-size:13px;">مدیریت صفحات لاگین، پروفایل</p><a href="<?php echo admin_url('admin.php?page=loginpro-pages'); ?>" class="button button-primary">ورود</a></div>
        <div style="background:#fff;padding:20px;border-radius:12px;border:1px solid #e0e0e0;"><h3 style="margin:0 0 10px;color:#28a745;">✉️ تنظیمات پیامک</h3><p style="color:#666;font-size:13px;">تنظیمات سرویس پیامکی</p><a href="<?php echo admin_url('admin.php?page=loginpro-sms'); ?>" class="button button-primary">ورود</a></div>
        <div style="background:#fff;padding:20px;border-radius:12px;border:1px solid #e0e0e0;"><h3 style="margin:0 0 10px;color:#fd7e14;">🎫 تیکت‌ها</h3><p style="color:#666;font-size:13px;">مدیریت تیکت‌های پشتیبانی</p><a href="<?php echo admin_url('admin.php?page=loginpro-tickets'); ?>" class="button button-primary">ورود</a></div>
        <div style="background:#fff;padding:20px;border-radius:12px;border:1px solid #e0e0e0;"><h3 style="margin:0 0 10px;color:#6f42c1;">📨 پیام‌ها</h3><p style="color:#666;font-size:13px;">مدیریت پیام‌های کاربران</p><a href="<?php echo admin_url('admin.php?page=loginpro-messages'); ?>" class="button button-primary">ورود</a></div>
    </div></div>
    <?php
}

function loginpro_render_appearance() {
    if (class_exists('LoginPro\Admin\AppearancePage')) {
        try { $page = new \LoginPro\Admin\AppearancePage(); if (method_exists($page, 'render')) { $page->render(); return; } } catch (Exception $e) {}
    }
    ?>
    <div class="wrap"><h1>🎨 تنظیمات رنگ</h1><form method="post" action="options.php"><?php settings_fields('loginpro_appearance'); ?>
    <table class="form-table">
        <tr><th scope="row">رنگ اصلی</th><td><input type="color" name="loginpro_primary_color" value="<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>"></td></tr>
        <tr><th scope="row">رنگ ثانویه</th><td><input type="color" name="loginpro_secondary_color" value="<?php echo esc_attr(get_option('loginpro_secondary_color', '#c62828')); ?>"></td></tr>
        <tr><th scope="row">فونت</th><td><select name="loginpro_font_family"><?php $fonts = ['IRANSans, Tahoma, sans-serif'=>'IRANSans','Vazirmatn, Tahoma, sans-serif'=>'Vazirmatn','Tahoma, Arial, sans-serif'=>'Tahoma','Arial, sans-serif'=>'Arial']; $current = get_option('loginpro_font_family'); foreach($fonts as $k=>$v) echo '<option value="'.$k.'" '.selected($current,$k,false).'>'.$v.'</option>'; ?></select></td></tr>
        <tr><th scope="row">تعداد ارقام OTP</th><td><input type="number" name="loginpro_otp_length" value="<?php echo esc_attr(get_option('loginpro_otp_length', 6)); ?>" min="4" max="8"></td></tr>
    </table><?php submit_button(); ?></form></div>
    <?php
}

function loginpro_render_pages() {
    if (class_exists('LoginPro\Admin\PagesSettingsPage')) {
        try { $page = new \LoginPro\Admin\PagesSettingsPage(); if (method_exists($page, 'render')) { $page->render(); return; } } catch (Exception $e) {}
    }
    ?>
    <div class="wrap"><h1>📄 تنظیمات صفحات</h1><form method="post" action="options.php"><?php settings_fields('loginpro_pages'); ?>
    <?php $pages = get_pages(); $login_sel = get_option('loginpro_login_page_id', 0); $prof_sel = get_option('loginpro_profile_page_id', 0); ?>
    <p>صفحه لاگین: <select name="loginpro_login_page_id"><option value="0">---</option><?php foreach($pages as $p) echo '<option value="'.$p->ID.'" '.selected($login_sel,$p->ID,false).'>'.$p->post_title.'</option>'; ?></select></p>
    <p>صفحه پروفایل: <select name="loginpro_profile_page_id"><option value="0">---</option><?php foreach($pages as $p) echo '<option value="'.$p->ID.'" '.selected($prof_sel,$p->ID,false).'>'.$p->post_title.'</option>'; ?></select></p>
    <?php submit_button(); ?></form></div>
    <?php
}

function loginpro_render_sms() {
    if (class_exists('LoginPro\Admin\SmsProvidersPage')) {
        try { $page = new \LoginPro\Admin\SmsProvidersPage(); if (method_exists($page, 'render')) { $page->render(); return; } } catch (Exception $e) {}
    }
    ?>
    <div class="wrap"><h1>✉️ تنظیمات پیامک</h1><form method="post" action="options.php"><?php settings_fields('loginpro_sms'); ?>
    <p>فعال: <input type="radio" name="loginpro_sms_enabled" value="1" <?php checked(get_option('loginpro_sms_enabled',1),1); ?>> بله <input type="radio" name="loginpro_sms_enabled" value="0" <?php checked(get_option('loginpro_sms_enabled',1),0); ?>> خیر</p>
    <p>نام کاربری: <input type="text" name="loginpro_sms_username" value="<?php echo esc_attr(get_option('loginpro_sms_username','')); ?>"></p>
    <p>رمز: <input type="password" name="loginpro_sms_password" value="<?php echo esc_attr(get_option('loginpro_sms_password','')); ?>"></p>
    <?php submit_button(); ?></form></div>
    <?php
}

function loginpro_render_otp() {
    if (class_exists('LoginPro\Admin\OtpSettingsPage')) {
        try {
            $page = new \LoginPro\Admin\OtpSettingsPage();
            if (method_exists($page, 'render')) {
                $page->render();
                return;
            }
        } catch (Exception $e) {}
    }
    ?>
    <div class="wrap"><h1>🔐 تنظیمات OTP</h1><p>صفحه تنظیمات کد یکبارمصرف</p></div>
    <?php
}

function loginpro_render_tickets() { ?><div class="wrap"><h1>🎫 تیکت‌ها</h1><p>در حال بارگذاری...</p></div><?php }
function loginpro_render_messages() { ?><div class="wrap"><h1>📨 پیام‌ها</h1><p>در حال بارگذاری...</p></div><?php }
// ==================================================
// ✅ ثبت شورت‌کدها (با بارگذاری مستقیم)
// ==================================================
add_action('init', 'loginpro_register_shortcodes', 999);

function loginpro_register_shortcodes() {
    // ✅ بارگذاری مستقیم فایل شورت‌کد
    $shortcode_file = LOGINPRO_PLUGIN_DIR . 'frontend/Shortcodes/LoginShortcode.php';
    
    if (file_exists($shortcode_file)) {
        require_once $shortcode_file;
        
        if (class_exists('LoginPro\Frontend\Shortcodes\LoginShortcode')) {
            new \LoginPro\Frontend\Shortcodes\LoginShortcode();
            error_log('[LoginPro] LoginShortcode registered successfully');
        } else {
            error_log('[LoginPro] LoginShortcode class not found');
        }
    } else {
        error_log('[LoginPro] LoginShortcode file not found: ' . $shortcode_file);
    }
    
    // ✅ ثبت شورت‌کدهای دیگر
    // نکته: ProfileShortcode.php دیگر اینجا ثبت نمی‌شود. داشبورد کاربری/تیکت‌ها
    // اکنون فقط توسط custom/custom-functions.php (شورت‌کدهای loginpro_user و
    // loginpro_dashboard) مدیریت می‌شود تا فقط یک پیاده‌سازی فعال وجود داشته باشد.
    $shortcode_files = [
        'RegisterShortcode.php',
        'DashboardShortcode.php',
        'LogoutShortcode.php',
    ];
    
    foreach ($shortcode_files as $file) {
        $path = LOGINPRO_PLUGIN_DIR . 'frontend/Shortcodes/' . $file;
        if (file_exists($path)) {
            require_once $path;
            $class_name = 'LoginPro\\Frontend\\Shortcodes\\' . str_replace('.php', '', $file);
            if (class_exists($class_name)) {
                new $class_name();
                error_log('[LoginPro] ' . $class_name . ' registered');
            }
        }
    }
}
// ==================================================
// ✅ ثبت تنظیمات
// ==================================================
add_action('admin_init', 'loginpro_register_settings');

function loginpro_register_settings() {
    register_setting('loginpro_appearance', 'loginpro_primary_color');
    register_setting('loginpro_appearance', 'loginpro_secondary_color');
    register_setting('loginpro_appearance', 'loginpro_font_family');
    register_setting('loginpro_appearance', 'loginpro_otp_length');
    register_setting('loginpro_pages', 'loginpro_login_page_id');
    register_setting('loginpro_pages', 'loginpro_profile_page_id');
    register_setting('loginpro_sms', 'loginpro_sms_enabled');
    register_setting('loginpro_sms', 'loginpro_sms_username');
    register_setting('loginpro_sms', 'loginpro_sms_password');
}

// ==================================================
// ✅ تعریف ajaxurl در صفحه مدیریت
// ==================================================
add_action('admin_footer', 'loginpro_admin_ajaxurl');

function loginpro_admin_ajaxurl() {
    $screen = get_current_screen();
    if ($screen && strpos($screen->id, 'loginpro') !== false) {
        ?>
        <script>
        if (typeof ajaxurl === 'undefined') {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
        }
        console.log('LoginPro: ajaxurl defined in admin =', ajaxurl);
        </script>
        <?php
    }
}

// ==================================================
// ✅ ثبت مستقیم اکشن تست OTP (admin-ajax)
// ==================================================
add_action('wp_ajax_loginpro_test_otp', 'loginpro_test_otp_direct');
add_action('wp_ajax_nopriv_loginpro_test_otp', 'loginpro_test_otp_direct');

function loginpro_test_otp_direct() {
    $identifier = isset($_POST['identifier']) ? sanitize_text_field($_POST['identifier']) : '';
    
    if (empty($identifier)) {
        wp_send_json_error(['message' => 'شماره موبایل یا ایمیل را وارد کنید']);
        return;
    }
    
    $code = rand(100000, 999999);
    set_transient('loginpro_test_otp_' . md5($identifier), $code, 300);
    
    try {
        if (class_exists('LoginPro\\Modules\\Providers\\Sms\\SmsManager')) {
            $smsManager = \LoginPro\Modules\Providers\Sms\SmsManager::getInstance();
            $result = $smsManager->sendOtp($identifier, $code);
            
            if (is_array($result) && isset($result['success']) && $result['success'] === true) {
                wp_send_json_success([
                    'message' => "✅ کد تست از طریق پیامک به {$identifier} ارسال شد (کد: {$code})"
                ]);
                return;
            }
        }
        
        wp_send_json_success([
            'message' => "✅ کد تست برای شماره {$identifier} تولید شد (کد: {$code})"
        ]);
        
    } catch (Exception $e) {
        wp_send_json_error(['message' => '❌ خطا: ' . $e->getMessage()]);
    }
}

// ==================================================
// ✅ ثبت مسیر REST API برای OTP
// ==================================================
add_action('rest_api_init', function() {
    register_rest_route('loginpro/v1', '/send-otp', [
        'methods' => 'POST',
        'callback' => 'loginpro_rest_send_otp',
        'permission_callback' => '__return_true'
    ]);
});

function loginpro_rest_send_otp($request) {
    $identifier = sanitize_text_field($request->get_param('identifier') ?? '');
    
    if (empty($identifier)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'شماره موبایل یا ایمیل را وارد کنید'
        ], 400);
    }
    
    $code = rand(100000, 999999);
    set_transient('loginpro_test_otp_' . md5($identifier), $code, 300);
    
    try {
        if (class_exists('LoginPro\\Modules\\Providers\\Sms\\SmsManager')) {
            $smsManager = \LoginPro\Modules\Providers\Sms\SmsManager::getInstance();
            $result = $smsManager->sendOtp($identifier, $code);
            
            if (is_array($result) && isset($result['success']) && $result['success'] === true) {
                return new WP_REST_Response([
                    'success' => true,
                    'message' => "✅ کد تست از طریق پیامک به {$identifier} ارسال شد (کد: {$code})"
                ], 200);
            }
        }
    } catch (Exception $e) {}
    
    return new WP_REST_Response([
        'success' => true,
        'message' => "✅ کد تست برای {$identifier} تولید شد (کد: {$code})"
    ], 200);
}
// ==================================================
// ✅ بارگذاری مستقیم اسکریپت در صفحه لاگین
// ==================================================
add_action('wp_footer', 'loginpro_direct_script', 1);

function loginpro_direct_script() {
    // بررسی اینکه در صفحه لاگین هستیم یا نه
    $is_login_page = is_page('login') || is_page('profile') || 
                     (strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false);
    
    // اگر صفحه لاگین نیست و کاربر لاگین نیست، بارگذاری نکن
    if (!$is_login_page && !is_user_logged_in()) {
        return;
    }
    ?>
    <script>
    // ✅ تعریف مستقیم متغیر برای صفحه لاگین
    if (typeof window.loginpro_ajax === 'undefined') {
        window.loginpro_ajax = {
            ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('loginpro_ajax_nonce'); ?>',
            plugin_url: '<?php echo LOGINPRO_PLUGIN_URL; ?>',
            is_login_page: true
        };
        console.log('LoginPro: Direct script loaded', window.loginpro_ajax);
    }
    
    // ✅ بارگذاری دستی فایل JS اگر بارگذاری نشده
    if (typeof window.LoginProFrontend === 'undefined') {
        var script = document.createElement('script');
        script.src = '<?php echo LOGINPRO_PLUGIN_URL . 'assets/js/loginpro.js'; ?>';
        script.type = 'text/javascript';
        script.onload = function() {
            console.log('LoginPro: Script loaded manually');
        };
        document.head.appendChild(script);
    }
    </script>
    <?php
}

// ==================================================
// ✅ END OF FILE
// ==================================================