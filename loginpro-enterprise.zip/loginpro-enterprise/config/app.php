<?php
/**
 * Application Configuration
 * تنظیمات اصلی افزونه
 * 
 * @package LoginPro
 * @version 3.0.16
 */

defined('ABSPATH') || exit;

return [
    // ==================================================
    // ✅ ماژول‌های فعال
    // ==================================================
    'modules' => [
        'Auth' => true,
        'OTP' => true,
        'Security' => true,
        'User' => true,
        'Ticket' => true,
        'Queue' => true,
        'Notification' => true,
        'WooCommerce' => class_exists('WooCommerce'),
        'Providers' => true,
    ],
    
    // ==================================================
    // ✅ قابلیت‌ها
    // ==================================================
    'features' => [
        'modal' => true,
        'ajax' => true,
        'rest_api' => true,
        'cron' => true,
        'cache' => true,
        'logging' => true,
    ],
    
    // ==================================================
    // ✅ تنظیمات امنیتی
    // ==================================================
    'security' => [
        'nonce_lifetime' => 86400, // 24 ساعت
        'rate_limit' => 5,
        'rate_window' => 300, // 5 دقیقه
        'max_otp_attempts' => 3,
        'otp_expiry' => 300, // 5 دقیقه
    ],
    
    // ==================================================
    // ✅ تنظیمات OTP
    // ==================================================
    'otp' => [
        'length' => 6,
        'expiry' => 300,
        'max_attempts' => 3,
        'channels' => ['sms', 'email', 'whatsapp'],
    ],
    
    // ==================================================
    // ✅ تنظیمات دیتابیس
    // ==================================================
    'database' => [
        'prefix' => 'loginpro_',
        'tables' => [
            'otps',
            'sessions',
            'devices',
            'login_history',
            'security_events',
            'tickets',
            'queue_jobs',
            'provider_logs',
            'webauthn_credentials',
            'notifications',
            'messages',
        ],
    ],
    
    // ==================================================
    // ✅ تنظیمات کش
    // ==================================================
    'cache' => [
        'enabled' => true,
        'driver' => 'wordpress', // wordpress, file, redis
        'ttl' => 3600,
        'prefix' => 'loginpro_',
    ],
    
    // ==================================================
    // ✅ تنظیمات لاگ
    // ==================================================
    'logging' => [
        'enabled' => true,
        'driver' => 'database', // database, file
        'level' => 'info', // emergency, alert, critical, error, warning, notice, info, debug
    ],
];