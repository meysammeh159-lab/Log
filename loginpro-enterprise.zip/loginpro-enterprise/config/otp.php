<?php
return [
    'enabled' => true,
    'default_method' => 'auto',
    'length' => 6,
    'ttl' => 300,
    'max_attempts' => 5,
    'resend_cooldown' => 60,
    'types' => [
        'login' => ['ttl' => 300, 'max_attempts' => 3, 'channels' => ['sms', 'email']],
        'register' => ['ttl' => 600, 'max_attempts' => 5, 'channels' => ['email', 'sms']],
        'password_reset' => ['ttl' => 300, 'max_attempts' => 3, 'channels' => ['email', 'sms']],
        'verification' => ['ttl' => 900, 'max_attempts' => 10, 'channels' => ['email', 'sms']],
    ],
];
