<?php
return [
    'bruteforce' => [
        'enabled' => true,
        'max_attempts' => 5,
        'lockout_time' => 900,
        'whitelist' => [],
    ],
    'rate_limit' => [
        'enabled' => true,
        'login' => ['attempts' => 10, 'window' => 60],
        'register' => ['attempts' => 3, 'window' => 3600],
        'reset_password' => ['attempts' => 3, 'window' => 3600],
        'api' => ['attempts' => 60, 'window' => 60],
    ],
    'captcha' => [
        'enabled' => false,
        'provider' => 'recaptcha',
    ],
    'csrf' => [
        'enabled' => true,
        'token_length' => 32,
        'expiry' => 7200,
    ],
    'session' => [
        'lifetime' => 7200,
        'secure' => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ],
    'password' => [
        'min_length' => 8,
        'require_mixed_case' => true,
        'require_numbers' => true,
        'require_symbols' => false,
        'prevent_common' => true,
    ],
];
