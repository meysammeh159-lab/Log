return [
    'sms' => [
        'default' => 'kavenegar',
        'providers' => [
            'kavenegar' => [
                'api_key' => '',
                'sender' => '1000596446'
            ],
            'smsir' => [
                'api_key' => '',
                'line_number' => '',
                'template_id' => '',
                'message_template' => 'کاربر گرامی {NAME}، کد تایید شما: %OTP%'
            ],
            'melipayamak' => [  // ✅ اضافه شده
                'api_key' => '',
                'from' => ''
            ],
            'twilio' => [
                'account_sid' => '',
                'auth_token' => '',
                'from' => ''
            ],
        ],
    ],
    // ...
];