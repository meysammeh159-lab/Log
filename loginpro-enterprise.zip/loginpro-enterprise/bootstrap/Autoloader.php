<?php
namespace LoginPro\Bootstrap;

defined('ABSPATH') || exit;

class Autoloader {
    
    public static function register() {
        spl_autoload_register([__CLASS__, 'autoload']);
    }
    
    public static function autoload($class) {
        $prefix = 'LoginPro\\';
        $base_dir = LOGINPRO_PATH;
        
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }
        
        $relative_class = substr($class, $len);
        $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
        
        // ✅ اگر فایل وجود دارد، آن را بارگذاری کن
        if (file_exists($file)) {
            require $file;
            return true;
        }
        
        // ✅ برای دیباگ
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[Autoloader] File not found: ' . $file);
        }
        
        return false;
    }
}

// ✅ ثبت Autoloader
Autoloader::register();