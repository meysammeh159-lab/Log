<?php
namespace LoginPro\Bootstrap;

defined('ABSPATH') || exit;

/**
 * Simple Dependency Injection Container
 */
class Container
{
    private static $instance = null;
    private $services = [];
    private $instances = [];

    private function __construct() {}

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function set(string $name, $definition): void
    {
        $this->services[$name] = $definition;
        unset($this->instances[$name]);
    }

    public function get(string $name)
    {
        if (!isset($this->services[$name])) {
            return null;
        }

        if (isset($this->instances[$name])) {
            return $this->instances[$name];
        }

        $definition = $this->services[$name];

        if ($definition instanceof \Closure) {
            $instance = $definition($this);
        } elseif (is_string($definition) && class_exists($definition)) {
            $instance = new $definition();
        } else {
            $instance = $definition;
        }

        $this->instances[$name] = $instance;
        return $instance;
    }

    public function has(string $name): bool
    {
        return isset($this->services[$name]);
    }
}