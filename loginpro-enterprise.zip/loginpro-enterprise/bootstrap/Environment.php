<?php
/**
 * Environment configuration for LoginPro Enterprise
 * 
 * @package LoginPro
 * @since 3.0.0
 */

namespace LoginPro\Bootstrap;

defined('ABSPATH') || exit;

class Environment {
    
    private $config = [];
    
    public function __construct() {
        $this->loadConfig();
    }
    
    private function loadConfig(): void {
        $config_file = dirname(__DIR__) . '/config/app.php';
        if (file_exists($config_file)) {
            $config = require $config_file;
            if (is_array($config)) {
                $this->config = $config;
            }
        }
    }
    
    public function get(string $key, $default = null) {
        return $this->config[$key] ?? $default;
    }
    
    public function set(string $key, $value): void {
        $this->config[$key] = $value;
    }
    
    public function getAll(): array {
        return $this->config;
    }
}