<?php

namespace LoginPro\Bootstrap;

abstract class Module
{
    /**
     * Constructor
     */
    public function __construct()
    {
        // می‌توانید کدهای اولیه را اینجا اضافه کنید
        // اگر نیازی نیست، خالی بگذارید
    }

    /**
     * Register the module
     */
    abstract public function register();

    /**
     * Get module name
     *
     * @return string
     */
    public function getName()
    {
        $class = get_class($this);
        $parts = explode('\\', $class);
        return end($parts);
    }

    /**
     * Get module path
     *
     * @return string
     */
    public function getPath()
    {
        $reflection = new \ReflectionClass($this);
        return dirname($reflection->getFileName());
    }

    /**
     * Get module URL
     *
     * @return string
     */
    public function getUrl()
    {
        $path = $this->getPath();
        $plugin_dir = defined('LOGINPRO_PLUGIN_DIR') ? LOGINPRO_PLUGIN_DIR : '';
        
        if (!empty($plugin_dir)) {
            $relative_path = str_replace($plugin_dir, '', $path);
            return defined('LOGINPRO_PLUGIN_URL') ? LOGINPRO_PLUGIN_URL . $relative_path : '';
        }
        
        return '';
    }

    /**
     * Load module views
     *
     * @param string $view
     * @param array $data
     * @return string
     */
    protected function renderView($view, $data = [])
    {
        $view_file = $this->getPath() . '/views/' . $view . '.php';
        
        if (!file_exists($view_file)) {
            return '';
        }
        
        extract($data, EXTR_SKIP);
        ob_start();
        include $view_file;
        return ob_get_clean();
    }

    /**
     * Load module assets
     *
     * @param string $type
     * @param string $file
     * @return string
     */
    protected function getAssetUrl($type, $file)
    {
        return $this->getUrl() . '/assets/' . $type . '/' . $file;
    }

    /**
     * Get module configuration
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    protected function getConfig($key, $default = null)
    {
        $config_file = $this->getPath() . '/config/config.php';
        
        if (!file_exists($config_file)) {
            return $default;
        }
        
        $config = include $config_file;
        
        if (!is_array($config)) {
            return $default;
        }
        
        if (strpos($key, '.') !== false) {
            $keys = explode('.', $key);
            $value = $config;
            
            foreach ($keys as $k) {
                if (!isset($value[$k])) {
                    return $default;
                }
                $value = $value[$k];
            }
            
            return $value;
        }
        
        return isset($config[$key]) ? $config[$key] : $default;
    }
}