<?php
namespace LoginPro\Bootstrap;

defined('ABSPATH') || exit;

/**
 * Bootstrap - قلب سیستم
 */
class Bootstrap
{
    /**
     * @var self نمونه Singleton
     */
    private static $instance = null;

    /**
     * @var Container دی‌آی کانتینر
     */
    private $container;

    /**
     * Singleton Pattern
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor خصوصی
     */
    private function __construct()
    {
        $this->container = Container::getInstance();
    }

    /**
     * بوت‌استرپ اصلی
     */
    public function boot(): void
    {
        // ==================================================
        // ۱. بارگذاری ماژول‌ها
        // ==================================================
        add_action('plugins_loaded', function () {
            $this->loadModules();
        });

        // ==================================================
        // ۲. ثبت هوک‌های AJAX (در زمان Init)
        // ==================================================
        add_action('init', function () {
            $this->registerAjaxHooks();
            $this->registerOtpAjaxHooks();
        });

        // ==================================================
        // ۳. ثبت Assets
        // ==================================================
        add_action('wp_enqueue_scripts', function () {
            $this->enqueueAssets();
        });

        // ==================================================
        // ۴. ثبت شورت‌کدها
        // ==================================================
        add_action('init', function () {
            if (class_exists('LoginPro\\Frontend\\Shortcodes\\LoginShortcode')) {
                new \LoginPro\Frontend\Shortcodes\LoginShortcode();
            }
        });

        // ==================================================
        // ۵. بارگذاری Text Domain
        // ==================================================
        add_action('plugins_loaded', function () {
            load_plugin_textdomain('loginpro', false, dirname(plugin_basename(LOGINPRO_PATH)) . '/languages');
        });
    }

    /**
     * بارگذاری ماژول‌ها
     */
    private function loadModules(): void
    {
        $modules = [
            'OTP'       => LOGINPRO_PATH . 'modules/OTP/Module.php',
            'Auth'      => LOGINPRO_PATH . 'modules/Auth/Module.php',
            'Providers' => LOGINPRO_PATH . 'modules/Providers/Module.php',
            'User'      => LOGINPRO_PATH . 'modules/User/Module.php',
            'Security'  => LOGINPRO_PATH . 'modules/Security/Module.php',
        ];

        foreach ($modules as $name => $file) {
            if (file_exists($file)) {
                require_once $file;
                $className = 'LoginPro\\Modules\\' . $name . '\\Module';
                if (class_exists($className)) {
                    $module = new $className();
                    if (method_exists($module, 'init')) {
                        $module->init();
                    }
                }
            }
        }
    }

    /**
     * ثبت هوک‌های AJAX اصلی
     */
    private function registerAjaxHooks(): void
    {
        // بررسی وجود کنترلر Login
        if (!class_exists('LoginPro\\Modules\\Auth\\Controllers\\LoginController')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[LoginPro] LoginController not found');
            }
            return;
        }

        $controller = new \LoginPro\Modules\Auth\Controllers\LoginController();

        // هوک‌های AJAX
        add_action('wp_ajax_loginpro_login', [$controller, 'handleLogin']);
        add_action('wp_ajax_nopriv_loginpro_login', [$controller, 'handleLogin']);

        add_action('wp_ajax_loginpro_register', [$controller, 'handleRegister']);
        add_action('wp_ajax_nopriv_loginpro_register', [$controller, 'handleRegister']);

        add_action('wp_ajax_loginpro_reset_password', [$controller, 'handleResetPassword']);
        add_action('wp_ajax_nopriv_loginpro_reset_password', [$controller, 'handleResetPassword']);
    }

    /**
     * ثبت هوک‌های AJAX برای OTP
     */
    private function registerOtpAjaxHooks(): void
    {
        // بررسی وجود کنترلر OTP
        if (!class_exists('LoginPro\\Modules\\Auth\\Controllers\\OtpController')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[LoginPro] OtpController not found');
            }
            return;
        }

        $controller = new \LoginPro\Modules\Auth\Controllers\OtpController();

        // ============================================
        // درخواست ارسال کد OTP
        // ============================================
        add_action('wp_ajax_loginpro_request_otp', function() use ($controller) {
            // بررسی Nonce در کنترلر انجام می‌شود
            $controller->requestOtp();
        });
        
        add_action('wp_ajax_nopriv_loginpro_request_otp', function() use ($controller) {
            $controller->requestOtp();
        });

        // ============================================
        // تأیید کد OTP
        // ============================================
        add_action('wp_ajax_loginpro_verify_otp', function() use ($controller) {
            $controller->verifyOtp();
        });
        
        add_action('wp_ajax_nopriv_loginpro_verify_otp', function() use ($controller) {
            $controller->verifyOtp();
        });

        // ============================================
        // ارسال مجدد کد OTP
        // ============================================
        add_action('wp_ajax_loginpro_resend_otp', function() use ($controller) {
            $controller->resendOtp();
        });
        
        add_action('wp_ajax_nopriv_loginpro_resend_otp', function() use ($controller) {
            $controller->resendOtp();
        });

        // ============================================
        // تست OTP (برای ادمین)
        // ============================================
        add_action('wp_ajax_loginpro_test_otp', function() {
            $this->handleTestOtp();
        });

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LoginPro] OTP Ajax hooks registered');
        }
    }

    /**
     * هندلر تست OTP
     */
    private function handleTestOtp(): void
    {
        // بررسی دسترسی ادمین
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'دسترسی غیرمجاز']);
        }

        // بررسی Nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_admin')) {
            wp_send_json_error(['message' => 'خطای امنیتی']);
        }

        $identifier = $_POST['identifier'] ?? '';
        if (empty($identifier)) {
            wp_send_json_error(['message' => 'شناسه را وارد کنید']);
        }

        try {
            $otpService = new \LoginPro\Modules\OTP\Services\OtpService();
            $dispatcher = new \LoginPro\Modules\OTP\Services\OtpDispatcherService();

            // تولید کد
            $otpData = $otpService->generateForMobile($identifier);
            if ($otpData === false) {
                wp_send_json_error(['message' => 'خطا در تولید کد']);
            }

            // ارسال
            $sent = $dispatcher->sendViaSms($identifier, $otpData['code'], 'test');

            if ($sent) {
                wp_send_json_success([
                    'message' => 'کد تست با موفقیت ارسال شد',
                    'code' => $otpData['code'],
                    'token' => $otpData['session_token']
                ]);
            } else {
                wp_send_json_error(['message' => 'خطا در ارسال کد تست']);
            }

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    /**
     * بارگذاری Assets
     */
    private function enqueueAssets(): void
    {
        // فقط در صفحات مورد نیاز
        if (!is_singular()) {
            return;
        }

        global $post;
        if (!isset($post) || !has_shortcode($post->post_content, 'loginpro_login')) {
            return;
        }

        // JS
        $jsFile = LOGINPRO_PATH . 'frontend/Assets/js/frontend.js';
        if (file_exists($jsFile)) {
            wp_enqueue_script(
                'loginpro-frontend',
                LOGINPRO_URL . 'frontend/Assets/js/frontend.js',
                ['jquery'],
                filemtime($jsFile),
                true
            );

            wp_localize_script('loginpro-frontend', 'loginproConfig', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('loginpro_nonce'),
                'isLoggedIn' => is_user_logged_in(),
                'debug' => defined('WP_DEBUG') && WP_DEBUG,
            ]);
        }
    }

    /**
     * دریافت کانتینر
     */
    public function getContainer(): Container
    {
        return $this->container;
    }
}