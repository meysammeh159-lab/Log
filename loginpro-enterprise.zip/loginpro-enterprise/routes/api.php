<?php
use LoginPro\Core\Http\Router;

Router::post('v1/auth/login', [\LoginPro\API\Controllers\AuthController::class, 'login']);
Router::post('v1/auth/register', [\LoginPro\API\Controllers\AuthController::class, 'register']);
Router::post('v1/auth/logout', [\LoginPro\API\Controllers\AuthController::class, 'logout']);
Router::get('v1/user/profile', [\LoginPro\API\Controllers\UserController::class, 'profile']);
Router::post('v1/user/profile', [\LoginPro\API\Controllers\UserController::class, 'updateProfile']);
Router::post('v1/otp/send', [\LoginPro\API\Controllers\OtpController::class, 'send']);
Router::post('v1/otp/verify', [\LoginPro\API\Controllers\OtpController::class, 'verify']);
