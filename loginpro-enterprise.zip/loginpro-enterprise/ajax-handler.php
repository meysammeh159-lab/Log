<?php
/**
 * LoginPro AJAX Handlers
 *
 * @package LoginPro
 * @version 3.1.0
 *
 * =====================================================================
 * ✅ اصلاح باگ: «ارسال/دریافت کد OTP در صفحه ورود کاربر کار نمی‌کند»
 * =====================================================================
 * علت باگ:
 * این فایل، در همان لحظه‌ی لود شدن پلاگین (خیلی زودتر از هوک init)،
 * برای اکشن‌های loginpro_check_identifier، loginpro_verify_otp،
 * loginpro_resend_otp، loginpro_login_password، loginpro_complete_profile،
 * loginpro_reset_password و loginpro_get_modal_form یک هندلر دومِ ناقص
 * ثبت می‌کرد؛ درحالی‌که هندلرهای واقعی و کامل همین اکشن‌ها (که کد را
 * تولید و واقعاً پیامک را ارسال می‌کنند) در loginpro.php روی هوک init
 * ثبت می‌شوند.
 *
 * چون هندلر این فایل زودتر ثبت و زودتر اجرا می‌شد، و توابع
 * loginpro_ajax_success()/loginpro_ajax_error() درونشان
 * wp_send_json_success()/wp_send_json_error() را صدا می‌زنند که خودشان
 * wp_die() را هم فرا می‌خوانند، درخواست همان‌جا قطع می‌شد و هندلر واقعی
 * (OtpController/LoginController) هرگز اجرا نمی‌شد؛ برای همین در صفحه‌ی
 * ورود، پیامک OTP واقعی هیچ‌وقت ارسال نمی‌شد، هرچند پاسخ ظاهراً موفق
 * برمی‌گشت. برای اکشن‌های resend_otp / login_password / complete_profile /
 * reset_password / get_modal_form هم چون تابع مقصدشان اصلاً در این فایل
 * تعریف نشده بود، نتیجه یک خطای Fatal از نوع
 * «Call to undefined function» بود.
 *
 * راه‌حل:
 * ثبت این اکشن‌های تکراری/ناقص از این فایل حذف شد تا هندلرهای واقعی که
 * از قبل به‌درستی در loginpro.php وجود دارند اجرا شوند. هیچ قابلیتی حذف
 * نشد، چون این نسخه‌ها یا اصلاً کار نمی‌کردند یا کاری جز شبیه‌سازی
 * (بدون ارسال پیامک واقعی) انجام نمی‌دادند. تنها اکشن test_sms که کامل
 * و صحیح بود، بدون هیچ تغییری باقی ماند. فیلتر loginpro_verify_nonce
 * (که در نسخه‌ی قبلی همیشه true برمی‌گرداند) هم چون در جای دیگری از
 * پلاگین استفاده نمی‌شد، به‌عنوان کد مرده حذف شد.
 * =====================================================================
 */

defined('ABSPATH') || exit;

// پاک کردن بافر خروجی (جلوگیری از آلوده شدن پاسخ JSON با خروجی اضافه)
ob_start();

/**
 * =========================================================
 * Register AJAX Actions
 * =========================================================
 * فقط test_sms (ابزار تست دستیِ ادمین) در همین فایل مدیریت می‌شود.
 * اکشن‌های OTP و ورود/ثبت‌نام (check_identifier، verify_otp، resend_otp،
 * login_password، complete_profile، reset_password، get_modal_form)
 * دیگر اینجا ثبت نمی‌شوند و توسط کنترلرهای واقعی
 * (OtpController::handleCheckIdentifier/handleVerifyOtp/handleResendOtp,
 * LoginController::handleLogin/handleRegister/handleResetPassword,
 * ProfileController::handleCompleteProfile)
 * که در loginpro.php روی هوک init ثبت می‌شوند، مدیریت می‌شوند.
 */

add_action('wp_ajax_loginpro_test_sms', 'loginpro_ajax_test_sms');
add_action('wp_ajax_nopriv_loginpro_test_sms', 'loginpro_ajax_test_sms');

/**
 * =========================================================
 * Helpers
 * =========================================================
 */

function loginpro_ajax_error(string $message)
{
    // پاک کردن بافر قبل از خروجی
    while (ob_get_level()) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('Content-Type: application/json');
    }
    wp_send_json_error(['message' => $message]);
}

function loginpro_ajax_success(array $data = [])
{
    // پاک کردن بافر قبل از خروجی
    while (ob_get_level()) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('Content-Type: application/json');
    }
    wp_send_json_success($data);
}

function loginpro_get_identifier(): string
{
    if (!empty($_POST['identifier'])) {
        return sanitize_text_field(wp_unslash($_POST['identifier']));
    }
    if (!empty($_POST['mobile'])) {
        return sanitize_text_field(wp_unslash($_POST['mobile']));
    }
    if (!empty($_POST['email'])) {
        return sanitize_email(wp_unslash($_POST['email']));
    }
    return '';
}

/**
 * =========================================================
 * Test SMS  (بدون هیچ تغییری نسبت به نسخه‌ی قبلی)
 * =========================================================
 */

function loginpro_ajax_test_sms()
{
    try {
        if (!current_user_can('manage_options')) {
            loginpro_ajax_error('دسترسی غیرمجاز.');
            return;
        }

        $mobile = loginpro_get_identifier();

        if (!$mobile) {
            loginpro_ajax_error('شماره موبایل وارد نشده.');
            return;
        }

        // بررسی وجود SmsManager
        if (!class_exists('\LoginPro\Modules\Providers\Sms\SmsManager')) {
            loginpro_ajax_error('سیستم پیامک فعال نیست.');
            return;
        }

        $sms = \LoginPro\Modules\Providers\Sms\SmsManager::getInstance();
        $result = $sms->sendOtp($mobile, random_int(100000, 999999));

        if ($result === true) {
            loginpro_ajax_success(['message' => 'پیامک ارسال شد.']);
            return;
        }

        if (is_array($result) && !empty($result['success'])) {
            loginpro_ajax_success(['message' => $result['message']]);
            return;
        }

        loginpro_ajax_error($result['message'] ?? 'خطا در ارسال پیامک.');

    } catch (Throwable $e) {
        error_log('LoginPro SMS Error: ' . $e->getMessage());
        loginpro_ajax_error('خطا در ارسال پیامک.');
    }
}

// آزادسازی بافر خروجی
ob_end_flush();
