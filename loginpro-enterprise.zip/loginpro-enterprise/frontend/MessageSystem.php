<?php
namespace LoginPro\Frontend;

defined('ABSPATH') || exit;

class MessageSystem
{
    private $messages_table;
    private $conversations_table;
    private $nonce_action = 'loginpro_message';
    
    public function __construct()
    {
        global $wpdb;
        $this->messages_table = $wpdb->prefix . 'loginpro_messages';
        $this->conversations_table = $wpdb->prefix . 'loginpro_conversations';
        
        $this->create_tables_if_not_exist();
        
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_loginpro_get_messages', [$this, 'ajax_get_messages']);
        add_action('wp_ajax_loginpro_mark_as_read', [$this, 'ajax_mark_as_read']);
        add_action('wp_ajax_loginpro_get_unread_count', [$this, 'ajax_get_unread_count']);
    }
    
    public function enqueue_scripts()
    {
        if (!is_user_logged_in()) {
            return;
        }
        
        wp_enqueue_script('jquery');
        
        $ajax_url = admin_url('admin-ajax.php');
        
        wp_localize_script('jquery', 'loginpro_message_ajax', [
            'ajax_url' => $ajax_url,
            'nonce' => wp_create_nonce($this->nonce_action),
            'user_id' => get_current_user_id()
        ]);
    }
    
    private function create_tables_if_not_exist()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql_conversations = "CREATE TABLE IF NOT EXISTS {$this->conversations_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user1_id bigint(20) NOT NULL,
            user2_id bigint(20) NOT NULL,
            last_message_id bigint(20) DEFAULT NULL,
            user1_unread_count int(11) DEFAULT 0,
            user2_unread_count int(11) DEFAULT 0,
            user1_deleted tinyint(1) DEFAULT 0,
            user2_deleted tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY conversation (user1_id, user2_id)
        ) {$charset_collate};";
        
        $sql_messages = "CREATE TABLE IF NOT EXISTS {$this->messages_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            conversation_id bigint(20) NOT NULL,
            sender_id bigint(20) NOT NULL,
            receiver_id bigint(20) NOT NULL,
            message text NOT NULL,
            is_read tinyint(1) DEFAULT 0,
            read_at datetime DEFAULT NULL,
            is_admin_message tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY conversation_id (conversation_id),
            KEY sender_id (sender_id),
            KEY receiver_id (receiver_id)
        ) {$charset_collate};";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_conversations);
        dbDelta($sql_messages);
    }
    
    public function render_message_page()
    {
        if (!is_user_logged_in()) {
            return '<p>' . sprintf(
                __('Please <a href="%s">login</a> to view messages.', 'loginpro'),
                esc_url(wp_login_url(get_permalink()))
            ) . '</p>';
        }
        
        ob_start();
        ?>
        <div class="loginpro-message-system">
            <div class="message-container">
                <div class="message-window" style="width:100%;">
                    <div class="message-header">
                        <div class="conversation-info">
                            <span class="user-avatar">📨</span>
                            <span class="user-name"><?php esc_html_e('پیام ها', 'loginpro'); ?></span>
                        </div>
                        <div class="message-actions">
                            <button class="refresh-btn" id="refreshMessagesBtn"><?php esc_html_e('بارگیری پیام ها', 'loginpro'); ?></button>
                        </div>
                    </div>
                    
                    <div class="messages-container" id="messages-container">
                        <div class="loading"><?php esc_html_e('در حال بارگیری پیام ها...', 'loginpro'); ?></div>
                    </div>
                    
<div class="message-input-area" style="background:#f5f5f5;">
    <div style="width:100%;text-align:center;padding:10px;color:#999;font-size:13px;">
        <?php printf(
            __('این بخش برای دریافت پیام‌های مدیریت است. برای پشتیبانی، لطفاً از بخش <strong>تیکت‌ها</strong> استفاده کنید.', 'loginpro'),
            '<strong>' . esc_html__('تیکت‌ها', 'loginpro') . '</strong>'
        ); ?>
    </div>
</div>
        
        <style>
            .loginpro-message-system {
                max-width: 800px;
                margin: 30px auto;
                background: #fff;
                border-radius: 16px;
                box-shadow: 0 5px 20px rgba(0,0,0,0.08);
                overflow: hidden;
                direction: rtl;
                text-align: right;
            }
            .message-container {
                display: flex;
                min-height: 500px;
            }
            .message-window {
                flex: 1;
                display: flex;
                flex-direction: column;
                background: #fff;
                width: 100%;
            }
            .message-header {
                padding: 15px 25px;
                border-bottom: 1px solid #eee;
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: #f8f9fa;
            }
            .message-header .conversation-info {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .message-header .user-avatar {
                font-size: 28px;
            }
            .message-header .user-name {
                font-weight: 600;
                font-size: 16px;
                color: #333;
            }
            .refresh-btn {
                background: #0d6efd;
                color: #fff;
                border: none;
                padding: 8px 20px;
                border-radius: 8px;
                cursor: pointer;
                font-size: 14px;
                transition: all 0.2s;
            }
            .refresh-btn:hover {
                background: #0b5ed7;
            }
            
            .messages-container {
                flex: 1;
                overflow-y: auto;
                padding: 25px;
                background: #fafafa;
                min-height: 350px;
                max-height: 450px;
            }
            
            .message-item {
                margin-bottom: 20px;
                display: flex;
                flex-direction: column;
                max-width: 85%;
            }
            .message-item.received {
                align-items: flex-start;
                margin-left: 0;
            }
            .message-item .message-sender {
                font-size: 13px;
                color: #6c757d;
                margin-bottom: 5px;
                font-weight: 500;
            }
            .message-item .message-sender .admin-badge {
                background: #0d6efd;
                color: #fff;
                padding: 1px 10px;
                border-radius: 12px;
                font-size: 11px;
                margin-right: 8px;
            }
            .message-bubble {
                padding: 12px 18px;
                border-radius: 12px;
                word-wrap: break-word;
                max-width: 100%;
                line-height: 1.8;
                font-size: 14px;
                background: #e9ecef;
                color: #333;
                border-bottom-right-radius: 4px;
                position: relative;
            }
            .message-bubble.admin-message {
                background: #cfe2ff;
                border-right: 4px solid #0d6efd;
            }
            .message-item .message-time {
                font-size: 11px;
                color: #adb5bd;
                margin-top: 6px;
            }
            .message-item.received .message-time {
                text-align: right;
            }
            
            .message-item .message-status {
                font-size: 11px;
                color: #6c757d;
                margin-top: 4px;
            }
            .message-item .message-status.read {
                color: #28a745;
            }
            .message-item .message-status.unread {
                color: #dc3545;
                font-weight: 500;
            }
            
            .message-input-area {
                padding: 15px 25px;
                border-top: 1px solid #eee;
                background: #f8f9fa;
            }
            
            .loading {
                text-align: center;
                padding: 40px;
                color: #6c757d;
            }
            .loading:before {
                content: "⏳";
                display: block;
                font-size: 32px;
                margin-bottom: 10px;
            }
            
            .no-messages {
                text-align: center;
                padding: 60px 20px;
                color: #6c757d;
            }
            .no-messages .empty-icon {
                font-size: 48px;
                display: block;
                margin-bottom: 15px;
            }
            .no-messages h3 {
                margin: 0 0 10px 0;
                color: #333;
                font-size: 18px;
            }
            .no-messages p {
                margin: 0;
                font-size: 14px;
            }
            
            .message-divider {
                text-align: center;
                padding: 15px 0;
                color: #adb5bd;
                font-size: 12px;
                position: relative;
            }
            .message-divider:before {
                content: "";
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                height: 1px;
                background: #e9ecef;
            }
            .message-divider span {
                background: #fafafa;
                padding: 0 15px;
                position: relative;
                z-index: 1;
            }
            
            @media (max-width: 768px) {
                .loginpro-message-system { margin: 15px; border-radius: 12px; }
                .message-container { min-height: 400px; }
                .messages-container { padding: 15px; min-height: 250px; max-height: 350px; }
                .message-item { max-width: 95%; }
                .message-header { padding: 12px 15px; }
                .message-header .user-name { font-size: 14px; }
                .message-bubble { font-size: 13px; padding: 10px 14px; }
            }
        </style>
        
        <script>
        (function() {
            'use strict';
            
            var ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
            var nonce = '<?php echo wp_create_nonce($this->nonce_action); ?>';
            var currentUserId = <?php echo get_current_user_id(); ?>;
            
            function loadMessages() {
                var container = document.getElementById('messages-container');
                if (!container) {
                    return;
                }
                container.innerHTML = '<div class="loading"><?php echo esc_js(__('در حال بارگیری پیام ها...', 'loginpro')); ?></div>';
                
                var formData = new FormData();
                formData.append('action', 'loginpro_get_messages');
                formData.append('_nonce', nonce);
                
                fetch(ajaxUrl, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('HTTP error: ' + response.status);
                    }
                    return response.json();
                })
                .then(function(data) {
                    if (data.success && data.data.messages) {
                        if (data.data.messages.length === 0) {
                            container.innerHTML = `
                                <div class="no-messages">
                                    <span class="empty-icon">📭</span>
                                    <h3><?php echo esc_js(__('پیامی وجود ندارد', 'loginpro')); ?></h3>
                                    <p><?php echo esc_js(__('هنوز پیامی از مدیریت دریافت نکرده‌اید.', 'loginpro')); ?></p>
                                </div>
                            `;
                        } else {
                            var html = '';
                            var lastDate = '';
                            data.data.messages.forEach(function(msg) {
                                var msgDate = msg.time.split(' ')[0];
                                if (msgDate !== lastDate) {
                                    if (lastDate !== '') {
                                        html += '</div>';
                                    }
                                    html += '<div class="message-divider"><span>' + msgDate + '</span></div>';
                                    lastDate = msgDate;
                                }
                                
                                var isAdmin = msg.is_admin_message == 1;
                                var senderName = isAdmin ? '<?php echo esc_js(__('مدیریت', 'loginpro')); ?>' : msg.sender_name;
                                var adminBadge = isAdmin ? '<span class="admin-badge"><?php echo esc_js(__('مدیریت', 'loginpro')); ?></span>' : '';
                                var statusClass = msg.is_read ? 'read' : 'unread';
                                var statusText = msg.is_read ? '<?php echo esc_js(__('خوانده شده', 'loginpro')); ?>' : '<?php echo esc_js(__('جدید', 'loginpro')); ?>';
                                
                                html += '<div class="message-item received">';
                                html += '<div class="message-sender">' + senderName + ' ' + adminBadge + '</div>';
                                html += '<div class="message-bubble ' + (isAdmin ? 'admin-message' : '') + '">';
                                html += msg.message;
                                html += '</div>';
                                html += '<div class="message-time">' + msg.time + ' <span class="message-status ' + statusClass + '">' + statusText + '</span></div>';
                                html += '</div>';
                            });
                            container.innerHTML = html;
                            container.scrollTop = container.scrollHeight;
                        }
                    } else {
                        container.innerHTML = '<div class="no-messages"><span class="empty-icon">❌</span><h3><?php echo esc_js(__('خطا', 'loginpro')); ?></h3><p>' + (data.data.message || '<?php echo esc_js(__('بارگیری پیام‌ها با مشکل مواجه شد.', 'loginpro')); ?>') + '</p></div>';
                    }
                })
                .catch(function(error) {
                    console.error('Error:', error);
                    container.innerHTML = '<div class="no-messages"><span class="empty-icon">❌</span><h3><?php echo esc_js(__('خطا در ارتباط', 'loginpro')); ?></h3><p><?php echo esc_js(__('لطفاً صفحه را بازخوانی کنید.', 'loginpro')); ?></p></div>';
                });
                
                markAsRead();
            }
            
            function markAsRead() {
                var formData = new FormData();
                formData.append('action', 'loginpro_mark_as_read');
                formData.append('_nonce', nonce);
                
                fetch(ajaxUrl, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                }).catch(function() {});
            }
            
            // Add event listener to refresh button
            document.addEventListener('DOMContentLoaded', function() {
                loadMessages();
                
                var refreshBtn = document.getElementById('refreshMessagesBtn');
                if (refreshBtn) {
                    refreshBtn.addEventListener('click', loadMessages);
                }
                
                // Auto refresh every 30 seconds
                setInterval(loadMessages, 30000);
            });
            
            // Store loadMessages in window for debugging
            window.loadMessages = loadMessages;
            
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    // ===== AJAX Methods =====
    
    public function ajax_get_messages()
    {
        if (function_exists('loginpro_force_disable_persian')) {
            loginpro_force_disable_persian();
        }
        
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], $this->nonce_action)) {
            wp_send_json_error(['message' => __('Security error', 'loginpro')]);
            return;
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('You are not logged in', 'loginpro')]);
            return;
        }
        
        global $wpdb;
        $user_id = get_current_user_id();
        
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT m.*, u.display_name as sender_name 
            FROM {$this->messages_table} m
            LEFT JOIN {$wpdb->users} u ON m.sender_id = u.ID
            WHERE m.receiver_id = %d 
            ORDER BY m.created_at DESC",
            $user_id
        ));
        
        $formatted_messages = [];
        foreach ($messages as $msg) {
            $formatted_messages[] = [
                'id' => $msg->id,
                'sender_id' => $msg->sender_id,
                'sender_name' => $msg->sender_name,
                'message' => nl2br(esc_html($msg->message)),
                'time' => date_i18n('j F Y ' . __('ساعت', 'loginpro') . ' H:i', strtotime($msg->created_at)),
                'is_read' => $msg->is_read,
                'is_admin_message' => $msg->is_admin_message
            ];
        }
        
        wp_send_json_success(['messages' => $formatted_messages]);
    }
    
    public function ajax_mark_as_read()
    {
        if (function_exists('loginpro_force_disable_persian')) {
            loginpro_force_disable_persian();
        }
        
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], $this->nonce_action)) {
            wp_send_json_error(['message' => __('Security error', 'loginpro')]);
            return;
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('You are not logged in', 'loginpro')]);
            return;
        }
        
        global $wpdb;
        $user_id = get_current_user_id();
        
        $wpdb->query($wpdb->prepare(
            "UPDATE {$this->messages_table} SET is_read = 1, read_at = %s 
            WHERE receiver_id = %d AND is_read = 0",
            current_time('mysql'), $user_id
        ));
        
        wp_send_json_success(['message' => __('Marked as read', 'loginpro')]);
    }
    
    public function ajax_get_unread_count()
    {
        if (function_exists('loginpro_force_disable_persian')) {
            loginpro_force_disable_persian();
        }
        
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], $this->nonce_action)) {
            wp_send_json_error(['message' => __('Security error', 'loginpro')]);
            return;
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('You are not logged in', 'loginpro')]);
            return;
        }
        
        global $wpdb;
        $user_id = get_current_user_id();
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->messages_table} 
            WHERE receiver_id = %d AND is_read = 0",
            $user_id
        ));
        
        wp_send_json_success(['unread_count' => intval($count)]);
    }
}