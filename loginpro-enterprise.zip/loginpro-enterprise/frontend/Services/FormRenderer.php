<?php
namespace LoginPro\Frontend\Services;

defined('ABSPATH') || exit;

class FormRenderer
{
    public function renderLoggedInMessage($user): string
    {
        ob_start();
        ?>
        <div class="loginpro-loggedin-message" style="text-align:center;padding:30px;background:#fff;border-radius:16px;">
            <h3>شما وارد شده اید</h3>
            <p>خوش آمدید <?php echo esc_html($user->display_name); ?></p>
            <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" 
               style="background:#ef394e;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;">
               خروج
            </a>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function renderLoginForm(array $options): string
    {
        ob_start();
        // ... HTML فرم (از کد اصلی اما با esc_attr مناسب)
        // این بخش طولانی است، می‌توانیم آن را به template فایل جدا منتقل کنیم
        ?>
        <div class="loginpro-form-container" 
             data-primary-color="<?php echo esc_attr($options['primary_color']); ?>"
             data-nonce="<?php echo esc_attr(wp_create_nonce('loginpro_ajax')); ?>"
             data-ajax-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
             
            <!-- HTML فرم از کد اصلی با اصلاحات امنیتی -->
            
        </div>
        <?php
        return ob_get_clean();
    }
}