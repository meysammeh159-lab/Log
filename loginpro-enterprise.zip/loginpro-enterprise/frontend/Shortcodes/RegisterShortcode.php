<?php
namespace LoginPro\Frontend\Shortcodes;

class RegisterShortcode {
    
    public static function render($atts) {
        if (is_user_logged_in()) {
            return '<div class="loginpro-logged-in">You are already registered and logged in.</div>';
        }
        
        ob_start();
        ?>
        <div class="loginpro-form-container">
            <form id="loginpro-register-form" method="post" action="<?php echo admin_url('admin-ajax.php'); ?>">
                <input type="hidden" name="action" value="loginpro_ajax_register">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('loginpro_ajax'); ?>">
                <div class="loginpro-row">
                    <div class="loginpro-col"><input type="text" name="first_name" placeholder="First Name"></div>
                    <div class="loginpro-col"><input type="text" name="last_name" placeholder="Last Name"></div>
                </div>
                <div class="loginpro-form-group">
                    <input type="text" name="username" placeholder="Username" required>
                </div>
                <div class="loginpro-form-group">
                    <input type="email" name="email" placeholder="Email Address" required>
                </div>
                <div class="loginpro-form-group">
                    <input type="tel" name="mobile" placeholder="Mobile Number" required>
                </div>
                <div class="loginpro-form-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <div class="loginpro-form-group">
                    <input type="password" name="password_confirmation" placeholder="Confirm Password" required>
                </div>
                <button type="submit" class="loginpro-btn">Register</button>
                <div class="loginpro-links">
                    <a href="<?php echo home_url('/login'); ?>">Already have an account? Login</a>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
}
