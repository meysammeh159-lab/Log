<?php
namespace LoginPro\Frontend\Shortcodes;

use LoginPro\Core\Helpers\I18n;

class LanguageSelectorShortcode {
    
    /**
     * رندر صفحه انتخاب زبان و کشور
     */
    public function render($atts = []) {
        $atts = shortcode_atts([
            'redirect' => home_url(),
            'show_country' => 'yes',
            'show_language' => 'yes',
            'show_currency' => 'yes',
        ], $atts);
        
        // اگر کاربر وارد نشده، به صفحه ورود هدایت شود
        if (!is_user_logged_in()) {
            wp_safe_redirect(wp_login_url(get_permalink()));
            exit;
        }
        
        $user_id = get_current_user_id();
        
        // بررسی اینکه آیا کاربر قبلاً تنظیمات را ذخیره کرده است
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_user_settings';
        $settings = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE user_id = %d",
                $user_id
            )
        );
        
        // اگر قبلاً تنظیمات را ذخیره کرده و صفحه انتخاب نیست، redirect
        if ($settings && $settings->is_first_login == 0 && !isset($_GET['force'])) {
            wp_safe_redirect($atts['redirect']);
            exit;
        }
        
        // دریافت تنظیمات فعلی
        $current_country = $settings ? $settings->country_code : 'IR';
        $current_language = $settings ? $settings->language : 'fa_IR';
        $current_currency = $settings ? $settings->currency : 'IRR';
        
        $countries = I18n::get_countries_list();
        $languages = [
            'en_US' => 'English',
            'fa_IR' => 'فارسی',
            'ar_SA' => 'العربية',
            'tr_TR' => 'Türkçe',
            'ru_RU' => 'Русский',
            'es_ES' => 'Español',
            'fr_FR' => 'Français',
            'de_DE' => 'Deutsch',
            'zh_CN' => '中文',
        ];
        
        $currencies = I18n::get_currency_symbols();
        $country_codes = I18n::get_country_codes();
        
        ob_start();
        ?>
        <div class="loginpro-language-selector-container" style="max-width:600px;margin:50px auto;padding:40px;background:#fff;border-radius:24px;box-shadow:0 10px 40px rgba(0,0,0,0.1);">
            <div style="text-align:center;margin-bottom:30px;">
                <h2 style="color:#1a1a1a;font-size:24px;margin-bottom:10px;">
                    🌍 <?php _e('تنظیمات زبان و کشور', 'loginpro'); ?>
                </h2>
                <p style="color:#6c757d;font-size:14px;">
                    <?php _e('لطفاً زبان، کشور و واحد پول خود را انتخاب کنید', 'loginpro'); ?>
                </p>
            </div>
            
            <div id="loginpro-language-message" style="display:none;padding:12px 16px;border-radius:12px;margin-bottom:20px;"></div>
            
            <form id="loginpro-language-form" method="post">
                <?php wp_nonce_field('loginpro_save_settings', 'loginpro_settings_nonce'); ?>
                
                <!-- انتخاب زبان -->
                <?php if ($atts['show_language'] === 'yes'): ?>
                <div class="loginpro-form-group" style="margin-bottom:20px;">
                    <label style="display:block;font-weight:600;margin-bottom:8px;color:#333;">
                        🗣️ <?php _e('زبان', 'loginpro'); ?>
                    </label>
                    <select name="language" id="loginpro-language" style="width:100%;height:48px;padding:0 15px;border:2px solid #e0e0e0;border-radius:12px;font-size:15px;">
                        <?php foreach ($languages as $code => $name): ?>
                            <option value="<?php echo esc_attr($code); ?>" 
                                <?php selected($code, $current_language); ?>>
                                <?php echo esc_html($name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size:12px;color:#adb5bd;margin-top:5px;">
                        <?php _e('زبانی که می‌خواهید در افزونه استفاده کنید', 'loginpro'); ?>
                    </p>
                </div>
                <?php endif; ?>
                
                <!-- انتخاب کشور -->
                <?php if ($atts['show_country'] === 'yes'): ?>
                <div class="loginpro-form-group" style="margin-bottom:20px;">
                    <label style="display:block;font-weight:600;margin-bottom:8px;color:#333;">
                        📍 <?php _e('کشور', 'loginpro'); ?>
                    </label>
                    <select name="country" id="loginpro-country" style="width:100%;height:48px;padding:0 15px;border:2px solid #e0e0e0;border-radius:12px;font-size:15px;">
                        <?php foreach ($countries as $code => $name): ?>
                            <option value="<?php echo esc_attr($code); ?>" 
                                <?php selected($code, $current_country); ?>>
                                <?php echo esc_html($code . ' - ' . $name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size:12px;color:#adb5bd;margin-top:5px;">
                        <?php _e('کشور محل سکونت شما', 'loginpro'); ?>
                    </p>
                </div>
                <?php endif; ?>
                
                <!-- انتخاب واحد پول -->
                <?php if ($atts['show_currency'] === 'yes'): ?>
                <div class="loginpro-form-group" style="margin-bottom:25px;">
                    <label style="display:block;font-weight:600;margin-bottom:8px;color:#333;">
                        💰 <?php _e('واحد پول', 'loginpro'); ?>
                    </label>
                    <select name="currency" id="loginpro-currency" style="width:100%;height:48px;padding:0 15px;border:2px solid #e0e0e0;border-radius:12px;font-size:15px;">
                        <?php foreach ($currencies as $code => $symbol): ?>
                            <option value="<?php echo esc_attr($code); ?>" 
                                <?php selected($code, $current_currency); ?>>
                                <?php echo esc_html($code . ' (' . $symbol . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size:12px;color:#adb5bd;margin-top:5px;">
                        <?php _e('واحد پول مورد نظر برای نمایش قیمت‌ها', 'loginpro'); ?>
                    </p>
                </div>
                <?php endif; ?>
                
                <button type="submit" id="loginpro-save-settings" 
                    style="width:100%;height:52px;background:#2d6aff;color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:600;cursor:pointer;transition:all 0.3s ease;">
                    💾 <?php _e('ذخیره تنظیمات و ادامه', 'loginpro'); ?>
                </button>
            </form>
            
            <p style="text-align:center;font-size:12px;color:#adb5bd;margin-top:15px;">
                <?php _e('تنظیمات شما ذخیره می‌شود و بعداً قابل تغییر است', 'loginpro'); ?>
            </p>
        </div>
        
        <style>
        .loginpro-language-selector-container select:focus {
            outline: none;
            border-color: #2d6aff;
            box-shadow: 0 0 0 3px rgba(45,106,255,0.1);
        }
        #loginpro-save-settings:hover {
            background: #1a4fcc;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(45,106,255,0.3);
        }
        #loginpro-save-settings:active {
            transform: translateY(0);
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#loginpro-language-form').on('submit', function(e) {
                e.preventDefault();
                
                var formData = $(this).serialize();
                var message = $('#loginpro-language-message');
                
                message.hide().empty();
                
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: formData + '&action=loginpro_save_user_settings',
                    beforeSend: function() {
                        $('#loginpro-save-settings')
                            .html('⏳ <?php _e('در حال ذخیره...', 'loginpro'); ?>')
                            .prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.success) {
                            message.html('✅ ' + response.data.message)
                                .css({
                                    'background': '#e8f5e9',
                                    'color': '#2e7d32',
                                    'display': 'block'
                                });
                            
                            // هدایت به صفحه بعد
                            setTimeout(function() {
                                window.location.href = response.data.redirect || '<?php echo esc_js($atts['redirect']); ?>';
                            }, 1000);
                        } else {
                            message.html('❌ ' + response.data.message)
                                .css({
                                    'background': '#fce4ec',
                                    'color': '#c62828',
                                    'display': 'block'
                                });
                        }
                    },
                    error: function() {
                        message.html('❌ <?php _e('خطا در ارتباط با سرور', 'loginpro'); ?>')
                            .css({
                                'background': '#fce4ec',
                                'color': '#c62828',
                                'display': 'block'
                            });
                    },
                    complete: function() {
                        $('#loginpro-save-settings')
                            .html('💾 <?php _e('ذخیره تنظیمات و ادامه', 'loginpro'); ?>')
                            .prop('disabled', false);
                    }
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }
}