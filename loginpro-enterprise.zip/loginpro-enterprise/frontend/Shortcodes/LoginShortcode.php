<?php
/**
 * LoginPro Login Shortcode
 *
 * @package LoginPro
 * @version 3.1.0
 */

namespace LoginPro\Frontend\Shortcodes;

defined('ABSPATH') || exit;

class LoginShortcode
{
    public function __construct()
    {
        add_shortcode(
            'loginpro_login',
            [
                $this,
                'render'
            ]
        );
    }

    /**
     * Render Login Form
     */
    public function render($atts = [])
    {
        $atts = shortcode_atts(
            [
                'redirect' => '',
                'force'    => 'false',
            ],
            $atts
        );

        /**
         * Already Logged In
         */
        if (is_user_logged_in() && $atts['force'] !== 'true') {
            return $this->loggedInMessage();
        }

        /**
         * Load Assets
         */
        $this->enqueueAssets();

        /**
         * Settings
         */
        $settings = [
            'primary_color' => get_option('loginpro_primary_color', '#0288d1'),
            'background_color' => get_option('loginpro_background_color', '#ffffff'),
            'border_radius' => (int)get_option('loginpro_border_radius', 24),
            'form_width' => get_option('loginpro_form_width', '400px'),
            'redirect' => !empty($atts['redirect']) ? esc_url($atts['redirect']) : home_url('/dashboard')
        ];

        /**
         * View
         */
        ob_start();
        
        // ✅ اصلاح: استفاده از LOGINPRO_PLUGIN_DIR به جای LOGINPRO_PATH
        $template_file = LOGINPRO_PLUGIN_DIR . 'frontend/Views/login-form.php';
        
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div style="color:red;padding:20px;border:2px solid red;border-radius:8px;">';
            echo '❌ <strong>خطا:</strong> فایل فرم لاگین پیدا نشد.<br>';
            echo 'مسیر: ' . esc_html($template_file);
            echo '</div>';
        }

        return ob_get_clean();
    }

    /**
     * Enqueue JS/CSS
     */
    private function enqueueAssets()
    {
        wp_enqueue_script(
            'loginpro-js',
            LOGINPRO_PLUGIN_URL . 'assets/js/loginpro.js',
            ['jquery'],
            LOGINPRO_VERSION,
            true
        );

        wp_localize_script(
            'loginpro-js',
            'loginproConfig',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('loginpro_ajax_nonce'),
                'redirect' => home_url('/dashboard'),
                'plugin_url' => LOGINPRO_PLUGIN_URL,
            ]
        );
        
        // ✅ همچنین loginpro_ajax را هم تعریف کن (برای سازگاری)
        wp_localize_script(
            'loginpro-js',
            'loginpro_ajax',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('loginpro_ajax_nonce'),
                'plugin_url' => LOGINPRO_PLUGIN_URL,
            ]
        );

        wp_enqueue_style(
            'loginpro-css',
            LOGINPRO_PLUGIN_URL . 'assets/css/loginpro.css',
            [],
            LOGINPRO_VERSION
        );
        
        // ✅ همچنین loginpro-styles را هم بارگذاری کن
        wp_enqueue_style(
            'loginpro-styles',
            LOGINPRO_PLUGIN_URL . 'assets/css/loginpro.css',
            [],
            LOGINPRO_VERSION
        );
    }

    /**
     * Logged in message
     */
    private function loggedInMessage(): string
    {
        $user = wp_get_current_user();

        return sprintf(
            '
            <div class="loginpro-logged-box">
                <h3>%s</h3>
                <p>%s</p>
                <a href="%s">%s</a>
            </div>
            ',
            esc_html__('شما وارد شده‌اید', 'loginpro'),
            esc_html($user->display_name),
            esc_url(wp_logout_url()),
            esc_html__('خروج', 'loginpro')
        );
    }
}