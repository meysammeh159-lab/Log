<?php
namespace LoginPro\Frontend\Shortcodes;

class DashboardShortcode {
    
    public static function render($atts) {
        if (!is_user_logged_in()) {
            return '<div class="loginpro-required-login">Please <a href="' . wp_login_url(get_permalink()) . '">login</a> to view your dashboard.</div>';
        }
        
        $user = wp_get_current_user();
        
        ob_start();
        ?>
        <div class="loginpro-dashboard">
            <div class="loginpro-dashboard-header">
                <img src="<?php echo get_avatar_url($user->ID); ?>" alt="Avatar" class="loginpro-avatar">
                <h2>Welcome, <?php echo esc_html($user->display_name); ?></h2>
            </div>
            <div class="loginpro-dashboard-stats">
                <div class="stat-card">
                    <span class="stat-value"><?php echo self::getLoginCount($user->ID); ?></span>
                    <span class="stat-label">Total Logins</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo self::getDeviceCount($user->ID); ?></span>
                    <span class="stat-label">Active Devices</span>
                </div>
            </div>
            <div class="loginpro-dashboard-links">
                <a href="<?php echo home_url('/profile'); ?>" class="dashboard-link">Edit Profile</a>
                <a href="<?php echo home_url('/security'); ?>" class="dashboard-link">Security Settings</a>
                <a href="<?php echo wp_logout_url(home_url()); ?>" class="dashboard-link logout">Logout</a>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private static function getLoginCount($userId) {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}loginpro_login_history WHERE user_id = %d",
            $userId
        ));
    }
    
    private static function getDeviceCount($userId) {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}loginpro_devices WHERE user_id = %d",
            $userId
        ));
    }
}
