<?php
namespace LoginPro\Frontend\Shortcodes;

defined('ABSPATH') || exit;

use LoginPro\Admin\ProfileTabsPage;

class ProfileShortcode
{
    private $tabs_manager;
    private $current_tab = 'profile';

    public function __construct()
    {
     $this->tabs_manager = null;
        add_shortcode('loginpro_user', [$this, 'render']);
        add_shortcode('loginpro_dashboard', [$this, 'render']);
    }

    public function render($atts)
    {
        if (!is_user_logged_in()) {
            return $this->login_form();
        }

        $this->current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'profile';
        $user = wp_get_current_user();
        
        ob_start();
        ?>
        
        <!-- استایل مستقیم در صفحه -->
        <style>
            .lp-simple-dashboard {
                direction: rtl;
                background: #0a0c10;
                padding: 20px;
                border-radius: 16px;
                font-family: 'Segoe UI', Tahoma, sans-serif;
            }
            .lp-simple-tabs {
                display: flex;
                flex-direction: row;
                flex-wrap: wrap;
                gap: 8px;
                margin-bottom: 20px;
                padding: 10px 0;
                border-bottom: 2px solid #2d6aff;
            }
            .lp-simple-tab {
                padding: 10px 24px;
                background: #2d2d3d;
                color: #fff;
                border: none;
                border-radius: 30px;
                cursor: pointer;
                font-size: 14px;
                transition: 0.3s;
            }
            .lp-simple-tab.active {
                background: #2d6aff;
                box-shadow: 0 2px 8px rgba(45,106,255,0.4);
            }
            .lp-simple-tab:hover {
                background: #2d6aff;
            }
            .lp-simple-content {
                background: #1a1c2a;
                padding: 25px;
                border-radius: 16px;
                color: #e8edf5;
            }
            .lp-simple-group {
                margin-bottom: 15px;
            }
            .lp-simple-group label {
                display: block;
                margin-bottom: 5px;
                font-size: 13px;
                color: #aaa;
            }
            .lp-simple-group input,
            .lp-simple-group select {
                width: 100%;
                max-width: 350px;
                padding: 10px;
                background: #2d2d3d;
                border: 1px solid #444;
                border-radius: 8px;
                color: #fff;
            }
            .lp-simple-btn {
                background: #2d6aff;
                color: #fff;
                padding: 10px 24px;
                border: none;
                border-radius: 30px;
                cursor: pointer;
            }
            .lp-simple-table {
                width: 100%;
                border-collapse: collapse;
            }
            .lp-simple-table th,
            .lp-simple-table td {
                padding: 10px;
                border-bottom: 1px solid #333;
                text-align: right;
            }
            @media (max-width: 768px) {
                .lp-simple-tabs {
                    flex-direction: column;
                }
                .lp-simple-tab {
                    width: 100%;
                    text-align: center;
                }
                .lp-simple-group input {
                    max-width: 100%;
                }
            }
        </style>
        
        <div class="lp-simple-dashboard">
            <div class="lp-simple-tabs">
                <?php foreach ($this->get_active_tabs() as $key => $label): ?>
                    <button class="lp-simple-tab <?php echo $this->current_tab == $key ? 'active' : ''; ?>" onclick="window.location.href='?tab=<?php echo $key; ?>'">
                        <?php echo esc_html($label); ?>
                    </button>
                <?php endforeach; ?>
                <button class="lp-simple-tab <?php echo $this->current_tab == 'logout' ? 'active' : ''; ?>" onclick="window.location.href='?tab=logout'">
                    🚪 <?php esc_html_e('خروج', 'loginpro'); ?>
                </button>
            </div>
            
            <div class="lp-simple-content">
                <?php
                if ($this->current_tab == 'logout') {
                    echo '<div style="text-align:center; padding:40px;"><h3>' . esc_html__('خروج از حساب', 'loginpro') . '</h3><a href="' . esc_url(wp_logout_url(home_url())) . '" class="lp-simple-btn" style="background:#dc3545;">' . esc_html__('خروج', 'loginpro') . '</a></div>';
                } else {
                    $this->render_tab_content($this->current_tab);
                }
                ?>
            </div>
        </div>
        
        <?php
        return ob_get_clean();
    }

    /**
     * نمایش فرم ورود برای کاربران مهمان
     * 
     * @return string
     */
    private function login_form()
    {
        $login_page_id = get_option('loginpro_login_page_id', 0);
        $login_url = $login_page_id ? get_permalink($login_page_id) : wp_login_url(get_permalink());
        
        return '<div style="text-align:center;padding:40px 20px;background:#0a0c10;border-radius:16px;color:#fff;">
            <h3>' . esc_html__('👋 خوش آمدید', 'loginpro') . '</h3>
            <p style="color:#aaa;">' . esc_html__('برای مشاهده داشبورد خود، لطفاً وارد شوید.', 'loginpro') . '</p>
            <a href="' . esc_url($login_url) . '" class="lp-simple-btn" style="display:inline-block;margin-top:15px;background:#2d6aff;color:#fff;padding:10px 30px;border-radius:30px;text-decoration:none;">' . esc_html__('ورود به حساب کاربری', 'loginpro') . '</a>
        </div>';
    }

    /**
     * دریافت لیست تب‌های فعال از دیتابیس
     * 
     * @return array
     */
    private function get_active_tabs()
    {
        $option_name = 'loginpro_user_dashboard_tabs';
        $active_tabs_from_db = get_option($option_name, null);
        
        $all_tabs = [
            'orders'          => __('سفارش‌ها', 'loginpro'),
            'wishlist'        => __('لیست‌های من', 'loginpro'),
            'reviews'         => __('دیدگاه و پرسش‌ها', 'loginpro'),
            'addresses'       => __('آدرس‌ها', 'loginpro'),
            'messages'        => __('پیام‌ها', 'loginpro'),
            'recent_views'    => __('بازدیدهای اخیر', 'loginpro'),
            'account_details' => __('اطلاعات حساب کاربری', 'loginpro'),
            'tickets'         => __('تیکت‌های پشتیبانی', 'loginpro'),
            'downloads'       => __('دانلودها', 'loginpro'),
            'subscription'    => __('اشتراک', 'loginpro'),
            'gifts'           => __('هدیه‌ها', 'loginpro'),
        ];

        if ($active_tabs_from_db === null || empty($active_tabs_from_db)) {
            return [
                'account_details' => __('اطلاعات حساب کاربری', 'loginpro'),
                'orders'          => __('سفارش‌ها', 'loginpro'),
                'messages'        => __('پیام‌ها', 'loginpro'),
                'tickets'         => __('تیکت‌های پشتیبانی', 'loginpro'),
                'addresses'       => __('آدرس‌ها', 'loginpro'),
            ];
        }

        $tabs = [];
        foreach ($active_tabs_from_db as $tab_key) {
            if (isset($all_tabs[$tab_key])) {
                $tabs[$tab_key] = $all_tabs[$tab_key];
            }
        }

        if (empty($tabs)) {
            $tabs = [
                'account_details' => __('اطلاعات حساب کاربری', 'loginpro'),
            ];
        }

        return $tabs;
    }

    /**
     * رندر محتوای تب انتخاب شده
     * 
     * @param string $tab
     * @return void
     */
    private function render_tab_content($tab)
    {
        switch ($tab) {
            case 'orders':
                echo $this->render_orders_tab();
                break;
            case 'wishlist':
                echo $this->render_wishlist_tab();
                break;
            case 'reviews':
                echo $this->render_reviews_tab();
                break;
            case 'addresses':
                echo $this->render_addresses_tab();
                break;
            case 'messages':
                echo $this->render_messages_tab();
                break;
            case 'recent_views':
                echo $this->render_recent_views_tab();
                break;
            case 'account_details':
                echo $this->render_account_details_tab();
                break;
            case 'tickets':
                echo $this->render_tickets_tab();
                break;
            case 'downloads':
                echo $this->render_downloads_tab();
                break;
            case 'subscription':
                echo $this->render_subscription_tab();
                break;
            case 'gifts':
                echo $this->render_gifts_tab();
                break;
            default:
                echo '<p>' . esc_html__('محتوای این تب در حال آماده‌سازی است.', 'loginpro') . '</p>';
        }
    }

    // =============================================
    // متدهای رندر تب‌ها
    // =============================================

    /**
     * رندر تب سفارش‌ها
     */
    private function render_orders_tab()
    {
        if (!class_exists('WooCommerce')) {
            return '<p>' . esc_html__('برای مشاهده سفارش‌ها، ووکامرس باید فعال باشد.', 'loginpro') . '</p>';
        }

        $user_id = get_current_user_id();
        $orders = wc_get_orders(['customer_id' => $user_id, 'limit' => 5]);

        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('🛒 سفارش‌های اخیر', 'loginpro'); ?></h3>
        <?php if (empty($orders)): ?>
            <p><?php esc_html_e('شما هنوز سفارشی ثبت نکرده‌اید.', 'loginpro'); ?></p>
        <?php else: ?>
            <div class="table-responsive" style="overflow-x:auto;">
                <table class="lp-simple-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('شماره', 'loginpro'); ?></th>
                            <th><?php esc_html_e('تاریخ', 'loginpro'); ?></th>
                            <th><?php esc_html_e('وضعیت', 'loginpro'); ?></th>
                            <th><?php esc_html_e('مبلغ', 'loginpro'); ?></th>
                            <th><?php esc_html_e('عملیات', 'loginpro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>#<?php echo $order->get_order_number(); ?></td>
                                <td><?php echo $order->get_date_created()->date_i18n('j F Y'); ?></td>
                                <td><?php echo wc_get_order_status_name($order->get_status()); ?></td>
                                <td><?php echo wc_price($order->get_total()); ?></td>
                                <td><a href="<?php echo $order->get_view_order_url(); ?>" style="color:#2d6aff;"><?php esc_html_e('مشاهده', 'loginpro'); ?></a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب لیست علاقه‌مندی‌ها
     */
    private function render_wishlist_tab()
    {
        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('❤️ لیست علاقه‌مندی‌ها', 'loginpro'); ?></h3>
        <?php if (class_exists('WooCommerce')): ?>
            <p><?php esc_html_e('مدیریت لیست علاقه‌مندی‌های شما.', 'loginpro'); ?></p>
            <?php 
            $wishlist_page_id = get_option('woocommerce_wishlist_page_id', 0);
            $wishlist_url = $wishlist_page_id ? get_permalink($wishlist_page_id) : '';
            if ($wishlist_url): ?>
                <a href="<?php echo esc_url($wishlist_url); ?>" class="lp-simple-btn"><?php esc_html_e('📋 مشاهده لیست علاقه‌مندی‌ها', 'loginpro'); ?></a>
            <?php else: ?>
                <p style="color:#aaa;"><?php esc_html_e('صفحه لیست علاقه‌مندی‌ها تنظیم نشده است.', 'loginpro'); ?></p>
            <?php endif; ?>
        <?php else: ?>
            <p><?php esc_html_e('برای استفاده از لیست علاقه‌مندی‌ها، ووکامرس باید فعال باشد.', 'loginpro'); ?></p>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب دیدگاه‌ها
     */
    private function render_reviews_tab()
    {
        global $wpdb;
        $user_id = get_current_user_id();
        
        $reviews = $wpdb->get_results($wpdb->prepare("
            SELECT * FROM {$wpdb->comments} 
            WHERE user_id = %d AND comment_approved = 1 
            ORDER BY comment_date DESC LIMIT 10
        ", $user_id));

        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('💬 دیدگاه‌های من', 'loginpro'); ?></h3>
        <?php if (empty($reviews)): ?>
            <p><?php esc_html_e('شما هنوز دیدگاهی ثبت نکرده‌اید.', 'loginpro'); ?></p>
        <?php else: ?>
            <?php foreach ($reviews as $review): ?>
                <div style="background:#1a1c2a;padding:12px;border-radius:8px;margin-bottom:10px;border-right:3px solid #2d6aff;">
                    <strong><?php echo esc_html(get_the_title($review->comment_post_ID)); ?></strong>
                    <span style="color:#aaa;font-size:12px;display:block;margin-top:4px;"><?php echo date_i18n('j F Y', strtotime($review->comment_date)); ?></span>
                    <p style="margin:8px 0 0 0;color:#ddd;font-size:14px;"><?php echo esc_html(substr($review->comment_content, 0, 150)) . (strlen($review->comment_content) > 150 ? '...' : ''); ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب آدرس‌ها
     */
    private function render_addresses_tab()
    {
        if (!class_exists('WooCommerce')) {
            return '<p>' . esc_html__('برای مشاهده آدرس‌ها، ووکامرس باید فعال باشد.', 'loginpro') . '</p>';
        }

        $user_id = get_current_user_id();
        $customer = new \WC_Customer($user_id);
        $billing = $customer->get_billing();
        $shipping = $customer->get_shipping();

        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('📍 آدرس‌های من', 'loginpro'); ?></h3>
        
        <h4 style="color:#ddd;margin:15px 0 10px 0;"><?php esc_html_e('آدرس صورتحساب', 'loginpro'); ?></h4>
        <div style="background:#1a1c2a;padding:15px;border-radius:8px;">
            <?php 
            $billing_fields = array_filter([
                ($billing['first_name'] ? $billing['first_name'] . ' ' . $billing['last_name'] : ''),
                $billing['company'] ?? '',
                $billing['address_1'] ?? '',
                $billing['address_2'] ?? '',
                $billing['city'] ?? '',
                $billing['state'] ?? '',
                $billing['postcode'] ?? '',
                isset($billing['country']) ? (WC()->countries->get_countries()[$billing['country']] ?? $billing['country']) : '',
                $billing['phone'] ?? '',
                $billing['email'] ?? '',
            ]);
            if (!empty($billing_fields)) {
                echo implode('<br>', $billing_fields);
            } else {
                echo '<span style="color:#aaa;">' . esc_html__('آدرس صورتحساب ثبت نشده است.', 'loginpro') . '</span>';
            }
            ?>
        </div>

        <h4 style="color:#ddd;margin:15px 0 10px 0;"><?php esc_html_e('آدرس ارسال', 'loginpro'); ?></h4>
        <div style="background:#1a1c2a;padding:15px;border-radius:8px;">
            <?php 
            $shipping_fields = array_filter([
                ($shipping['first_name'] ? $shipping['first_name'] . ' ' . $shipping['last_name'] : ''),
                $shipping['company'] ?? '',
                $shipping['address_1'] ?? '',
                $shipping['address_2'] ?? '',
                $shipping['city'] ?? '',
                $shipping['state'] ?? '',
                $shipping['postcode'] ?? '',
                isset($shipping['country']) ? (WC()->countries->get_countries()[$shipping['country']] ?? $shipping['country']) : '',
            ]);
            if (!empty($shipping_fields)) {
                echo implode('<br>', $shipping_fields);
            } else {
                echo '<span style="color:#aaa;">' . esc_html__('آدرس ارسال ثبت نشده است.', 'loginpro') . '</span>';
            }
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب پیام‌ها
     */
    private function render_messages_tab()
    {
        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('📨 پیام‌ها', 'loginpro'); ?></h3>
        <p><?php esc_html_e('پیام‌های دریافتی از مدیریت در این بخش نمایش داده می‌شود.', 'loginpro'); ?></p>
        
        <?php
        $message_file = LOGINPRO_PLUGIN_DIR . 'frontend/MessageSystem.php';
        if (file_exists($message_file) && !class_exists('LoginPro\Frontend\MessageSystem')) {
            require_once $message_file;
        }
        
        if (class_exists('LoginPro\Frontend\MessageSystem')) {
            $message_system = new \LoginPro\Frontend\MessageSystem();
            echo $message_system->render_message_page();
        } else {
            echo '<p style="color:#aaa;">' . esc_html__('سیستم پیام‌رسانی در دسترس نیست.', 'loginpro') . '</p>';
        }
        ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب بازدیدهای اخیر
     */
    private function render_recent_views_tab()
    {
        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('👁️ بازدیدهای اخیر', 'loginpro'); ?></h3>
        <?php if (class_exists('WooCommerce')): 
            $viewed_products = !empty($_COOKIE['woocommerce_recently_viewed']) ? (array) explode('|', $_COOKIE['woocommerce_recently_viewed']) : array();
            $viewed_products = array_reverse(array_filter(array_map('absint', $viewed_products)));
        ?>
            <?php if (empty($viewed_products)): ?>
                <p><?php esc_html_e('شما اخیراً محصولی را مشاهده نکرده‌اید.', 'loginpro'); ?></p>
                <a href="<?php echo wc_get_page_permalink('shop'); ?>" class="lp-simple-btn"><?php esc_html_e('🛍️ مشاهده محصولات', 'loginpro'); ?></a>
            <?php else: ?>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:15px;margin-top:15px;">
                    <?php foreach ($viewed_products as $product_id): 
                        $product = wc_get_product($product_id);
                        if (!$product) continue;
                    ?>
                        <div style="background:#1a1c2a;border-radius:8px;padding:10px;text-align:center;">
                            <a href="<?php echo get_permalink($product_id); ?>" style="text-decoration:none;color:inherit;">
                                <?php echo $product->get_image('thumbnail'); ?>
                                <div style="font-size:13px;margin-top:8px;color:#ddd;"><?php echo esc_html($product->get_name()); ?></div>
                                <div style="font-size:14px;font-weight:bold;color:#2d6aff;"><?php echo wc_price($product->get_price()); ?></div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <p><?php esc_html_e('برای مشاهده بازدیدهای اخیر، ووکامرس باید فعال باشد.', 'loginpro'); ?></p>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب اطلاعات حساب کاربری
     */
    private function render_account_details_tab()
    {
        $user = wp_get_current_user();
        $mobile = get_user_meta($user->ID, 'loginpro_mobile', true);
        $registered = date_i18n('j F Y، ساعت H:i', strtotime($user->user_registered));

        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('👤 اطلاعات حساب کاربری', 'loginpro'); ?></h3>
        
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;">
            <div style="background:#1a1c2a;padding:15px;border-radius:8px;">
                <label style="color:#aaa;font-size:13px;display:block;margin-bottom:5px;"><?php esc_html_e('نام نمایشی', 'loginpro'); ?></label>
                <span style="color:#fff;font-size:16px;"><?php echo esc_html($user->display_name); ?></span>
            </div>
            <div style="background:#1a1c2a;padding:15px;border-radius:8px;">
                <label style="color:#aaa;font-size:13px;display:block;margin-bottom:5px;"><?php esc_html_e('ایمیل', 'loginpro'); ?></label>
                <span style="color:#fff;font-size:16px;"><?php echo esc_html($user->user_email); ?></span>
            </div>
            <div style="background:#1a1c2a;padding:15px;border-radius:8px;">
                <label style="color:#aaa;font-size:13px;display:block;margin-bottom:5px;"><?php esc_html_e('شماره موبایل', 'loginpro'); ?></label>
                <span style="color:#fff;font-size:16px;"><?php echo $mobile ? esc_html($mobile) : '<span style="color:#aaa;">' . esc_html__('ثبت نشده', 'loginpro') . '</span>'; ?></span>
            </div>
            <div style="background:#1a1c2a;padding:15px;border-radius:8px;">
                <label style="color:#aaa;font-size:13px;display:block;margin-bottom:5px;"><?php esc_html_e('تاریخ عضویت', 'loginpro'); ?></label>
                <span style="color:#fff;font-size:16px;"><?php echo esc_html($registered); ?></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب تیکت‌ها
     */
    private function render_tickets_tab()
    {
        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('🎫 تیکت‌های پشتیبانی', 'loginpro'); ?></h3>
        <?php
        $ticket_view_file = LOGINPRO_PLUGIN_DIR . 'frontend/TicketView.php';
        if (file_exists($ticket_view_file) && !class_exists('LoginPro\Frontend\TicketView')) {
            require_once $ticket_view_file;
        }
        
        if (class_exists('LoginPro\Frontend\TicketView')) {
            $ticket_view = new \LoginPro\Frontend\TicketView();
            echo $ticket_view->render_ticket_page();
        } else {
            echo '<p style="color:#aaa;">' . esc_html__('سیستم تیکت در دسترس نیست.', 'loginpro') . '</p>';
        }
        ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب دانلودها
     */
    private function render_downloads_tab()
    {
        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('📥 دانلودها', 'loginpro'); ?></h3>
        <?php if (class_exists('WooCommerce')): ?>
            <p><?php esc_html_e('فایل‌هایی که مجوز دانلود دارید.', 'loginpro'); ?></p>
            <a href="<?php echo wc_get_account_endpoint_url('downloads'); ?>" class="lp-simple-btn"><?php esc_html_e('📥 مشاهده دانلودها', 'loginpro'); ?></a>
        <?php else: ?>
            <p><?php esc_html_e('برای استفاده از این بخش، ووکامرس باید فعال باشد.', 'loginpro'); ?></p>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب اشتراک
     */
    private function render_subscription_tab()
    {
        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('📋 اشتراک', 'loginpro'); ?></h3>
        <?php if (class_exists('WooCommerce')): ?>
            <p><?php esc_html_e('اطلاعات اشتراک شما در این بخش نمایش داده می‌شود.', 'loginpro'); ?></p>
            <a href="<?php echo wc_get_account_endpoint_url('subscriptions'); ?>" class="lp-simple-btn"><?php esc_html_e('📋 مدیریت اشتراک', 'loginpro'); ?></a>
        <?php else: ?>
            <p><?php esc_html_e('برای استفاده از این بخش، ووکامرس اشتراکی باید فعال باشد.', 'loginpro'); ?></p>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    /**
     * رندر تب هدیه‌ها
     */
    private function render_gifts_tab()
    {
        ob_start();
        ?>
        <h3 class="lp-simple-group"><?php esc_html_e('🎁 هدیه‌ها', 'loginpro'); ?></h3>
        <p><?php esc_html_e('لیست هدیه‌های دریافتی و ارسالی شما.', 'loginpro'); ?></p>
        <a href="<?php echo home_url('/gifts/'); ?>" class="lp-simple-btn"><?php esc_html_e('🎁 مشاهده هدیه‌ها', 'loginpro'); ?></a>
        <?php
        return ob_get_clean();
    }
}