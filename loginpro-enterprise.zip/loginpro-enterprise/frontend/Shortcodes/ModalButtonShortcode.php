<?php
/**
 * Modal Button Shortcode
 * شورت‌کد دکمه مودال
 * 
 * @package LoginPro
 * @version 3.0.17
 */

namespace LoginPro\Frontend\Shortcodes;

defined('ABSPATH') || exit;

class ModalButtonShortcode {
    
    /**
     * رندر شورت‌کد
     */
    public static function render($atts = []) {
        $atts = shortcode_atts([
            'text' => get_option('loginpro_modal_btn_text', __('ورود / ثبت‌نام', 'loginpro')),
            'logged_in_text' => get_option('loginpro_modal_btn_logged_text', __('پنل کاربری', 'loginpro')),
            'icon' => get_option('loginpro_modal_btn_icon', '🔐'),
            'logged_in_icon' => get_option('loginpro_modal_btn_logged_icon', '👤'),
            'class' => '',
        ], $atts);
        
        $btn_bg_color = get_option('loginpro_modal_btn_bg_color', '#ef394e');
        $btn_text_color = get_option('loginpro_modal_btn_text_color', '#ffffff');
        $btn_border_radius = get_option('loginpro_modal_btn_border_radius', 8);
        $btn_padding = get_option('loginpro_modal_btn_padding', '8px 20px');
        $btn_font_size = get_option('loginpro_modal_btn_font_size', 14);
        $font_family = get_option('loginpro_font_family', 'IRANSans, Tahoma, sans-serif');
        
        $style = 'display: inline-flex; align-items: center; gap: 8px; background: ' . esc_attr($btn_bg_color) . '; color: ' . esc_attr($btn_text_color) . '; border: none; border-radius: ' . esc_attr($btn_border_radius) . 'px; padding: ' . esc_attr($btn_padding) . '; font-size: ' . esc_attr($btn_font_size) . 'px; font-family: ' . esc_attr($font_family) . '; cursor: pointer; text-decoration: none; transition: all 0.3s ease;';
        
        if (is_user_logged_in()) {
            $profile_page_id = get_option('loginpro_profile_page_id', 0);
            $profile_url = $profile_page_id ? get_permalink($profile_page_id) : home_url('/profile/');
            return '<a href="' . esc_url($profile_url) . '" class="loginpro-profile-button ' . esc_attr($atts['class']) . '" style="' . $style . '">' . 
                    esc_html($atts['logged_in_icon']) . ' ' . esc_html($atts['logged_in_text']) . 
                    '</a>';
        }
        
        $icon_html = !empty($atts['icon']) ? esc_html($atts['icon']) . ' ' : '';
        return '<button type="button" class="loginpro-modal-trigger ' . esc_attr($atts['class']) . '" style="' . $style . '" data-loginpro-modal="true" data-loginpro-trigger="true">' . 
                $icon_html . esc_html($atts['text']) . 
                '</button>';
    }
}