<?php
namespace LoginPro\Frontend\Shortcodes;

defined('ABSPATH') || exit;

use LoginPro\Admin\ProfileTabsPage;

class ProfileShortcode
{
    private $tabs_manager;
    private $current_tab = 'profile';

    public function __construct()
    {
        $this->tabs_manager = new ProfileTabsPage();
        add_shortcode('loginpro_user', [$this, 'render']);
    }
    
    public function render($atts)
    {
        if (!is_user_logged_in()) {
            return '<div style="text-align:center;padding:50px;"><h3>لطفاً وارد شوید</h3><a href="' . wp_login_url() . '">ورود</a></div>';
        }
        
        ob_start();
        ?>
        <div style="direction:rtl; text-align:right;">
            <h2>داشبورد کاربری</h2>
            <p>خوش آمدید <?php echo wp_get_current_user()->display_name; ?></p>
            <a href="<?php echo wp_logout_url(home_url()); ?>" style="background:#dc3545;color:#fff;padding:10px 20px;text-decoration:none;border-radius:5px;">خروج</a>
        </div>
        <?php
        return ob_get_clean();
    }
}