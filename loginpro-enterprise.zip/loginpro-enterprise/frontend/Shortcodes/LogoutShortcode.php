<?php
namespace LoginPro\Frontend\Shortcodes;

class LogoutShortcode {
    
    public static function render($atts) {
        $atts = shortcode_atts([
            'redirect' => home_url(),
            'text' => 'Logout',
            'class' => 'loginpro-logout-btn'
        ], $atts);
        
        if (!is_user_logged_in()) {
            return '';
        }
        
        return '<a href="' . wp_logout_url($atts['redirect']) . '" class="' . esc_attr($atts['class']) . '">' . esc_html($atts['text']) . '</a>';
    }
}
