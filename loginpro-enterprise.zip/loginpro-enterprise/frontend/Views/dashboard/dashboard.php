<?php
/**
 * Dashboard View
 * قالب داشبورد کاربری
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// این فایل برای قالب‌بندی داشبورد کاربری استفاده می‌شود
// محتوای آن توسط شورت‌کد [loginpro_dashboard] تولید می‌شود
?>