<?php
/**
 * Login View
 * قالب صفحه ورود
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// این فایل برای قالب‌بندی صفحه ورود استفاده می‌شود
// محتوای آن توسط شورت‌کد [loginpro_login] تولید می‌شود
?>