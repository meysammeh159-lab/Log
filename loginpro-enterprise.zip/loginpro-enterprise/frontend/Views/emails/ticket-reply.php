<?php
/**
 * Ticket Reply Email Template
 * قالب ایمیل پاسخ تیکت
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// این فایل برای قالب‌بندی ایمیل‌های پاسخ تیکت استفاده می‌شود
// محتوای آن به صورت پویا تولید می‌شود
?>