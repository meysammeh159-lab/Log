<?php
/**
 * فرم ورود با OTP
 * 
 * @package LoginPro
 * @version 3.0.0
 */

defined('ABSPATH') || exit;
?>

<div class="loginpro-wrapper" id="loginpro-login-form">
    
    <!-- ============================================
    // ✅ مرحله 1: ورود شناسه (موبایل یا ایمیل)
    // ============================================ -->
    <div id="loginpro-identifier-box" class="loginpro-step loginpro-step-identifier">
        <div class="loginpro-header">
            <h2><?php _e('ورود / ثبت‌نام', 'loginpro'); ?></h2>
            <p><?php _e('شماره موبایل یا ایمیل خود را وارد کنید', 'loginpro'); ?></p>
        </div>
        
        <div class="loginpro-field-group">
            <label for="loginpro-identifier"><?php _e('شماره موبایل یا ایمیل', 'loginpro'); ?></label>
            <input type="text" 
                   id="loginpro-identifier" 
                   name="identifier" 
                   class="loginpro-input" 
                   placeholder="<?php _e('09123456789 یا example@email.com', 'loginpro'); ?>"
                   autocomplete="username"
                   dir="ltr">
        </div>
        
        <div id="loginpro-message" class="loginpro-message" style="display:none;"></div>
        
        <button type="button" 
                id="loginpro-check-identifier" 
                class="loginpro-button loginpro-button-primary loginpro-button-block"
                data-loginpro-check>
            <?php _e('بررسی و ادامه', 'loginpro'); ?>
        </button>
        
        <div class="loginpro-footer">
            <a href="<?php echo wp_login_url(); ?>" class="loginpro-link">
                <?php _e('ورود با رمز عبور', 'loginpro'); ?>
            </a>
        </div>
    </div>
    
    <!-- ============================================
    // ✅ مرحله 2: تأیید کد OTP
    // ============================================ -->
    <div id="loginpro-otp-container" class="loginpro-step loginpro-step-otp" style="display:none;">
        <div class="loginpro-header">
            <h2><?php _e('کد تایید', 'loginpro'); ?></h2>
            <p><?php _e('کد ارسال شده به شماره زیر را وارد کنید', 'loginpro'); ?></p>
            <div id="loginpro-otp-mobile-display" class="loginpro-otp-mobile"></div>
        </div>
        
        <div class="loginpro-field-group">
            <label for="loginpro-otp-code"><?php _e('کد ۶ رقمی', 'loginpro'); ?></label>
            <input type="text" 
                   id="loginpro-otp-code" 
                   name="otp_code" 
                   class="loginpro-input loginpro-otp-input" 
                   placeholder="123456"
                   maxlength="6"
                   autocomplete="one-time-code"
                   inputmode="numeric"
                   dir="ltr">
        </div>
        
        <!-- فیلدهای مخفی -->
        <input type="hidden" id="loginpro-otp-mobile" name="otp_mobile" value="">
        <input type="hidden" id="loginpro-otp-token" name="otp_token" value="">
        
        <div id="loginpro-otp-message" class="loginpro-message" style="display:none;"></div>
        
        <button type="button" 
                id="loginpro-verify-otp" 
                class="loginpro-button loginpro-button-primary loginpro-button-block"
                data-loginpro-verify>
            <?php _e('تأیید و ورود', 'loginpro'); ?>
        </button>
        
        <div class="loginpro-otp-actions">
            <button type="button" 
                    id="loginpro-resend-otp" 
                    class="loginpro-button-link"
                    data-loginpro-resend>
                <?php _e('ارسال مجدد کد', 'loginpro'); ?>
            </button>
            <span id="loginpro-otp-timer" class="loginpro-timer"></span>
        </div>
        
        <div class="loginpro-footer">
            <button type="button" id="loginpro-back-to-identifier" class="loginpro-link">
                ← <?php _e('بازگشت', 'loginpro'); ?>
            </button>
        </div>
    </div>
    
</div>

<style>
/* ============================================
// استایل‌های فرم لاگین
// ============================================ */
.loginpro-wrapper {
    max-width: 400px;
    margin: 0 auto;
    padding: 30px 25px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    direction: rtl;
    font-family: IRANSans, Tahoma, sans-serif;
}

.loginpro-step {
    transition: all 0.3s ease;
}

.loginpro-header {
    text-align: center;
    margin-bottom: 25px;
}

.loginpro-header h2 {
    font-size: 22px;
    font-weight: 700;
    color: #1d2327;
    margin: 0 0 8px 0;
}

.loginpro-header p {
    font-size: 14px;
    color: #646970;
    margin: 0;
}

.loginpro-otp-mobile {
    font-size: 18px;
    font-weight: 700;
    color: #2271b1;
    margin-top: 10px;
    padding: 8px 12px;
    background: #f0f6fc;
    border-radius: 8px;
    display: inline-block;
}

.loginpro-field-group {
    margin-bottom: 20px;
}

.loginpro-field-group label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #3c434a;
    margin-bottom: 6px;
}

.loginpro-field-group input {
    width: 100%;
    padding: 12px 15px;
    font-size: 16px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    box-sizing: border-box;
    transition: border-color 0.3s;
    font-family: inherit;
    direction: ltr;
    text-align: left;
}

.loginpro-field-group input:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 3px rgba(34,113,177,0.1);
}

.loginpro-field-group input.loginpro-otp-input {
    font-size: 28px;
    text-align: center;
    letter-spacing: 8px;
    font-weight: 700;
    padding: 15px;
}

.loginpro-button {
    display: inline-block;
    padding: 12px 25px;
    font-size: 16px;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    text-align: center;
    font-family: inherit;
}

.loginpro-button-block {
    display: block;
    width: 100%;
}

.loginpro-button-primary {
    background: #ef394e;
    color: #fff;
}

.loginpro-button-primary:hover {
    background: #c62828;
    transform: translateY(-1px);
}

.loginpro-button-primary:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

.loginpro-button-link {
    background: none;
    border: none;
    color: #2271b1;
    cursor: pointer;
    font-size: 14px;
    text-decoration: underline;
    padding: 5px 0;
    font-family: inherit;
}

.loginpro-button-link:hover {
    color: #135e96;
}

.loginpro-button-link:disabled {
    color: #999;
    cursor: not-allowed;
    text-decoration: none;
}

.loginpro-message {
    padding: 12px 15px;
    border-radius: 8px;
    margin-bottom: 15px;
    font-size: 14px;
    display: none;
}

.loginpro-message-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
    display: block;
}

.loginpro-message-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
    display: block;
}

.loginpro-message-info {
    background: #d1ecf1;
    color: #0c5460;
    border: 1px solid #bee5eb;
    display: block;
}

.loginpro-otp-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 15px;
    padding: 10px 0;
}

.loginpro-timer {
    font-size: 14px;
    color: #646970;
}

.loginpro-footer {
    margin-top: 20px;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
    text-align: center;
}

.loginpro-link {
    color: #646970;
    text-decoration: none;
    font-size: 14px;
    background: none;
    border: none;
    cursor: pointer;
}

.loginpro-link:hover {
    color: #2271b1;
    text-decoration: underline;
}

/* ============================================
// واکنش‌گرا
// ============================================ */
@media (max-width: 480px) {
    .loginpro-wrapper {
        padding: 20px 15px;
        margin: 10px;
    }
    
    .loginpro-header h2 {
        font-size: 18px;
    }
    
    .loginpro-field-group input {
        font-size: 14px;
        padding: 10px 12px;
    }
    
    .loginpro-field-group input.loginpro-otp-input {
        font-size: 22px;
        letter-spacing: 5px;
        padding: 12px;
    }
}
</style>

<script>
// ============================================
// ✅ اسکریپت‌های فرم لاگین (در صورت نیاز)
// ============================================
jQuery(document).ready(function($) {
    // ✅ دکمه بازگشت
    $('#loginpro-back-to-identifier').on('click', function() {
        $('#loginpro-otp-container').hide();
        $('#loginpro-identifier-box').show();
        $('#loginpro-identifier').val('').focus();
        $('#loginpro-otp-code').val('');
        clearInterval(window.otpTimerInterval);
        $('#loginpro-otp-timer').text('');
        $('#loginpro-resend-otp').prop('disabled', false);
    });
    
    // ✅ جلوگیری از ارسال فرم
    $('form').on('submit', function(e) {
        e.preventDefault();
        return false;
    });
});
</script>