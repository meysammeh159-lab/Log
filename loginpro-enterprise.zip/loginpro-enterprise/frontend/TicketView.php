<?php
namespace LoginPro\Frontend;

defined('ABSPATH') || exit;

class TicketView
{
    private $tickets_table;
    private $replies_table;
    private $attachments_table;
    private $upload_dir;
    
    public function __construct()
    {
        global $wpdb;
        $this->tickets_table = $wpdb->prefix . 'loginpro_tickets';
        $this->replies_table = $this->tickets_table . '_replies';
        $this->attachments_table = $this->tickets_table . '_attachments';
        $this->upload_dir = wp_upload_dir()['basedir'] . '/loginpro-tickets/';
        
        if (!file_exists($this->upload_dir)) {
            wp_mkdir_p($this->upload_dir);
        }
    }
    
    private function table_exists()
    {
        global $wpdb;
        return $wpdb->get_var("SHOW TABLES LIKE '{$this->tickets_table}'") == $this->tickets_table;
    }
    
    private function get_last_submit_time($user_id)
    {
        $key = 'loginpro_ticket_submitted_' . $user_id;
        return get_transient($key);
    }
    
    private function set_last_submit_time($user_id)
    {
        $key = 'loginpro_ticket_submitted_' . $user_id;
        set_transient($key, time(), 60);
    }
    
    public function render_ticket_page()
    {
        if (!is_user_logged_in()) {
            return '<p>' . sprintf(
                __('لطفاً <a href="%s">وارد شوید</a>.', 'loginpro'),
                esc_url(wp_login_url(get_permalink()))
            ) . '</p>';
        }
        
        if (!$this->table_exists()) {
            return '<div class="loginpro-error">⚠️ ' . esc_html__('سیستم تیکت در دسترس نیست. لطفاً با مدیر سایت تماس بگیرید.', 'loginpro') . '</div>';
        }
        
        $user_id = get_current_user_id();
        $message = '';
        
        // پردازش ثبت تیکت جدید با بررسی جلوگیری از ارسال مجدد
        if (isset($_POST['submit_new_ticket'])) {
            if (isset($_POST['ticket_nonce']) && wp_verify_nonce($_POST['ticket_nonce'], 'new_ticket')) {
                $last_submit = $this->get_last_submit_time($user_id);
                
                if (!$last_submit) {
                    $result = $this->process_new_ticket();
                    if ($result === true) {
                        $this->set_last_submit_time($user_id);
                        $message = '<div class="loginpro-success">✅ ' . esc_html__('تیکت شما با موفقیت ثبت شد.', 'loginpro') . '</div>';
                    } elseif (is_string($result)) {
                        $message = '<div class="loginpro-error">❌ ' . esc_html($result) . '</div>';
                    }
                } else {
                    $message = '<div class="loginpro-error">❌ ' . esc_html__('شما اخیراً یک تیکت ثبت کرده‌اید. لطفاً چند لحظه صبر کنید.', 'loginpro') . '</div>';
                }
            } else {
                $message = '<div class="loginpro-error">❌ ' . esc_html__('خطای امنیتی. لطفاً صفحه را رفرش کنید.', 'loginpro') . '</div>';
            }
        }
        
        // پردازش ارسال پاسخ
        if (isset($_POST['submit_reply']) && isset($_POST['reply_nonce'])) {
            $ticket_id = intval($_POST['ticket_id']);
            if (wp_verify_nonce($_POST['reply_nonce'], 'user_reply_ticket_' . $ticket_id)) {
                $this->process_reply($ticket_id);
            }
        }
        
        // پردازش بستن تیکت
        if (isset($_GET['close']) && is_numeric($_GET['close'])) {
            $close_id = intval($_GET['close']);
            global $wpdb;
            $wpdb->update($this->tickets_table, ['status' => 'closed'], ['id' => $close_id, 'user_id' => $user_id]);
            wp_redirect(remove_query_arg('close'));
            exit;
        }
        
        $ticket_id = isset($_GET['view']) ? intval($_GET['view']) : 0;
        
        if ($ticket_id) {
            $content = $this->render_single_ticket($ticket_id, $user_id);
        } else {
            $content = $this->render_ticket_list($user_id);
        }
        
        return $message . $content;
    }
    
    private function process_new_ticket()
    {
        global $wpdb;
        $user_id = get_current_user_id();
        
        // محدودیت تعداد تیکت‌های باز
        $open_tickets = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->tickets_table} WHERE user_id = %d AND status IN ('open', 'in_progress')",
            $user_id
        ));
        
        if ($open_tickets >= 5) {
            return __('شما بیش از ۵ تیکت باز دارید. لطفاً ابتدا تیکت‌های قدیمی را ببندید.', 'loginpro');
        }
        
        $title = sanitize_text_field($_POST['ticket_title']);
        $category = sanitize_text_field($_POST['ticket_category']);
        $priority = sanitize_text_field($_POST['ticket_priority']);
        $message = sanitize_textarea_field($_POST['ticket_message']);
        
        if (empty($title) || empty($message)) {
            return __('لطفاً عنوان و متن تیکت را وارد کنید.', 'loginpro');
        }
        
        // بررسی تیکت تکراری در 5 ثانیه اخیر
        $recent_ticket = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->tickets_table} 
            WHERE user_id = %d AND title = %s AND created_at > DATE_SUB(NOW(), INTERVAL 5 SECOND)",
            $user_id, $title
        ));
        
        if ($recent_ticket > 0) {
            return __('شما اخیراً یک تیکت با همین عنوان ثبت کرده‌اید.', 'loginpro');
        }
        
        $wpdb->insert($this->tickets_table, [
            'user_id' => $user_id,
            'title' => $title,
            'message' => $message,
            'category' => $category,
            'priority' => $priority,
            'status' => 'open',
            'created_at' => current_time('mysql')
        ]);
        
        $ticket_id = $wpdb->insert_id;
        
        if (!empty($_FILES['ticket_attachment']['tmp_name']) && $_FILES['ticket_attachment']['error'] === UPLOAD_ERR_OK) {
            $this->upload_attachment($_FILES['ticket_attachment'], $ticket_id, null, $user_id);
        }
        
        return true;
    }
    
    private function process_reply($ticket_id)
    {
        global $wpdb;
        $user_id = get_current_user_id();
        
        $message = sanitize_textarea_field($_POST['reply_message']);
        if (empty($message)) {
            return;
        }
        
        $wpdb->insert($this->replies_table, [
            'ticket_id' => $ticket_id,
            'user_id' => $user_id,
            'message' => $message,
            'is_admin' => 0,
            'created_at' => current_time('mysql')
        ]);
        
        $reply_id = $wpdb->insert_id;
        
        if (!empty($_FILES['reply_attachments']['tmp_name'][0])) {
            foreach ($_FILES['reply_attachments']['tmp_name'] as $i => $tmp_name) {
                if ($_FILES['reply_attachments']['error'][$i] === UPLOAD_ERR_OK) {
                    $file = [
                        'tmp_name' => $tmp_name,
                        'name' => $_FILES['reply_attachments']['name'][$i],
                        'size' => $_FILES['reply_attachments']['size'][$i]
                    ];
                    $this->upload_attachment($file, $ticket_id, $reply_id, $user_id);
                }
            }
        }
        
        wp_redirect(add_query_arg('view', $ticket_id));
        exit;
    }
    
    private function upload_attachment($file, $ticket_id, $reply_id, $user_id)
    {
        global $wpdb;
        
        $file_name = sanitize_file_name($file['name']);
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'txt', 'zip', 'rar'];
        $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowed) || $file['size'] > 5 * 1024 * 1024) {
            return false;
        }
        
        $unique_name = time() . '_' . wp_rand(1000, 9999) . '_' . $file_name;
        $upload_path = $this->upload_dir . $unique_name;
        
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            $wpdb->insert($this->attachments_table, [
                'ticket_id' => $ticket_id,
                'reply_id' => $reply_id,
                'user_id' => $user_id,
                'file_name' => $file_name,
                'file_path' => $upload_path,
                'file_size' => $file['size'],
                'created_at' => current_time('mysql')
            ]);
            return true;
        }
        return false;
    }
    
    private function render_single_ticket($ticket_id, $user_id)
    {
        global $wpdb;
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->tickets_table} WHERE id = %d AND user_id = %d",
            $ticket_id, $user_id
        ));
        
        if (!$ticket) {
            return '<div class="loginpro-error">❌ ' . esc_html__('تیکت یافت نشد یا دسترسی ندارید.', 'loginpro') . '</div>';
        }
        
        $replies = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->replies_table} WHERE ticket_id = %d ORDER BY created_at ASC",
            $ticket_id
        ));
        
        $attachments = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->attachments_table} WHERE ticket_id = %d AND reply_id IS NULL",
            $ticket_id
        ));
        
        ob_start();
        ?>
        <div class="loginpro-ticket-view">
            <div class="ticket-header">
                <h2><?php echo esc_html($ticket->title); ?></h2>
                <div class="ticket-meta">
                    <span class="status-<?php echo $ticket->status; ?>">
                        <?php echo $this->get_status_label($ticket->status); ?>
                    </span>
                    <span class="priority-<?php echo $ticket->priority; ?>">
                        <?php echo $this->get_priority_label($ticket->priority); ?>
                    </span>
                    <span class="ticket-date">📅 <?php echo date_i18n('j F Y ' . __('ساعت', 'loginpro') . ' H:i', strtotime($ticket->created_at)); ?></span>
                </div>
            </div>
            
            <div class="ticket-message">
                <div class="message-content">
                    <?php echo nl2br(esc_html($ticket->message)); ?>
                </div>
                <?php if ($attachments): ?>
                    <div class="ticket-attachments">
                        <strong><?php esc_html_e('📎 پیوست‌ها:', 'loginpro'); ?></strong>
                        <?php foreach ($attachments as $att): ?>
                            <a href="<?php echo admin_url('admin-ajax.php?action=loginpro_download_attachment&id=' . $att->id . '&_nonce=' . wp_create_nonce('download_' . $att->id)); ?>" class="attachment-link" download>
                                📄 <?php echo esc_html($att->file_name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if ($replies): ?>
                <div class="ticket-replies">
                    <h3><?php printf(esc_html__('💬 پاسخ‌ها (%d)', 'loginpro'), count($replies)); ?></h3>
                    <?php foreach ($replies as $reply): 
                        $reply_user = get_userdata($reply->user_id);
                    ?>
                        <div class="reply-item <?php echo $reply->is_admin ? 'admin-reply' : 'user-reply'; ?>">
                            <div class="reply-header">
                                <strong><?php echo $reply->is_admin ? esc_html__('👨‍💼 پشتیبانی', 'loginpro') : '👤 ' . esc_html($reply_user->display_name); ?></strong>
                                <span><?php echo date_i18n('j F Y ' . __('ساعت', 'loginpro') . ' H:i', strtotime($reply->created_at)); ?></span>
                            </div>
                            <div class="reply-content">
                                <?php echo nl2br(esc_html($reply->message)); ?>
                            </div>
                            <?php 
                            $reply_attachments = $wpdb->get_results($wpdb->prepare(
                                "SELECT * FROM {$this->attachments_table} WHERE reply_id = %d",
                                $reply->id
                            ));
                            if ($reply_attachments): ?>
                                <div class="reply-attachments">
                                    <?php foreach ($reply_attachments as $att): ?>
                                        <a href="<?php echo admin_url('admin-ajax.php?action=loginpro_download_attachment&id=' . $att->id . '&_nonce=' . wp_create_nonce('download_' . $att->id)); ?>" class="attachment-link" download>
                                            📎 <?php echo esc_html($att->file_name); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="ticket-no-replies">
                    <p>📭 <?php esc_html_e('هنوز پاسخی برای این تیکت ثبت نشده است.', 'loginpro'); ?></p>
                </div>
            <?php endif; ?>
            
            <?php if ($ticket->status !== 'closed'): ?>
                <div class="ticket-reply-form">
                    <h3><?php esc_html_e('✏️ ارسال پاسخ جدید', 'loginpro'); ?></h3>
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('user_reply_ticket_' . $ticket->id, 'reply_nonce'); ?>
                        <input type="hidden" name="ticket_id" value="<?php echo $ticket->id; ?>">
                        <textarea name="reply_message" placeholder="<?php esc_attr_e('پاسخ خود را وارد کنید...', 'loginpro'); ?>" required></textarea>
                        <div class="form-row">
                            <div class="file-upload-area">
                                <label><?php esc_html_e('📎 پیوست فایل (اختیاری)', 'loginpro'); ?></label>
                                <input type="file" name="reply_attachments[]" multiple>
                                <small><?php esc_html_e('حداکثر 5 مگابایت - jpg, png, pdf, doc, zip', 'loginpro'); ?></small>
                            </div>
                            <button type="submit" name="submit_reply" class="loginpro-submit-btn"><?php esc_html_e('📨 ارسال پاسخ', 'loginpro'); ?></button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
            
            <div class="ticket-actions">
                <a href="<?php echo remove_query_arg('view'); ?>" class="loginpro-back-btn">🔙 <?php esc_html_e('بازگشت به لیست تیکت‌ها', 'loginpro'); ?></a>
                <?php if ($ticket->status !== 'closed'): ?>
                    <a href="<?php echo add_query_arg('close', $ticket->id); ?>" class="loginpro-close-btn" onclick="return confirm('<?php echo esc_js(__('آیا از بستن این تیکت مطمئن هستید؟', 'loginpro')); ?>')">🔒 <?php esc_html_e('بستن تیکت', 'loginpro'); ?></a>
                <?php endif; ?>
            </div>
        </div>
        
        <style>
            .loginpro-ticket-view {
                max-width: 800px;
                margin: 30px auto;
                padding: 25px;
                background: #fff;
                border-radius: 16px;
                box-shadow: 0 5px 20px rgba(0,0,0,0.08);
                direction: rtl;
                text-align: right;
            }
            .ticket-header {
                border-bottom: 2px solid #f0f0f0;
                padding-bottom: 15px;
                margin-bottom: 20px;
            }
            .ticket-header h2 { margin: 0 0 10px 0; font-size: 22px; }
            .ticket-meta { display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
            .ticket-meta span { padding: 4px 14px; border-radius: 20px; font-size: 13px; }
            .status-open { background: #fff3cd; color: #856404; }
            .status-in_progress { background: #cfe2ff; color: #084298; }
            .status-closed { background: #d1e7dd; color: #0f5132; }
            .priority-high { background: #f8d7da; color: #721c24; }
            .priority-normal { background: #fff3cd; color: #856404; }
            .priority-low { background: #d1e7dd; color: #0f5132; }
            .ticket-date { background: #f0f0f0; padding: 4px 14px; border-radius: 20px; font-size: 13px; }
            
            .ticket-message {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 12px;
                margin-bottom: 25px;
            }
            .message-content { line-height: 1.8; }
            .ticket-attachments { margin-top: 15px; }
            .ticket-attachments strong { display: block; margin-bottom: 8px; }
            
            .attachment-link {
                display: inline-block;
                margin: 5px 5px 5px 0;
                padding: 5px 14px;
                background: #e9ecef;
                border-radius: 15px;
                text-decoration: none;
                color: #333;
                font-size: 13px;
                transition: all 0.2s;
            }
            .attachment-link:hover { background: #dee2e6; color: #000; }
            
            .ticket-replies { margin-bottom: 25px; }
            .ticket-replies h3 { margin-bottom: 15px; }
            
            .reply-item {
                padding: 15px 20px;
                border-radius: 12px;
                margin-bottom: 15px;
                border-right: 4px solid #ddd;
            }
            .reply-item.admin-reply {
                background: #e3f2fd;
                border-right-color: #2196f3;
            }
            .reply-item.user-reply {
                background: #f5f5f5;
                border-right-color: #9e9e9e;
            }
            .reply-header {
                display: flex;
                justify-content: space-between;
                margin-bottom: 10px;
                font-size: 14px;
                flex-wrap: wrap;
                gap: 5px;
            }
            .reply-content { line-height: 1.8; }
            .reply-attachments { margin-top: 10px; }
            
            .ticket-no-replies {
                text-align: center;
                padding: 20px;
                background: #f8f9fa;
                border-radius: 12px;
                margin-bottom: 25px;
                color: #666;
            }
            
            .ticket-reply-form {
                margin-top: 25px;
                padding-top: 20px;
                border-top: 2px solid #f0f0f0;
            }
            .ticket-reply-form h3 { margin-bottom: 15px; }
            .ticket-reply-form textarea {
                width: 100%;
                min-height: 120px;
                padding: 12px 15px;
                border: 1px solid #ddd;
                border-radius: 8px;
                margin-bottom: 15px;
                font-family: inherit;
                resize: vertical;
                box-sizing: border-box;
                font-size: 14px;
            }
            .ticket-reply-form textarea:focus {
                border-color: #2196f3;
                outline: none;
                box-shadow: 0 0 0 3px rgba(33,150,243,0.1);
            }
            .form-row {
                display: flex;
                gap: 15px;
                flex-wrap: wrap;
                align-items: center;
            }
            .file-upload-area {
                flex: 1;
                min-width: 200px;
            }
            .file-upload-area label {
                display: block;
                font-weight: 600;
                margin-bottom: 5px;
                font-size: 14px;
            }
            .file-upload-area input[type="file"] {
                width: 100%;
                padding: 8px;
                border: 1px dashed #ddd;
                border-radius: 8px;
                background: #fafafa;
            }
            .file-upload-area small {
                display: block;
                color: #666;
                font-size: 12px;
                margin-top: 5px;
            }
            
            .loginpro-submit-btn {
                background: #28a745;
                color: #fff;
                border: none;
                padding: 10px 30px;
                border-radius: 8px;
                cursor: pointer;
                font-size: 14px;
                transition: all 0.2s;
                height: 42px;
            }
            .loginpro-submit-btn:hover { opacity: 0.85; transform: scale(1.02); }
            
            .ticket-actions {
                display: flex;
                gap: 15px;
                flex-wrap: wrap;
                margin-top: 20px;
                padding-top: 20px;
                border-top: 2px solid #f0f0f0;
            }
            .loginpro-back-btn {
                display: inline-block;
                padding: 8px 20px;
                background: #f0f0f0;
                color: #333;
                text-decoration: none;
                border-radius: 8px;
                transition: all 0.2s;
            }
            .loginpro-back-btn:hover { background: #e0e0e0; }
            
            .loginpro-close-btn {
                display: inline-block;
                padding: 8px 20px;
                background: #dc3545;
                color: #fff;
                text-decoration: none;
                border-radius: 8px;
                transition: all 0.2s;
            }
            .loginpro-close-btn:hover { opacity: 0.85; }
            
            .loginpro-error {
                max-width: 800px;
                margin: 10px auto;
                padding: 15px 20px;
                background: #f8d7da;
                color: #721c24;
                border-radius: 12px;
                text-align: center;
                border-right: 4px solid #dc3545;
            }
            .loginpro-success {
                max-width: 800px;
                margin: 10px auto;
                padding: 15px 20px;
                background: #d4edda;
                color: #155724;
                border-radius: 12px;
                text-align: center;
                border-right: 4px solid #28a745;
            }
            
            @media (max-width: 600px) {
                .loginpro-ticket-view { padding: 15px; margin: 15px; }
                .ticket-meta { gap: 8px; }
                .ticket-meta span { font-size: 12px; padding: 3px 10px; }
                .reply-header { flex-direction: column; gap: 5px; }
                .form-row { flex-direction: column; }
                .file-upload-area { width: 100%; }
                .loginpro-submit-btn { width: 100%; justify-content: center; }
                .ticket-actions { flex-direction: column; }
                .ticket-actions a { text-align: center; }
            }
        </style>
        <?php
        return ob_get_clean();
    }
    
    private function render_ticket_list($user_id)
    {
        global $wpdb;
        
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
        
        $status_where = '';
        if ($status_filter !== 'all') {
            $status_where = $wpdb->prepare(" AND status = %s", $status_filter);
        }
        
        $tickets = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->tickets_table} WHERE user_id = %d {$status_where} ORDER BY 
                CASE WHEN status = 'open' THEN 1 WHEN status = 'in_progress' THEN 2 ELSE 3 END,
                created_at DESC",
            $user_id
        ));
        
        $stats = [
            'open' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->tickets_table} WHERE user_id = %d AND status = 'open'", $user_id)),
            'in_progress' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->tickets_table} WHERE user_id = %d AND status = 'in_progress'", $user_id)),
            'closed' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->tickets_table} WHERE user_id = %d AND status = 'closed'", $user_id)),
            'total' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->tickets_table} WHERE user_id = %d", $user_id))
        ];
        
        ob_start();
        ?>
        <div class="loginpro-tickets-list">
            <div class="list-header">
                <h2><?php esc_html_e('🎫 تیکت‌های پشتیبانی', 'loginpro'); ?></h2>
                <a href="<?php echo add_query_arg('new', '1'); ?>" class="loginpro-new-ticket-btn"><?php esc_html_e('➕ تیکت جدید', 'loginpro'); ?></a>
            </div>
            
            <div class="ticket-stats">
                <div class="stat-box <?php echo $status_filter == 'all' ? 'active' : ''; ?>" onclick="window.location.href='<?php echo remove_query_arg('status'); ?>'">
                    <div class="stat-number"><?php echo $stats['total']; ?></div>
                    <div class="stat-label">📊 <?php esc_html_e('همه', 'loginpro'); ?></div>
                </div>
                <div class="stat-box open <?php echo $status_filter == 'open' ? 'active' : ''; ?>" onclick="window.location.href='<?php echo add_query_arg('status', 'open'); ?>'">
                    <div class="stat-number"><?php echo $stats['open']; ?></div>
                    <div class="stat-label">🟡 <?php esc_html_e('باز', 'loginpro'); ?></div>
                </div>
                <div class="stat-box in_progress <?php echo $status_filter == 'in_progress' ? 'active' : ''; ?>" onclick="window.location.href='<?php echo add_query_arg('status', 'in_progress'); ?>'">
                    <div class="stat-number"><?php echo $stats['in_progress']; ?></div>
                    <div class="stat-label">🔵 <?php esc_html_e('در حال بررسی', 'loginpro'); ?></div>
                </div>
                <div class="stat-box closed <?php echo $status_filter == 'closed' ? 'active' : ''; ?>" onclick="window.location.href='<?php echo add_query_arg('status', 'closed'); ?>'">
                    <div class="stat-number"><?php echo $stats['closed']; ?></div>
                    <div class="stat-label">✅ <?php esc_html_e('بسته', 'loginpro'); ?></div>
                </div>
            </div>
            
            <?php if (isset($_GET['new'])): ?>
                <?php echo $this->render_new_ticket_form(); ?>
            <?php endif; ?>
            
            <?php if (empty($tickets)): ?>
                <div class="loginpro-empty">
                    <p>📭 <?php esc_html_e('شما هیچ تیکتی ثبت نکرده‌اید.', 'loginpro'); ?></p>
                    <a href="<?php echo add_query_arg('new', '1'); ?>" class="loginpro-submit-btn"><?php esc_html_e('➕ ثبت تیکت جدید', 'loginpro'); ?></a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="loginpro-tickets-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php esc_html_e('عنوان', 'loginpro'); ?></th>
                                <th><?php esc_html_e('وضعیت', 'loginpro'); ?></th>
                                <th><?php esc_html_e('اولویت', 'loginpro'); ?></th>
                                <th><?php esc_html_e('تاریخ', 'loginpro'); ?></th>
                                <th><?php esc_html_e('عملیات', 'loginpro'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $ticket): ?>
                                <tr>
                                    <td>#<?php echo $ticket->id; ?></td>
                                    <td><?php echo esc_html($ticket->title); ?></td>
                                    <td><?php echo $this->get_status_label($ticket->status); ?></td>
                                    <td><?php echo $this->get_priority_label($ticket->priority); ?></td>
                                    <td><?php echo date_i18n('j F Y', strtotime($ticket->created_at)); ?></td>
                                    <td>
                                        <a href="<?php echo add_query_arg('view', $ticket->id); ?>" class="view-link">🔍 <?php esc_html_e('مشاهده', 'loginpro'); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        
        <style>
            .loginpro-tickets-list {
                max-width: 800px;
                margin: 30px auto;
                padding: 25px;
                background: #fff;
                border-radius: 16px;
                box-shadow: 0 5px 20px rgba(0,0,0,0.08);
                direction: rtl;
                text-align: right;
            }
            .list-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
                flex-wrap: wrap;
                gap: 10px;
            }
            .list-header h2 { margin: 0; font-size: 22px; }
            
            .loginpro-new-ticket-btn {
                background: #28a745;
                color: #fff;
                padding: 8px 20px;
                border-radius: 8px;
                text-decoration: none;
                font-size: 14px;
                transition: all 0.2s;
                display: inline-block;
            }
            .loginpro-new-ticket-btn:hover { opacity: 0.85; transform: scale(1.02); }
            
            .ticket-stats {
                display: flex;
                gap: 15px;
                flex-wrap: wrap;
                margin-bottom: 25px;
            }
            .stat-box {
                flex: 1;
                min-width: 80px;
                padding: 12px 15px;
                background: #f8f9fa;
                border-radius: 12px;
                text-align: center;
                cursor: pointer;
                transition: all 0.2s;
                border-bottom: 3px solid transparent;
            }
            .stat-box:hover { background: #e9ecef; }
            .stat-box.active {
                background: #e3f2fd;
                border-bottom-color: #2196f3;
            }
            .stat-box.open.active { border-bottom-color: #ff9800; background: #fff3cd; }
            .stat-box.in_progress.active { border-bottom-color: #2196f3; background: #cfe2ff; }
            .stat-box.closed.active { border-bottom-color: #28a745; background: #d1e7dd; }
            
            .stat-number { font-size: 28px; font-weight: bold; }
            .stat-label { font-size: 13px; color: #666; margin-top: 3px; }
            
            .table-responsive { overflow-x: auto; }
            
            .loginpro-tickets-table {
                width: 100%;
                border-collapse: collapse;
            }
            .loginpro-tickets-table th {
                text-align: right;
                padding: 12px;
                border-bottom: 2px solid #f0f0f0;
                font-weight: 600;
                font-size: 14px;
            }
            .loginpro-tickets-table td {
                padding: 12px;
                border-bottom: 1px solid #f0f0f0;
                vertical-align: middle;
                font-size: 14px;
            }
            .loginpro-tickets-table tr:hover { background: #fafafa; }
            .view-link {
                color: #2271b1;
                text-decoration: none;
                font-weight: 500;
            }
            .view-link:hover { text-decoration: underline; }
            
            .loginpro-empty {
                text-align: center;
                padding: 40px 20px;
            }
            .loginpro-empty p { color: #666; margin-bottom: 15px; font-size: 16px; }
            
            .ticket-form {
                background: #f8f9fa;
                padding: 25px;
                border-radius: 12px;
                margin-bottom: 25px;
                border: 2px dashed #ddd;
            }
            .ticket-form h3 { margin-top: 0; margin-bottom: 20px; }
            .ticket-form .form-group {
                margin-bottom: 15px;
            }
            .ticket-form label {
                display: block;
                font-weight: 600;
                margin-bottom: 5px;
                font-size: 14px;
            }
            .ticket-form .required { color: #dc3545; }
            .ticket-form input[type="text"],
            .ticket-form select,
            .ticket-form textarea {
                width: 100%;
                padding: 10px 12px;
                border: 1px solid #ddd;
                border-radius: 8px;
                box-sizing: border-box;
                font-size: 14px;
                font-family: inherit;
                transition: all 0.2s;
            }
            .ticket-form input[type="text"]:focus,
            .ticket-form select:focus,
            .ticket-form textarea:focus {
                border-color: #2196f3;
                outline: none;
                box-shadow: 0 0 0 3px rgba(33,150,243,0.1);
            }
            .ticket-form textarea {
                min-height: 120px;
                resize: vertical;
            }
            .ticket-form .form-row {
                display: flex;
                gap: 15px;
                flex-wrap: wrap;
            }
            .ticket-form .form-row .half {
                flex: 1;
                min-width: 150px;
            }
            .ticket-form input[type="file"] {
                width: 100%;
                padding: 8px;
                border: 1px dashed #ddd;
                border-radius: 8px;
                background: #fff;
            }
            .ticket-form small {
                display: block;
                color: #666;
                font-size: 12px;
                margin-top: 5px;
            }
            .ticket-form .form-actions {
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
                margin-top: 10px;
            }
            .ticket-form .cancel-btn {
                background: #dc3545;
                color: #fff;
                border: none;
                padding: 10px 25px;
                border-radius: 8px;
                cursor: pointer;
                font-size: 14px;
                text-decoration: none;
                display: inline-block;
                transition: all 0.2s;
            }
            .ticket-form .cancel-btn:hover { opacity: 0.85; }
            
            @media (max-width: 600px) {
                .loginpro-tickets-list { padding: 15px; margin: 15px; }
                .list-header { flex-direction: column; align-items: stretch; text-align: center; }
                .loginpro-new-ticket-btn { text-align: center; }
                .stat-box { min-width: 60px; padding: 10px; }
                .stat-number { font-size: 22px; }
                .loginpro-tickets-table th,
                .loginpro-tickets-table td { padding: 8px 6px; font-size: 12px; }
                .ticket-form { padding: 15px; }
                .ticket-form .form-row { flex-direction: column; }
                .ticket-form .form-row .half { min-width: unset; }
                .ticket-form .form-actions { flex-direction: column; }
                .ticket-form .form-actions button,
                .ticket-form .form-actions a { width: 100%; text-align: center; }
            }
        </style>
        <?php
        return ob_get_clean();
    }
    
    public function render_new_ticket_form()
    {
        ob_start();
        ?>
        <div class="ticket-form">
            <h3><?php esc_html_e('📝 ثبت تیکت جدید', 'loginpro'); ?></h3>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('new_ticket', 'ticket_nonce'); ?>
                
                <div class="form-group">
                    <label><?php esc_html_e('عنوان تیکت', 'loginpro'); ?> <span class="required">*</span></label>
                    <input type="text" name="ticket_title" placeholder="<?php esc_attr_e('عنوان تیکت را وارد کنید...', 'loginpro'); ?>" required>
                </div>
                
                <div class="form-row">
                    <div class="half form-group">
                        <label><?php esc_html_e('بخش مربوطه', 'loginpro'); ?></label>
                        <select name="ticket_category">
                            <option value="general"><?php esc_html_e('عمومی', 'loginpro'); ?></option>
                            <option value="technical"><?php esc_html_e('فنی', 'loginpro'); ?></option>
                            <option value="billing"><?php esc_html_e('صورتحساب', 'loginpro'); ?></option>
                            <option value="support"><?php esc_html_e('پشتیبانی', 'loginpro'); ?></option>
                            <option value="sales"><?php esc_html_e('فروش', 'loginpro'); ?></option>
                        </select>
                    </div>
                    <div class="half form-group">
                        <label><?php esc_html_e('اولویت', 'loginpro'); ?></label>
                        <select name="ticket_priority">
                            <option value="low">🟢 <?php esc_html_e('پایین', 'loginpro'); ?></option>
                            <option value="normal" selected>🟠 <?php esc_html_e('معمولی', 'loginpro'); ?></option>
                            <option value="high">🔴 <?php esc_html_e('بالا', 'loginpro'); ?></option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label><?php esc_html_e('متن تیکت', 'loginpro'); ?> <span class="required">*</span></label>
                    <textarea name="ticket_message" placeholder="<?php esc_attr_e('مشکل خود را به طور کامل توضیح دهید...', 'loginpro'); ?>" required></textarea>
                </div>
                
                <div class="form-group">
                    <label><?php esc_html_e('📎 پیوست (اختیاری)', 'loginpro'); ?></label>
                    <input type="file" name="ticket_attachment">
                    <small><?php esc_html_e('حداکثر 5 مگابایت - فرمت‌های مجاز: jpg, png, pdf, doc, zip', 'loginpro'); ?></small>
                </div>
                
                <div class="form-actions">
                    <a href="<?php echo remove_query_arg('new'); ?>" class="cancel-btn">❌ <?php esc_html_e('انصراف', 'loginpro'); ?></a>
                    <button type="submit" name="submit_new_ticket" class="loginpro-submit-btn"><?php esc_html_e('📨 ثبت تیکت', 'loginpro'); ?></button>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function get_status_label($status)
    {
        $labels = [
            'open' => '<span class="status-open">🟡 ' . __('باز', 'loginpro') . '</span>',
            'in_progress' => '<span class="status-in_progress">🔵 ' . __('در حال بررسی', 'loginpro') . '</span>',
            'closed' => '<span class="status-closed">✅ ' . __('بسته', 'loginpro') . '</span>'
        ];
        return $labels[$status] ?? $status;
    }
    
    private function get_priority_label($priority)
    {
        $labels = [
            'high' => '<span class="priority-high">🔴 ' . __('بالا', 'loginpro') . '</span>',
            'normal' => '<span class="priority-normal">🟠 ' . __('معمولی', 'loginpro') . '</span>',
            'low' => '<span class="priority-low">🟢 ' . __('پایین', 'loginpro') . '</span>'
        ];
        return $labels[$priority] ?? $priority;
    }
}