<?php
namespace LoginPro\Admin;

class CaptchaPage
{
    private $container;

    public function __construct($container = null)
    {
        $this->container = $container;
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('loginpro_captcha_settings')) {
            $this->saveSettings();
        }
        
        $selected = get_option('loginpro_captcha_provider', 'recaptcha');
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1>تنظیمات کپچا</h1>
            <p class="loginpro-description">محافظت از فرم‌ها در برابر اسپم و ربات‌ها</p>
            
            <form method="post">
                <?php wp_nonce_field('loginpro_captcha_settings'); ?>
                
                <div class="loginpro-admin-card">
                    <h3>🔒 تنظیمات عمومی کپچا</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>فعال کردن کپچا</label></td>
                            <td>
                                <label class="loginpro-checkbox-label"><input type="checkbox" name="captcha_enabled" value="1" <?php checked(get_option('loginpro_captcha_enabled', false), true); ?>> فعال کردن کپچا در فرم‌های ورود و ثبت‌نام</label>
                             </td>
                        </tr>
                        <tr>
                            <td><label>سرویس کپچا</label></td>
                            <td>
                                <select name="captcha_provider" id="provider_select" class="loginpro-select">
                                    <option value="recaptcha" <?php selected($selected, 'recaptcha'); ?>>Google reCAPTCHA v2/v3</option>
                                    <option value="hcaptcha" <?php selected($selected, 'hcaptcha'); ?>>hCaptcha</option>
                                    <option value="turnstile" <?php selected($selected, 'turnstile'); ?>>Cloudflare Turnstile</option>
                                    <option value="math" <?php selected($selected, 'math'); ?>>Math Captcha (ساده)</option>
                                </select>
                             </td>
                        </tr>
                    </table>
                </div>
                
                <div id="recaptcha_box" class="provider_box loginpro-admin-card" <?php echo $selected != 'recaptcha' ? 'style="display:none;"' : ''; ?>>
                    <h3>✅ تنظیمات Google reCAPTCHA</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>نوع reCAPTCHA</label></td>
                            <td>
                                <select name="recaptcha_type" id="recaptcha_type" class="loginpro-select">
                                    <option value="v2" <?php selected(get_option('loginpro_recaptcha_type', 'v3'), 'v2'); ?>>reCAPTCHA v2 (چک‌باکس)</option>
                                    <option value="v3" <?php selected(get_option('loginpro_recaptcha_type', 'v3'), 'v3'); ?>>reCAPTCHA v3 (نامرئی)</option>
                                </select>
                             </td>
                        </tr>
                        <tr>
                            <td><label>کلید سایت (Site Key)</label></td>
                            <td><input type="text" name="site_key" value="<?php echo esc_attr(get_option('loginpro_captcha_site_key', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"></td>
                        </tr>
                        <tr>
                            <td><label>کلید مخفی (Secret Key)</label></td>
                            <td><input type="password" name="secret_key" value="<?php echo esc_attr(get_option('loginpro_captcha_secret_key', '')); ?>" class="loginpro-input loginpro-input-full"></td>
                        </tr>
                        <tr>
                            <td id="score_threshold_row"><label>آستانه امتیاز (Score Threshold)</label></td>
                            <td>
                                <input type="number" name="threshold" step="0.1" min="0" max="1" value="<?php echo esc_attr(get_option('loginpro_captcha_threshold', 0.5)); ?>" class="loginpro-input-small">
                                <p class="loginpro-help-text">حداقل امتیاز مورد نیاز (0.0 تا 1.0) - فقط برای نسخه v3</p>
                             </td>
                        </tr>
                    </table>
                </div>
                
                <div id="hcaptcha_box" class="provider_box loginpro-admin-card" <?php echo $selected != 'hcaptcha' ? 'style="display:none;"' : ''; ?>>
                    <h3>✅ تنظیمات hCaptcha</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>کلید سایت (Site Key)</label></td>
                            <td><input type="text" name="hcaptcha_site_key" value="<?php echo esc_attr(get_option('loginpro_hcaptcha_site_key', '')); ?>" class="loginpro-input loginpro-input-full"></td>
                        </tr>
                        <tr>
                            <td><label>کلید مخفی (Secret Key)</label></td>
                            <td><input type="password" name="hcaptcha_secret_key" value="<?php echo esc_attr(get_option('loginpro_hcaptcha_secret_key', '')); ?>" class="loginpro-input loginpro-input-full"></td>
                        </tr>
                    </table>
                </div>
                
                <div id="turnstile_box" class="provider_box loginpro-admin-card" <?php echo $selected != 'turnstile' ? 'style="display:none;"' : ''; ?>>
                    <h3>✅ تنظیمات Cloudflare Turnstile</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>کلید سایت (Site Key)</label></td>
                            <td><input type="text" name="turnstile_site_key" value="<?php echo esc_attr(get_option('loginpro_turnstile_site_key', '')); ?>" class="loginpro-input loginpro-input-full"></td>
                        </tr>
                        <tr>
                            <td><label>کلید مخفی (Secret Key)</label></td>
                            <td><input type="password" name="turnstile_secret_key" value="<?php echo esc_attr(get_option('loginpro_turnstile_secret_key', '')); ?>" class="loginpro-input loginpro-input-full"></td>
                        </tr>
                    </table>
                </div>
                
                <div id="math_box" class="provider_box loginpro-admin-card" <?php echo $selected != 'math' ? 'style="display:none;"' : ''; ?>>
                    <h3>✅ تنظیمات Math Captcha</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>محدوده اعداد</label></td>
                            <td>
                                <input type="number" name="math_min" value="<?php echo esc_attr(get_option('loginpro_math_min', 1)); ?>" class="loginpro-input-small"> تا 
                                <input type="number" name="math_max" value="<?php echo esc_attr(get_option('loginpro_math_max', 10)); ?>" class="loginpro-input-small">
                             </td>
                        </tr>
                        <tr>
                            <td><label>عملیات‌ها</label></td>
                            <td>
                                <label class="loginpro-checkbox-label"><input type="checkbox" name="math_addition" value="1" <?php checked(get_option('loginpro_math_addition', true), true); ?>> جمع (+)</label>
                                <label class="loginpro-checkbox-label"><input type="checkbox" name="math_subtraction" value="1" <?php checked(get_option('loginpro_math_subtraction', false), true); ?>> تفریق (-)</label>
                             </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h3>📍 مکان‌های نمایش کپچا</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>نمایش در فرم ورود</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="show_on_login" value="1" <?php checked(get_option('loginpro_captcha_show_on_login', true), true); ?>> نمایش کپچا در فرم ورود</label></td>
                        </tr>
                        <tr>
                            <td><label>نمایش در فرم ثبت‌نام</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="show_on_register" value="1" <?php checked(get_option('loginpro_captcha_show_on_register', true), true); ?>> نمایش کپچا در فرم ثبت‌نام</label></td>
                        </tr>
                        <tr>
                            <td><label>نمایش در فرم بازنشانی رمز</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="show_on_reset" value="1" <?php checked(get_option('loginpro_captcha_show_on_reset', true), true); ?>> نمایش کپچا در فرم بازنشانی رمز عبور</label></td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h3>⚙️ تنظیمات پیشرفته</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>نمایش بعد از تلاش ناموفق</label></td>
                            <td>
                                <input type="number" name="show_after_attempts" value="<?php echo esc_attr(get_option('loginpro_captcha_show_after_attempts', 3)); ?>" class="loginpro-input-small"> تلاش
                                <p class="loginpro-help-text">نمایش کپچا بعد از این تعداد تلاش ناموفق (0 = همیشه)</p>
                             </td>
                        </tr>
                        <tr>
                            <td><label>تم کپچا</label></td>
                            <td>
                                <select name="captcha_theme" class="loginpro-select">
                                    <option value="light" <?php selected(get_option('loginpro_captcha_theme', 'light'), 'light'); ?>>روشن</option>
                                    <option value="dark" <?php selected(get_option('loginpro_captcha_theme', 'light'), 'dark'); ?>>تیره</option>
                                </select>
                             </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-form-actions">
                    <button type="submit" name="save_captcha_settings" class="button button-primary button-large">💾 ذخیره تنظیمات کپچا</button>
                </div>
            </form>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#provider_select').on('change', function() {
                var val = $(this).val();
                $('.provider_box').hide();
                $('#' + val + '_box').show();
            });
            
            $('#recaptcha_type').on('change', function() {
                if ($(this).val() === 'v3') {
                    $('#score_threshold_row').show();
                } else {
                    $('#score_threshold_row').hide();
                }
            });
            
            if ($('#recaptcha_type').val() !== 'v3') {
                $('#score_threshold_row').hide();
            }
        });
        </script>
        <?php
    }
    
    private function saveSettings() {
        update_option('loginpro_captcha_enabled', isset($_POST['captcha_enabled']));
        update_option('loginpro_captcha_provider', sanitize_text_field($_POST['captcha_provider']));
        update_option('loginpro_captcha_site_key', sanitize_text_field($_POST['site_key']));
        update_option('loginpro_captcha_secret_key', sanitize_text_field($_POST['secret_key']));
        update_option('loginpro_captcha_threshold', (float) $_POST['threshold']);
        update_option('loginpro_recaptcha_type', sanitize_text_field($_POST['recaptcha_type']));
        update_option('loginpro_hcaptcha_site_key', sanitize_text_field($_POST['hcaptcha_site_key']));
        update_option('loginpro_hcaptcha_secret_key', sanitize_text_field($_POST['hcaptcha_secret_key']));
        update_option('loginpro_turnstile_site_key', sanitize_text_field($_POST['turnstile_site_key']));
        update_option('loginpro_turnstile_secret_key', sanitize_text_field($_POST['turnstile_secret_key']));
        update_option('loginpro_math_min', (int) $_POST['math_min']);
        update_option('loginpro_math_max', (int) $_POST['math_max']);
        update_option('loginpro_math_addition', isset($_POST['math_addition']));
        update_option('loginpro_math_subtraction', isset($_POST['math_subtraction']));
        update_option('loginpro_captcha_show_on_login', isset($_POST['show_on_login']));
        update_option('loginpro_captcha_show_on_register', isset($_POST['show_on_register']));
        update_option('loginpro_captcha_show_on_reset', isset($_POST['show_on_reset']));
        update_option('loginpro_captcha_show_after_attempts', (int) $_POST['show_after_attempts']);
        update_option('loginpro_captcha_theme', sanitize_text_field($_POST['captcha_theme']));
        
        echo '<div class="notice notice-success"><p>تنظیمات کپچا با موفقیت ذخیره شد.</p></div>';
    }
}