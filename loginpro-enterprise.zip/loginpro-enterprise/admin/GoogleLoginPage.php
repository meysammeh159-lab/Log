<?php
namespace LoginPro\Admin;

class GoogleLoginPage
{
    private $container;

    public function __construct($container = null)
    {
        $this->container = $container;
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('loginpro_google_settings')) {
            $this->saveSettings();
        }
        
        $enabled = get_option('loginpro_google_enabled', false);
        $clientId = get_option('loginpro_google_client_id', '');
        $clientSecret = get_option('loginpro_google_client_secret', '');
        $redirectUri = get_option('loginpro_google_redirect_uri', home_url('/?loginpro_google_callback=1'));
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1>تنظیمات ورود با گوگل</h1>
            <p class="loginpro-description">تنظیمات احراز هویت گوگل OAuth برای ورود با حساب گوگل</p>
            
            <?php if (!$clientId || !$clientSecret): ?>
                <div class="notice notice-warning"><p>لطفاً اطلاعات credentials خود را از کنسول گوگل وارد کنید.</p></div>
            <?php endif; ?>
            
            <form method="post">
                <?php wp_nonce_field('loginpro_google_settings'); ?>
                
                <div class="loginpro-admin-card">
                    <h3>🔐 تنظیمات OAuth گوگل</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>فعال کردن ورود با گوگل</label></td>
                            <td>
                                <label class="loginpro-checkbox-label"><input type="checkbox" name="google_enabled" value="1" <?php checked($enabled, true); ?>> فعال کردن ورود با گوگل</label>
                             </td>
                        </tr>
                        <tr>
                            <td><label>شناسه کاربری (Client ID)</label></td>
                            <td><input type="text" name="client_id" value="<?php echo esc_attr($clientId); ?>" class="loginpro-input loginpro-input-full" placeholder="xxxxxxxxxxxxxxxx.apps.googleusercontent.com"></td>
                        </tr>
                        <tr>
                            <td><label>کلید مخفی (Client Secret)</label></td>
                            <td><input type="password" name="client_secret" value="<?php echo esc_attr($clientSecret); ?>" class="loginpro-input loginpro-input-full" placeholder="GOCSPX-xxxxxxxxxxxxxxxx"></td>
                        </tr>
                        <tr>
                            <td><label>آدرس بازگشت (Redirect URI)</label></td>
                            <td>
                                <input type="url" name="redirect_uri" value="<?php echo esc_attr($redirectUri); ?>" class="loginpro-input loginpro-input-full">
                                <p class="loginpro-help-text">این آدرس را در کنسول گوگل در بخش Authorized redirect URIs اضافه کنید</p>
                             </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h3>👤 تنظیمات حساب کاربری</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>ساخت خودکار حساب</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="auto_create" value="1" <?php checked(get_option('loginpro_google_auto_create', true), true); ?>> ایجاد خودکار حساب برای کاربران جدید گوگل</label></td>
                        </tr>
                        <tr>
                            <td><label>اتصال حساب</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="account_linking" value="1" <?php checked(get_option('loginpro_google_account_linking', true), true); ?>> اجازه اتصال حساب گوگل به حساب موجود</label></td>
                        </tr>
                        <tr>
                            <td><label>نقش پیش‌فرض کاربر</label></td>
                            <td><select name="default_role" class="loginpro-select"><?php wp_dropdown_roles(get_option('loginpro_google_default_role', 'subscriber')); ?></select></td>
                        </tr>
                        <tr>
                            <td><label>نیاز به تأیید ایمیل</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="require_verification" value="1" <?php checked(get_option('loginpro_google_require_verification', false), true); ?>> فقط اجازه ورود در صورت تأیید ایمیل گوگل</label></td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h3>🎨 ظاهر دکمه</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>متن دکمه</label></td>
                            <td><input type="text" name="button_text" value="<?php echo esc_attr(get_option('loginpro_google_button_text', 'ورود با گوگل')); ?>" class="loginpro-input loginpro-input-full"></td>
                        </tr>
                        <tr>
                            <td><label>تم دکمه</label></td>
                            <td>
                                <select name="button_theme" class="loginpro-select">
                                    <option value="light" <?php selected(get_option('loginpro_google_button_theme', 'light'), 'light'); ?>>روشن</option>
                                    <option value="dark" <?php selected(get_option('loginpro_google_button_theme', 'light'), 'dark'); ?>>تیره</option>
                                    <option value="outline" <?php selected(get_option('loginpro_google_button_theme', 'light'), 'outline'); ?>>حاشیه‌ای</option>
                                </select>
                             </td>
                        </tr>
                        <tr>
                            <td><label>اندازه دکمه</label></td>
                            <td>
                                <select name="button_size" class="loginpro-select">
                                    <option value="small" <?php selected(get_option('loginpro_google_button_size', 'medium'), 'small'); ?>>کوچک</option>
                                    <option value="medium" <?php selected(get_option('loginpro_google_button_size', 'medium'), 'medium'); ?>>متوسط</option>
                                    <option value="large" <?php selected(get_option('loginpro_google_button_size', 'medium'), 'large'); ?>>بزرگ</option>
                                </select>
                             </td>
                        </tr>
                        <tr>
                            <td><label>شکل دکمه</label></td>
                            <td>
                                <select name="button_shape" class="loginpro-select">
                                    <option value="square" <?php selected(get_option('loginpro_google_button_shape', 'square'), 'square'); ?>>مربع</option>
                                    <option value="pill" <?php selected(get_option('loginpro_google_button_shape', 'square'), 'pill'); ?>>کپسولی</option>
                                    <option value="circle" <?php selected(get_option('loginpro_google_button_shape', 'square'), 'circle'); ?>>دایره</option>
                                </select>
                             </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h3>📍 مکان‌های نمایش</h3>
                    <table class="loginpro-admin-table">
                        <tr>
                            <td><label>نمایش در فرم ورود</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="show_on_login" value="1" <?php checked(get_option('loginpro_google_show_on_login', true), true); ?>> نمایش دکمه گوگل در فرم ورود</label></td>
                        </tr>
                        <tr>
                            <td><label>نمایش در فرم ثبت‌نام</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="show_on_register" value="1" <?php checked(get_option('loginpro_google_show_on_register', true), true); ?>> نمایش دکمه گوگل در فرم ثبت‌نام</label></td>
                        </tr>
                        <tr>
                            <td><label>نمایش در صفحه تسویه حساب</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="show_on_checkout" value="1" <?php checked(get_option('loginpro_google_show_on_checkout', false), true); ?>> نمایش دکمه گوگل در صفحه تسویه حساب ووکامرس</label></td>
                        </tr>
                        <tr>
                            <td><label>نمایش در پنجره بازشو</label></td>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="show_in_modal" value="1" <?php checked(get_option('loginpro_google_show_in_modal', true), true); ?>> نمایش دکمه گوگل در مودال لاگین</label></td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-form-actions">
                    <button type="submit" class="button button-primary button-large">💾 ذخیره تنظیمات گوگل</button>
                </div>
            </form>
        </div>
        <?php
    }
    
    private function saveSettings() {
        update_option('loginpro_google_enabled', isset($_POST['google_enabled']));
        update_option('loginpro_google_client_id', sanitize_text_field($_POST['client_id']));
        update_option('loginpro_google_client_secret', sanitize_text_field($_POST['client_secret']));
        update_option('loginpro_google_redirect_uri', esc_url_raw($_POST['redirect_uri']));
        update_option('loginpro_google_auto_create', isset($_POST['auto_create']));
        update_option('loginpro_google_account_linking', isset($_POST['account_linking']));
        update_option('loginpro_google_default_role', sanitize_text_field($_POST['default_role']));
        update_option('loginpro_google_require_verification', isset($_POST['require_verification']));
        update_option('loginpro_google_button_text', sanitize_text_field($_POST['button_text']));
        update_option('loginpro_google_button_theme', sanitize_text_field($_POST['button_theme']));
        update_option('loginpro_google_button_size', sanitize_text_field($_POST['button_size']));
        update_option('loginpro_google_button_shape', sanitize_text_field($_POST['button_shape']));
        update_option('loginpro_google_show_on_login', isset($_POST['show_on_login']));
        update_option('loginpro_google_show_on_register', isset($_POST['show_on_register']));
        update_option('loginpro_google_show_on_checkout', isset($_POST['show_on_checkout']));
        update_option('loginpro_google_show_in_modal', isset($_POST['show_in_modal']));
        
        echo '<div class="notice notice-success"><p>تنظیمات ورود با گوگل ذخیره شد.</p></div>';
    }
}