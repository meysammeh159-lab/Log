<?php
/**
 * SmsProvidersPage.php
 * 
 * صفحه مدیریت درگاه‌های پیامک در پنل ادمین
 * 
 * @package LoginPro
 * @since 1.0.0
 */

namespace LoginPro\Admin;

use LoginPro\Modules\Providers\Sms\SmsManager;

defined('ABSPATH') || exit;

// ✅ جلوگیری از تعریف مجدد کلاس
if (class_exists('LoginPro\\Admin\\SmsProvidersPage')) {
    return;
}

class SmsProvidersPage
{
    private SmsManager $smsManager;
    private array $providers = [];
    private bool $debugMode = true;

    public function __construct()
    {
        $this->smsManager = SmsManager::getInstance();
        $this->providers = $this->smsManager->getAvailableProviders();

        $this->log('Initialized. Found ' . count($this->providers) . ' providers');

        add_action('admin_footer', [$this, 'addTestPopupHtml']);
        add_action('wp_ajax_loginpro_test_sms', [$this, 'ajaxTestSms']);
        add_action('admin_notices', [$this, 'showAdminNotices']);
    }

    private function log(string $message): void
    {
        if ($this->debugMode) {
            error_log('LoginPro SmsProvidersPage: ' . $message);
        }
    }

    public function showAdminNotices(): void
    {
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'toplevel_page_loginpro-settings') {
            return;
        }

        if (empty($this->providers)) {
            $smsDir = LOGINPRO_PLUGIN_DIR . 'modules/Providers/Sms/';
            $fileCount = is_dir($smsDir) ? count(glob($smsDir . '*Provider.php')) : 0;

            echo '<div class="notice notice-error is-dismissible">';
            echo '<p><strong>⚠️ هیچ درگاه پیامکی یافت نشد!</strong></p>';
            echo '<p>مسیر جستجو: <code>' . esc_html($smsDir) . '</code></p>';
            echo '<p>تعداد فایل‌های Provider: <strong>' . (int) $fileCount . '</strong></p>';
            echo '<p>لطفاً اطمینان حاصل کنید که فایل‌های Provider در مسیر صحیح قرار دارند و اینترفیس SmsProviderInterface را پیاده‌سازی می‌کنند.</p>';
            echo '</div>';
        }
    }

    public function ajaxTestSms(): void
    {
        $this->log('AJAX test SMS started');

        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_test_sms')) {
            $this->log('Nonce verification failed');
            wp_send_json_error(['message' => 'خطای امنیتی: نشست نامعتبر است. صفحه را refresh کنید.']);
        }

        if (!current_user_can('manage_options')) {
            $this->log('Permission denied');
            wp_send_json_error(['message' => 'دسترسی غیرمجاز.']);
        }

        $mobile = isset($_POST['mobile']) ? sanitize_text_field(wp_unslash($_POST['mobile'])) : '';
        $mobile = preg_replace('/[^0-9]/', '', $mobile);

        $this->log('Mobile: ' . $mobile);

        if (empty($mobile) || strlen($mobile) < 10) {
            $this->log('Invalid mobile');
            wp_send_json_error(['message' => 'شماره موبایل نامعتبر است. حداقل ۱۰ رقم وارد کنید.']);
        }

        if (strlen($mobile) === 10) {
            $mobile = '0' . $mobile;
        }

        $this->smsManager->refreshProviders();
        $this->providers = $this->smsManager->getAvailableProviders();

        $activeSlug = $this->smsManager->getActiveProviderSlug();
        $this->log('Active provider slug: ' . ($activeSlug ?? 'none'));

        if (!$activeSlug) {
            $this->log('No active provider');
            wp_send_json_error(['message' => 'هیچ درگاه پیامکی فعالی انتخاب نشده است. لطفاً از تنظیمات یک درگاه را فعال کنید.']);
        }

        $activeProvider = $this->smsManager->getActiveProvider();
        if ($activeProvider && !$activeProvider->isConfigured()) {
            $this->log('Provider not configured');
            wp_send_json_error([
                'message' => sprintf(
                    'درگاه %s به درستی پیکربندی نشده است. لطفاً تنظیمات درگاه را تکمیل کنید.',
                    $activeProvider::getName()
                ),
            ]);
        }

        $testCode = wp_rand(100000, 999999);
        $testMessage = "🔔 پیام تست لاگین پرو\nکد تست: {$testCode}\n" . current_time('Y-m-d H:i:s');

        $this->log('Sending test SMS to ' . $mobile);
        $result = $this->smsManager->send($mobile, $testMessage);

        if ($result['success']) {
            $this->log('Test SMS sent successfully');
            wp_send_json_success([
                'message' => "✅ پیامک تست با موفقیت به شماره {$mobile} ارسال شد.\nکد تست: {$testCode}",
            ]);
        } else {
            $errorMsg = $result['message'] ?? 'خطای نامشخص';
            $this->log('Test SMS failed: ' . $errorMsg);
            wp_send_json_error(['message' => '❌ خطا در ارسال پیامک: ' . $errorMsg]);
        }
    }

    private function saveSettings(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_POST['resend_delay'])) {
            $delay = absint($_POST['resend_delay']);
            if ($delay >= 30 && $delay <= 300) {
                update_option('loginpro_sms_resend_delay', $delay);
            }
        }

        if (isset($_POST['active_provider']) && !empty($_POST['active_provider'])) {
            $slug = sanitize_text_field(wp_unslash($_POST['active_provider']));
            $this->smsManager->activateProvider($slug);
        }

        foreach ($this->providers as $providerInfo) {
            $slug = $providerInfo['slug'];
            $settingsFields = $providerInfo['settings_fields'] ?? [];
            $providerData = [];

            foreach ($settingsFields as $fieldName => $field) {
                $postKey = $slug . '_' . $fieldName;

                if (!isset($_POST[$postKey])) {
                    continue;
                }

                $value = wp_unslash($_POST[$postKey]);

                switch ($field['type'] ?? 'text') {
                    case 'textarea':
                        $value = sanitize_textarea_field($value);
                        break;
                    case 'password':
                        if (empty($value)) {
                            continue 2;
                        }
                        $value = sanitize_text_field($value);
                        break;
                    case 'number':
                        $value = absint($value);
                        break;
                    default:
                        $value = sanitize_text_field($value);
                }

                $providerData[$fieldName] = $value;
            }

            if (!empty($providerData)) {
                $this->smsManager->saveProviderSettings($slug, $providerData);
            }
        }
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if (
            isset($_POST['save_sms_settings'])
            && isset($_POST['sms_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sms_nonce'])), 'save_sms_settings')
        ) {
            $this->saveSettings();
            $this->smsManager->refreshProviders();
            $this->providers = $this->smsManager->getAvailableProviders();
            echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات با موفقیت ذخیره شد!</p></div>';
        }

        $this->providers = $this->smsManager->getAvailableProviders();
        $activeSlug = $this->smsManager->getActiveProviderSlug();
        $resendDelay = get_option('loginpro_sms_resend_delay', 90);

        if (!$activeSlug && !empty($this->providers)) {
            $activeSlug = $this->providers[0]['slug'] ?? '';
        }

        ?>
        <div class="wrap loginpro-sms-settings">
            <h1>
                ✉️ تنظیمات درگاه پیامک
                <?php if (!empty($this->providers)): ?>
                    <span class="provider-count-badge">
                        ✅ <?php echo count($this->providers); ?> درگاه
                    </span>
                <?php endif; ?>
            </h1>

            <?php if (empty($this->providers)): ?>
                <div class="card card-error">
                    <h2>❌ هیچ درگاه پیامکی یافت نشد!</h2>
                    <p>مسیر جستجو: <code><?php echo esc_html(LOGINPRO_PLUGIN_DIR . 'modules/Providers/Sms/'); ?></code></p>
                    <p>لطفاً از وجود فایل‌های Provider در مسیر فوق اطمینان حاصل کنید.</p>
                    <p>فایل‌های Provider باید اینترفیس <code>SmsProviderInterface</code> را پیاده‌سازی کرده باشند.</p>
                </div>
                <?php return; ?>
            <?php endif; ?>

            <form method="post" id="loginpro-sms-form">
                <?php wp_nonce_field('save_sms_settings', 'sms_nonce'); ?>

                <div class="card">
                    <h2>⏱️ تنظیمات عمومی</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="resend_delay">زمان ارسال مجدد:</label>
                            </th>
                            <td>
                                <input type="number"
                                       name="resend_delay"
                                       id="resend_delay"
                                       value="<?php echo esc_attr($resendDelay); ?>"
                                       class="small-text"
                                       min="30"
                                       max="300"
                                       step="5">
                                <span>ثانیه</span>
                                <p class="description">حداقل فاصله زمانی بین دو ارسال مجدد پیامک (۳۰ تا ۳۰۰ ثانیه)</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="card">
                    <h2>📡 انتخاب درگاه فعال</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="active_provider">درگاه پیامکی:</label>
                            </th>
                            <td>
                                <select name="active_provider" id="active_provider" class="regular-text">
                                    <?php foreach ($this->providers as $provider): ?>
                                        <option value="<?php echo esc_attr($provider['slug']); ?>"
                                            <?php selected($activeSlug, $provider['slug']); ?>>
                                            <?php echo esc_html($provider['name']); ?>
                                            <?php if (!$provider['is_configured']): ?>
                                                (تنظیم نشده)
                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">درگاهی که برای ارسال پیامک‌های تست و OTP استفاده می‌شود.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php foreach ($this->providers as $provider): ?>
                    <div id="provider_<?php echo esc_attr($provider['slug']); ?>_box"
                         class="card provider-card"
                         style="display: <?php echo ($activeSlug === $provider['slug']) ? 'block' : 'none'; ?>;">
                        <h2>
                            <?php if ($provider['is_configured']): ?>
                                ✅
                            <?php else: ?>
                                ⚠️
                            <?php endif; ?>
                            تنظیمات <?php echo esc_html($provider['name']); ?>
                        </h2>

                        <?php if (!empty($provider['description'])): ?>
                            <p class="provider-description"><?php echo esc_html($provider['description']); ?></p>
                        <?php endif; ?>

                        <table class="form-table">
                            <?php foreach ($provider['settings_fields'] as $fieldName => $field): ?>
                                <tr>
                                    <th scope="row">
                                        <label for="field_<?php echo esc_attr($provider['slug'] . '_' . $fieldName); ?>">
                                            <?php echo esc_html($field['label']); ?>:
                                            <?php if (!empty($field['required'])): ?>
                                                <span class="required">*</span>
                                            <?php endif; ?>
                                        </label>
                                    </th>
                                    <td>
                                        <?php
                                        $optionKey = 'loginpro_sms_' . $provider['slug'] . '_' . $fieldName;
                                        $fieldValue = get_option($optionKey, '');
                                        $inputName = $provider['slug'] . '_' . $fieldName;
                                        $inputId = 'field_' . $provider['slug'] . '_' . $fieldName;

                                        switch ($field['type'] ?? 'text') {
                                            case 'textarea':
                                                printf(
                                                    '<textarea name="%s" id="%s" rows="3" class="large-text code" placeholder="%s">%s</textarea>',
                                                    esc_attr($inputName),
                                                    esc_attr($inputId),
                                                    esc_attr($field['placeholder'] ?? ''),
                                                    esc_textarea($fieldValue)
                                                );
                                                break;

                                            case 'password':
                                                printf(
                                                    '<input type="password" name="%s" id="%s" value="%s" class="regular-text" autocomplete="new-password" placeholder="%s">',
                                                    esc_attr($inputName),
                                                    esc_attr($inputId),
                                                    esc_attr($fieldValue),
                                                    esc_attr($field['placeholder'] ?? '')
                                                );
                                                if (!empty($fieldValue)) {
                                                    echo '<p class="description">مقدار قبلی ذخیره شده است. برای تغییر، مقدار جدید وارد کنید.</p>';
                                                }
                                                break;

                                            case 'number':
                                                $inputClass = 'regular-text';
                                                if ($fieldName === 'template_id') {
                                                    $inputClass = 'large-text';
                                                }
                                                printf(
                                                    '<input type="number" name="%s" id="%s" value="%s" class="%s" placeholder="%s" style="max-width:300px;">',
                                                    esc_attr($inputName),
                                                    esc_attr($inputId),
                                                    esc_attr($fieldValue),
                                                    esc_attr($inputClass),
                                                    esc_attr($field['placeholder'] ?? '')
                                                );
                                                break;

                                            default:
                                                printf(
                                                    '<input type="text" name="%s" id="%s" value="%s" class="regular-text" placeholder="%s">',
                                                    esc_attr($inputName),
                                                    esc_attr($inputId),
                                                    esc_attr($fieldValue),
                                                    esc_attr($field['placeholder'] ?? '')
                                                );
                                        }

                                        if (!empty($field['description'])) {
                                            echo '<p class="description">' . esc_html($field['description']) . '</p>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            
                            <?php if ($provider['slug'] === 'smsir'): ?>
                                <tr>
                                    <td colspan="2">
                                        <div style="background:#f0f8ff;padding:15px;border-radius:8px;border:1px solid #b8d4e3;margin-top:10px;">
                                            <p style="margin:0;font-size:14px;color:#004085;">
                                                <strong>📌 راهنمای تنظیمات SMS.ir:</strong>
                                            </p>
                                            <ol style="margin:10px 0 0 20px;font-size:13px;color:#0056b3;padding-right:20px;">
                                                <li>وارد <a href="https://panel.sms.ir/" target="_blank">پنل SMS.ir</a> شوید</li>
                                                <li>به بخش <strong>ارسال سریع → قالب‌ها</strong> بروید</li>
                                                <li>یک قالب جدید با پارامتر <code>{OTP}</code> ایجاد کنید</li>
                                                <li>شناسه قالب را در فیلد بالا وارد کنید</li>
                                                <li>کلید API را از بخش <strong>API</strong> دریافت کنید</li>
                                            </ol>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                <?php endforeach; ?>

                <p class="submit">
                    <button type="submit" name="save_sms_settings" class="button button-primary button-large">
                        💾 ذخیره تنظیمات
                    </button>
                </p>
            </form>

            <div class="card test-sms-card">
                <h2>📱 تست ارسال پیامک</h2>
                <p>با کلیک روی دکمه زیر یک پیامک تست به شماره مورد نظر ارسال می‌شود.</p>
                <p class="description">هزینه پیامک تست از اعتبار درگاه انتخابی کسر خواهد شد.</p>
                <button type="button"
                        onclick="openTestPopup()"
                        class="button button-secondary button-large">
                    📨 ارسال پیامک تست
                </button>
            </div>
        </div>

        <?php $this->renderStyles(); ?>
        <?php $this->renderScripts(); ?>
        <?php $this->addTestPopupHtml(); ?>
        <?php
    }

    private function renderStyles(): void
    {
        ?>
        <style>
            .loginpro-sms-settings .card {
                background: #fff;
                border: 1px solid #c3c4c7;
                border-radius: 8px;
                padding: 20px 25px;
                margin: 0 auto 25px;
                max-width: 960px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            }
            .loginpro-sms-settings .card h2 {
                margin-top: 0;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 1px solid #eee;
                font-size: 1.25em;
            }
            .loginpro-sms-settings .card-error {
                border-color: #d63638;
                background: #fff8f8;
            }
            .loginpro-sms-settings .provider-count-badge {
                display: inline-block;
                background: #d4edda;
                padding: 3px 12px;
                border-radius: 12px;
                margin-right: 10px;
                font-size: 12px;
                color: #155724;
                vertical-align: middle;
            }
            .loginpro-sms-settings .form-table th {
                width: 200px;
                padding: 15px 10px 15px 0;
                vertical-align: top;
            }
            .loginpro-sms-settings .form-table td {
                padding: 15px 0;
            }
            .loginpro-sms-settings .required {
                color: #d63638;
            }
            .loginpro-sms-settings .description {
                color: #646970;
                font-size: 13px;
                margin-top: 5px;
            }
            .loginpro-sms-settings .provider-description {
                color: #646970;
                margin-bottom: 20px;
                padding: 10px 15px;
                background: #f0f6fc;
                border-right: 4px solid #2271b1;
                border-radius: 4px;
            }
            .loginpro-sms-settings .test-sms-card {
                text-align: center;
                background: #f8f9fa;
            }
            .loginpro-sms-settings input.large-text {
                width: 100%;
                max-width: 400px;
            }
            @media (max-width: 782px) {
                .loginpro-sms-settings .form-table th,
                .loginpro-sms-settings .form-table td {
                    display: block;
                    width: 100%;
                    padding: 8px 0;
                }
                .loginpro-sms-settings input.large-text {
                    max-width: 100%;
                }
            }
        </style>
        <?php
    }

    private function renderScripts(): void
    {
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('#active_provider').on('change', function() {
                var selected = $(this).val();
                $('.provider-card').hide();
                $('#provider_' + selected + '_box').show();
            });
        });
        </script>
        <?php
    }

    public function addTestPopupHtml(): void
    {
        ?>
        <div id="loginpro-test-sms-popup"
             style="display:none;
                    position:fixed;
                    top:0; left:0;
                    width:100%; height:100%;
                    background:rgba(0,0,0,0.6);
                    z-index:999999;
                    align-items:center;
                    justify-content:center;"
             role="dialog"
             aria-modal="true"
             aria-labelledby="test-popup-title">
            <div style="background:#fff;
                        border-radius:12px;
                        padding:30px;
                        max-width:480px;
                        width:90%;
                        box-shadow:0 20px 60px rgba(0,0,0,0.3);
                        position:relative;
                        direction:rtl;">
                <button onclick="closeTestPopup()"
                        style="position:absolute;
                               top:12px;
                               left:15px;
                               background:none;
                               border:none;
                               font-size:28px;
                               cursor:pointer;
                               color:#999;
                               line-height:1;"
                        aria-label="بستن">
                    &times;
                </button>

                <h2 id="test-popup-title" style="margin-top:0; margin-bottom:20px; color:#1d2327;">📱 ارسال پیامک تست</h2>

                <div id="test-sms-result"
                     style="display:none;
                            padding:12px 15px;
                            border-radius:8px;
                            margin-bottom:18px;
                            font-size:14px;">
                </div>

                <div style="margin-bottom:18px;">
                    <label for="test-mobile-input"
                           style="display:block;
                                  font-weight:600;
                                  margin-bottom:6px;
                                  color:#3c434a;">
                        شماره موبایل:
                    </label>
                    <input type="tel"
                           id="test-mobile-input"
                           placeholder="09123456789"
                           maxlength="11"
                           style="width:100%;
                                  padding:12px 15px;
                                  border:2px solid #ddd;
                                  border-radius:8px;
                                  font-size:16px;
                                  box-sizing:border-box;
                                  direction:ltr;
                                  text-align:left;
                                  transition:border-color 0.3s;"
                           onfocus="this.style.borderColor='#2271b1'"
                           onblur="this.style.borderColor='#ddd'">
                </div>

                <div id="test-sms-loading"
                     style="display:none;
                            text-align:center;
                            margin:15px 0;
                            color:#646970;">
                    <div style="display:inline-block;
                                width:28px;
                                height:28px;
                                border:3px solid #f0f0f0;
                                border-top-color:#ef394e;
                                border-radius:50%;
                                animation:loginpro-spin 0.8s linear infinite;
                                vertical-align:middle;">
                    </div>
                    <span style="display:block; margin-top:8px;">در حال ارسال پیامک...</span>
                </div>

                <div style="display:flex; gap:10px; margin-top:20px;">
                    <button onclick="sendTestSms()"
                            id="send-test-btn"
                            style="flex:2;
                                   background:#ef394e;
                                   color:#fff;
                                   border:none;
                                   padding:12px 20px;
                                   border-radius:8px;
                                   cursor:pointer;
                                   font-size:15px;
                                   font-weight:600;
                                   transition:background 0.3s;">
                        📨 ارسال پیام تست
                    </button>
                    <button onclick="closeTestPopup()"
                            style="flex:1;
                                   background:#f0f0f1;
                                   color:#3c434a;
                                   border:none;
                                   padding:12px 20px;
                                   border-radius:8px;
                                   cursor:pointer;
                                   font-size:15px;
                                   transition:background 0.3s;">
                        انصراف
                    </button>
                </div>
            </div>
        </div>

        <style>
            @keyframes loginpro-spin {
                to { transform: rotate(360deg); }
            }
            #loginpro-test-sms-popup {
                animation: loginpro-fadeIn 0.25s ease;
            }
            @keyframes loginpro-fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            #test-sms-result.notice-success {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
            }
            #test-sms-result.notice-error {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
            }
        </style>

        <script>
        function openTestPopup() {
            document.getElementById('loginpro-test-sms-popup').style.display = 'flex';
            document.getElementById('test-mobile-input').value = '';
            document.getElementById('test-sms-result').style.display = 'none';
            document.getElementById('send-test-btn').disabled = false;
            document.getElementById('send-test-btn').textContent = '📨 ارسال پیام تست';
            document.getElementById('test-sms-loading').style.display = 'none';
            setTimeout(function() {
                document.getElementById('test-mobile-input').focus();
            }, 100);
        }

        function closeTestPopup() {
            document.getElementById('loginpro-test-sms-popup').style.display = 'none';
        }

        function sendTestSms() {
            var mobileInput = document.getElementById('test-mobile-input');
            var mobile = mobileInput.value.trim();
            var cleanMobile = mobile.replace(/[^0-9]/g, '');
            var resultDiv = document.getElementById('test-sms-result');
            var sendBtn = document.getElementById('send-test-btn');
            var loadingDiv = document.getElementById('test-sms-loading');

            if (cleanMobile.length < 10) {
                resultDiv.style.display = 'block';
                resultDiv.className = 'notice-error';
                resultDiv.innerHTML = '❌ لطفاً یک شماره موبایل معتبر وارد کنید (حداقل ۱۰ رقم).';
                mobileInput.focus();
                return;
            }

            sendBtn.disabled = true;
            sendBtn.textContent = '⏳ در حال ارسال...';
            loadingDiv.style.display = 'block';
            resultDiv.style.display = 'none';

            var formData = new FormData();
            formData.append('action', 'loginpro_test_sms');
            formData.append('mobile', cleanMobile);
            formData.append('_nonce', '<?php echo wp_create_nonce('loginpro_test_sms'); ?>');

            fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                body: formData,
            })
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('خطای شبکه: ' + response.status);
                }
                return response.json();
            })
            .then(function(data) {
                loadingDiv.style.display = 'none';
                sendBtn.disabled = false;
                sendBtn.textContent = '📨 ارسال پیام تست';
                resultDiv.style.display = 'block';

                if (data.success) {
                    resultDiv.className = 'notice-success';
                    resultDiv.innerHTML = '✅ ' + (data.data.message || 'پیامک با موفقیت ارسال شد.');
                } else {
                    resultDiv.className = 'notice-error';
                    resultDiv.innerHTML = '❌ خطا: ' + (data.data.message || 'خطای ناشناخته');
                }
            })
            .catch(function(error) {
                loadingDiv.style.display = 'none';
                sendBtn.disabled = false;
                sendBtn.textContent = '📨 ارسال پیام تست';
                resultDiv.style.display = 'block';
                resultDiv.className = 'notice-error';
                resultDiv.innerHTML = '❌ خطا در ارتباط با سرور: ' + error.message;
            });
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeTestPopup();
            }
        });

        document.addEventListener('click', function(e) {
            var popup = document.getElementById('loginpro-test-sms-popup');
            if (e.target === popup) {
                closeTestPopup();
            }
        });

        document.getElementById('test-mobile-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendTestSms();
            }
        });
        </script>
        <?php
    }
}