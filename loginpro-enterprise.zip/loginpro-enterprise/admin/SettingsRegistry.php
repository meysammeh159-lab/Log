<?php
namespace LoginPro\Admin;

use LoginPro\Core\Container;

defined('ABSPATH') || exit;

class SettingsRegistry
{
    private $container;
    private $settings = [];
    private $sections = [];
    private $fields = [];
    
    public function __construct(Container $container)
    {
        $this->container = $container;
        add_action('admin_init', [$this, 'registerAllSettings']);
    }
    
    public function registerAllSettings(): void
    {
        $this->registerCoreSettings();
        $this->registerOtpSettings();
        $this->registerSecuritySettings();
        $this->registerProviderSettings();
        $this->registerNotificationSettings();
        $this->registerPrivacySettings();
    }
    
    private function registerCoreSettings(): void
    {
        $coreSettings = [
            'loginpro_method_email_password',
            'loginpro_method_mobile_password',
            'loginpro_method_email_otp',
            'loginpro_method_sms_otp',
            'loginpro_method_magic_link',
            'loginpro_default_redirect',
            'loginpro_register_redirect',
            'loginpro_logout_redirect',
            'loginpro_auto_login_register',
            'loginpro_email_verification',
            'loginpro_mobile_verification',
            'loginpro_require_terms'
        ];
        
        foreach ($coreSettings as $setting) {
            register_setting('loginpro_core_settings', $setting);
        }
        
        add_settings_section(
            'loginpro_core_section',
            __('Core Authentication Settings', 'loginpro'),
            [$this, 'renderCoreSection'],
            'loginpro-core'
        );
        
        $this->addCoreFields();
    }
    
    private function addCoreFields(): void
    {
        $fields = [
            'loginpro_method_email_password' => [
                'title' => __('Email & Password Login', 'loginpro'),
                'type' => 'checkbox',
                'section' => 'loginpro_core_section'
            ],
            'loginpro_method_mobile_password' => [
                'title' => __('Mobile & Password Login', 'loginpro'),
                'type' => 'checkbox',
                'section' => 'loginpro_core_section'
            ],
            'loginpro_method_email_otp' => [
                'title' => __('Email OTP Login', 'loginpro'),
                'type' => 'checkbox',
                'section' => 'loginpro_core_section'
            ],
            'loginpro_method_sms_otp' => [
                'title' => __('SMS OTP Login', 'loginpro'),
                'type' => 'checkbox',
                'section' => 'loginpro_core_section'
            ],
            'loginpro_default_redirect' => [
                'title' => __('Default Login Redirect', 'loginpro'),
                'type' => 'url',
                'section' => 'loginpro_core_section',
                'description' => __('Leave empty to redirect to homepage', 'loginpro')
            ],
            'loginpro_auto_login_register' => [
                'title' => __('Auto Login After Registration', 'loginpro'),
                'type' => 'checkbox',
                'section' => 'loginpro_core_section'
            ]
        ];
        
        foreach ($fields as $field => $args) {
            add_settings_field(
                $field,
                $args['title'],
                [$this, 'renderField'],
                'loginpro-core',
                $args['section'],
                [
                    'label_for' => $field,
                    'type' => $args['type'],
                    'description' => $args['description'] ?? ''
                ]
            );
        }
    }
    
    private function registerOtpSettings(): void
    {
        $otpSettings = [
            'loginpro_otp_length',
            'loginpro_otp_type',
            'loginpro_otp_expiry',
            'loginpro_otp_max_attempts',
            'loginpro_otp_resend_delay',
            'loginpro_otp_channel_sms',
            'loginpro_otp_channel_whatsapp',
            'loginpro_otp_channel_email',
            'loginpro_otp_default_channel',
            'loginpro_otp_sms_template',
            'loginpro_otp_email_template'
        ];
        
        foreach ($otpSettings as $setting) {
            register_setting('loginpro_otp_settings', $setting);
        }
        
        add_settings_section(
            'loginpro_otp_section',
            __('OTP Configuration', 'loginpro'),
            [$this, 'renderOtpSection'],
            'loginpro-otp'
        );
    }
    
    private function registerSecuritySettings(): void
    {
        $securitySettings = [
            'loginpro_bf_max_attempts',
            'loginpro_bf_lockout_minutes',
            'loginpro_bf_progressive',
            'loginpro_rate_max_attempts',
            'loginpro_rate_decay_minutes',
            'loginpro_session_timeout',
            'loginpro_max_sessions',
            'loginpro_session_regeneration',
            'loginpro_prevent_concurrent',
            'loginpro_tfa_enforcement',
            'loginpro_blocked_ips',
            'loginpro_ip_whitelist'
        ];
        
        foreach ($securitySettings as $setting) {
            register_setting('loginpro_security_settings', $setting);
        }
        
        add_settings_section(
            'loginpro_security_section',
            __('Security Configuration', 'loginpro'),
            [$this, 'renderSecuritySection'],
            'loginpro-security'
        );
    }
    
    private function registerProviderSettings(): void
    {
        $smsProviders = ['kavenegar', 'farazsms', 'melipayamak', 'smsir', 'twilio'];
        foreach ($smsProviders as $provider) {
            register_setting('loginpro_sms_settings', "loginpro_sms_{$provider}_enabled");
            register_setting('loginpro_sms_settings', "loginpro_sms_{$provider}_api_key");
            register_setting('loginpro_sms_settings', "loginpro_sms_{$provider}_username");
            register_setting('loginpro_sms_settings', "loginpro_sms_{$provider}_password");
            register_setting('loginpro_sms_settings', "loginpro_sms_{$provider}_sender");
        }
        register_setting('loginpro_sms_settings', 'loginpro_sms_default_provider');
        
        $whatsappProviders = ['meta', 'twilio', 'greenapi'];
        foreach ($whatsappProviders as $provider) {
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_enabled");
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_access_token");
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_phone_number_id");
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_account_sid");
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_auth_token");
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_from_number");
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_id_instance");
            register_setting('loginpro_whatsapp_settings', "loginpro_whatsapp_{$provider}_api_token");
        }
        register_setting('loginpro_whatsapp_settings', 'loginpro_whatsapp_default_provider');
        
        $emailProviders = ['smtp', 'sendgrid', 'mailgun', 'ses', 'postmark'];
        foreach ($emailProviders as $provider) {
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_enabled");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_host");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_port");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_username");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_password");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_encryption");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_api_key");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_from_email");
            register_setting('loginpro_email_settings', "loginpro_email_{$provider}_from_name");
        }
        register_setting('loginpro_email_settings', 'loginpro_email_default_provider');
        register_setting('loginpro_email_settings', 'loginpro_email_fallback_provider');
    }
    
    private function registerNotificationSettings(): void
    {
        $notificationSettings = [
            'loginpro_email_notifications',
            'loginpro_sms_notifications',
            'loginpro_whatsapp_notifications',
            'loginpro_login_alert',
            'loginpro_new_device_alert',
            'loginpro_failed_login_alert'
        ];
        
        foreach ($notificationSettings as $setting) {
            register_setting('loginpro_notification_settings', $setting);
        }
        
        add_settings_section(
            'loginpro_notification_section',
            __('Notification Settings', 'loginpro'),
            [$this, 'renderNotificationSection'],
            'loginpro-notifications'
        );
    }
    
    private function registerPrivacySettings(): void
    {
        $privacySettings = [
            'loginpro_retain_logs_days',
            'loginpro_retain_history_days',
            'loginpro_delete_data_on_uninstall',
            'loginpro_anonymize_ip',
            'loginpro_export_user_data'
        ];
        
        foreach ($privacySettings as $setting) {
            register_setting('loginpro_privacy_settings', $setting);
        }
        
        add_settings_section(
            'loginpro_privacy_section',
            __('Privacy & Data Retention', 'loginpro'),
            [$this, 'renderPrivacySection'],
            'loginpro-privacy'
        );
    }
    
    public function renderCoreSection(): void
    {
        echo '<p class="loginpro-description">' . esc_html__('Configure the core authentication methods and behaviors.', 'loginpro') . '</p>';
    }
    
    public function renderOtpSection(): void
    {
        echo '<p class="loginpro-description">' . esc_html__('Configure one-time password generation and delivery settings.', 'loginpro') . '</p>';
    }
    
    public function renderSecuritySection(): void
    {
        echo '<p class="loginpro-description">' . esc_html__('Configure security settings to protect against attacks.', 'loginpro') . '</p>';
    }
    
    public function renderNotificationSection(): void
    {
        echo '<p class="loginpro-description">' . esc_html__('Configure which notifications to send to users.', 'loginpro') . '</p>';
    }
    
    public function renderPrivacySection(): void
    {
        echo '<p class="loginpro-description">' . esc_html__('Configure how user data is stored and retained.', 'loginpro') . '</p>';
    }
    
    public function renderField(array $args): void
    {
        $option = get_option($args['label_for']);
        $type = $args['type'];
        $description = $args['description'] ?? '';
        
        if ($type === 'checkbox') {
            echo '<input type="checkbox" id="' . esc_attr($args['label_for']) . '" 
                   name="' . esc_attr($args['label_for']) . '" value="1" ' . checked(1, $option, false) . ' class="loginpro-checkbox">';
        } elseif ($type === 'url') {
            echo '<input type="url" id="' . esc_attr($args['label_for']) . '" 
                   name="' . esc_attr($args['label_for']) . '" 
                   class="loginpro-input loginpro-input-regular" value="' . esc_attr($option) . '">';
        } else {
            echo '<input type="text" id="' . esc_attr($args['label_for']) . '" 
                   name="' . esc_attr($args['label_for']) . '" 
                   class="loginpro-input loginpro-input-regular" value="' . esc_attr($option) . '">';
        }
        
        if ($description) {
            echo '<p class="loginpro-description">' . esc_html($description) . '</p>';
        }
    }
    
    public function getSettingsPage(string $page, string $groups): string
    {
        if (!current_user_can('manage_options')) {
            return '<p>' . esc_html__('You do not have permission to access this page.', 'loginpro') . '</p>';
        }
        
        ob_start();
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields($groups);
                do_settings_sections($page);
                submit_button(__('Save Settings', 'loginpro'));
                ?>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
}