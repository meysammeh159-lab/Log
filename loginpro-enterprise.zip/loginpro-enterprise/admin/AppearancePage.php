<?php
namespace LoginPro\Admin;

use Exception;

defined('ABSPATH') || exit;

class AppearancePage
{
    private $nonceAction = 'loginpro_appearance';

    public function render(): void
    {
        // بارگذاری وابستگی‌ها
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_media();
        
        // ==========================================
        // ✅ ذخیره با فرم معمولی (POST)
        // ==========================================
        if (isset($_POST['save_appearance']) && isset($_POST['_wpnonce'])) {
            if (wp_verify_nonce($_POST['_wpnonce'], $this->nonceAction) && current_user_can('manage_options')) {
                $result = $this->saveSettings();
                if ($result) {
                    // رفرش صفحه با پیام موفقیت
                    $redirect_url = add_query_arg('settings-updated', 'true', wp_get_referer());
                    wp_redirect($redirect_url);
                    exit;
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>خطا در ذخیره تنظیمات.</p></div>';
                }
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>خطای امنیتی.</p></div>';
            }
        }
        
        // ==========================================
        // ✅ ذخیره با Ajax (برای درخواست‌های AJAX)
        // ==========================================
        add_action('wp_ajax_loginpro_save_appearance', [$this, 'ajax_save_settings']);
        
        // ==========================================
        // ✅ نمایش پیام موفقیت
        // ==========================================
        if (isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true') {
            echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات ظاهر با موفقیت ذخیره شد.</p></div>';
        }
        
        // ==========================================
        // ✅ بارگذاری فایل تب
        // ==========================================
        $tab_file = LOGINPRO_PLUGIN_DIR . 'admin/tabs/tab-appearance.php';
        if (file_exists($tab_file)) {
            include $tab_file;
        } else {
            echo '<div class="notice notice-error"><p>فایل تنظیمات ظاهر یافت نشد.</p></div>';
        }
    }
    
    // ==========================================
    // ✅ ذخیره از طریق Ajax
    // ==========================================
    public function ajax_save_settings(): void
    {
        // بررسی nonce
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], $this->nonceAction)) {
            wp_send_json_error(['message' => 'درخواست نامعتبر است.']);
            return;
        }
        
        // بررسی دسترسی
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید.']);
            return;
        }
        
        // ذخیره تنظیمات
        $result = $this->saveSettings();
        
        if ($result) {
            wp_send_json_success(['message' => 'تنظیمات ظاهر با موفقیت ذخیره شد.']);
        } else {
            wp_send_json_error(['message' => 'خطا در ذخیره تنظیمات.']);
        }
    }
    
    private function getSettings(): array
    {
        return [
            // رنگ‌ها
            'primary_color' => get_option('loginpro_primary_color', '#ef394e'),
            'button_color' => get_option('loginpro_button_color', '#ef394e'),
            'button_hover_color' => get_option('loginpro_button_hover_color', '#e02e43'),
            'error_color' => get_option('loginpro_error_color', '#dc3545'),
            'success_color' => get_option('loginpro_success_color', '#28a745'),
            'background_color' => get_option('loginpro_background_color', '#ffffff'),
            'text_color' => get_option('loginpro_text_color', '#1a1a1a'),
            'subtitle_color' => get_option('loginpro_subtitle_color', '#6c6c6c'),
            'border_color' => get_option('loginpro_border_color', '#e0e0e0'),
            
            // رنگ‌های جدید قالب کاربری
            'dashboard_header_bg_color' => get_option('loginpro_dashboard_header_bg_color', '#ef394e'),
            'dashboard_header_text_color' => get_option('loginpro_dashboard_header_text_color', '#ffffff'),
            'dashboard_tab_active_color' => get_option('loginpro_dashboard_tab_active_color', '#ef394e'),
            'dashboard_tab_hover_color' => get_option('loginpro_dashboard_tab_hover_color', '#f0f0f0'),
            'dashboard_section_bg_color' => get_option('loginpro_dashboard_section_bg_color', '#f8f9fa'),
            'dashboard_section_border_color' => get_option('loginpro_dashboard_section_border_color', '#e9ecef'),
            
            // اندازه‌ها
            'form_width' => get_option('loginpro_form_width', '400px'),
            'form_padding' => get_option('loginpro_form_padding', '40px 30px'),
            'border_radius' => get_option('loginpro_border_radius', 20),
            'input_height' => get_option('loginpro_input_height', 48),
            'button_height' => get_option('loginpro_button_height', 52),
            
            // فونت
            'font_family' => get_option('loginpro_font_family', 'IRANSans, Tahoma, sans-serif'),
            'title_font_size' => get_option('loginpro_title_font_size', 22),
            'subtitle_font_size' => get_option('loginpro_subtitle_font_size', 14),
            'help_font_size' => get_option('loginpro_help_font_size', 13),
            'normal_font_size' => get_option('loginpro_normal_font_size', 15),
            'button_font_size' => get_option('loginpro_button_font_size', 16),
            'forgot_font_size' => get_option('loginpro_forgot_font_size', 12),
            
            // لوگو
            'logo_url' => get_option('loginpro_logo_url', ''),
            'logo_width' => get_option('loginpro_logo_width', '150'),
            'logo_height' => get_option('loginpro_logo_height', 'auto'),
            
            // CSS
            'custom_css' => get_option('loginpro_custom_css', ''),
            
            // متن‌ها
            'text_title' => get_option('loginpro_text_title', 'ورود یا ثبت نام'),
            'text_subtitle' => get_option('loginpro_text_subtitle', 'لطفا اطلاعات خود را وارد کنید'),
            'text_help_identifier' => get_option('loginpro_text_help_identifier', 'ایمیل یا نام کاربری خود را وارد کنید'),
            'text_continue_btn' => get_option('loginpro_text_continue_btn', 'ادامه'),
            'text_password_title' => get_option('loginpro_text_password_title', 'ورود با رمز عبور'),
            'text_help_password' => get_option('loginpro_text_help_password', 'رمز عبور خود را وارد کنید'),
            'text_login_btn' => get_option('loginpro_text_login_btn', 'ورود'),
            'text_register_btn' => get_option('loginpro_text_register_btn', 'ثبت نام'),
            'text_otp_title' => get_option('loginpro_text_otp_title', 'کد تایید'),
            'text_help_otp' => get_option('loginpro_text_help_otp', 'کد 6 رقمی ارسال شده را وارد کنید'),
            'text_verify_btn' => get_option('loginpro_text_verify_btn', 'تایید و ورود'),
            'text_forgot_password' => get_option('loginpro_text_forgot_password', 'فراموشی رمز عبور'),
            
            // هدر و فوتر
            'text_header_title' => get_option('loginpro_text_header_title', 'لاگین پرو'),
            'text_header_description' => get_option('loginpro_text_header_description', 'به سامانه کاربری خوش آمدید'),
            'text_footer_text' => get_option('loginpro_text_footer_text', ''),
            'text_footer_links' => get_option('loginpro_text_footer_links', ''),
            'text_privacy_link' => get_option('loginpro_text_privacy_link', ''),
            'text_terms_link' => get_option('loginpro_text_terms_link', ''),
            
            // متن‌های OTP
            'text_otp_register_message' => get_option('loginpro_text_otp_register_message', 'شماره شما ثبت نشده است. کد تایید برای ثبت نام ارسال شد.'),
            'text_otp_login_message' => get_option('loginpro_text_otp_login_message', 'کد تایید برای شما ارسال شد.'),
            
            // تنظیمات دکمه مودال
            'modal_btn_bg_color' => get_option('loginpro_modal_btn_bg_color', '#ef394e'),
            'modal_btn_bg_hover_color' => get_option('loginpro_modal_btn_bg_hover_color', '#e02e43'),
            'modal_btn_text_color' => get_option('loginpro_modal_btn_text_color', '#ffffff'),
            'modal_btn_text_hover_color' => get_option('loginpro_modal_btn_text_hover_color', '#ffffff'),
            'modal_btn_text' => get_option('loginpro_modal_btn_text', 'ورود / ثبت‌نام'),
            'modal_btn_logged_text' => get_option('loginpro_modal_btn_logged_text', 'پنل کاربری'),
            'modal_btn_icon' => get_option('loginpro_modal_btn_icon', ''),
            'modal_btn_logged_icon' => get_option('loginpro_modal_btn_logged_icon', ''),
            'modal_btn_border_width' => get_option('loginpro_modal_btn_border_width', 0),
            'modal_btn_border_radius' => get_option('loginpro_modal_btn_border_radius', 8),
            'modal_btn_padding' => get_option('loginpro_modal_btn_padding', '8px 20px'),
            'modal_btn_font_size' => get_option('loginpro_modal_btn_font_size', 14),
            'modal_btn_shadow' => get_option('loginpro_modal_btn_shadow', 'small'),
            'modal_btn_shadow_direction' => get_option('loginpro_modal_btn_shadow_direction', 'bottom'),
            'modal_btn_hover_effect' => get_option('loginpro_modal_btn_hover_effect', 'opacity'),
            'modal_btn_size' => get_option('loginpro_modal_btn_size', 'medium'),
            'modal_btn_border_color' => get_option('loginpro_modal_btn_border_color', 'transparent'),
            'modal_btn_shadow_color' => get_option('loginpro_modal_btn_shadow_color', 'rgba(0,0,0,0.15)'),
            'modal_btn_width' => get_option('loginpro_modal_btn_width', ''),
            'modal_btn_height' => get_option('loginpro_modal_btn_height', ''),
            
            // تنظیمات قالب کاربری
            'dashboard_width' => get_option('loginpro_dashboard_width', '800px'),
            'dashboard_border_radius' => get_option('loginpro_dashboard_border_radius', '24'),
            'dashboard_input_height' => get_option('loginpro_dashboard_input_height', '52'),
            'dashboard_button_height' => get_option('loginpro_dashboard_button_height', '52'),
            'dashboard_title_font_size' => get_option('loginpro_dashboard_title_font_size', '22'),
            'dashboard_normal_font_size' => get_option('loginpro_dashboard_normal_font_size', '15'),
            'dashboard_button_font_size' => get_option('loginpro_dashboard_button_font_size', '16'),
            'dashboard_font_family' => get_option('loginpro_dashboard_font_family', 'IRANSans, Tahoma, sans-serif'),
        ];
    }
    
    private function saveSettings(): bool
    {
        if (!current_user_can('manage_options')) {
            return false;
        }
        
        try {
            // رنگ‌ها
            $colorFields = ['primary_color', 'button_color', 'button_hover_color', 'error_color', 'success_color', 'background_color', 'text_color', 'subtitle_color', 'border_color'];
            foreach ($colorFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            // رنگ‌های جدید قالب کاربری
            $dashboardColorFields = [
                'dashboard_header_bg_color', 'dashboard_header_text_color',
                'dashboard_tab_active_color', 'dashboard_tab_hover_color',
                'dashboard_section_bg_color', 'dashboard_section_border_color'
            ];
            foreach ($dashboardColorFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            // اندازه‌ها
            $sizeFields = ['form_width', 'form_padding', 'border_radius', 'input_height', 'button_height'];
            foreach ($sizeFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            // فونت
            if (isset($_POST['font_family'])) {
                update_option('loginpro_font_family', sanitize_text_field($_POST['font_family']));
            }
            
            $fontNumberFields = ['title_font_size', 'subtitle_font_size', 'help_font_size', 'normal_font_size', 'button_font_size', 'forgot_font_size'];
            foreach ($fontNumberFields as $field) {
                if (isset($_POST[$field]) && is_numeric($_POST[$field])) {
                    update_option('loginpro_' . $field, (int) $_POST[$field]);
                }
            }
            
            // لوگو
            if (isset($_POST['logo_url'])) {
                update_option('loginpro_logo_url', esc_url_raw($_POST['logo_url']));
            }
            if (isset($_POST['logo_width'])) {
                update_option('loginpro_logo_width', (int) $_POST['logo_width']);
            }
            if (isset($_POST['logo_height'])) {
                update_option('loginpro_logo_height', sanitize_text_field($_POST['logo_height']));
            }
            
            // CSS سفارشی
            if (isset($_POST['custom_css'])) {
                update_option('loginpro_custom_css', wp_strip_all_tags($_POST['custom_css']));
            }
            
            // متن‌ها
            $textFields = [
                'text_title', 'text_subtitle', 'text_help_identifier', 'text_continue_btn',
                'text_password_title', 'text_help_password', 'text_login_btn', 'text_register_btn',
                'text_otp_title', 'text_help_otp', 'text_verify_btn', 'text_forgot_password',
                'text_header_title', 'text_header_description', 'text_footer_text', 'text_footer_links',
                'text_privacy_link', 'text_terms_link', 'text_otp_register_message', 'text_otp_login_message'
            ];
            foreach ($textFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            // تنظیمات دکمه مودال
            $modalColorFields = ['modal_btn_bg_color', 'modal_btn_bg_hover_color', 'modal_btn_text_color', 'modal_btn_text_hover_color', 'modal_btn_border_color', 'modal_btn_shadow_color'];
            foreach ($modalColorFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            $modalSizeFields = ['modal_btn_border_width', 'modal_btn_border_radius', 'modal_btn_font_size'];
            foreach ($modalSizeFields as $field) {
                if (isset($_POST[$field]) && is_numeric($_POST[$field])) {
                    update_option('loginpro_' . $field, (int) $_POST[$field]);
                }
            }
            
            $modalTextFields = ['modal_btn_text', 'modal_btn_logged_text', 'modal_btn_icon', 'modal_btn_logged_icon', 'modal_btn_padding', 'modal_btn_width', 'modal_btn_height'];
            foreach ($modalTextFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            $modalSelectFields = ['modal_btn_shadow', 'modal_btn_shadow_direction', 'modal_btn_hover_effect', 'modal_btn_size'];
            foreach ($modalSelectFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            // تنظیمات قالب کاربری
            $dashboardFields = [
                'dashboard_width', 'dashboard_border_radius', 'dashboard_input_height',
                'dashboard_button_height', 'dashboard_title_font_size',
                'dashboard_normal_font_size', 'dashboard_button_font_size', 'dashboard_font_family'
            ];
            foreach ($dashboardFields as $field) {
                if (isset($_POST[$field])) {
                    update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
            
            return true;
            
        } catch (Exception $e) {
            error_log('[LoginPro] Error saving settings: ' . $e->getMessage());
            return false;
        }
    }
}