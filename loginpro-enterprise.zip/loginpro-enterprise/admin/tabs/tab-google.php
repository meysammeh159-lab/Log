<?php
/**
 * تب تنظیمات ورود با شبکه‌های اجتماعی
 * 
 * @package LoginPro
 * @version 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// دریافت تنظیمات
// ==================================================

// تنظیمات کلی
$social_enabled = get_option('loginpro_social_enabled', false);
$social_show_in_modal = get_option('loginpro_social_show_in_modal', true);
$social_button_style = get_option('loginpro_social_button_style', 'default');
$social_button_size = get_option('loginpro_social_button_size', 'medium');
$social_button_radius = get_option('loginpro_social_button_radius', 8);
$social_button_padding = get_option('loginpro_social_button_padding', '10px 20px');

// تنظیمات گوگل
$google_enabled = get_option('loginpro_google_enabled', false);
$google_client_id = get_option('loginpro_google_client_id', '');
$google_client_secret = get_option('loginpro_google_client_secret', '');
$google_redirect_uri = get_option('loginpro_google_redirect_uri', home_url('/?loginpro_google_callback=1'));
$google_auto_create = get_option('loginpro_google_auto_create', true);
$google_account_linking = get_option('loginpro_google_account_linking', true);
$google_default_role = get_option('loginpro_google_default_role', 'subscriber');
$google_button_text = get_option('loginpro_google_button_text', 'گوگل');

// تنظیمات فیسبوک
$facebook_enabled = get_option('loginpro_facebook_enabled', false);
$facebook_app_id = get_option('loginpro_facebook_app_id', '');
$facebook_app_secret = get_option('loginpro_facebook_app_secret', '');
$facebook_redirect_uri = get_option('loginpro_facebook_redirect_uri', home_url('/?loginpro_facebook_callback=1'));
$facebook_auto_create = get_option('loginpro_facebook_auto_create', true);
$facebook_account_linking = get_option('loginpro_facebook_account_linking', true);
$facebook_default_role = get_option('loginpro_facebook_default_role', 'subscriber');
$facebook_button_text = get_option('loginpro_facebook_button_text', 'فیسبوک');
$facebook_version = get_option('loginpro_facebook_version', 'v18.0');
$facebook_scope = get_option('loginpro_facebook_scope', 'email,public_profile');

// تنظیمات گیت‌هاب
$github_enabled = get_option('loginpro_github_enabled', false);
$github_client_id = get_option('loginpro_github_client_id', '');
$github_client_secret = get_option('loginpro_github_client_secret', '');
$github_redirect_uri = get_option('loginpro_github_redirect_uri', home_url('/?loginpro_github_callback=1'));
$github_auto_create = get_option('loginpro_github_auto_create', true);
$github_account_linking = get_option('loginpro_github_account_linking', true);
$github_default_role = get_option('loginpro_github_default_role', 'subscriber');
$github_button_text = get_option('loginpro_github_button_text', 'گیت هاب');

// ==================================================
// پردازش ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_social']) && isset($_POST['social_nonce']) && wp_verify_nonce($_POST['social_nonce'], 'social_settings')) {
    
    // ✅ تنظیمات کلی
    $social_enabled_val = isset($_POST['social_enabled']) ? '1' : '0';
    update_option('loginpro_social_enabled', $social_enabled_val);
    
    $social_show_in_modal_val = isset($_POST['social_show_in_modal']) ? '1' : '0';
    update_option('loginpro_social_show_in_modal', $social_show_in_modal_val);
    
    if (isset($_POST['social_button_style'])) {
        update_option('loginpro_social_button_style', sanitize_text_field($_POST['social_button_style']));
    }
    if (isset($_POST['social_button_size'])) {
        update_option('loginpro_social_button_size', sanitize_text_field($_POST['social_button_size']));
    }
    if (isset($_POST['social_button_radius'])) {
        update_option('loginpro_social_button_radius', intval($_POST['social_button_radius']));
    }
    if (isset($_POST['social_button_padding'])) {
        update_option('loginpro_social_button_padding', sanitize_text_field($_POST['social_button_padding']));
    }
    
    // ✅ تنظیمات گوگل
    $google_enabled_val = isset($_POST['google_enabled']) ? '1' : '0';
    update_option('loginpro_google_enabled', $google_enabled_val);
    
    if (isset($_POST['google_client_id'])) {
        update_option('loginpro_google_client_id', sanitize_text_field($_POST['google_client_id']));
    }
    if (isset($_POST['google_client_secret'])) {
        update_option('loginpro_google_client_secret', sanitize_text_field($_POST['google_client_secret']));
    }
    if (isset($_POST['google_redirect_uri'])) {
        update_option('loginpro_google_redirect_uri', sanitize_url($_POST['google_redirect_uri']));
    }
    
    $google_auto_create_val = isset($_POST['google_auto_create']) ? '1' : '0';
    update_option('loginpro_google_auto_create', $google_auto_create_val);
    
    $google_account_linking_val = isset($_POST['google_account_linking']) ? '1' : '0';
    update_option('loginpro_google_account_linking', $google_account_linking_val);
    
    if (isset($_POST['google_default_role'])) {
        update_option('loginpro_google_default_role', sanitize_text_field($_POST['google_default_role']));
    }
    if (isset($_POST['google_button_text'])) {
        update_option('loginpro_google_button_text', sanitize_text_field($_POST['google_button_text']));
    }
    
    // ✅ تنظیمات فیسبوک
    $facebook_enabled_val = isset($_POST['facebook_enabled']) ? '1' : '0';
    update_option('loginpro_facebook_enabled', $facebook_enabled_val);
    
    if (isset($_POST['facebook_app_id'])) {
        update_option('loginpro_facebook_app_id', sanitize_text_field($_POST['facebook_app_id']));
    }
    if (isset($_POST['facebook_app_secret'])) {
        update_option('loginpro_facebook_app_secret', sanitize_text_field($_POST['facebook_app_secret']));
    }
    if (isset($_POST['facebook_redirect_uri'])) {
        update_option('loginpro_facebook_redirect_uri', sanitize_url($_POST['facebook_redirect_uri']));
    }
    
    $facebook_auto_create_val = isset($_POST['facebook_auto_create']) ? '1' : '0';
    update_option('loginpro_facebook_auto_create', $facebook_auto_create_val);
    
    $facebook_account_linking_val = isset($_POST['facebook_account_linking']) ? '1' : '0';
    update_option('loginpro_facebook_account_linking', $facebook_account_linking_val);
    
    if (isset($_POST['facebook_default_role'])) {
        update_option('loginpro_facebook_default_role', sanitize_text_field($_POST['facebook_default_role']));
    }
    if (isset($_POST['facebook_button_text'])) {
        update_option('loginpro_facebook_button_text', sanitize_text_field($_POST['facebook_button_text']));
    }
    if (isset($_POST['facebook_version'])) {
        update_option('loginpro_facebook_version', sanitize_text_field($_POST['facebook_version']));
    }
    if (isset($_POST['facebook_scope'])) {
        update_option('loginpro_facebook_scope', sanitize_text_field($_POST['facebook_scope']));
    }
    
    // ✅ تنظیمات گیت‌هاب
    $github_enabled_val = isset($_POST['github_enabled']) ? '1' : '0';
    update_option('loginpro_github_enabled', $github_enabled_val);
    
    if (isset($_POST['github_client_id'])) {
        update_option('loginpro_github_client_id', sanitize_text_field($_POST['github_client_id']));
    }
    if (isset($_POST['github_client_secret'])) {
        update_option('loginpro_github_client_secret', sanitize_text_field($_POST['github_client_secret']));
    }
    if (isset($_POST['github_redirect_uri'])) {
        update_option('loginpro_github_redirect_uri', sanitize_url($_POST['github_redirect_uri']));
    }
    
    $github_auto_create_val = isset($_POST['github_auto_create']) ? '1' : '0';
    update_option('loginpro_github_auto_create', $github_auto_create_val);
    
    $github_account_linking_val = isset($_POST['github_account_linking']) ? '1' : '0';
    update_option('loginpro_github_account_linking', $github_account_linking_val);
    
    if (isset($_POST['github_default_role'])) {
        update_option('loginpro_github_default_role', sanitize_text_field($_POST['github_default_role']));
    }
    if (isset($_POST['github_button_text'])) {
        update_option('loginpro_github_button_text', sanitize_text_field($_POST['github_button_text']));
    }
    
    // به‌روزرسانی متغیرها برای نمایش
    $social_enabled = get_option('loginpro_social_enabled', false);
    $social_show_in_modal = get_option('loginpro_social_show_in_modal', true);
    $google_enabled = get_option('loginpro_google_enabled', false);
    $facebook_enabled = get_option('loginpro_facebook_enabled', false);
    $github_enabled = get_option('loginpro_github_enabled', false);
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات با موفقیت ذخیره شد.</p></div>';
}

// ==================================================
// HTML فرم
// ==================================================
?>
<style>
/* ===== استایل اصلی ===== */
.tab-social-settings {
    margin: 20px 20px 0 0;
}

.loginpro-card {
    background: #fff;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 20px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.loginpro-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
    display: flex;
    align-items: center;
    gap: 10px;
}

.loginpro-card h3 .badge {
    font-size: 12px;
    background: #e8f5e9;
    color: #2e7d32;
    padding: 2px 12px;
    border-radius: 20px;
    font-weight: normal;
}

.loginpro-card h3 .badge.inactive {
    background: #fce4ec;
    color: #c62828;
}

/* ===== فرم ===== */
.loginpro-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.loginpro-form-table th {
    width: 200px;
    text-align: right;
    padding: 12px 12px 12px 0;
    font-weight: 600;
    vertical-align: top;
    font-size: 13px;
    color: #1d2327;
}

.loginpro-form-table td {
    padding: 12px 0;
    vertical-align: middle;
}

.loginpro-form-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.loginpro-form-table tr:last-child {
    border-bottom: none;
}

/* ===== فیلدهای ورودی ===== */
.loginpro-form-table input[type="text"],
.loginpro-form-table input[type="password"],
.loginpro-form-table input[type="url"],
.loginpro-form-table select {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 100%;
    max-width: 350px;
    font-size: 13px;
    box-sizing: border-box;
    height: 40px;
    background: #fff;
    transition: border-color 0.2s;
}

.loginpro-form-table input[type="text"]:focus,
.loginpro-form-table input[type="password"]:focus,
.loginpro-form-table input[type="url"]:focus,
.loginpro-form-table select:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.loginpro-form-table input[readonly] {
    background: #f5f5f5;
    color: #666;
    cursor: not-allowed;
}

/* ===== چک‌باکس ===== */
.loginpro-checkbox-label {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    font-size: 13px;
    color: #333;
}

.loginpro-checkbox-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    min-width: 18px;
    cursor: pointer;
    accent-color: #2271b1;
    margin: 0;
}

/* ===== توضیحات ===== */
.description {
    color: #666;
    font-size: 11px;
    margin-top: 4px;
    display: block;
}

.description .highlight {
    color: #2271b1;
    font-weight: 500;
}

/* ===== دکمه ذخیره ===== */
.loginpro-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.loginpro-submit-btn:hover {
    background: #135e96;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-1px);
}

/* ===== پیام موفقیت ===== */
.notice-success {
    background: #d4edda;
    color: #155724;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #28a745;
}

/* ===== تقسیم‌کننده ===== */
.social-divider {
    height: 2px;
    background: linear-gradient(to left, #e2e8f0 30%, transparent);
    margin: 25px 0;
}

/* ===== وضعیت شبکه ===== */
.status-badge {
    display: inline-block;
    padding: 2px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.status-badge.active {
    background: #e8f5e9;
    color: #2e7d32;
}

.status-badge.inactive {
    background: #fce4ec;
    color: #c62828;
}

/* ============================================== */
/* ===== رسپانسیو ===== */
/* ============================================== */

@media (max-width: 1024px) {
    .loginpro-form-table th {
        width: 160px;
        font-size: 12px;
    }
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="password"],
    .loginpro-form-table input[type="url"],
    .loginpro-form-table select {
        max-width: 300px;
    }
}

@media (max-width: 782px) {
    .tab-social-settings {
        margin: 10px 10px 0 0;
    }
    
    .loginpro-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .loginpro-card h3 {
        font-size: 16px;
    }
    
    .loginpro-form-table {
        display: block;
        width: 100%;
    }
    
    .loginpro-form-table tbody {
        display: block;
        width: 100%;
    }
    
    .loginpro-form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #eee;
    }
    
    .loginpro-form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .loginpro-form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
        color: #1d2327;
        border-bottom: none;
    }
    
    .loginpro-form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="password"],
    .loginpro-form-table input[type="url"],
    .loginpro-form-table select {
        max-width: 100% !important;
        width: 100% !important;
        height: 44px;
        font-size: 15px;
        padding: 10px 12px;
    }
    
    .loginpro-checkbox-label {
        font-size: 14px;
        gap: 12px;
    }
    
    .loginpro-checkbox-label input[type="checkbox"] {
        width: 20px;
        height: 20px;
        min-width: 20px;
    }
    
    .loginpro-submit-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
        font-size: 15px;
    }
    
    .social-divider {
        margin: 15px 0;
    }
}

@media (max-width: 480px) {
    .loginpro-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .loginpro-card h3 {
        font-size: 15px;
        flex-wrap: wrap;
    }
    
    .loginpro-form-table tr {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    
    .loginpro-form-table th {
        font-size: 12px;
    }
    
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="password"],
    .loginpro-form-table input[type="url"],
    .loginpro-form-table select {
        height: 40px;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 4px;
    }
    
    .loginpro-checkbox-label {
        font-size: 13px;
    }
    
    .loginpro-checkbox-label input[type="checkbox"] {
        width: 18px;
        height: 18px;
        min-width: 18px;
    }
    
    .loginpro-submit-btn {
        font-size: 14px;
        padding: 10px 16px;
    }
}
</style>

<div class="tab-social-settings">
    
    <!-- ========================================== -->
    <!-- کارت تنظیمات کلی -->
    <!-- ========================================== -->
    <div class="loginpro-card">
        <h3>
            🌐 تنظیمات کلی شبکه‌های اجتماعی
            <span class="badge <?php echo $social_enabled ? 'active' : 'inactive'; ?>">
                <?php echo $social_enabled ? 'فعال' : 'غیرفعال'; ?>
            </span>
        </h3>
        
        <form method="post" action="">
            <?php wp_nonce_field('social_settings', 'social_nonce'); ?>
            <input type="hidden" name="save_social" value="1">
            
            <table class="loginpro-form-table">
                <tr>
                    <th>فعالسازی کلی</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="social_enabled" value="1" <?php checked($social_enabled, true); ?>>
                            <span>ورود با شبکه‌های اجتماعی فعال باشد</span>
                        </label>
                        <span class="description">با غیرفعال کردن این گزینه، تمام دکمه‌های شبکه‌های اجتماعی مخفی می‌شوند</span>
                    </td>
                </tr>
                <tr>
                    <th>نمایش در مودال</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="social_show_in_modal" value="1" <?php checked($social_show_in_modal, true); ?>>
                            <span>دکمه‌های شبکه‌های اجتماعی در مودال نمایش داده شوند</span>
                        </label>
                        <span class="description">اگر غیرفعال باشد، دکمه‌ها در فرم لاگین نمایش داده نمی‌شوند</span>
                    </td>
                </tr>
                <tr>
                    <th>استایل دکمه‌ها</th>
                    <td>
                        <select name="social_button_style">
                            <option value="default" <?php selected($social_button_style, 'default'); ?>>پیش‌فرض</option>
                            <option value="outline" <?php selected($social_button_style, 'outline'); ?>>حاشیه‌دار</option>
                            <option value="solid" <?php selected($social_button_style, 'solid'); ?>>پررنگ</option>
                            <option value="glass" <?php selected($social_button_style, 'glass'); ?>>شیشه‌ای</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>اندازه دکمه‌ها</th>
                    <td>
                        <select name="social_button_size">
                            <option value="small" <?php selected($social_button_size, 'small'); ?>>کوچک</option>
                            <option value="medium" <?php selected($social_button_size, 'medium'); ?>>متوسط</option>
                            <option value="large" <?php selected($social_button_size, 'large'); ?>>بزرگ</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>گردی گوشه دکمه‌ها (px)</th>
                    <td>
                        <input type="number" name="social_button_radius" value="<?php echo esc_attr($social_button_radius); ?>" min="0" max="50" style="max-width:80px;">
                        <span class="description">مقدار 0 برای گوشه‌های تیز، مقادیر بیشتر برای گردتر</span>
                    </td>
                </tr>
                <tr>
                    <th>فاصله داخلی دکمه‌ها</th>
                    <td>
                        <input type="text" name="social_button_padding" value="<?php echo esc_attr($social_button_padding); ?>" placeholder="مثلاً 10px 20px" style="max-width:150px;">
                        <span class="description">مقدار اول بالا/پایین، مقدار دوم چپ/راست</span>
                    </td>
                </tr>
            </table>
            
            <div class="social-divider"></div>
            
            <!-- ========================================== -->
            <!-- بخش گوگل -->
            <!-- ========================================== -->
            <h3 style="margin-top:0;">
                🔑 گوگل (Google)
                <span class="badge <?php echo $google_enabled ? 'active' : 'inactive'; ?>">
                    <?php echo $google_enabled ? 'فعال' : 'غیرفعال'; ?>
                </span>
            </h3>
            
            <table class="loginpro-form-table">
                <tr>
                    <th>فعالسازی</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="google_enabled" value="1" <?php checked($google_enabled, true); ?>>
                            <span>ورود با گوگل فعال باشد</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>Client ID</th>
                    <td>
                        <input type="text" name="google_client_id" value="<?php echo esc_attr($google_client_id); ?>" placeholder="XXXXX-XXXXXXXX.apps.googleusercontent.com">
                        <span class="description">از <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a> دریافت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>Client Secret</th>
                    <td>
                        <input type="password" name="google_client_secret" value="<?php echo esc_attr($google_client_secret); ?>" placeholder="GOCSPX-xxxxxxxxxxxxxxxxxxxx">
                        <span class="description">از Google Cloud Console دریافت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>آدرس بازگشت</th>
                    <td>
                        <input type="text" name="google_redirect_uri" value="<?php echo esc_attr($google_redirect_uri); ?>" readonly>
                        <span class="description">این آدرس را در Google Cloud Console ثبت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>متن دکمه</th>
                    <td>
                        <input type="text" name="google_button_text" value="<?php echo esc_attr($google_button_text); ?>" placeholder="ورود با گوگل">
                    </td>
                </tr>
                <tr>
                    <th>ایجاد خودکار حساب</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="google_auto_create" value="1" <?php checked($google_auto_create, true); ?>>
                            <span>در صورت عدم وجود کاربر، حساب جدید ایجاد شود</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>اتصال حساب‌ها</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="google_account_linking" value="1" <?php checked($google_account_linking, true); ?>>
                            <span>اجازه اتصال حساب گوگل به حساب موجود</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>نقش پیش‌فرض</th>
                    <td>
                        <select name="google_default_role">
                            <option value="subscriber" <?php selected($google_default_role, 'subscriber'); ?>>مشترک</option>
                            <option value="contributor" <?php selected($google_default_role, 'contributor'); ?>>مشارکت‌کننده</option>
                            <option value="author" <?php selected($google_default_role, 'author'); ?>>نویسنده</option>
                            <option value="editor" <?php selected($google_default_role, 'editor'); ?>>ویرایشگر</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <div class="social-divider"></div>
            
            <!-- ========================================== -->
            <!-- بخش فیسبوک -->
            <!-- ========================================== -->
            <h3 style="margin-top:0;">
                📘 فیسبوک (Facebook)
                <span class="badge <?php echo $facebook_enabled ? 'active' : 'inactive'; ?>">
                    <?php echo $facebook_enabled ? 'فعال' : 'غیرفعال'; ?>
                </span>
            </h3>
            
            <table class="loginpro-form-table">
                <tr>
                    <th>فعالسازی</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="facebook_enabled" value="1" <?php checked($facebook_enabled, true); ?>>
                            <span>ورود با فیسبوک فعال باشد</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>App ID</th>
                    <td>
                        <input type="text" name="facebook_app_id" value="<?php echo esc_attr($facebook_app_id); ?>" placeholder="1234567890123456">
                        <span class="description">از <a href="https://developers.facebook.com/apps/" target="_blank">Facebook Developers</a> دریافت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>App Secret</th>
                    <td>
                        <input type="password" name="facebook_app_secret" value="<?php echo esc_attr($facebook_app_secret); ?>" placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                        <span class="description">از Facebook Developers دریافت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>آدرس بازگشت</th>
                    <td>
                        <input type="text" name="facebook_redirect_uri" value="<?php echo esc_attr($facebook_redirect_uri); ?>" readonly>
                        <span class="description">این آدرس را در Facebook Developers ثبت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>نسخه API</th>
                    <td>
                        <select name="facebook_version">
                            <option value="v18.0" <?php selected($facebook_version, 'v18.0'); ?>>v18.0</option>
                            <option value="v17.0" <?php selected($facebook_version, 'v17.0'); ?>>v17.0</option>
                            <option value="v16.0" <?php selected($facebook_version, 'v16.0'); ?>>v16.0</option>
                            <option value="v15.0" <?php selected($facebook_version, 'v15.0'); ?>>v15.0</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>دسترسی‌ها (Scope)</th>
                    <td>
                        <input type="text" name="facebook_scope" value="<?php echo esc_attr($facebook_scope); ?>" placeholder="email,public_profile">
                        <span class="description">با کاما جدا کنید: <span class="highlight">email, public_profile, user_birthday</span></span>
                    </td>
                </tr>
                <tr>
                    <th>متن دکمه</th>
                    <td>
                        <input type="text" name="facebook_button_text" value="<?php echo esc_attr($facebook_button_text); ?>" placeholder="ورود با فیسبوک">
                    </td>
                </tr>
                <tr>
                    <th>ایجاد خودکار حساب</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="facebook_auto_create" value="1" <?php checked($facebook_auto_create, true); ?>>
                            <span>در صورت عدم وجود کاربر، حساب جدید ایجاد شود</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>اتصال حساب‌ها</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="facebook_account_linking" value="1" <?php checked($facebook_account_linking, true); ?>>
                            <span>اجازه اتصال حساب فیسبوک به حساب موجود</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>نقش پیش‌فرض</th>
                    <td>
                        <select name="facebook_default_role">
                            <option value="subscriber" <?php selected($facebook_default_role, 'subscriber'); ?>>مشترک</option>
                            <option value="contributor" <?php selected($facebook_default_role, 'contributor'); ?>>مشارکت‌کننده</option>
                            <option value="author" <?php selected($facebook_default_role, 'author'); ?>>نویسنده</option>
                            <option value="editor" <?php selected($facebook_default_role, 'editor'); ?>>ویرایشگر</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <div class="social-divider"></div>
            
            <!-- ========================================== -->
            <!-- بخش گیت‌هاب -->
            <!-- ========================================== -->
            <h3 style="margin-top:0;">
                🐙 گیت‌هاب (GitHub)
                <span class="badge <?php echo $github_enabled ? 'active' : 'inactive'; ?>">
                    <?php echo $github_enabled ? 'فعال' : 'غیرفعال'; ?>
                </span>
            </h3>
            
            <table class="loginpro-form-table">
                <tr>
                    <th>فعالسازی</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="github_enabled" value="1" <?php checked($github_enabled, true); ?>>
                            <span>ورود با گیت‌هاب فعال باشد</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>Client ID</th>
                    <td>
                        <input type="text" name="github_client_id" value="<?php echo esc_attr($github_client_id); ?>" placeholder="xxxxxxxxxxxxxxxxxxxx">
                        <span class="description">از <a href="https://github.com/settings/developers" target="_blank">GitHub Developer Settings</a> دریافت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>Client Secret</th>
                    <td>
                        <input type="password" name="github_client_secret" value="<?php echo esc_attr($github_client_secret); ?>" placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                        <span class="description">از GitHub Developer Settings دریافت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>آدرس بازگشت</th>
                    <td>
                        <input type="text" name="github_redirect_uri" value="<?php echo esc_attr($github_redirect_uri); ?>" readonly>
                        <span class="description">این آدرس را در GitHub Developer Settings ثبت کنید</span>
                    </td>
                </tr>
                <tr>
                    <th>متن دکمه</th>
                    <td>
                        <input type="text" name="github_button_text" value="<?php echo esc_attr($github_button_text); ?>" placeholder="گیت هابت‌هاب">
                    </td>
                </tr>
                <tr>
                    <th>ایجاد خودکار حساب</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="github_auto_create" value="1" <?php checked($github_auto_create, true); ?>>
                            <span>در صورت عدم وجود کاربر، حساب جدید ایجاد شود</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>اتصال حساب‌ها</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="github_account_linking" value="1" <?php checked($github_account_linking, true); ?>>
                            <span>اجازه اتصال حساب گیت‌هاب به حساب موجود</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>نقش پیش‌فرض</th>
                    <td>
                        <select name="github_default_role">
                            <option value="subscriber" <?php selected($github_default_role, 'subscriber'); ?>>مشترک</option>
                            <option value="contributor" <?php selected($github_default_role, 'contributor'); ?>>مشارکت‌کننده</option>
                            <option value="author" <?php selected($github_default_role, 'author'); ?>>نویسنده</option>
                            <option value="editor" <?php selected($github_default_role, 'editor'); ?>>ویرایشگر</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <div style="margin-top:20px;display:flex;gap:10px;flex-wrap:wrap;">
                <button type="submit" class="loginpro-submit-btn">💾 ذخیره تمام تنظیمات</button>
            </div>
        </form>
    </div>
    
    <!-- ========================================== -->
    <!-- کارت راهنما -->
    <!-- ========================================== -->
    <div class="loginpro-card" style="background:#f8f9fa;border:1px dashed #ccc;">
        <h3 style="border-bottom-color:#ddd;">ℹ️ راهنمای تنظیمات شبکه‌های اجتماعی</h3>
        <ul style="margin:0;padding:0 20px;line-height:2.2;font-size:13px;">
            <li>✅ برای فعال‌سازی هر شبکه اجتماعی، گزینه <strong>"فعال باشد"</strong> را علامت بزنید</li>
            <li>✅ <strong>Client ID/App ID</strong> و <strong>Client Secret/App Secret</strong> را از پنل توسعه‌دهنده هر شبکه دریافت کنید</li>
            <li>✅ آدرس بازگشت (<strong>Redirect URI</strong>) را در پنل توسعه‌دهنده هر شبکه ثبت کنید</li>
            <li>✅ با گزینه <strong>"نمایش در مودال"</strong> می‌توانید دکمه‌ها را در فرم لاگین نمایش دهید یا مخفی کنید</li>
            <li>✅ تنظیمات <strong>"ایجاد خودکار حساب"</strong> و <strong>"اتصال حساب‌ها"</strong> تجربه کاربری را بهبود می‌بخشد</li>
        </ul>
    </div>
</div>