<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب 📧 تنظیمات ایمیل
// ==================================================
$email_default_provider = get_option('loginpro_email_default_provider', 'smtp');
$email_smtp_host = get_option('loginpro_email_smtp_host', 'smtp.gmail.com');
$email_smtp_username = get_option('loginpro_email_smtp_username', '');
$email_smtp_password = get_option('loginpro_email_smtp_password', '');
$email_smtp_port = get_option('loginpro_email_smtp_port', 587);
$email_smtp_encryption = get_option('loginpro_email_smtp_encryption', 'tls');
$email_smtp_from_email = get_option('loginpro_email_smtp_from_email', '');
$email_smtp_from_name = get_option('loginpro_email_smtp_from_name', get_bloginfo('name'));
$email_fallback_provider = get_option('loginpro_email_fallback_provider', '');

// ==================================================
// پردازش ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_email']) && isset($_POST['email_settings']) && wp_verify_nonce($_POST['email_settings'], 'email_settings')) {
    if (isset($_POST['email_default_provider'])) {
        update_option('loginpro_email_default_provider', sanitize_text_field($_POST['email_default_provider']));
    }
    if (isset($_POST['email_smtp_host'])) {
        update_option('loginpro_email_smtp_host', sanitize_text_field($_POST['email_smtp_host']));
    }
    if (isset($_POST['email_smtp_username'])) {
        update_option('loginpro_email_smtp_username', sanitize_text_field($_POST['email_smtp_username']));
    }
    if (isset($_POST['email_smtp_password']) && !empty($_POST['email_smtp_password'])) {
        update_option('loginpro_email_smtp_password', sanitize_text_field($_POST['email_smtp_password']));
    }
    if (isset($_POST['email_smtp_port'])) {
        update_option('loginpro_email_smtp_port', intval($_POST['email_smtp_port']));
    }
    if (isset($_POST['email_smtp_encryption'])) {
        update_option('loginpro_email_smtp_encryption', sanitize_text_field($_POST['email_smtp_encryption']));
    }
    if (isset($_POST['email_smtp_from_email'])) {
        update_option('loginpro_email_smtp_from_email', sanitize_email($_POST['email_smtp_from_email']));
    }
    if (isset($_POST['email_smtp_from_name'])) {
        update_option('loginpro_email_smtp_from_name', sanitize_text_field($_POST['email_smtp_from_name']));
    }
    if (isset($_POST['email_fallback_provider'])) {
        update_option('loginpro_email_fallback_provider', sanitize_text_field($_POST['email_fallback_provider']));
    }
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات با موفقیت ذخیره شد.</p></div>';
}

// ==================================================
// HTML فرم
// ==================================================
?>
<style>
/* ===== استایل‌های تب ایمیل ===== */
.tab-email-settings {
    margin: 20px 20px 0 0;
}

/* ===== کارت اصلی ===== */
.loginpro-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.loginpro-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

/* ===== جدول فرم ===== */
.loginpro-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 10px;
}

.loginpro-form-table th {
    width: 220px;
    text-align: right;
    padding: 15px 15px 15px 0;
    font-weight: 600;
    vertical-align: top;
    font-size: 14px;
    color: #1d2327;
}

.loginpro-form-table td {
    padding: 15px 0;
    vertical-align: middle;
}

.loginpro-form-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.loginpro-form-table tr:last-child {
    border-bottom: none;
}

/* ===== فیلدهای ورودی ===== */
.loginpro-form-table input[type="text"],
.loginpro-form-table input[type="number"],
.loginpro-form-table input[type="email"],
.loginpro-form-table input[type="password"],
.loginpro-form-table select {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 100%;
    max-width: 400px;
    font-size: 14px;
    height: 42px;
    box-sizing: border-box;
    background: #fff;
    transition: border-color 0.2s;
}

.loginpro-form-table input[type="text"]:focus,
.loginpro-form-table input[type="number"]:focus,
.loginpro-form-table input[type="email"]:focus,
.loginpro-form-table input[type="password"]:focus,
.loginpro-form-table select:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.loginpro-form-table input[type="number"] {
    max-width: 150px;
}

/* ===== توضیحات ===== */
.description {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

/* ===== پیام موفقیت ===== */
.notice-success {
    background: #d4edda;
    color: #155724;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #28a745;
}

/* ===== دکمه ذخیره ===== */
.loginpro-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.loginpro-submit-btn:hover {
    background: #135e96;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-1px);
}

/* ============================================== */
/* ===== رسپانسیو ===== */
/* ============================================== */

@media (max-width: 1024px) {
    .loginpro-form-table th {
        width: 180px;
        font-size: 13px;
    }
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="number"],
    .loginpro-form-table input[type="email"],
    .loginpro-form-table input[type="password"],
    .loginpro-form-table select {
        max-width: 320px;
    }
}

@media (max-width: 782px) {
    .tab-email-settings {
        margin: 10px 10px 0 0;
    }
    
    .loginpro-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .loginpro-card h3 {
        font-size: 16px;
    }
    
    /* ===== تبدیل جدول به ستونی ===== */
    .loginpro-form-table {
        display: block;
        width: 100%;
    }
    
    .loginpro-form-table tbody {
        display: block;
        width: 100%;
    }
    
    .loginpro-form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #eee;
    }
    
    .loginpro-form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .loginpro-form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
        color: #1d2327;
        border-bottom: none;
    }
    
    .loginpro-form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    
    /* ===== فیلدها در موبایل ===== */
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="number"],
    .loginpro-form-table input[type="email"],
    .loginpro-form-table input[type="password"],
    .loginpro-form-table select {
        max-width: 100% !important;
        width: 100% !important;
        height: 44px;
        font-size: 15px;
        padding: 10px 12px;
    }
    
    .loginpro-form-table input[type="number"] {
        max-width: 100% !important;
    }
    
    /* ===== دکمه ذخیره ===== */
    .loginpro-submit-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
        font-size: 15px;
    }
    
    /* ===== توضیحات ===== */
    .description {
        font-size: 11px;
        margin-top: 4px;
    }
    
    /* ===== پیام موفقیت ===== */
    .notice-success {
        font-size: 13px;
        padding: 10px 14px;
    }
}

@media (max-width: 480px) {
    .loginpro-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .loginpro-card h3 {
        font-size: 15px;
    }
    
    .loginpro-form-table tr {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    
    .loginpro-form-table th {
        font-size: 12px;
    }
    
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="number"],
    .loginpro-form-table input[type="email"],
    .loginpro-form-table input[type="password"],
    .loginpro-form-table select {
        height: 40px;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 4px;
    }
    
    .loginpro-submit-btn {
        font-size: 14px;
        padding: 10px 16px;
    }
    
    .description {
        font-size: 10px;
    }
    
    .notice-success {
        font-size: 12px;
        padding: 8px 12px;
    }
}
</style>

<div class="tab-email-settings">
    <div class="loginpro-card">
        <h3>📧 تنظیمات ایمیل</h3>
        <form method="post">
            <?php wp_nonce_field('email_settings', 'email_settings'); ?>
            <input type="hidden" name="save_email" value="1">
            
            <table class="loginpro-form-table">
                <tr>
                    <th>ارائه دهنده ایمیل</th>
                    <td>
                        <select name="email_default_provider">
                            <option value="smtp" <?php selected($email_default_provider, 'smtp'); ?>>SMTP</option>
                            <option value="mailgun" <?php selected($email_default_provider, 'mailgun'); ?>>Mailgun</option>
                            <option value="sendgrid" <?php selected($email_default_provider, 'sendgrid'); ?>>SendGrid</option>
                            <option value="wp_mail" <?php selected($email_default_provider, 'wp_mail'); ?>>wp_mail (پیش‌فرض)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>سرور SMTP</th>
                    <td>
                        <input type="text" name="email_smtp_host" value="<?php echo esc_attr($email_smtp_host); ?>" placeholder="smtp.gmail.com">
                        <span class="description">مثال: smtp.gmail.com</span>
                    </td>
                </tr>
                <tr>
                    <th>نام کاربری SMTP</th>
                    <td>
                        <input type="text" name="email_smtp_username" value="<?php echo esc_attr($email_smtp_username); ?>" placeholder="your-email@gmail.com">
                    </td>
                </tr>
                <tr>
                    <th>رمز عبور SMTP</th>
                    <td>
                        <input type="password" name="email_smtp_password" value="" placeholder="برای تغییر ندهید، خالی بگذارید">
                        <?php if(!empty($email_smtp_password)): ?>
                            <span class="description">✅ رمز عبور ذخیره شده است. برای تغییر مجدداً وارد کنید.</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>پورت SMTP</th>
                    <td>
                        <input type="number" name="email_smtp_port" value="<?php echo esc_attr($email_smtp_port); ?>" min="1" max="9999">
                        <span class="description">587 برای TLS، 465 برای SSL</span>
                    </td>
                </tr>
                <tr>
                    <th>رمزنگاری SMTP</th>
                    <td>
                        <select name="email_smtp_encryption">
                            <option value="none" <?php selected($email_smtp_encryption, 'none'); ?>>بدون رمزنگاری</option>
                            <option value="tls" <?php selected($email_smtp_encryption, 'tls'); ?>>TLS</option>
                            <option value="ssl" <?php selected($email_smtp_encryption, 'ssl'); ?>>SSL</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>آدرس ایمیل فرستنده</th>
                    <td>
                        <input type="email" name="email_smtp_from_email" value="<?php echo esc_attr($email_smtp_from_email); ?>" placeholder="noreply@example.com">
                    </td>
                </tr>
                <tr>
                    <th>نام فرستنده</th>
                    <td>
                        <input type="text" name="email_smtp_from_name" value="<?php echo esc_attr($email_smtp_from_name); ?>" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>">
                    </td>
                </tr>
                <tr>
                    <th>ارائه دهنده پشتیبان</th>
                    <td>
                        <select name="email_fallback_provider">
                            <option value="">هیچکدام</option>
                            <option value="smtp" <?php selected($email_fallback_provider, 'smtp'); ?>>SMTP</option>
                            <option value="wp_mail" <?php selected($email_fallback_provider, 'wp_mail'); ?>>wp_mail</option>
                        </select>
                        <span class="description">اگر ارائه دهنده اصلی موفق نبود، از این ارائه دهنده استفاده شود</span>
                    </td>
                </tr>
            </table>
            
            <button type="submit" class="loginpro-submit-btn">💾 ذخیره تنظیمات</button>
        </form>
    </div>
</div>