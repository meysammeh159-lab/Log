<?php
defined('ABSPATH') || exit;

global $wpdb;

$logs_table = $wpdb->prefix . 'loginpro_logs';
$history_table = $wpdb->prefix . 'loginpro_login_history';

$logs_exists = $wpdb->get_var("SHOW TABLES LIKE '$logs_table'") === $logs_table;
$history_exists = $wpdb->get_var("SHOW TABLES LIKE '$history_table'") === $history_table;

$per_page = 20;
$current_page = isset($_GET['activity_page']) ? max(1, intval($_GET['activity_page'])) : 1;
$offset = ($current_page - 1) * $per_page;
$filter_type = isset($_GET['filter_type']) ? sanitize_text_field($_GET['filter_type']) : '';
$filter_user = isset($_GET['filter_user']) ? intval($_GET['filter_user']) : 0;

$where = [];
$params = [];

if (!empty($filter_type) && $filter_type !== 'all') {
    $where[] = "type = %s";
    $params[] = $filter_type;
}

if (!empty($filter_user)) {
    $where[] = "user_id = %d";
    $params[] = $filter_user;
}

$where_sql = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);

if ($logs_exists) {
    if (!empty($params)) {
        $total_items = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $logs_table $where_sql", $params));
        $activities = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $logs_table $where_sql ORDER BY created_at DESC LIMIT %d OFFSET %d",
            array_merge($params, [$per_page, $offset])
        ));
    } else {
        $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table");
        $activities = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $logs_table ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ));
    }
} else {
    $total_items = 0;
    $activities = [];
}

$total_pages = ceil($total_items / $per_page);
$users = get_users(['number' => 100, 'fields' => ['ID', 'user_login', 'display_name']]);
$activity_types = $logs_exists ? $wpdb->get_col("SELECT DISTINCT type FROM $logs_table") : [];

$stats = [];
if ($logs_exists) {
    $stats['today'] = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table WHERE DATE(created_at) = CURDATE()");
    $stats['week'] = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $stats['month'] = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $stats['login_success'] = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table WHERE type = 'login_success'");
    $stats['login_failed'] = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table WHERE type = 'login_failed'");
}
?>
<style>
.tab-activity-settings {
    margin: 20px 20px 0 0;
}

.activity-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.activity-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.activity-stats {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 12px;
    margin-bottom: 25px;
}

.stat-item {
    padding: 15px;
    border-radius: 12px;
    text-align: center;
}
.stat-item .num { font-size: 26px; font-weight: 700; }
.stat-item .label { font-size: 12px; margin-top: 4px; }

.stat-blue { background: #e3f2fd; }
.stat-blue .num { color: #1565c0; }
.stat-green { background: #e8f5e9; }
.stat-green .num { color: #2e7d32; }
.stat-orange { background: #fff3e0; }
.stat-orange .num { color: #e65100; }
.stat-purple { background: #e8eaf6; }
.stat-purple .num { color: #283593; }
.stat-red { background: #ffebee; }
.stat-red .num { color: #c62828; }

.activity-filter {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
    align-items: flex-end;
}
.activity-filter label { font-size: 13px; font-weight: 600; display: block; margin-bottom: 3px; }
.activity-filter select,
.activity-filter input { padding: 6px 12px; border: 1px solid #ddd; border-radius: 6px; height: 36px; }
.activity-filter .button { height: 36px; line-height: 34px; padding: 0 16px; }

.notice-info {
    background: #d1ecf1;
    color: #0c5460;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #17a2b8;
}

.wp-list-table th { font-weight: 600; }
.wp-list-table td { padding: 8px 10px !important; vertical-align: middle; }

.activity-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 500;
}
.badge-success { background: #e8f5e9; color: #2e7d32; }
.badge-danger { background: #ffebee; color: #c62828; }
.badge-warning { background: #fff3e0; color: #e65100; }
.badge-info { background: #e3f2fd; color: #1565c0; }

.pagination { margin-top: 20px; text-align: center; }
.pagination a {
    display: inline-block;
    padding: 5px 12px;
    margin: 0 3px;
    border-radius: 4px;
    text-decoration: none;
    background: #f1f1f1;
    color: #333;
}
.pagination a.active { background: #2271b1; color: #fff; }
.pagination a:hover { background: #ddd; }
.pagination a.active:hover { background: #135e96; }

.description { color: #666; font-size: 12px; margin-top: 5px; }

@media (max-width: 1024px) {
    .activity-stats { grid-template-columns: repeat(3, 1fr); }
}

@media (max-width: 782px) {
    .tab-activity-settings { margin: 10px 10px 0 0; }
    .activity-card { padding: 16px 18px; border-radius: 8px; }
    .activity-card h3 { font-size: 16px; }
    .activity-stats { grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .stat-item { padding: 10px; }
    .stat-item .num { font-size: 20px; }
    .stat-item .label { font-size: 11px; }
    .activity-filter { flex-direction: column; align-items: stretch; }
    .activity-filter select,
    .activity-filter input { width: 100%; }
    .activity-filter .button { width: 100%; text-align: center; }
    .wp-list-table thead { display: none; }
    .wp-list-table tbody tr { display: block; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 6px; padding: 8px; }
    .wp-list-table tbody tr td { display: flex; justify-content: space-between; padding: 4px 6px !important; border-bottom: 1px solid #f0f0f0; }
    .wp-list-table tbody tr td:last-child { border-bottom: none; }
    .wp-list-table tbody tr td:before { content: attr(data-label); font-weight: 600; font-size: 11px; color: #555; }
    .pagination a { padding: 4px 10px; font-size: 13px; }
}

@media (max-width: 480px) {
    .activity-card { padding: 12px 14px; }
    .activity-card h3 { font-size: 15px; }
    .activity-stats { grid-template-columns: 1fr 1fr; gap: 6px; }
    .stat-item { padding: 8px; border-radius: 8px; }
    .stat-item .num { font-size: 17px; }
    .stat-item .label { font-size: 10px; }
    .wp-list-table tbody tr td { font-size: 12px; padding: 3px 4px !important; }
    .wp-list-table tbody tr td:before { font-size: 10px; }
}
</style>

<div class="tab-activity-settings">
    <div class="activity-card">
        <h3>👥 فعالیت کاربران</h3>
        <p class="description">مشاهده و جستجوی فعالیت‌های کاربران در سیستم</p>
        
        <?php if ($logs_exists): ?>
        <div class="activity-stats">
            <div class="stat-item stat-blue">
                <div class="num"><?php echo isset($stats['today']) ? $stats['today'] : 0; ?></div>
                <div class="label">فعالیت امروز</div>
            </div>
            <div class="stat-item stat-green">
                <div class="num"><?php echo isset($stats['week']) ? $stats['week'] : 0; ?></div>
                <div class="label">فعالیت این هفته</div>
            </div>
            <div class="stat-item stat-orange">
                <div class="num"><?php echo isset($stats['month']) ? $stats['month'] : 0; ?></div>
                <div class="label">فعالیت این ماه</div>
            </div>
            <div class="stat-item stat-purple">
                <div class="num"><?php echo isset($stats['login_success']) ? $stats['login_success'] : 0; ?></div>
                <div class="label">ورود موفق</div>
            </div>
            <div class="stat-item stat-red">
                <div class="num"><?php echo isset($stats['login_failed']) ? $stats['login_failed'] : 0; ?></div>
                <div class="label">ورود ناموفق</div>
            </div>
        </div>
        <?php endif; ?>
        
        <form method="get" class="activity-filter">
            <input type="hidden" name="page" value="loginpro-dashboard">
            <input type="hidden" name="tab" value="user-activity">
            
            <div>
                <label>نوع فعالیت:</label>
                <select name="filter_type">
                    <option value="all" <?php selected($filter_type, 'all'); ?>>همه</option>
                    <?php foreach ($activity_types as $type): ?>
                        <option value="<?php echo esc_attr($type); ?>" <?php selected($filter_type, $type); ?>>
                            <?php echo esc_html($type); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label>کاربر:</label>
                <select name="filter_user">
                    <option value="0">همه کاربران</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?php echo $user->ID; ?>" <?php selected($filter_user, $user->ID); ?>>
                            <?php echo esc_html($user->display_name . ' (' . $user->user_login . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <button type="submit" class="button">🔍 اعمال فیلتر</button>
                <a href="?page=loginpro-dashboard&tab=user-activity" class="button">🗑️ پاک کردن</a>
            </div>
        </form>
        
        <?php if (!$logs_exists): ?>
            <div class="notice-info">
                <p>⚠️ جدول فعالیت‌ها هنوز ایجاد نشده است. لطفاً افزونه را غیرفعال و دوباره فعال کنید.</p>
            </div>
        <?php elseif (empty($activities)): ?>
            <div class="notice-info">
                <p>📭 هیچ فعالیتی یافت نشد.</p>
            </div>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th width="15%">زمان</th>
                            <th width="12%">نوع</th>
                            <th width="40%">پیام</th>
                            <th width="13%">IP</th>
                            <th width="20%">کاربر</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($activities as $activity): ?>
                        <tr>
                            <td data-label="زمان"><?php echo esc_html($activity->created_at); ?></td>
                            <td data-label="نوع">
                                <span class="activity-badge 
                                    <?php 
                                    if (strpos($activity->type, 'success') !== false || $activity->type == 'login') echo 'badge-success';
                                    elseif (strpos($activity->type, 'failed') !== false || $activity->type == 'error') echo 'badge-danger';
                                    elseif ($activity->type == 'logout') echo 'badge-warning';
                                    else echo 'badge-info';
                                    ?>">
                                    <?php echo esc_html($activity->type); ?>
                                </span>
                            </td>
                            <td data-label="پیام"><?php echo esc_html(substr($activity->message, 0, 80)); ?>…</td>
                            <td data-label="IP"><?php echo esc_html($activity->ip_address); ?></td>
                            <td data-label="کاربر">
                                <?php 
                                if ($activity->user_id) {
                                    $user = get_userdata($activity->user_id);
                                    echo $user ? esc_html($user->display_name) : esc_html($activity->user_id);
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php
                for ($i = 1; $i <= $total_pages; $i++) {
                    $url = add_query_arg(['activity_page' => $i, 'filter_type' => $filter_type, 'filter_user' => $filter_user]);
                    $active = $i == $current_page ? 'active' : '';
                    echo '<a href="' . esc_url($url) . '" class="' . $active . '">' . $i . '</a>';
                }
                ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>