<?php
/**
 * تب تنظیمات ظاهر لاگین‌پرو
 * مسیر: admin/tabs/tab-appearance.php
 * 
 * @package LoginPro
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// بارگذاری وابستگی‌های Color Picker
// ==================================================
wp_enqueue_style('wp-color-picker');
wp_enqueue_script('wp-color-picker');
wp_enqueue_media();

// ==================================================
// ذخیره تنظیمات با پاکسازی Cache
// ==================================================

if (isset($_POST['save_appearance']) && isset($_POST['_wpnonce'])) {
    if (wp_verify_nonce($_POST['_wpnonce'], 'loginpro_appearance') && current_user_can('manage_options')) {
        
        // ==================================================
        // ذخیره رنگ‌ها
        // ==================================================
        $colorFields = [
            'primary_color', 'button_color', 'button_hover_color', 
            'error_color', 'success_color', 'background_color', 
            'text_color', 'subtitle_color', 'border_color',
            // رنگ‌های جدید قالب کاربری
            'dashboard_header_bg_color', 'dashboard_header_text_color',
            'dashboard_tab_active_color', 'dashboard_tab_hover_color',
            'dashboard_section_bg_color', 'dashboard_section_border_color'
        ];
        foreach ($colorFields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, sanitize_hex_color($_POST[$field]));
            }
        }
        
        // ==================================================
        // ذخیره اندازه‌ها
        // ==================================================
        $sizeFields = ['form_width', 'form_padding', 'border_radius', 'input_height', 'button_height'];
        foreach ($sizeFields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        // ==================================================
        // ذخیره فونت
        // ==================================================
        if (isset($_POST['font_family'])) {
            update_option('loginpro_font_family', sanitize_text_field($_POST['font_family']));
        }
        
        $fontNumberFields = ['title_font_size', 'subtitle_font_size', 'help_font_size', 'normal_font_size', 'button_font_size', 'forgot_font_size'];
        foreach ($fontNumberFields as $field) {
            if (isset($_POST[$field]) && is_numeric($_POST[$field])) {
                update_option('loginpro_' . $field, (int) $_POST[$field]);
            }
        }
        
        // ==================================================
        // ذخیره لوگو
        // ==================================================
        if (isset($_POST['logo_url'])) {
            update_option('loginpro_logo_url', esc_url_raw($_POST['logo_url']));
        }
        if (isset($_POST['logo_width'])) {
            update_option('loginpro_logo_width', (int) $_POST['logo_width']);
        }
        if (isset($_POST['logo_height'])) {
            update_option('loginpro_logo_height', sanitize_text_field($_POST['logo_height']));
        }
        
        // ==================================================
        // ذخیره CSS سفارشی
        // ==================================================
        if (isset($_POST['custom_css'])) {
            update_option('loginpro_custom_css', wp_strip_all_tags($_POST['custom_css']));
        }
        
        // ==================================================
        // ذخیره متن‌ها با Escaping مناسب
        // ==================================================
        $textFields = [
            'text_title', 'text_subtitle', 'text_help_identifier', 'text_continue_btn',
            'text_password_title', 'text_help_password', 'text_login_btn', 'text_register_btn',
            'text_otp_title', 'text_help_otp', 'text_verify_btn', 'text_forgot_password',
            'text_header_title', 'text_header_description', 'text_footer_text', 'text_footer_links',
            'text_privacy_link', 'text_terms_link', 'text_otp_register_message', 'text_otp_login_message',
            'text_otp_subtitle'
        ];
        foreach ($textFields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        // ==================================================
        // ذخیره تنظیمات دکمه مودال
        // ==================================================
        $modalColorFields = [
            'modal_btn_bg_color', 'modal_btn_bg_hover_color', 
            'modal_btn_text_color', 'modal_btn_text_hover_color', 
            'modal_btn_border_color', 'modal_btn_shadow_color'
        ];
        foreach ($modalColorFields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, sanitize_hex_color($_POST[$field]));
            }
        }
        
        $modalSizeFields = ['modal_btn_border_width', 'modal_btn_border_radius', 'modal_btn_font_size'];
        foreach ($modalSizeFields as $field) {
            if (isset($_POST[$field]) && is_numeric($_POST[$field])) {
                update_option('loginpro_' . $field, (int) $_POST[$field]);
            }
        }
        
        $modalTextFields = [
            'modal_btn_text', 'modal_btn_logged_text', 'modal_btn_icon', 
            'modal_btn_logged_icon', 'modal_btn_padding', 'modal_btn_width', 'modal_btn_height'
        ];
        foreach ($modalTextFields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        $modalSelectFields = ['modal_btn_shadow', 'modal_btn_shadow_direction', 'modal_btn_hover_effect', 'modal_btn_size'];
        foreach ($modalSelectFields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        // ==================================================
        // ذخیره تنظیمات قالب کاربری
        // ==================================================
        $dashboardFields = [
            'dashboard_width', 'dashboard_border_radius', 'dashboard_input_height',
            'dashboard_button_height', 'dashboard_title_font_size',
            'dashboard_normal_font_size', 'dashboard_button_font_size', 'dashboard_font_family'
        ];
        foreach ($dashboardFields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        // ==================================================
        // 🔥 CRITICAL FIX: پاکسازی کامل Cache
        // ==================================================
        // این بخش مشکل اصلی را حل می‌کند - تنظیمات در Cache نمی‌مانند
        
        // 1. پاکسازی Object Cache
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        // 2. پاکسازی Transients مربوط به تنظیمات
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_loginpro_%'
            )
        );
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_timeout_loginpro_%'
            )
        );
        
        // 3. پاکسازی Cache دیتابیس
        if (function_exists('wp_cache_clean_cache')) {
            wp_cache_clean_cache();
        }
        
        // 4. آپدیت نسخه Assets برای刷新 CSS/JS
        update_option('loginpro_assets_version', time());
        
        // 5. ثبت زمان آخرین آپدیت تنظیمات
        update_option('loginpro_settings_updated', time());
        
        echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات ظاهر با موفقیت ذخیره شد.</p></div>';
    } else {
        echo '<div class="notice notice-error is-dismissible"><p>❌ خطای امنیتی. لطفاً مجدد تلاش کنید.</p></div>';
    }
}

// ==================================================
// دریافت تنظیمات
// ==================================================

$settings = [
    // رنگ‌ها
    'primary_color' => get_option('loginpro_primary_color', '#ef394e'),
    'button_color' => get_option('loginpro_button_color', '#ef394e'),
    'button_hover_color' => get_option('loginpro_button_hover_color', '#e02e43'),
    'error_color' => get_option('loginpro_error_color', '#dc3545'),
    'success_color' => get_option('loginpro_success_color', '#28a745'),
    'background_color' => get_option('loginpro_background_color', '#ffffff'),
    'text_color' => get_option('loginpro_text_color', '#1a1a1a'),
    'subtitle_color' => get_option('loginpro_subtitle_color', '#6c6c6c'),
    'border_color' => get_option('loginpro_border_color', '#e0e0e0'),
    
    // رنگ‌های جدید قالب کاربری
    'dashboard_header_bg_color' => get_option('loginpro_dashboard_header_bg_color', '#ef394e'),
    'dashboard_header_text_color' => get_option('loginpro_dashboard_header_text_color', '#ffffff'),
    'dashboard_tab_active_color' => get_option('loginpro_dashboard_tab_active_color', '#ef394e'),
    'dashboard_tab_hover_color' => get_option('loginpro_dashboard_tab_hover_color', '#f0f0f0'),
    'dashboard_section_bg_color' => get_option('loginpro_dashboard_section_bg_color', '#f8f9fa'),
    'dashboard_section_border_color' => get_option('loginpro_dashboard_section_border_color', '#e9ecef'),
    
    // اندازه‌ها
    'form_width' => get_option('loginpro_form_width', '400px'),
    'form_padding' => get_option('loginpro_form_padding', '40px 30px'),
    'border_radius' => get_option('loginpro_border_radius', 20),
    'input_height' => get_option('loginpro_input_height', 48),
    'button_height' => get_option('loginpro_button_height', 52),
    
    // فونت
    'font_family' => get_option('loginpro_font_family', 'IRANSans, Tahoma, sans-serif'),
    'title_font_size' => get_option('loginpro_title_font_size', 22),
    'subtitle_font_size' => get_option('loginpro_subtitle_font_size', 14),
    'help_font_size' => get_option('loginpro_help_font_size', 13),
    'normal_font_size' => get_option('loginpro_normal_font_size', 15),
    'button_font_size' => get_option('loginpro_button_font_size', 16),
    'forgot_font_size' => get_option('loginpro_forgot_font_size', 12),
    
    // لوگو
    'logo_url' => get_option('loginpro_logo_url', ''),
    'logo_width' => get_option('loginpro_logo_width', '150'),
    'logo_height' => get_option('loginpro_logo_height', 'auto'),
    
    // CSS
    'custom_css' => get_option('loginpro_custom_css', ''),
    
    // متن‌ها
    'text_title' => get_option('loginpro_text_title', 'ورود یا ثبت نام'),
    'text_subtitle' => get_option('loginpro_text_subtitle', 'لطفا اطلاعات خود را وارد کنید'),
    'text_help_identifier' => get_option('loginpro_text_help_identifier', 'ایمیل یا نام کاربری خود را وارد کنید'),
    'text_continue_btn' => get_option('loginpro_text_continue_btn', 'ادامه'),
    'text_password_title' => get_option('loginpro_text_password_title', 'ورود با رمز عبور'),
    'text_help_password' => get_option('loginpro_text_help_password', 'رمز عبور خود را وارد کنید'),
    'text_login_btn' => get_option('loginpro_text_login_btn', 'ورود'),
    'text_register_btn' => get_option('loginpro_text_register_btn', 'ثبت نام'),
    'text_otp_title' => get_option('loginpro_text_otp_title', 'کد تایید'),
    'text_help_otp' => get_option('loginpro_text_help_otp', 'کد 6 رقمی ارسال شده را وارد کنید'),
    'text_verify_btn' => get_option('loginpro_text_verify_btn', 'تایید و ورود'),
    'text_forgot_password' => get_option('loginpro_text_forgot_password', 'فراموشی رمز عبور'),
    'text_otp_subtitle' => get_option('loginpro_text_otp_subtitle', 'لطفا کد 6 رقمی ارسال شده را وارد کنید.'),
    
    // هدر و فوتر
    'text_header_title' => get_option('loginpro_text_header_title', 'لاگین پرو'),
    'text_header_description' => get_option('loginpro_text_header_description', 'به سامانه کاربری خوش آمدید'),
    'text_footer_text' => get_option('loginpro_text_footer_text', ''),
    'text_footer_links' => get_option('loginpro_text_footer_links', ''),
    'text_privacy_link' => get_option('loginpro_text_privacy_link', ''),
    'text_terms_link' => get_option('loginpro_text_terms_link', ''),
    
    // متن‌های OTP
    'text_otp_register_message' => get_option('loginpro_text_otp_register_message', 'شماره شما ثبت نشده است. کد تایید برای ثبت نام ارسال شد.'),
    'text_otp_login_message' => get_option('loginpro_text_otp_login_message', 'کد تایید برای شما ارسال شد.'),
    
    // تنظیمات دکمه مودال
    'modal_btn_bg_color' => get_option('loginpro_modal_btn_bg_color', '#ef394e'),
    'modal_btn_bg_hover_color' => get_option('loginpro_modal_btn_bg_hover_color', '#e02e43'),
    'modal_btn_text_color' => get_option('loginpro_modal_btn_text_color', '#ffffff'),
    'modal_btn_text_hover_color' => get_option('loginpro_modal_btn_text_hover_color', '#ffffff'),
    'modal_btn_text' => get_option('loginpro_modal_btn_text', 'ورود / ثبت‌نام'),
    'modal_btn_logged_text' => get_option('loginpro_modal_btn_logged_text', 'پنل کاربری'),
    'modal_btn_icon' => get_option('loginpro_modal_btn_icon', ''),
    'modal_btn_logged_icon' => get_option('loginpro_modal_btn_logged_icon', ''),
    'modal_btn_border_width' => get_option('loginpro_modal_btn_border_width', 0),
    'modal_btn_border_radius' => get_option('loginpro_modal_btn_border_radius', 8),
    'modal_btn_padding' => get_option('loginpro_modal_btn_padding', '8px 20px'),
    'modal_btn_font_size' => get_option('loginpro_modal_btn_font_size', 14),
    'modal_btn_shadow' => get_option('loginpro_modal_btn_shadow', 'small'),
    'modal_btn_shadow_direction' => get_option('loginpro_modal_btn_shadow_direction', 'bottom'),
    'modal_btn_hover_effect' => get_option('loginpro_modal_btn_hover_effect', 'opacity'),
    'modal_btn_size' => get_option('loginpro_modal_btn_size', 'medium'),
    'modal_btn_border_color' => get_option('loginpro_modal_btn_border_color', 'transparent'),
    'modal_btn_shadow_color' => get_option('loginpro_modal_btn_shadow_color', 'rgba(0,0,0,0.15)'),
    'modal_btn_width' => get_option('loginpro_modal_btn_width', ''),
    'modal_btn_height' => get_option('loginpro_modal_btn_height', ''),
    
    // تنظیمات قالب کاربری
    'dashboard_width' => get_option('loginpro_dashboard_width', '800px'),
    'dashboard_border_radius' => get_option('loginpro_dashboard_border_radius', '24'),
    'dashboard_input_height' => get_option('loginpro_dashboard_input_height', '52'),
    'dashboard_button_height' => get_option('loginpro_dashboard_button_height', '52'),
    'dashboard_title_font_size' => get_option('loginpro_dashboard_title_font_size', '22'),
    'dashboard_normal_font_size' => get_option('loginpro_dashboard_normal_font_size', '15'),
    'dashboard_button_font_size' => get_option('loginpro_dashboard_button_font_size', '16'),
    'dashboard_font_family' => get_option('loginpro_dashboard_font_family', 'IRANSans, Tahoma, sans-serif'),
];
?>

<!-- HTML فرم - بدون تغییر (همان کد قبلی) -->
<div class="wrap">
    <h1>تنظیمات ظاهر لاگین‌پرو</h1>
    
    <?php
    // نمایش پیام‌های اضافی برای Cache
    if (isset($_POST['save_appearance']) && wp_verify_nonce($_POST['_wpnonce'] ?? '', 'loginpro_appearance')) {
        echo '<div class="notice notice-info is-dismissible"><p>🔄 Cache پاکسازی شد. تغییرات در صفحه‌های عمومی اعمال خواهد شد.</p></div>';
    }
    ?>
    
    <form method="post" id="loginpro-appearance-form">
        <?php wp_nonce_field('loginpro_appearance'); ?>
        
        <!-- ================================================== -->
        <!-- ادامه کد HTML بدون تغییر -->
        <!-- ================================================== -->
        
        <div class="nav-tab-wrapper">
            <a href="#colors" class="nav-tab nav-tab-active" data-tab="colors">رنگ‌ها</a>
            <a href="#sizes" class="nav-tab" data-tab="sizes">اندازه‌ها</a>
            <a href="#typography" class="nav-tab" data-tab="typography">تایپوگرافی</a>
            <a href="#texts" class="nav-tab" data-tab="texts">متن‌ها</a>
            <a href="#modal-button" class="nav-tab" data-tab="modal-button">دکمه مودال</a>
            <a href="#logo" class="nav-tab" data-tab="logo">لوگو</a>
            <a href="#user-dashboard" class="nav-tab" data-tab="user-dashboard">قالب کاربری</a>
            <a href="#custom" class="nav-tab" data-tab="custom">CSS سفارشی</a>
        </div>
        
        <!-- ================================================== -->
        <!-- تب رنگ‌ها -->
        <!-- ================================================== -->
        <div id="colors" class="tab-content" style="display: block;">
            <table class="form-table">
                <?php
                $colorFields = [
                    'primary_color' => 'رنگ اصلی (لینک‌ها)',
                    'button_color' => 'رنگ دکمه',
                    'button_hover_color' => 'رنگ دکمه در هاور',
                    'error_color' => 'رنگ خطا',
                    'success_color' => 'رنگ موفقیت',
                    'background_color' => 'رنگ پس‌زمینه فرم',
                    'text_color' => 'رنگ متن اصلی',
                    'subtitle_color' => 'رنگ متن فرعی',
                    'border_color' => 'رنگ حاشیه'
                ];
                foreach ($colorFields as $key => $label):
                ?>
                <tr>
                    <th scope="row"><label><?php echo esc_html($label); ?></label></th>
                    <td>
                        <input type="text" 
                               name="<?php echo esc_attr($key); ?>" 
                               value="<?php echo esc_attr($settings[$key]); ?>" 
                               class="loginpro-color-picker" 
                               data-default-color="<?php echo esc_attr($settings[$key]); ?>">
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        
        <!-- ================================================== -->
        <!-- تب اندازه‌ها -->
        <!-- ================================================== -->
        <div id="sizes" class="tab-content" style="display: none;">
            <table class="form-table">
                <?php
                $sizeFields = [
                    'form_width' => 'عرض فرم',
                    'form_padding' => 'فاصله داخلی فرم',
                    'border_radius' => 'گردی گوشه فرم (px)',
                    'input_height' => 'ارتفاع فیلدها (px)',
                    'button_height' => 'ارتفاع دکمه (px)'
                ];
                foreach ($sizeFields as $key => $label):
                ?>
                <tr>
                    <th scope="row"><label><?php echo esc_html($label); ?></label></th>
                    <td>
                        <input type="text" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($settings[$key]); ?>" style="width: 150px;">
                        <?php if ($key !== 'form_padding'): ?>px<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        
        <!-- ================================================== -->
        <!-- تب تایپوگرافی -->
        <!-- ================================================== -->
        <div id="typography" class="tab-content" style="display: none;">
            <table class="form-table">
                <tr>
                    <th scope="row"><label>فونت</label></th>
                    <td>
                        <select name="font_family">
                            <option value="IRANSans, Tahoma, sans-serif" <?php selected($settings['font_family'], 'IRANSans, Tahoma, sans-serif'); ?>>ایران‌سنس</option>
                            <option value="Vazir, Tahoma, sans-serif" <?php selected($settings['font_family'], 'Vazir, Tahoma, sans-serif'); ?>>وزیر</option>
                            <option value="Tahoma, sans-serif" <?php selected($settings['font_family'], 'Tahoma, sans-serif'); ?>>تهوما</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label>سایز عنوان اصلی (px)</label></th>
                    <td><input type="number" name="title_font_size" value="<?php echo esc_attr($settings['title_font_size']); ?>" style="width: 80px;"> px</td>
                </tr>
                <tr>
                    <th scope="row"><label>سایز زیرنویس (px)</label></th>
                    <td><input type="number" name="subtitle_font_size" value="<?php echo esc_attr($settings['subtitle_font_size']); ?>" style="width: 80px;"> px</td>
                </tr>
                <tr>
                    <th scope="row"><label>سایز متن راهنما (px)</label></th>
                    <td><input type="number" name="help_font_size" value="<?php echo esc_attr($settings['help_font_size']); ?>" style="width: 80px;"> px</td>
                </tr>
                <tr>
                    <th scope="row"><label>سایز متن معمولی (px)</label></th>
                    <td><input type="number" name="normal_font_size" value="<?php echo esc_attr($settings['normal_font_size']); ?>" style="width: 80px;"> px</td>
                </tr>
                <tr>
                    <th scope="row"><label>سایز دکمه (px)</label></th>
                    <td><input type="number" name="button_font_size" value="<?php echo esc_attr($settings['button_font_size']); ?>" style="width: 80px;"> px</td>
                </tr>
                <tr>
                    <th scope="row"><label>سایز لینک فراموشی (px)</label></th>
                    <td><input type="number" name="forgot_font_size" value="<?php echo esc_attr($settings['forgot_font_size']); ?>" style="width: 80px;"> px</td>
                </tr>
            </table>
        </div>
        
        <!-- ================================================== -->
        <!-- تب متن‌ها -->
        <!-- ================================================== -->
        <div id="texts" class="tab-content" style="display: none;">
            
            <div class="loginpro-admin-card">
                <h3>هدر فرم</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>عنوان هدر</label></th>
                        <td><input type="text" name="text_header_title" value="<?php echo esc_attr($settings['text_header_title']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>توضیحات هدر</label></th>
                        <td><input type="text" name="text_header_description" value="<?php echo esc_attr($settings['text_header_description']); ?>" class="regular-text"></td>
                    </tr>
                </table>
            </div>
            
            <div class="loginpro-admin-card">
                <h3>لینک‌های فوتر</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>لینک حریم خصوصی</label></th>
                        <td><input type="url" name="text_privacy_link" value="<?php echo esc_attr($settings['text_privacy_link']); ?>" class="regular-text" placeholder="https://example.com/privacy"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>لینک قوانین و مقررات</label></th>
                        <td><input type="url" name="text_terms_link" value="<?php echo esc_attr($settings['text_terms_link']); ?>" class="regular-text" placeholder="https://example.com/terms"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>متن فوتر</label></th>
                        <td><input type="text" name="text_footer_text" value="<?php echo esc_attr($settings['text_footer_text']); ?>" class="regular-text" placeholder="متن دلخواه"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>لینک‌های سفارشی فوتر</label></th>
                        <td>
                            <textarea name="text_footer_links" rows="4" style="width: 100%;" placeholder="مثال:&#10;ورود|/login&#10;ثبت نام|/register"><?php echo esc_textarea($settings['text_footer_links']); ?></textarea>
                            <p class="description">هر لینک در یک خط: متن|آدرس</p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="loginpro-admin-card">
                <h3>متن‌های صفحه اصلی</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>عنوان اصلی</label></th>
                        <td><input type="text" name="text_title" value="<?php echo esc_attr($settings['text_title']); ?>" class="regular-text"></td>
                    <tr>
                    <tr>
                        <th scope="row"><label>زیرنویس اصلی</label></th>
                        <td><input type="text" name="text_subtitle" value="<?php echo esc_attr($settings['text_subtitle']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>متن راهنما</label></th>
                        <td><input type="text" name="text_help_identifier" value="<?php echo esc_attr($settings['text_help_identifier']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>دکمه ادامه</label></th>
                        <td><input type="text" name="text_continue_btn" value="<?php echo esc_attr($settings['text_continue_btn']); ?>" class="regular-text"></td>
                    </tr>
                </table>
            </div>
            
            <div class="loginpro-admin-card">
                <h3>متن‌های صفحه رمز عبور</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>عنوان صفحه رمز</label></th>
                        <td><input type="text" name="text_password_title" value="<?php echo esc_attr($settings['text_password_title']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>متن راهنما</label></th>
                        <td><input type="text" name="text_help_password" value="<?php echo esc_attr($settings['text_help_password']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>دکمه ورود</label></th>
                        <td><input type="text" name="text_login_btn" value="<?php echo esc_attr($settings['text_login_btn']); ?>" class="regular-text"></td>
                    </tr>
                </table>
            </div>
            
            <div class="loginpro-admin-card">
                <h3>متن‌های صفحه کد تایید</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>عنوان کد تایید</label></th>
                        <td><input type="text" name="text_otp_title" value="<?php echo esc_attr($settings['text_otp_title']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>متن راهنما</label></th>
                        <td><input type="text" name="text_help_otp" value="<?php echo esc_attr($settings['text_help_otp']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>زیرنویس OTP</label></th>
                        <td><input type="text" name="text_otp_subtitle" value="<?php echo esc_attr($settings['text_otp_subtitle']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>دکمه تایید</label></th>
                        <td><input type="text" name="text_verify_btn" value="<?php echo esc_attr($settings['text_verify_btn']); ?>" class="regular-text"></td>
                    </tr>
                </table>
            </div>
            
            <div class="loginpro-admin-card">
                <h3>متن لینک فراموشی رمز</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>متن فراموشی رمز</label></th>
                        <td><input type="text" name="text_forgot_password" value="<?php echo esc_attr($settings['text_forgot_password']); ?>" class="regular-text"></td>
                    </tr>
                </table>
            </div>
            
            <div class="loginpro-admin-card">
                <h3>متن‌های پیامک OTP</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>پیام ثبت نام (کاربر جدید)</label></th>
                        <td><input type="text" name="text_otp_register_message" value="<?php echo esc_attr($settings['text_otp_register_message']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>پیام ورود (کاربر موجود)</label></th>
                        <td><input type="text" name="text_otp_login_message" value="<?php echo esc_attr($settings['text_otp_login_message']); ?>" class="regular-text"></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- ================================================== -->
        <!-- تب دکمه مودال -->
        <!-- ================================================== -->
        <div id="modal-button" class="tab-content" style="display: none;">
            <div class="loginpro-admin-card">
                <h3>تنظیمات دکمه مودال</h3>
                <p class="description">تنظیمات ظاهر دکمه‌ای که با شورت‌کد [loginpro_modal_button] نمایش داده می‌شود.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>رنگ پس‌زمینه دکمه</label></th>
                        <td><input type="text" name="modal_btn_bg_color" value="<?php echo esc_attr($settings['modal_btn_bg_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ پس‌زمینه هاور</label></th>
                        <td><input type="text" name="modal_btn_bg_hover_color" value="<?php echo esc_attr($settings['modal_btn_bg_hover_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ متن دکمه</label></th>
                        <td><input type="text" name="modal_btn_text_color" value="<?php echo esc_attr($settings['modal_btn_text_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ متن هاور</label></th>
                        <td><input type="text" name="modal_btn_text_hover_color" value="<?php echo esc_attr($settings['modal_btn_text_hover_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>عرض دکمه (px)</label></th>
                        <td><input type="text" name="modal_btn_width" value="<?php echo esc_attr($settings['modal_btn_width']); ?>" style="width: 100px;" placeholder="auto"><br><span class="description">خالی = خودکار</span></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>ارتفاع دکمه (px)</label></th>
                        <td><input type="text" name="modal_btn_height" value="<?php echo esc_attr($settings['modal_btn_height']); ?>" style="width: 100px;" placeholder="auto"><br><span class="description">خالی = خودکار</span></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>فاصله داخلی (padding)</label></th>
                        <td><input type="text" name="modal_btn_padding" value="<?php echo esc_attr($settings['modal_btn_padding']); ?>" style="width: 120px;" placeholder="8px 20px"><br><span class="description">مثال: 8px 20px</span></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>سایز فونت (px)</label></th>
                        <td><input type="number" name="modal_btn_font_size" value="<?php echo esc_attr($settings['modal_btn_font_size']); ?>" style="width: 80px;"> px</td>
                    </tr>
                    <tr>
                        <th scope="row"><label>گردی گوشه (px)</label></th>
                        <td><input type="number" name="modal_btn_border_radius" value="<?php echo esc_attr($settings['modal_btn_border_radius']); ?>" style="width: 80px;"> px</td>
                    </tr>
                    <tr>
                        <th scope="row"><label>ضخامت خط دور دکمه (px)</label></th>
                        <td><input type="number" name="modal_btn_border_width" value="<?php echo esc_attr($settings['modal_btn_border_width']); ?>" style="width: 80px;"> px<br><span class="description">0 = بدون خط</span></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ خط دور دکمه</label></th>
                        <td><input type="text" name="modal_btn_border_color" value="<?php echo esc_attr($settings['modal_btn_border_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>نوع سایه</label></th>
                        <td>
                            <select name="modal_btn_shadow">
                                <option value="none" <?php selected($settings['modal_btn_shadow'], 'none'); ?>>بدون سایه</option>
                                <option value="small" <?php selected($settings['modal_btn_shadow'], 'small'); ?>>سایه کوچک</option>
                                <option value="medium" <?php selected($settings['modal_btn_shadow'], 'medium'); ?>>سایه متوسط</option>
                                <option value="large" <?php selected($settings['modal_btn_shadow'], 'large'); ?>>سایه بزرگ</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>جهت سایه</label></th>
                        <td>
                            <select name="modal_btn_shadow_direction">
                                <option value="bottom" <?php selected($settings['modal_btn_shadow_direction'], 'bottom'); ?>>پایین</option>
                                <option value="top" <?php selected($settings['modal_btn_shadow_direction'], 'top'); ?>>بالا</option>
                                <option value="left" <?php selected($settings['modal_btn_shadow_direction'], 'left'); ?>>چپ</option>
                                <option value="right" <?php selected($settings['modal_btn_shadow_direction'], 'right'); ?>>راست</option>
                                <option value="all" <?php selected($settings['modal_btn_shadow_direction'], 'all'); ?>>چهار طرف</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ سایه</label></th>
                        <td><input type="text" name="modal_btn_shadow_color" value="<?php echo esc_attr($settings['modal_btn_shadow_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>آیکون دکمه</label></th>
                        <td><input type="text" name="modal_btn_icon" value="<?php echo esc_attr($settings['modal_btn_icon']); ?>" style="width: 100px;" placeholder="مثال: 🔐"><br><span class="description">خالی بگذارید = بدون آیکون</span></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>متن دکمه</label></th>
                        <td><input type="text" name="modal_btn_text" value="<?php echo esc_attr($settings['modal_btn_text']); ?>" class="regular-text" style="width: 200px;"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>متن دکمه برای کاربر وارد شده</label></th>
                        <td><input type="text" name="modal_btn_logged_text" value="<?php echo esc_attr($settings['modal_btn_logged_text']); ?>" class="regular-text" style="width: 200px;"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>آیکون برای کاربر وارد شده</label></th>
                        <td><input type="text" name="modal_btn_logged_icon" value="<?php echo esc_attr($settings['modal_btn_logged_icon']); ?>" style="width: 100px;" placeholder="مثال: 👤"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>افکت hover</label></th>
                        <td>
                            <select name="modal_btn_hover_effect">
                                <option value="none" <?php selected($settings['modal_btn_hover_effect'], 'none'); ?>>بدون افکت</option>
                                <option value="opacity" <?php selected($settings['modal_btn_hover_effect'], 'opacity'); ?>>کم نور شدن</option>
                                <option value="scale" <?php selected($settings['modal_btn_hover_effect'], 'scale'); ?>>بزرگ شدن</option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <h4>پیش‌نمایش دکمه</h4>
                <div style="background: #f0f0f0; padding: 30px; text-align: center; border-radius: 12px;">
                    <button type="button" id="preview_modal_btn" style="border: none; cursor: pointer; padding: 10px 20px; border-radius: 8px;">
                        ورود / ثبت‌نام
                    </button>
                </div>
            </div>
        </div>
        
        <!-- ================================================== -->
        <!-- تب لوگو -->
        <!-- ================================================== -->
        <div id="logo" class="tab-content" style="display: none;">
            <table class="form-table">
                <tr>
                    <th scope="row"><label>آدرس لوگو</label></th>
                    <td>
                        <input type="text" name="logo_url" id="logo_url" value="<?php echo esc_url($settings['logo_url']); ?>" style="width: 100%; max-width: 400px;" class="regular-text">
                        <button type="button" id="upload_logo" class="button">انتخاب تصویر</button>
                        <button type="button" id="clear_logo" class="button">حذف</button>
                        <div id="logo_preview" style="margin-top: 15px;">
                            <?php if (!empty($settings['logo_url'])): ?>
                                <img src="<?php echo esc_url($settings['logo_url']); ?>" style="max-width: 150px; max-height: 80px; border: 1px solid #ddd; padding: 5px; border-radius: 8px;">
                            <?php endif; ?>
                        </div>
                        <p class="description">لوگوی خود را انتخاب کنید. این لوگو در بالای فرم لاگین نمایش داده می‌شود.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label>عرض لوگو (px)</label></th>
                    <td><input type="number" name="logo_width" value="<?php echo esc_attr($settings['logo_width']); ?>" style="width: 100px;"> px</td>
                </tr>
                <tr>
                    <th scope="row"><label>ارتفاع لوگو (px)</label></th>
                    <td><input type="text" name="logo_height" value="<?php echo esc_attr($settings['logo_height']); ?>" style="width: 100px;" placeholder="auto"> px</td>
                </tr>
            </table>
        </div>
        
        <!-- ================================================== -->
        <!-- تب قالب کاربری -->
        <!-- ================================================== -->
        <div id="user-dashboard" class="tab-content" style="display: none;">
            <div class="loginpro-admin-card">
                <h3>تنظیمات قالب کاربری</h3>
                <p class="description">تنظیمات ظاهر داشبورد کاربری که با شورت‌کد [loginpro_user] نمایش داده می‌شود.</p>
                
                <h4 style="margin-top:0;margin-bottom:10px;color:#333;">🎨 رنگ‌های اختصاصی قالب کاربری</h4>
                <table class="form-table" style="margin-bottom:20px;">
                    <tr>
                        <th scope="row"><label>رنگ پس‌زمینه هدر</label></th>
                        <td><input type="text" name="dashboard_header_bg_color" value="<?php echo esc_attr($settings['dashboard_header_bg_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ متن هدر</label></th>
                        <td><input type="text" name="dashboard_header_text_color" value="<?php echo esc_attr($settings['dashboard_header_text_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ تب فعال</label></th>
                        <td><input type="text" name="dashboard_tab_active_color" value="<?php echo esc_attr($settings['dashboard_tab_active_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ تب در هاور</label></th>
                        <td><input type="text" name="dashboard_tab_hover_color" value="<?php echo esc_attr($settings['dashboard_tab_hover_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ پس‌زمینه بخش‌ها</label></th>
                        <td><input type="text" name="dashboard_section_bg_color" value="<?php echo esc_attr($settings['dashboard_section_bg_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label>رنگ حاشیه بخش‌ها</label></th>
                        <td><input type="text" name="dashboard_section_border_color" value="<?php echo esc_attr($settings['dashboard_section_border_color']); ?>" class="loginpro-color-picker"></td>
                    </tr>
                </table>
                
                <h4 style="margin-top:20px;margin-bottom:10px;color:#333;">📐 اندازه‌های قالب کاربری</h4>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label>عرض قالب کاربری</label></th>
                        <td>
                            <input type="text" name="dashboard_width" value="<?php echo esc_attr($settings['dashboard_width']); ?>" style="width: 150px;" placeholder="800px">
                            <br><span class="description">مثال: 800px, 100%, 600px</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>گردی گوشه قالب (px)</label></th>
                        <td>
                            <input type="number" name="dashboard_border_radius" value="<?php echo esc_attr($settings['dashboard_border_radius']); ?>" style="width: 80px;"> px
                            <br><span class="description">گردی گوشه‌های قالب کاربری</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>ارتفاع فیلدهای ورودی (px)</label></th>
                        <td>
                            <input type="number" name="dashboard_input_height" value="<?php echo esc_attr($settings['dashboard_input_height']); ?>" style="width: 80px;"> px
                            <br><span class="description">ارتفاع فیلدهای ورودی در فرم‌ها</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>ارتفاع دکمه‌ها (px)</label></th>
                        <td>
                            <input type="number" name="dashboard_button_height" value="<?php echo esc_attr($settings['dashboard_button_height']); ?>" style="width: 80px;"> px
                            <br><span class="description">ارتفاع دکمه‌های قالب کاربری</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>سایز عنوان‌ها (px)</label></th>
                        <td>
                            <input type="number" name="dashboard_title_font_size" value="<?php echo esc_attr($settings['dashboard_title_font_size']); ?>" style="width: 80px;"> px
                            <br><span class="description">سایز عنوان‌های اصلی در قالب کاربری</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>سایز متن معمولی (px)</label></th>
                        <td>
                            <input type="number" name="dashboard_normal_font_size" value="<?php echo esc_attr($settings['dashboard_normal_font_size']); ?>" style="width: 80px;"> px
                            <br><span class="description">سایز متن‌های معمولی در قالب کاربری</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>سایز متن دکمه‌ها (px)</label></th>
                        <td>
                            <input type="number" name="dashboard_button_font_size" value="<?php echo esc_attr($settings['dashboard_button_font_size']); ?>" style="width: 80px;"> px
                            <br><span class="description">سایز متن دکمه‌ها در قالب کاربری</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label>فونت قالب کاربری</label></th>
                        <td>
                            <select name="dashboard_font_family">
                                <option value="IRANSans, Tahoma, sans-serif" <?php selected($settings['dashboard_font_family'], 'IRANSans, Tahoma, sans-serif'); ?>>ایران‌سنس</option>
                                <option value="Vazir, Tahoma, sans-serif" <?php selected($settings['dashboard_font_family'], 'Vazir, Tahoma, sans-serif'); ?>>وزیر</option>
                                <option value="Tahoma, sans-serif" <?php selected($settings['dashboard_font_family'], 'Tahoma, sans-serif'); ?>>تهوما</option>
                            </select>
                            <br><span class="description">فونت مورد استفاده در قالب کاربری</span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- ================================================== -->
        <!-- تب CSS سفارشی -->
        <!-- ================================================== -->
        <div id="custom" class="tab-content" style="display: none;">
            <table class="form-table">
                <tr>
                    <th scope="row"><label>CSS سفارشی</label></th>
                    <td>
                        <textarea name="custom_css" rows="10" style="width: 100%; font-family: monospace;"><?php echo esc_textarea($settings['custom_css']); ?></textarea>
                        <p class="description">CSS سفارشی خود را اینجا وارد کنید. بدون تگ &lt;style&gt;</p>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- ================================================== -->
        <!-- دکمه ذخیره -->
        <!-- ================================================== -->
        <p class="submit">
            <button type="submit" name="save_appearance" class="button button-primary button-large">💾 ذخیره تنظیمات</button>
            <span style="margin-right:15px;font-size:12px;color:#888;">
                ⚡ پس از ذخیره، Cache پاکسازی می‌شود تا تغییرات بلافاصله اعمال شوند.
            </span>
        </p>
    </form>
</div>

<!-- ================================================== -->
<!-- استایل‌های رسپانسیو و جاوااسکریپت (همان کد قبلی) -->
<!-- ================================================== -->
<style>
.tab-content { padding: 20px 0; }
.nav-tab-wrapper { 
    margin-bottom: 20px; 
    border-bottom: 1px solid #c3c4c7; 
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
}
.nav-tab { 
    cursor: pointer; 
    padding: 8px 16px;
    font-size: 13px;
    white-space: nowrap;
}
.nav-tab-active { 
    background: #fff; 
    border-bottom-color: #fff; 
}
.loginpro-admin-card { 
    background: #f9f9f9; 
    padding: 20px; 
    margin-bottom: 20px; 
    border: 1px solid #e5e5e5; 
    border-radius: 8px; 
    overflow: hidden;
}
.loginpro-admin-card h3 { 
    margin-top: 0; 
    margin-bottom: 15px; 
}
.loginpro-admin-card h4 {
    margin-top: 20px;
    margin-bottom: 10px;
    color: #333;
}
.regular-text { 
    width: 100%; 
    max-width: 400px; 
}
.description { 
    color: #666; 
    font-size: 12px; 
    margin-top: 5px; 
}
.wp-picker-container { 
    display: inline-block; 
}
.form-table th { 
    width: 200px; 
}

/* رسپانسیو */
@media screen and (max-width: 782px) {
    .nav-tab-wrapper {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        padding: 8px 0;
        border-bottom: none;
    }
    .nav-tab {
        flex: 1 1 auto;
        min-width: calc(50% - 6px);
        text-align: center;
        padding: 10px 12px;
        font-size: 12px;
        border: 1px solid #c3c4c7;
        border-radius: 4px;
        background: #f1f1f1;
        margin: 0;
        white-space: normal;
        word-break: break-word;
    }
    .nav-tab-active {
        background: #fff;
        border-bottom: 2px solid #2271b1;
    }
    .form-table {
        display: block;
        width: 100%;
    }
    .form-table tbody {
        display: block;
        width: 100%;
    }
    .form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 15px;
        padding-bottom: 15px;
        border-bottom: 1px solid #eee;
    }
    .form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    .form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
    }
    .form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    .form-table td input[type="text"],
    .form-table td input[type="url"],
    .form-table td input[type="number"],
    .form-table td select,
    .form-table td textarea {
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box;
    }
    .loginpro-admin-card {
        padding: 15px;
        margin-bottom: 15px;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    
    // ==================================================
    // فعال‌سازی Color Picker برای همه فیلدها
    // ==================================================
    if ($.fn.wpColorPicker) {
        $('.loginpro-color-picker').each(function() {
            var $this = $(this);
            var defaultValue = $this.data('default-color') || $this.val() || '#000000';
            $this.wpColorPicker({
                defaultColor: defaultValue,
                change: function(event, ui) {
                    if (typeof updateModalButtonPreview === 'function') {
                        updateModalButtonPreview();
                    }
                },
                clear: function() {
                    if (typeof updateModalButtonPreview === 'function') {
                        updateModalButtonPreview();
                    }
                }
            });
        });
    }
    
    // ==================================================
    // سیستم تب‌ها
    // ==================================================
    function showTab(tabId) {
        $('.tab-content').hide();
        $('#' + tabId).show();
        $('.nav-tab').removeClass('nav-tab-active');
        $('.nav-tab[data-tab="' + tabId + '"]').addClass('nav-tab-active');
    }
    
    var activeTab = localStorage.getItem('loginpro_active_tab');
    var validTabs = ['colors', 'sizes', 'typography', 'texts', 'modal-button', 'logo', 'user-dashboard', 'custom'];
    if (activeTab && validTabs.indexOf(activeTab) !== -1) {
        showTab(activeTab);
    } else {
        showTab('colors');
    }
    
    $('.nav-tab').on('click', function(e) {
        e.preventDefault();
        var tabId = $(this).data('tab');
        if (tabId) {
            showTab(tabId);
            localStorage.setItem('loginpro_active_tab', tabId);
        }
    });
    
    // ==================================================
    // آپلود لوگو
    // ==================================================
    var file_frame;
    $('#upload_logo').on('click', function(e) {
        e.preventDefault();
        if (file_frame) {
            file_frame.open();
            return;
        }
        file_frame = wp.media({
            title: 'انتخاب لوگو',
            button: { text: 'استفاده از تصویر' },
            multiple: false,
            library: { type: 'image' }
        });
        file_frame.on('select', function() {
            var attachment = file_frame.state().get('selection').first().toJSON();
            $('#logo_url').val(attachment.url);
            $('#logo_preview').html('<img src="' + attachment.url + '" style="max-width: 150px; max-height: 80px; border: 1px solid #ddd; padding: 5px; border-radius: 8px;">');
        });
        file_frame.open();
    });
    
    $('#clear_logo').on('click', function() {
        $('#logo_url').val('');
        $('#logo_preview').html('');
    });
    
    // ==================================================
    // پیش‌نمایش دکمه مودال
    // ==================================================
    function updateModalButtonPreview() {
        var bgColor = $('input[name="modal_btn_bg_color"]').val() || '#ef394e';
        var bgHover = $('input[name="modal_btn_bg_hover_color"]').val() || '#e02e43';
        var textColor = $('input[name="modal_btn_text_color"]').val() || '#ffffff';
        var textHover = $('input[name="modal_btn_text_hover_color"]').val() || '#ffffff';
        var icon = $('input[name="modal_btn_icon"]').val() || '';
        var btnText = $('input[name="modal_btn_text"]').val() || 'ورود / ثبت‌نام';
        var borderRadius = parseInt($('input[name="modal_btn_border_radius"]').val()) || 8;
        var padding = $('input[name="modal_btn_padding"]').val() || '8px 20px';
        var fontSize = parseInt($('input[name="modal_btn_font_size"]').val()) || 14;
        var borderWidth = parseInt($('input[name="modal_btn_border_width"]').val()) || 0;
        var borderColor = $('input[name="modal_btn_border_color"]').val() || 'transparent';
        var shadowType = $('select[name="modal_btn_shadow"]').val();
        var shadowDirection = $('select[name="modal_btn_shadow_direction"]').val();
        var shadowColor = $('input[name="modal_btn_shadow_color"]').val() || 'rgba(0,0,0,0.15)';
        var width = $('input[name="modal_btn_width"]').val() || '';
        var height = $('input[name="modal_btn_height"]').val() || '';
        
        var shadowStyle = 'none';
        if (shadowType !== 'none') {
            var size = shadowType === 'small' ? '2px' : (shadowType === 'medium' ? '5px' : '10px');
            var blur = shadowType === 'small' ? '5px' : (shadowType === 'medium' ? '15px' : '25px');
            
            switch (shadowDirection) {
                case 'bottom': shadowStyle = '0 ' + size + ' ' + blur + ' ' + shadowColor; break;
                case 'top': shadowStyle = '0 -' + size + ' ' + blur + ' ' + shadowColor; break;
                case 'left': shadowStyle = '-' + size + ' 0 ' + blur + ' ' + shadowColor; break;
                case 'right': shadowStyle = size + ' 0 ' + blur + ' ' + shadowColor; break;
                default: shadowStyle = '0 0 ' + blur + ' ' + shadowColor;
            }
        }
        
        var $previewBtn = $('#preview_modal_btn');
        $previewBtn.css({
            'background': bgColor,
            'color': textColor,
            'border-radius': borderRadius + 'px',
            'padding': padding,
            'font-size': fontSize + 'px',
            'border': borderWidth + 'px solid ' + borderColor,
            'box-shadow': shadowStyle !== 'none' ? shadowStyle : 'none',
            'transition': 'all 0.3s ease',
            'cursor': 'pointer'
        });
        
        if (width && width !== 'auto') $previewBtn.css('width', width + 'px');
        else $previewBtn.css('width', 'auto');
        
        if (height && height !== 'auto') $previewBtn.css('height', height + 'px');
        else $previewBtn.css('height', 'auto');
        
        var displayText = '';
        if (icon && icon !== '') displayText += icon + ' ';
        displayText += btnText;
        $previewBtn.html(displayText);
        
        var hoverEffect = $('select[name="modal_btn_hover_effect"]').val();
        $previewBtn.off('mouseenter mouseleave').on('mouseenter', function() {
            $(this).css({ 'background': bgHover, 'color': textHover });
            if (hoverEffect === 'scale') $(this).css('transform', 'scale(1.05)');
            else if (hoverEffect === 'opacity') $(this).css('opacity', '0.85');
        }).on('mouseleave', function() {
            $(this).css({ 'background': bgColor, 'color': textColor, 'transform': 'none', 'opacity': '1' });
        });
    }
    
    $(document).on('change keyup', 
        'input[name="modal_btn_icon"], input[name="modal_btn_text"], input[name="modal_btn_border_radius"], input[name="modal_btn_padding"], input[name="modal_btn_font_size"], input[name="modal_btn_border_width"], input[name="modal_btn_width"], input[name="modal_btn_height"]', 
        updateModalButtonPreview);
    
    $(document).on('colorchange', 
        'input[name="modal_btn_bg_color"], input[name="modal_btn_bg_hover_color"], input[name="modal_btn_text_color"], input[name="modal_btn_text_hover_color"], input[name="modal_btn_border_color"], input[name="modal_btn_shadow_color"]', 
        updateModalButtonPreview);
    
    $(document).on('change', 
        'select[name="modal_btn_shadow"], select[name="modal_btn_shadow_direction"], select[name="modal_btn_hover_effect"]', 
        updateModalButtonPreview);
    
    updateModalButtonPreview();
});
</script>