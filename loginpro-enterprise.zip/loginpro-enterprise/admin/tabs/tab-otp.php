<?php
/**
 * تب تنظیمات OTP
 * این فایل محتوای اصلی تنظیمات OTP را نمایش می‌دهد
 */

defined('ABSPATH') || exit;

// بارگذاری فایل اصلی تنظیمات OTP
$settings_file = __DIR__ . '/tab-otp-settings.php';

if (file_exists($settings_file)) {
    require_once $settings_file;
} else {
    ?>
    <div class="wrap">
        <h1>⚙️ تنظیمات کد یکبارمصرف (OTP)</h1>
        <div class="notice notice-error">
            <p>❌ فایل تنظیمات OTP یافت نشد. لطفاً افزونه را غیرفعال و دوباره فعال کنید.</p>
        </div>
    </div>
    <?php
}