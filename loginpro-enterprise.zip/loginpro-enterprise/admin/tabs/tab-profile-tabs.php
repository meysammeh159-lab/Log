<?php
defined('ABSPATH') || exit;

$option_name = 'loginpro_user_dashboard_tabs';
$nonce_action = 'loginpro_user_tabs';
$save_message = '';

// ==================================================
// ترتیب پیش‌فرض - دقیقاً همون چیزی که میخوای
// ==================================================
$all_tabs = [
    'account_details' => '👤 اطلاعات حساب کاربری',
    'messages'        => '✉️ پیام‌ها',
    'addresses'       => '📍 آدرس‌ها',
    'orders'          => '🛒 سفارش‌ها',
    'wishlist'        => '❤️ لیست‌های من',
    'downloads'       => '📥 دانلودها',
    'subscription'    => '📋 اشتراک',
    'gifts'           => '🎁 هدیه‌ها',
    'tickets'         => '🎫 تیکت‌های پشتیبانی',
    'reviews'         => '💬 دیدگاه و پرسش‌ها',
    'recent_views'    => '👁️ بازدیدهای اخیر',
    'logout'          => '🚪 خروج از حساب',
];

$active_tabs = get_option($option_name, array_keys($all_tabs));

// ==================================================
// ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_tabs']) && check_admin_referer($nonce_action)) {
    if (current_user_can('manage_options')) {
        $tabs = isset($_POST[$option_name]) ? (array) $_POST[$option_name] : [];
        $tabs = array_map('sanitize_text_field', $tabs);
        $tabs = array_intersect($tabs, array_keys($all_tabs));
        update_option($option_name, $tabs);
        $active_tabs = $tabs;
        $save_message = '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات ذخیره شد.</p></div>';
    }
}

wp_enqueue_style('wp-color-picker');
wp_enqueue_script('wp-color-picker');
?>
<style>
.tab-profile-tabs-settings { margin: 0 !important; padding: 20px 20px 0 0 !important; max-width: 100% !important; width: 100% !important; box-sizing: border-box !important; }
.tab-profile-tabs-settings * { box-sizing: border-box; }
.tab-profile-tabs-settings .notice { margin-bottom: 20px; margin-left: 0 !important; }
.tab-profile-tabs-settings .card { background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; padding: 25px 30px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); width: 100% !important; max-width: 100% !important; box-sizing: border-box; display: block; float: none; clear: both; }
.tab-profile-tabs-settings .card h2 { margin-top: 0; margin-bottom: 10px; font-size: 22px; font-weight: 600; color: #1d2327; }
.tab-profile-tabs-settings .card h3 { margin-top: 0; margin-bottom: 12px; font-size: 17px; font-weight: 600; color: #1d2327; }
.tab-profile-tabs-settings .card .desc { color: #6c757d; font-size: 14px; margin-bottom: 20px; line-height: 1.7; }
.tab-profile-tabs-settings .card .desc code { background: #f0f0f0; padding: 2px 8px; border-radius: 4px; font-size: 13px; color: #d63384; }
.tab-profile-tabs-settings .form-wrap { width: 100% !important; max-width: 100% !important; display: block; }
.tab-profile-tabs-settings .form-label { display: block; font-weight: 600; font-size: 15px; color: #1d2327; margin-bottom: 12px; }
.tab-profile-tabs-settings .tabs-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 8px 16px; margin-bottom: 10px; width: 100% !important; max-width: 100% !important; }
.tab-profile-tabs-settings .tabs-grid .tab-item { display: flex; align-items: center; padding: 10px 14px; background: #f8f9fa; border-radius: 8px; border: 1.5px solid #e9ecef; transition: all 0.25s ease; gap: 8px; font-size: 14px; font-weight: 500; color: #333; }
.tab-profile-tabs-settings .tabs-grid .tab-item:hover { background: #f1f3f5; border-color: #adb5bd; }
.tab-profile-tabs-settings .tabs-grid .tab-item.checked { background: #e7f3ff; border-color: #2271b1; box-shadow: 0 0 0 1px rgba(34,113,177,0.15); }
.tab-profile-tabs-settings .tabs-grid .tab-item .tab-number { font-size: 12px; font-weight: 700; color: #6c757d; background: #e9ecef; padding: 0 8px; border-radius: 12px; min-width: 28px; text-align: center; flex-shrink: 0; line-height: 22px; }
.tab-profile-tabs-settings .tabs-grid .tab-item.checked .tab-number { background: #cfe2ff; color: #2271b1; }
.tab-profile-tabs-settings .tabs-grid .tab-item input[type="checkbox"] { width: 18px; height: 18px; min-width: 18px; margin: 0; accent-color: #2271b1; cursor: pointer; border-radius: 4px; flex-shrink: 0; }
.tab-profile-tabs-settings .tabs-grid .tab-item .tab-label { font-size: 14px; font-weight: 500; line-height: 1.4; word-break: break-word; flex: 1; }
.tab-profile-tabs-settings .submit-wrap { display: flex; flex-wrap: wrap; align-items: center; gap: 15px; margin-top: 15px; padding-top: 15px; border-top: 1px solid #e9ecef; }
.tab-profile-tabs-settings .submit-btn { background: #2271b1; color: #fff; border: none; padding: 12px 32px; border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: 600; transition: all 0.25s ease; min-width: 180px; display: inline-flex; align-items: center; justify-content: center; gap: 8px; }
.tab-profile-tabs-settings .submit-btn:hover { background: #135e96; box-shadow: 0 4px 12px rgba(34,113,177,0.3); transform: translateY(-1px); }
.tab-profile-tabs-settings .selected-count { font-size: 14px; color: #6c757d; background: #f1f3f5; padding: 6px 16px; border-radius: 20px; }
.tab-profile-tabs-settings .selected-count strong { color: #1d2327; }
.tab-profile-tabs-settings .status-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 15px; }
.tab-profile-tabs-settings .status-item { background: #f8f9fa; padding: 14px 18px; border-radius: 8px; border: 1px solid #e9ecef; text-align: center; }
.tab-profile-tabs-settings .status-item .num { font-size: 28px; font-weight: 700; color: #2271b1; display: block; line-height: 1.2; }
.tab-profile-tabs-settings .status-item .label { font-size: 13px; color: #6c757d; margin-top: 4px; display: block; }
.tab-profile-tabs-settings .status-item .status-active { color: #28a745; font-weight: 600; }
.tab-profile-tabs-settings .status-item .status-inactive { color: #dc3545; font-weight: 600; }
.tab-profile-tabs-settings .active-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.tab-profile-tabs-settings .active-tag { background: #e8f0fe; padding: 4px 14px; border-radius: 20px; font-size: 13px; color: #1a3c6e; border: 1px solid #d0e0f0; white-space: nowrap; }
.tab-profile-tabs-settings .active-tag-empty { color: #dc3545; font-weight: 500; }
.tab-profile-tabs-settings .shortcode-box { background: #1e1e2e; color: #cdd6f4; padding: 14px 20px; border-radius: 8px; font-family: monospace; font-size: 15px; display: inline-flex; align-items: center; gap: 12px; border: 1px solid #313244; user-select: all; }
.tab-profile-tabs-settings .shortcode-box code { background: transparent; color: #a6e3a1; padding: 0; font-size: 15px; }
.tab-profile-tabs-settings .shortcode-box .copy-btn { background: rgba(255,255,255,0.08); border: none; color: #9399b2; padding: 4px 12px; border-radius: 4px; cursor: pointer; font-size: 12px; transition: all 0.2s; }
.tab-profile-tabs-settings .shortcode-box .copy-btn:hover { background: rgba(255,255,255,0.15); color: #fff; }
.tab-profile-tabs-settings .shortcode-box .copy-btn.copied { background: #a6e3a1; color: #1e1e2e; }
.tab-profile-tabs-settings .shortcode-help { margin-top: 12px; font-size: 13px; color: #6c757d; line-height: 1.6; }

@media (max-width: 782px) {
    .tab-profile-tabs-settings .card { padding: 16px 18px; }
    .tab-profile-tabs-settings .tabs-grid { grid-template-columns: 1fr 1fr; gap: 6px; }
    .tab-profile-tabs-settings .tabs-grid .tab-item { padding: 8px 10px; font-size: 13px; flex-wrap: wrap; }
    .tab-profile-tabs-settings .submit-wrap { flex-direction: column; align-items: stretch; gap: 10px; }
    .tab-profile-tabs-settings .submit-btn { width: 100%; text-align: center; padding: 14px 20px; min-width: unset; }
    .tab-profile-tabs-settings .selected-count { text-align: center; padding: 8px 12px; }
    .tab-profile-tabs-settings .status-grid { grid-template-columns: 1fr 1fr; gap: 8px; }
}

@media (max-width: 480px) {
    .tab-profile-tabs-settings .card { padding: 12px 14px; }
    .tab-profile-tabs-settings .tabs-grid { grid-template-columns: 1fr; gap: 5px; }
    .tab-profile-tabs-settings .status-grid { grid-template-columns: 1fr; gap: 6px; }
    .tab-profile-tabs-settings .status-item { display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; }
    .tab-profile-tabs-settings .status-item .num { font-size: 20px; display: inline; }
    .tab-profile-tabs-settings .status-item .label { display: inline; margin-top: 0; font-size: 12px; }
}

@media (prefers-color-scheme: dark) {
    .tab-profile-tabs-settings .card { background: #1e1e2e; border-color: #313244; }
    .tab-profile-tabs-settings .card h2, .tab-profile-tabs-settings .card h3 { color: #cdd6f4; }
    .tab-profile-tabs-settings .card .desc { color: #a6adc8; }
    .tab-profile-tabs-settings .tabs-grid .tab-item { background: #28283a; border-color: #313244; color: #cdd6f4; }
    .tab-profile-tabs-settings .tabs-grid .tab-item:hover { background: #313244; border-color: #45475a; }
    .tab-profile-tabs-settings .tabs-grid .tab-item.checked { background: #1e3a5f; border-color: #2271b1; }
    .tab-profile-tabs-settings .tabs-grid .tab-item .tab-number { background: #313244; color: #a6adc8; }
    .tab-profile-tabs-settings .tabs-grid .tab-item.checked .tab-number { background: #1e3a5f; color: #89b4fa; }
    .tab-profile-tabs-settings .status-item { background: #28283a; border-color: #313244; }
    .tab-profile-tabs-settings .status-item .label { color: #a6adc8; }
    .tab-profile-tabs-settings .active-tag { background: #1e3a5f; color: #89b4fa; border-color: #1e3a5f; }
    .tab-profile-tabs-settings .selected-count { background: #28283a; color: #a6adc8; }
    .tab-profile-tabs-settings .selected-count strong { color: #cdd6f4; }
}
</style>

<div class="tab-profile-tabs-settings">
    <?php if (isset($save_message) && $save_message) echo $save_message; ?>
    
    <form method="post">
        <?php wp_nonce_field($nonce_action); ?>
        
        <div class="card">
            <h2>📑 مدیریت تب‌های داشبورد کاربری</h2>
            <p class="desc">تب‌هایی که انتخاب کنید، در داشبورد کاربران با شورت‌کد <code>[loginpro_user]</code> نمایش داده می‌شوند.</p>
            
            <div class="form-wrap">
                <div class="form-label">📋 تب‌های فعال</div>
                
                <div class="tabs-grid">
                    <?php 
                    $index = 0;
                    foreach ($all_tabs as $key => $label): 
                        $checked = in_array($key, $active_tabs);
                        $index++;
                    ?>
                        <div class="tab-item <?php echo $checked ? 'checked' : ''; ?>">
                            <span class="tab-number"><?php echo $index; ?></span>
                            <input type="checkbox" name="<?php echo esc_attr($option_name); ?>[]" value="<?php echo esc_attr($key); ?>" <?php checked($checked); ?>>
                            <span class="tab-label"><?php echo esc_html($label); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="submit-wrap">
                <button type="submit" name="save_tabs" class="submit-btn">💾 ذخیره تنظیمات</button>
                <span class="selected-count"><strong id="selectedCount"><?php echo count($active_tabs); ?></strong> از <strong><?php echo count($all_tabs); ?></strong> تب انتخاب شده</span>
            </div>
        </div>
    </form>
    
    <div class="card">
        <h3>📊 وضعیت سیستمی</h3>
        <div class="status-grid">
            <div class="status-item"><span class="num"><?php echo count($all_tabs); ?></span><span class="label">📋 کل تب‌ها</span></div>
            <div class="status-item"><span class="num" style="color:#28a745;"><?php echo count($active_tabs); ?></span><span class="label">✅ تب‌های فعال</span></div>
            <div class="status-item"><span class="num" style="font-size:18px;margin-top:6px;"><span class="<?php echo class_exists('WooCommerce') ? 'status-active' : 'status-inactive'; ?>"><?php echo class_exists('WooCommerce') ? '✅ فعال' : '❌ غیرفعال'; ?></span></span><span class="label">🛒 ووکامرس</span></div>
        </div>
        
        <div style="margin-top:10px;padding-top:12px;border-top:1px solid #e9ecef;">
            <strong>📋 لیست تب‌های فعال:</strong>
            <div class="active-tags">
                <?php foreach ($active_tabs as $key): ?>
                    <span class="active-tag"><?php echo isset($all_tabs[$key]) ? esc_html($all_tabs[$key]) : $key; ?></span>
                <?php endforeach; ?>
                <?php if (empty($active_tabs)): ?>
                    <span class="active-tag-empty">⚠️ هیچ تب‌ای فعال نیست!</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="card" style="background:#f8f9fa;">
        <h3>📖 نحوه استفاده</h3>
        <p style="margin-bottom:12px;color:#444;font-size:14px;">برای نمایش داشبورد کاربری در سایت، از شورت‌کد زیر استفاده کنید:</p>
        <div class="shortcode-box"><code>[loginpro_user]</code><button class="copy-btn" onclick="copyShortcode(this)">📋 کپی</button></div>
        <p class="shortcode-help">💡 می‌توانید این شورت‌کد را در صفحه پروفایل کاربری یا هر صفحه دلخواه قرار دهید.</p>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    function updateTabsUI() {
        var checked = $('input[name="<?php echo esc_js($option_name); ?>[]"]:checked');
        $('#selectedCount').text(checked.length);
        $('.tab-item').removeClass('checked');
        checked.each(function() { $(this).closest('.tab-item').addClass('checked'); });
    }
    $('input[name="<?php echo esc_js($option_name); ?>[]"]').on('change', updateTabsUI);
    updateTabsUI();
    
    window.copyShortcode = function(btn) {
        var shortcode = '[loginpro_user]';
        var $btn = $(btn);
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(shortcode).then(function() {
                $btn.text('✅ کپی شد').addClass('copied');
                setTimeout(function() { $btn.text('📋 کپی').removeClass('copied'); }, 2000);
            });
        } else {
            var textarea = document.createElement('textarea');
            textarea.value = shortcode;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            $btn.text('✅ کپی شد').addClass('copied');
            setTimeout(function() { $btn.text('📋 کپی').removeClass('copied'); }, 2000);
        }
    };
});
</script>