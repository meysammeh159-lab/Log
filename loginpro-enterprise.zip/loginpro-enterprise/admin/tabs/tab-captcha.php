<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب 🔒 تنظیمات کپچا
// ==================================================

// دریافت مقادیر از دیتابیس
$captcha_enabled = get_option('loginpro_captcha_enabled', false);
$captcha_provider = get_option('loginpro_captcha_provider', 'recaptcha');
$site_key = get_option('loginpro_captcha_site_key', '');
$secret_key = get_option('loginpro_captcha_secret_key', '');
$threshold = get_option('loginpro_captcha_threshold', 0.5);
$recaptcha_type = get_option('loginpro_recaptcha_type', 'v3');
$hcaptcha_site_key = get_option('loginpro_hcaptcha_site_key', '');
$hcaptcha_secret_key = get_option('loginpro_hcaptcha_secret_key', '');
$turnstile_site_key = get_option('loginpro_turnstile_site_key', '');
$turnstile_secret_key = get_option('loginpro_turnstile_secret_key', '');
$math_min = get_option('loginpro_math_min', 1);
$math_max = get_option('loginpro_math_max', 10);
$math_addition = get_option('loginpro_math_addition', true);
$math_subtraction = get_option('loginpro_math_subtraction', false);
$show_on_login = get_option('loginpro_captcha_show_on_login', true);
$show_on_register = get_option('loginpro_captcha_show_on_register', true);
$show_on_reset = get_option('loginpro_captcha_show_on_reset', true);
$show_after_attempts = get_option('loginpro_captcha_show_after_attempts', 3);
$captcha_theme = get_option('loginpro_captcha_theme', 'light');

// ==================================================
// پردازش ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_captcha']) && isset($_POST['captcha_settings']) && wp_verify_nonce($_POST['captcha_settings'], 'captcha_settings')) {
    
    update_option('loginpro_captcha_enabled', isset($_POST['captcha_enabled']));
    update_option('loginpro_captcha_provider', sanitize_text_field($_POST['captcha_provider']));
    update_option('loginpro_captcha_site_key', sanitize_text_field($_POST['site_key']));
    update_option('loginpro_captcha_secret_key', sanitize_text_field($_POST['secret_key']));
    update_option('loginpro_captcha_threshold', (float) $_POST['threshold']);
    update_option('loginpro_recaptcha_type', sanitize_text_field($_POST['recaptcha_type']));
    update_option('loginpro_hcaptcha_site_key', sanitize_text_field($_POST['hcaptcha_site_key']));
    update_option('loginpro_hcaptcha_secret_key', sanitize_text_field($_POST['hcaptcha_secret_key']));
    update_option('loginpro_turnstile_site_key', sanitize_text_field($_POST['turnstile_site_key']));
    update_option('loginpro_turnstile_secret_key', sanitize_text_field($_POST['turnstile_secret_key']));
    update_option('loginpro_math_min', (int) $_POST['math_min']);
    update_option('loginpro_math_max', (int) $_POST['math_max']);
    update_option('loginpro_math_addition', isset($_POST['math_addition']));
    update_option('loginpro_math_subtraction', isset($_POST['math_subtraction']));
    update_option('loginpro_captcha_show_on_login', isset($_POST['show_on_login']));
    update_option('loginpro_captcha_show_on_register', isset($_POST['show_on_register']));
    update_option('loginpro_captcha_show_on_reset', isset($_POST['show_on_reset']));
    update_option('loginpro_captcha_show_after_attempts', (int) $_POST['show_after_attempts']);
    update_option('loginpro_captcha_theme', sanitize_text_field($_POST['captcha_theme']));
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات کپچا با موفقیت ذخیره شد.</p></div>';
    
    // به‌روزرسانی متغیرها بعد از ذخیره
    $captcha_enabled = get_option('loginpro_captcha_enabled', false);
    $captcha_provider = get_option('loginpro_captcha_provider', 'recaptcha');
}

// ==================================================
// HTML فرم
// ==================================================
?>
<style>
.tab-captcha-settings {
    margin: 20px 20px 0 0;
}

/* ===== کارت اصلی ===== */
.captcha-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.captcha-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

/* ===== جدول فرم ===== */
.captcha-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 10px;
}

.captcha-form-table th {
    width: 220px;
    text-align: right;
    padding: 15px 15px 15px 0;
    font-weight: 600;
    vertical-align: top;
    font-size: 14px;
    color: #1d2327;
}

.captcha-form-table td {
    padding: 15px 0;
    vertical-align: middle;
}

.captcha-form-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.captcha-form-table tr:last-child {
    border-bottom: none;
}

/* ===== فیلدهای ورودی ===== */
.captcha-form-table input[type="text"],
.captcha-form-table input[type="password"],
.captcha-form-table input[type="number"],
.captcha-form-table select {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 100%;
    max-width: 350px;
    font-size: 14px;
    height: 42px;
    box-sizing: border-box;
    background: #fff;
    transition: border-color 0.2s;
}

.captcha-form-table input[type="text"]:focus,
.captcha-form-table input[type="password"]:focus,
.captcha-form-table input[type="number"]:focus,
.captcha-form-table select:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.captcha-input-small {
    max-width: 80px !important;
    width: 80px !important;
    display: inline-block;
}

/* ===== چک‌باکس ===== */
.captcha-checkbox-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    font-size: 14px;
    color: #333;
    margin-left: 15px;
}

.captcha-checkbox-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    min-width: 18px;
    cursor: pointer;
    accent-color: #2271b1;
    margin: 0;
}

/* ===== توضیحات ===== */
.captcha-help-text {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

.captcha-description {
    color: #666;
    font-size: 13px;
    margin-bottom: 20px;
}

/* ===== دکمه ذخیره ===== */
.captcha-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.captcha-submit-btn:hover {
    background: #135e96;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-1px);
}

.captcha-form-actions {
    margin-top: 20px;
}

/* ===== Provider Box ===== */
.provider_box {
    margin-top: 20px;
}

/* ============================================== */
/* ===== رسپانسیو ===== */
/* ============================================== */

@media (max-width: 1024px) {
    .captcha-form-table th {
        width: 180px;
        font-size: 13px;
    }
    .captcha-form-table input[type="text"],
    .captcha-form-table input[type="password"],
    .captcha-form-table input[type="number"],
    .captcha-form-table select {
        max-width: 300px;
    }
}

@media (max-width: 782px) {
    .tab-captcha-settings {
        margin: 10px 10px 0 0;
    }
    
    .captcha-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .captcha-card h3 {
        font-size: 16px;
    }
    
    /* ===== تبدیل جدول به ستونی ===== */
    .captcha-form-table {
        display: block;
        width: 100%;
    }
    
    .captcha-form-table tbody {
        display: block;
        width: 100%;
    }
    
    .captcha-form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #eee;
    }
    
    .captcha-form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .captcha-form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
        color: #1d2327;
        border-bottom: none;
    }
    
    .captcha-form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    
    /* ===== فیلدها در موبایل ===== */
    .captcha-form-table input[type="text"],
    .captcha-form-table input[type="password"],
    .captcha-form-table input[type="number"],
    .captcha-form-table select {
        max-width: 100% !important;
        width: 100% !important;
        height: 44px;
        font-size: 15px;
        padding: 10px 12px;
    }
    
    .captcha-input-small {
        max-width: 100% !important;
        width: 100% !important;
    }
    
    /* ===== چک‌باکس در موبایل ===== */
    .captcha-checkbox-label {
        font-size: 14px;
        gap: 12px;
        margin-left: 0;
        margin-right: 12px;
        display: flex;
        align-items: center;
    }
    
    .captcha-checkbox-label input[type="checkbox"] {
        width: 20px;
        height: 20px;
        min-width: 20px;
    }
    
    /* ===== دکمه ذخیره ===== */
    .captcha-submit-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
        font-size: 15px;
    }
    
    /* ===== توضیحات ===== */
    .captcha-help-text {
        font-size: 11px;
        margin-top: 4px;
    }
    
    /* ===== Provider Box ===== */
    .provider_box {
        margin-top: 15px;
    }
}

@media (max-width: 480px) {
    .captcha-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .captcha-card h3 {
        font-size: 15px;
    }
    
    .captcha-form-table tr {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    
    .captcha-form-table th {
        font-size: 12px;
    }
    
    .captcha-form-table input[type="text"],
    .captcha-form-table input[type="password"],
    .captcha-form-table input[type="number"],
    .captcha-form-table select {
        height: 40px;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 4px;
    }
    
    .captcha-checkbox-label {
        font-size: 13px;
        margin-right: 8px;
    }
    
    .captcha-checkbox-label input[type="checkbox"] {
        width: 18px;
        height: 18px;
        min-width: 18px;
    }
    
    .captcha-submit-btn {
        font-size: 14px;
        padding: 10px 16px;
    }
    
    .captcha-help-text {
        font-size: 10px;
    }
}
</style>

<div class="tab-captcha-settings">
    
    <form method="post">
        <?php wp_nonce_field('captcha_settings', 'captcha_settings'); ?>
        <input type="hidden" name="save_captcha" value="1">
        
        <!-- کارت 1: تنظیمات عمومی -->
        <div class="captcha-card">
            <h3>🔒 تنظیمات عمومی کپچا</h3>
            <table class="captcha-form-table">
                <tr>
                    <th scope="row">فعال کردن کپچا</th>
                    <td>
                        <label class="captcha-checkbox-label">
                            <input type="checkbox" name="captcha_enabled" value="1" <?php checked($captcha_enabled, true); ?>>
                            <span>فعال کردن کپچا در فرم‌های ورود و ثبت‌نام</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">سرویس کپچا</th>
                    <td>
                        <select name="captcha_provider" id="provider_select">
                            <option value="recaptcha" <?php selected($captcha_provider, 'recaptcha'); ?>>Google reCAPTCHA v2/v3</option>
                            <option value="hcaptcha" <?php selected($captcha_provider, 'hcaptcha'); ?>>hCaptcha</option>
                            <option value="turnstile" <?php selected($captcha_provider, 'turnstile'); ?>>Cloudflare Turnstile</option>
                            <option value="math" <?php selected($captcha_provider, 'math'); ?>>Math Captcha (ساده)</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 2: تنظیمات Google reCAPTCHA -->
        <div id="recaptcha_box" class="provider_box captcha-card" <?php echo $captcha_provider != 'recaptcha' ? 'style="display:none;"' : ''; ?>>
            <h3>✅ تنظیمات Google reCAPTCHA</h3>
            <table class="captcha-form-table">
                <tr>
                    <th scope="row">نوع reCAPTCHA</th>
                    <td>
                        <select name="recaptcha_type" id="recaptcha_type">
                            <option value="v2" <?php selected($recaptcha_type, 'v2'); ?>>reCAPTCHA v2 (چک‌باکس)</option>
                            <option value="v3" <?php selected($recaptcha_type, 'v3'); ?>>reCAPTCHA v3 (نامرئی)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">کلید سایت (Site Key)</th>
                    <td>
                        <input type="text" name="site_key" value="<?php echo esc_attr($site_key); ?>" placeholder="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI">
                    </td>
                </tr>
                <tr>
                    <th scope="row">کلید مخفی (Secret Key)</th>
                    <td>
                        <input type="password" name="secret_key" value="<?php echo esc_attr($secret_key); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row" id="score_threshold_label">آستانه امتیاز (Score Threshold)</th>
                    <td>
                        <input type="number" name="threshold" step="0.1" min="0" max="1" value="<?php echo esc_attr($threshold); ?>" class="captcha-input-small">
                        <span class="captcha-help-text">حداقل امتیاز مورد نیاز (0.0 تا 1.0) - فقط برای نسخه v3</span>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 3: تنظیمات hCaptcha -->
        <div id="hcaptcha_box" class="provider_box captcha-card" <?php echo $captcha_provider != 'hcaptcha' ? 'style="display:none;"' : ''; ?>>
            <h3>✅ تنظیمات hCaptcha</h3>
            <table class="captcha-form-table">
                <tr>
                    <th scope="row">کلید سایت (Site Key)</th>
                    <td>
                        <input type="text" name="hcaptcha_site_key" value="<?php echo esc_attr($hcaptcha_site_key); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row">کلید مخفی (Secret Key)</th>
                    <td>
                        <input type="password" name="hcaptcha_secret_key" value="<?php echo esc_attr($hcaptcha_secret_key); ?>">
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 4: تنظیمات Cloudflare Turnstile -->
        <div id="turnstile_box" class="provider_box captcha-card" <?php echo $captcha_provider != 'turnstile' ? 'style="display:none;"' : ''; ?>>
            <h3>✅ تنظیمات Cloudflare Turnstile</h3>
            <table class="captcha-form-table">
                <tr>
                    <th scope="row">کلید سایت (Site Key)</th>
                    <td>
                        <input type="text" name="turnstile_site_key" value="<?php echo esc_attr($turnstile_site_key); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row">کلید مخفی (Secret Key)</th>
                    <td>
                        <input type="password" name="turnstile_secret_key" value="<?php echo esc_attr($turnstile_secret_key); ?>">
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 5: تنظیمات Math Captcha -->
        <div id="math_box" class="provider_box captcha-card" <?php echo $captcha_provider != 'math' ? 'style="display:none;"' : ''; ?>>
            <h3>✅ تنظیمات Math Captcha</h3>
            <table class="captcha-form-table">
                <tr>
                    <th scope="row">محدوده اعداد</th>
                    <td>
                        <input type="number" name="math_min" value="<?php echo esc_attr($math_min); ?>" class="captcha-input-small"> 
                        <span style="margin:0 5px;">تا</span> 
                        <input type="number" name="math_max" value="<?php echo esc_attr($math_max); ?>" class="captcha-input-small">
                    </td>
                </tr>
                <tr>
                    <th scope="row">عملیات‌ها</th>
                    <td>
                        <label class="captcha-checkbox-label">
                            <input type="checkbox" name="math_addition" value="1" <?php checked($math_addition, true); ?>>
                            <span>جمع (+)</span>
                        </label>
                        <label class="captcha-checkbox-label">
                            <input type="checkbox" name="math_subtraction" value="1" <?php checked($math_subtraction, true); ?>>
                            <span>تفریق (-)</span>
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 6: مکان‌های نمایش کپچا -->
        <div class="captcha-card">
            <h3>📍 مکان‌های نمایش کپچا</h3>
            <table class="captcha-form-table">
                <tr>
                    <th scope="row">نمایش در فرم ورود</th>
                    <td>
                        <label class="captcha-checkbox-label">
                            <input type="checkbox" name="show_on_login" value="1" <?php checked($show_on_login, true); ?>>
                            <span>نمایش کپچا در فرم ورود</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">نمایش در فرم ثبت‌نام</th>
                    <td>
                        <label class="captcha-checkbox-label">
                            <input type="checkbox" name="show_on_register" value="1" <?php checked($show_on_register, true); ?>>
                            <span>نمایش کپچا در فرم ثبت‌نام</span>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">نمایش در فرم بازنشانی رمز</th>
                    <td>
                        <label class="captcha-checkbox-label">
                            <input type="checkbox" name="show_on_reset" value="1" <?php checked($show_on_reset, true); ?>>
                            <span>نمایش کپچا در فرم بازنشانی رمز عبور</span>
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 7: تنظیمات پیشرفته -->
        <div class="captcha-card">
            <h3>⚙️ تنظیمات پیشرفته</h3>
            <table class="captcha-form-table">
                <tr>
                    <th scope="row">نمایش بعد از تلاش ناموفق</th>
                    <td>
                        <input type="number" name="show_after_attempts" value="<?php echo esc_attr($show_after_attempts); ?>" class="captcha-input-small"> 
                        <span style="margin:0 5px;">تلاش</span>
                        <span class="captcha-help-text">نمایش کپچا بعد از این تعداد تلاش ناموفق (0 = همیشه)</span>
                    </td>
                </tr>
                <tr>
                    <th scope="row">تم کپچا</th>
                    <td>
                        <select name="captcha_theme">
                            <option value="light" <?php selected($captcha_theme, 'light'); ?>>روشن</option>
                            <option value="dark" <?php selected($captcha_theme, 'dark'); ?>>تیره</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="captcha-form-actions">
            <button type="submit" name="save_captcha" class="captcha-submit-btn">💾 ذخیره تنظیمات کپچا</button>
        </div>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    $('#provider_select').on('change', function() {
        var val = $(this).val();
        $('.provider_box').hide();
        $('#' + val + '_box').show();
    });
    
    $('#recaptcha_type').on('change', function() {
        if ($(this).val() === 'v3') {
            $('#score_threshold_label').show();
            $('input[name="threshold"]').closest('td').prev('th').show();
            $('input[name="threshold"]').closest('td').show();
        } else {
            $('#score_threshold_label').hide();
            $('input[name="threshold"]').closest('td').prev('th').hide();
            $('input[name="threshold"]').closest('td').hide();
        }
    });
    
    // تنظیم اولیه نمایش آستانه امتیاز
    if ($('#recaptcha_type').val() !== 'v3') {
        $('#score_threshold_label').hide();
        $('input[name="threshold"]').closest('td').prev('th').hide();
        $('input[name="threshold"]').closest('td').hide();
    }
});
</script>