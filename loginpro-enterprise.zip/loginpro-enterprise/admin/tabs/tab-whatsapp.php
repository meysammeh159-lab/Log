<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب 💬 تنظیمات واتساپ
// ==================================================

// دریافت مقادیر از دیتابیس
$whatsapp_enabled = get_option('loginpro_whatsapp_enabled', false);
$whatsapp_default_provider = get_option('loginpro_whatsapp_default_provider', 'meta');
$whatsapp_meta_access_token = get_option('loginpro_whatsapp_meta_access_token', '');
$whatsapp_meta_phone_number_id = get_option('loginpro_whatsapp_meta_phone_number_id', '');
$whatsapp_meta_business_account_id = get_option('loginpro_whatsapp_meta_business_account_id', '');
$whatsapp_meta_app_id = get_option('loginpro_whatsapp_meta_app_id', '');
$whatsapp_meta_app_secret = get_option('loginpro_whatsapp_meta_app_secret', '');
$whatsapp_meta_message_template = get_option('loginpro_whatsapp_meta_message_template', '✅ کد تأیید شما: %OTP%');
$whatsapp_fallback_order = get_option('loginpro_whatsapp_fallback_order', 'whatsapp,sms');
$whatsapp_retry_attempts = get_option('loginpro_whatsapp_retry_attempts', 3);
$whatsapp_retry_delay = get_option('loginpro_whatsapp_retry_delay', 60);

// ==================================================
// پردازش ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_whatsapp']) && isset($_POST['whatsapp_settings']) && wp_verify_nonce($_POST['whatsapp_settings'], 'whatsapp_settings')) {
    
    update_option('loginpro_whatsapp_enabled', isset($_POST['whatsapp_enabled']));
    
    if (isset($_POST['whatsapp_default_provider'])) {
        update_option('loginpro_whatsapp_default_provider', sanitize_text_field($_POST['whatsapp_default_provider']));
    }
    if (isset($_POST['whatsapp_meta_access_token'])) {
        update_option('loginpro_whatsapp_meta_access_token', sanitize_text_field($_POST['whatsapp_meta_access_token']));
    }
    if (isset($_POST['whatsapp_meta_phone_number_id'])) {
        update_option('loginpro_whatsapp_meta_phone_number_id', sanitize_text_field($_POST['whatsapp_meta_phone_number_id']));
    }
    if (isset($_POST['whatsapp_meta_business_account_id'])) {
        update_option('loginpro_whatsapp_meta_business_account_id', sanitize_text_field($_POST['whatsapp_meta_business_account_id']));
    }
    if (isset($_POST['whatsapp_meta_app_id'])) {
        update_option('loginpro_whatsapp_meta_app_id', sanitize_text_field($_POST['whatsapp_meta_app_id']));
    }
    if (isset($_POST['whatsapp_meta_app_secret']) && !empty($_POST['whatsapp_meta_app_secret'])) {
        update_option('loginpro_whatsapp_meta_app_secret', sanitize_text_field($_POST['whatsapp_meta_app_secret']));
    }
    if (isset($_POST['whatsapp_meta_message_template'])) {
        update_option('loginpro_whatsapp_meta_message_template', wp_kses_post($_POST['whatsapp_meta_message_template']));
    }
    if (isset($_POST['whatsapp_fallback_order'])) {
        update_option('loginpro_whatsapp_fallback_order', sanitize_text_field($_POST['whatsapp_fallback_order']));
    }
    if (isset($_POST['whatsapp_retry_attempts'])) {
        update_option('loginpro_whatsapp_retry_attempts', intval($_POST['whatsapp_retry_attempts']));
    }
    if (isset($_POST['whatsapp_retry_delay'])) {
        update_option('loginpro_whatsapp_retry_delay', intval($_POST['whatsapp_retry_delay']));
    }
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات واتساپ با موفقیت ذخیره شد.</p></div>';
    
    // به‌روزرسانی متغیرها
    $whatsapp_enabled = get_option('loginpro_whatsapp_enabled', false);
}

// ==================================================
// HTML فرم
// ==================================================
?>
<style>
/* ===== استایل‌های تب واتساپ ===== */
.wrap-whatsapp-tab {
    margin: 20px 20px 0 0;
}

/* ===== کارت اصلی ===== */
.whatsapp-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.whatsapp-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.whatsapp-card .badge-new {
    background: #28a745;
    color: #fff;
    font-size: 10px;
    padding: 2px 8px;
    border-radius: 12px;
    margin-right: 5px;
    display: inline-block;
}

/* ===== جدول فرم ===== */
.whatsapp-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 10px;
}

.whatsapp-form-table th {
    width: 220px;
    text-align: right;
    padding: 15px 15px 15px 0;
    font-weight: 600;
    vertical-align: top;
    font-size: 14px;
    color: #1d2327;
}

.whatsapp-form-table td {
    padding: 15px 0;
    vertical-align: middle;
}

.whatsapp-form-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.whatsapp-form-table tr:last-child {
    border-bottom: none;
}

/* ===== فیلدهای ورودی ===== */
.whatsapp-form-table input[type="text"],
.whatsapp-form-table input[type="number"],
.whatsapp-form-table input[type="password"],
.whatsapp-form-table select {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 100%;
    max-width: 450px;
    font-size: 14px;
    height: 42px;
    box-sizing: border-box;
    background: #fff;
    transition: border-color 0.2s;
}

.whatsapp-form-table input[type="text"]:focus,
.whatsapp-form-table input[type="number"]:focus,
.whatsapp-form-table input[type="password"]:focus,
.whatsapp-form-table select:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.whatsapp-form-table input[type="number"] {
    max-width: 150px;
}

/* ===== چک‌باکس ===== */
.whatsapp-checkbox-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    font-size: 14px;
    color: #333;
}

.whatsapp-checkbox-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    min-width: 18px;
    cursor: pointer;
    accent-color: #2271b1;
    margin: 0;
}

/* ===== توضیحات ===== */
.whatsapp-help-text {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

.whatsapp-help-text code {
    background: #f1f1f1;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 12px;
    color: #d63384;
}

/* ===== باکس هشدار ===== */
.whatsapp-help-warning {
    color: #856404;
    background: #fff3cd;
    padding: 10px 15px;
    border-radius: 6px;
    display: inline-block;
    margin-top: 10px;
    font-size: 13px;
    border-right: 3px solid #ff9800;
    width: 100%;
    box-sizing: border-box;
}

/* ===== دکمه ذخیره ===== */
.whatsapp-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 20px;
}

.whatsapp-submit-btn:hover {
    background: #135e96;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-1px);
}

/* ============================================== */
/* ===== رسپانسیو ===== */
/* ============================================== */

@media (max-width: 1024px) {
    .whatsapp-form-table th {
        width: 180px;
        font-size: 13px;
    }
    .whatsapp-form-table input[type="text"],
    .whatsapp-form-table input[type="number"],
    .whatsapp-form-table input[type="password"],
    .whatsapp-form-table select {
        max-width: 350px;
    }
}

@media (max-width: 782px) {
    .wrap-whatsapp-tab {
        margin: 10px 10px 0 0;
    }
    
    .whatsapp-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .whatsapp-card h3 {
        font-size: 16px;
    }
    
    .whatsapp-form-table {
        display: block;
        width: 100%;
    }
    
    .whatsapp-form-table tbody {
        display: block;
        width: 100%;
    }
    
    .whatsapp-form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #eee;
    }
    
    .whatsapp-form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .whatsapp-form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
        color: #1d2327;
        border-bottom: none;
    }
    
    .whatsapp-form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    
    .whatsapp-form-table input[type="text"],
    .whatsapp-form-table input[type="number"],
    .whatsapp-form-table input[type="password"],
    .whatsapp-form-table select {
        max-width: 100% !important;
        width: 100% !important;
        height: 44px;
        font-size: 15px;
        padding: 10px 12px;
    }
    
    .whatsapp-form-table input[type="number"] {
        max-width: 100% !important;
    }
    
    .whatsapp-checkbox-label {
        font-size: 14px;
        gap: 12px;
    }
    
    .whatsapp-checkbox-label input[type="checkbox"] {
        width: 20px;
        height: 20px;
        min-width: 20px;
    }
    
    .whatsapp-help-warning {
        font-size: 12px;
        padding: 8px 12px;
    }
    
    .whatsapp-submit-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
        font-size: 15px;
    }
    
    .whatsapp-help-text {
        font-size: 11px;
        margin-top: 4px;
    }
}

@media (max-width: 480px) {
    .whatsapp-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .whatsapp-card h3 {
        font-size: 15px;
    }
    
    .whatsapp-form-table tr {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    
    .whatsapp-form-table th {
        font-size: 12px;
    }
    
    .whatsapp-form-table input[type="text"],
    .whatsapp-form-table input[type="number"],
    .whatsapp-form-table input[type="password"],
    .whatsapp-form-table select {
        height: 40px;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 4px;
    }
    
    .whatsapp-checkbox-label {
        font-size: 13px;
    }
    
    .whatsapp-checkbox-label input[type="checkbox"] {
        width: 18px;
        height: 18px;
        min-width: 18px;
    }
    
    .whatsapp-help-warning {
        font-size: 11px;
        padding: 6px 10px;
    }
    
    .whatsapp-submit-btn {
        font-size: 14px;
        padding: 10px 16px;
    }
    
    .whatsapp-help-text {
        font-size: 10px;
    }
}
</style>

<div class="wrap-whatsapp-tab">
    <div class="whatsapp-card">
        <h3>
            💬 تنظیمات WhatsApp Business
            <span class="badge-new">جدید</span>
        </h3>
        
        <form method="post">
            <?php wp_nonce_field('whatsapp_settings', 'whatsapp_settings'); ?>
            <input type="hidden" name="save_whatsapp" value="1">
            
            <table class="whatsapp-form-table">
                <tr>
                    <th>فعال‌سازی WhatsApp</th>
                    <td>
                        <label class="whatsapp-checkbox-label">
                            <input type="checkbox" name="whatsapp_enabled" value="1" <?php checked($whatsapp_enabled, true); ?>>
                            <span>فعال کردن ارسال پیام از طریق WhatsApp</span>
                        </label>
                        <span class="whatsapp-help-text">پس از فعال‌سازی، OTP از طریق WhatsApp نیز ارسال می‌شود</span>
                    </td>
                </tr>
                <tr>
                    <th>درگاه پیش‌فرض واتساپ</th>
                    <td>
                        <select name="whatsapp_default_provider" style="width: 100%; max-width: 300px;">
                            <option value="meta" <?php selected($whatsapp_default_provider, 'meta'); ?>>Meta Cloud API (WhatsApp Business)</option>
                            <option value="twilio" disabled>Twilio (به زودی)</option>
                            <option value="greenapi" disabled>Green API (به زودی)</option>
                        </select>
                        <span class="whatsapp-help-text">درگاه پیش‌فرض برای ارسال پیام</span>
                    </td>
                </tr>
                <tr>
                    <th>توکن دسترسی (Access Token)</th>
                    <td>
                        <input type="text" name="whatsapp_meta_access_token" value="<?php echo esc_attr($whatsapp_meta_access_token); ?>" placeholder="EAxxxxxxxxxxxxxxxx" style="width: 100%; max-width: 400px;">
                        <span class="whatsapp-help-text">توکن دسترسی بلندمدت از Meta Business Suite</span>
                    </td>
                </tr>
                <tr>
                    <th>شناسه شماره تلفن (Phone Number ID)</th>
                    <td>
                        <input type="text" name="whatsapp_meta_phone_number_id" value="<?php echo esc_attr($whatsapp_meta_phone_number_id); ?>" placeholder="123456789012345" style="width: 100%; max-width: 400px;">
                        <span class="whatsapp-help-text">شناسه شماره تلفنی که در Meta Business ثبت شده است</span>
                    </td>
                </tr>
                <tr>
                    <th>شناسه حساب بیزینس (Business Account ID)</th>
                    <td>
                        <input type="text" name="whatsapp_meta_business_account_id" value="<?php echo esc_attr($whatsapp_meta_business_account_id); ?>" placeholder="123456789012345" style="width: 100%; max-width: 400px;">
                        <span class="whatsapp-help-text">اختیاری - شناسه حساب بیزینس Meta</span>
                    </td>
                </tr>
                <tr>
                    <th>شناسه اپلیکیشن (App ID)</th>
                    <td>
                        <input type="text" name="whatsapp_meta_app_id" value="<?php echo esc_attr($whatsapp_meta_app_id); ?>" placeholder="123456789012345" style="width: 100%; max-width: 400px;">
                        <span class="whatsapp-help-text">شناسه اپلیکیشن Meta</span>
                    </td>
                </tr>
                <tr>
                    <th>کلید مخفی اپلیکیشن (App Secret)</th>
                    <td>
                        <input type="password" name="whatsapp_meta_app_secret" value="<?php echo esc_attr($whatsapp_meta_app_secret); ?>" placeholder="****************" style="width: 100%; max-width: 400px;">
                        <span class="whatsapp-help-text">در صورت تمایل خالی بگذارید تا تغییر نکند</span>
                    </td>
                </tr>
                <tr>
                    <th>الگوی پیام (Message Template)</th>
                    <td>
                        <textarea name="whatsapp_meta_message_template" rows="3" style="width: 100%; max-width: 500px; font-family: monospace;"><?php echo esc_textarea($whatsapp_meta_message_template); ?></textarea>
                        <span class="whatsapp-help-text">متغیرهای قابل استفاده: <code>%OTP%</code> - <code>{NAME}</code> - <code>{DOMAIN}</code></span>
                    </td>
                </tr>
                <tr>
                    <th>ترتیب بازگشت (Fallback Order)</th>
                    <td>
                        <select name="whatsapp_fallback_order" style="width: 100%; max-width: 300px;">
                            <option value="whatsapp,sms" <?php selected($whatsapp_fallback_order, 'whatsapp,sms'); ?>>واتساپ → پیامک</option>
                            <option value="whatsapp,email" <?php selected($whatsapp_fallback_order, 'whatsapp,email'); ?>>واتساپ → ایمیل</option>
                            <option value="whatsapp,sms,email" <?php selected($whatsapp_fallback_order, 'whatsapp,sms,email'); ?>>واتساپ → پیامک → ایمیل</option>
                        </select>
                        <span class="whatsapp-help-text">در صورت عدم موفقیت واتساپ، از کانال بعدی استفاده می‌شود</span>
                    </td>
                </tr>
                <tr>
                    <th>تعداد تلاش مجدد</th>
                    <td>
                        <input type="number" name="whatsapp_retry_attempts" value="<?php echo esc_attr($whatsapp_retry_attempts); ?>" min="1" max="5" style="width: 80px;">
                        <span class="whatsapp-help-text">تعداد دفعات تلاش مجدد در صورت خطا</span>
                    </td>
                </tr>
                <tr>
                    <th>زمان انتظار بین تلاش‌ها</th>
                    <td>
                        <input type="number" name="whatsapp_retry_delay" value="<?php echo esc_attr($whatsapp_retry_delay); ?>" min="10" max="300" style="width: 80px;">
                        <span class="whatsapp-help-text">زمان انتظار بین تلاش‌ها (ثانیه)</span>
                    </td>
                </tr>
            </table>
            
            <div class="whatsapp-help-warning">
                ⚠️ افزونه مسئولیتی در قبال هیچ یک از پنل‌های واتساپ ندارد.
            </div>
            
            <button type="submit" class="whatsapp-submit-btn">💾 ذخیره تنظیمات</button>
        </form>
    </div>
</div>