<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب 🛒 اتصال با ووکامرس
// ==================================================

$woocommerce_active = class_exists('WooCommerce');

if ($woocommerce_active) {
    $checkout_otp_enabled = get_option('loginpro_woo_checkout_otp', false);
    $checkout_otp_channel = get_option('loginpro_woo_otp_channel', 'sms');
    $skip_logged_in = get_option('loginpro_woo_skip_logged_in', true);
    $auto_create_user = get_option('loginpro_woo_auto_create_user', true);
    $auto_user_role = get_option('loginpro_woo_auto_user_role', 'customer');
    $send_welcome_email = get_option('loginpro_woo_send_welcome_email', true);
    $sync_billing_phone = get_option('loginpro_woo_sync_billing_phone', true);
    $sync_billing_email = get_option('loginpro_woo_sync_billing_email', true);
    $sync_shipping_address = get_option('loginpro_woo_sync_shipping_address', false);
}

if ($woocommerce_active && isset($_POST['save_woocommerce']) && isset($_POST['woocommerce_settings']) && wp_verify_nonce($_POST['woocommerce_settings'], 'woocommerce_settings')) {
    
    update_option('loginpro_woo_checkout_otp', isset($_POST['checkout_otp_enabled']));
    update_option('loginpro_woo_otp_channel', sanitize_text_field($_POST['checkout_otp_channel']));
    update_option('loginpro_woo_skip_logged_in', isset($_POST['skip_logged_in']));
    update_option('loginpro_woo_auto_create_user', isset($_POST['auto_create_user']));
    update_option('loginpro_woo_auto_user_role', sanitize_text_field($_POST['auto_user_role']));
    update_option('loginpro_woo_send_welcome_email', isset($_POST['send_welcome_email']));
    update_option('loginpro_woo_sync_billing_phone', isset($_POST['sync_billing_phone']));
    update_option('loginpro_woo_sync_billing_email', isset($_POST['sync_billing_email']));
    update_option('loginpro_woo_sync_shipping_address', isset($_POST['sync_shipping_address']));
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات ووکامرس با موفقیت ذخیره شد.</p></div>';
    
    $checkout_otp_enabled = get_option('loginpro_woo_checkout_otp', false);
    $checkout_otp_channel = get_option('loginpro_woo_otp_channel', 'sms');
    $skip_logged_in = get_option('loginpro_woo_skip_logged_in', true);
    $auto_create_user = get_option('loginpro_woo_auto_create_user', true);
    $auto_user_role = get_option('loginpro_woo_auto_user_role', 'customer');
    $send_welcome_email = get_option('loginpro_woo_send_welcome_email', true);
    $sync_billing_phone = get_option('loginpro_woo_sync_billing_phone', true);
    $sync_billing_email = get_option('loginpro_woo_sync_billing_email', true);
    $sync_shipping_address = get_option('loginpro_woo_sync_shipping_address', false);
}
?>
<style>
.tab-woocommerce-settings {
    margin: 20px 20px 0 0;
}

.woo-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.woo-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.woo-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 10px;
}

.woo-form-table th {
    width: 220px;
    text-align: right;
    padding: 15px 15px 15px 0;
    font-weight: 600;
    vertical-align: top;
    font-size: 14px;
    color: #1d2327;
}

.woo-form-table td {
    padding: 15px 0;
    vertical-align: middle;
}

.woo-form-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.woo-form-table tr:last-child {
    border-bottom: none;
}

.woo-form-table select {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 100%;
    max-width: 300px;
    font-size: 14px;
    height: 42px;
    box-sizing: border-box;
    background: #fff;
}

.woo-form-table select:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.woo-checkbox-label {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    font-size: 14px;
    color: #333;
}

.woo-checkbox-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    min-width: 18px;
    cursor: pointer;
    accent-color: #2271b1;
    margin: 0;
}

.woo-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.woo-submit-btn:hover {
    background: #135e96;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-1px);
}

.woo-help-text {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

.woo-warning {
    background: #fff3cd;
    border-right: 4px solid #ffb900;
    padding: 12px 16px;
    margin-bottom: 20px;
    border-radius: 6px;
    color: #856404;
}

@media (max-width: 1024px) {
    .woo-form-table th {
        width: 180px;
        font-size: 13px;
    }
    .woo-form-table select {
        max-width: 280px;
    }
}

@media (max-width: 782px) {
    .tab-woocommerce-settings {
        margin: 10px 10px 0 0;
    }
    
    .woo-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .woo-card h3 {
        font-size: 16px;
    }
    
    .woo-form-table {
        display: block;
        width: 100%;
    }
    
    .woo-form-table tbody {
        display: block;
        width: 100%;
    }
    
    .woo-form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #eee;
    }
    
    .woo-form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .woo-form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
        color: #1d2327;
        border-bottom: none;
    }
    
    .woo-form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    
    .woo-form-table select {
        max-width: 100% !important;
        width: 100% !important;
        height: 44px;
        font-size: 15px;
        padding: 10px 12px;
    }
    
    .woo-checkbox-label {
        font-size: 14px;
        gap: 12px;
    }
    
    .woo-checkbox-label input[type="checkbox"] {
        width: 20px;
        height: 20px;
        min-width: 20px;
    }
    
    .woo-submit-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
        font-size: 15px;
    }
    
    .woo-help-text {
        font-size: 11px;
        margin-top: 4px;
    }
    
    .woo-warning {
        font-size: 13px;
        padding: 10px 14px;
    }
}

@media (max-width: 480px) {
    .woo-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .woo-card h3 {
        font-size: 15px;
    }
    
    .woo-form-table tr {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    
    .woo-form-table th {
        font-size: 12px;
    }
    
    .woo-form-table select {
        height: 40px;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 4px;
    }
    
    .woo-checkbox-label {
        font-size: 13px;
    }
    
    .woo-checkbox-label input[type="checkbox"] {
        width: 18px;
        height: 18px;
        min-width: 18px;
    }
    
    .woo-submit-btn {
        font-size: 14px;
        padding: 10px 16px;
    }
    
    .woo-help-text {
        font-size: 10px;
    }
}
</style>

<div class="tab-woocommerce-settings">
    
    <?php if (!$woocommerce_active): ?>
        <div class="woo-warning">
            <strong>⚠️ ووکامرس نصب و فعال نیست!</strong>
            <p style="margin: 5px 0 0 0;">برای استفاده از تنظیمات ووکامرس، لطفاً افزونه <strong>ووکامرس (WooCommerce)</strong> را نصب و فعال کنید.</p>
        </div>
        
        <div class="woo-card" style="opacity: 0.6;">
            <h3>🔐 تأیید OTP در تسویه حساب</h3>
            <table class="woo-form-table">
                <tr>
                    <th scope="row">فعال کردن OTP در تسویه حساب</th>
                    <td>
                        <label class="woo-checkbox-label">
                            <input type="checkbox" disabled> نیاز به تأیید OTP قبل از تکمیل خرید
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">کانال ارسال OTP</th>
                    <td>
                        <select disabled class="woo-select">
                            <option>پیامک (SMS)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">رد شدن برای کاربران وارد شده</th>
                    <td>
                        <label class="woo-checkbox-label">
                            <input type="checkbox" disabled> رد شدن از تأیید OTP برای کاربرانی که وارد شده‌اند
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="woo-card" style="opacity: 0.6;">
            <h3>👤 ایجاد خودکار کاربر</h3>
            <table class="woo-form-table">
                <tr>
                    <th scope="row">ایجاد خودکار حساب</th>
                    <td>
                        <label class="woo-checkbox-label">
                            <input type="checkbox" disabled> ایجاد خودکار حساب کاربری بعد از تأیید OTP
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">نقش کاربر</th>
                    <td>
                        <select disabled class="woo-select">
                            <option>مشتری</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">ارسال ایمیل خوشآمدگویی</th>
                    <td>
                        <label class="woo-checkbox-label">
                            <input type="checkbox" disabled> ارسال ایمیل خوشآمدگویی به کاربران جدید
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="woo-card" style="opacity: 0.6;">
            <h3>🔄 همگام‌سازی حساب</h3>
            <table class="woo-form-table">
                <tr>
                    <th scope="row">همگام‌سازی تلفن صورتحساب</th>
                    <td>
                        <label class="woo-checkbox-label">
                            <input type="checkbox" disabled> همگام‌سازی شماره تلفن صورتحساب با شماره موبایل کاربر
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">همگام‌سازی ایمیل صورتحساب</th>
                    <td>
                        <label class="woo-checkbox-label">
                            <input type="checkbox" disabled> همگام‌سازی ایمیل صورتحساب با حساب کاربری
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">همگام‌سازی آدرس حمل‌ونقل</th>
                    <td>
                        <label class="woo-checkbox-label">
                            <input type="checkbox" disabled> همگام‌سازی آدرس حمل‌ونقل با پروفایل کاربر
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        
        <div style="margin-top: 20px;">
            <button type="button" class="woo-submit-btn" disabled style="opacity: 0.5;">💾 ذخیره تنظیمات ووکامرس</button>
        </div>
        
    <?php else: ?>
        
        <form method="post">
            <?php wp_nonce_field('woocommerce_settings', 'woocommerce_settings'); ?>
            <input type="hidden" name="save_woocommerce" value="1">
            
            <div class="woo-card">
                <h3>🔐 تأیید OTP در تسویه حساب</h3>
                <table class="woo-form-table">
                    <tr>
                        <th scope="row">فعال کردن OTP در تسویه حساب</th>
                        <td>
                            <label class="woo-checkbox-label">
                                <input type="checkbox" name="checkout_otp_enabled" value="1" <?php echo ($checkout_otp_enabled) ? 'checked' : ''; ?>>
                                نیاز به تأیید OTP قبل از تکمیل خرید
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">کانال ارسال OTP</th>
                        <td>
                            <select name="checkout_otp_channel">
                                <option value="sms" <?php echo ($checkout_otp_channel == 'sms') ? 'selected' : ''; ?>>پیامک (SMS)</option>
                                <option value="whatsapp" <?php echo ($checkout_otp_channel == 'whatsapp') ? 'selected' : ''; ?>>واتساپ (WhatsApp)</option>
                                <option value="email" <?php echo ($checkout_otp_channel == 'email') ? 'selected' : ''; ?>>ایمیل (Email)</option>
                            </select>
                            <span class="woo-help-text">کانالی که کد تأیید از طریق آن ارسال می‌شود</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">رد شدن برای کاربران وارد شده</th>
                        <td>
                            <label class="woo-checkbox-label">
                                <input type="checkbox" name="skip_logged_in" value="1" <?php echo ($skip_logged_in) ? 'checked' : ''; ?>>
                                رد شدن از تأیید OTP برای کاربرانی که وارد شده‌اند
                            </label>
                            <span class="woo-help-text">کاربرانی که قبلاً وارد شده‌اند، نیازی به تأیید OTP ندارند</span>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="woo-card">
                <h3>👤 ایجاد خودکار کاربر</h3>
                <table class="woo-form-table">
                    <tr>
                        <th scope="row">ایجاد خودکار حساب</th>
                        <td>
                            <label class="woo-checkbox-label">
                                <input type="checkbox" name="auto_create_user" value="1" <?php echo ($auto_create_user) ? 'checked' : ''; ?>>
                                ایجاد خودکار حساب کاربری بعد از تأیید OTP
                            </label>
                            <span class="woo-help-text">برای مشتریان جدید که شماره موبایل دارند، حساب کاربری خودکار ساخته می‌شود</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">نقش کاربر</th>
                        <td>
                            <select name="auto_user_role">
                                <?php wp_dropdown_roles($auto_user_role); ?>
                            </select>
                            <span class="woo-help-text">نقش کاربری که برای کاربران جدید ایجاد می‌شود</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">ارسال ایمیل خوشآمدگویی</th>
                        <td>
                            <label class="woo-checkbox-label">
                                <input type="checkbox" name="send_welcome_email" value="1" <?php echo ($send_welcome_email) ? 'checked' : ''; ?>>
                                ارسال ایمیل خوشآمدگویی به کاربران جدید
                            </label>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="woo-card">
                <h3>🔄 همگام‌سازی حساب</h3>
                <table class="woo-form-table">
                    <tr>
                        <th scope="row">همگام‌سازی تلفن صورتحساب</th>
                        <td>
                            <label class="woo-checkbox-label">
                                <input type="checkbox" name="sync_billing_phone" value="1" <?php echo ($sync_billing_phone) ? 'checked' : ''; ?>>
                                همگام‌سازی شماره تلفن صورتحساب با شماره موبایل کاربر
                            </label>
                            <span class="woo-help-text">شماره موبایل کاربر در متادیتا با فیلد billing_phone همگام می‌شود</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">همگام‌سازی ایمیل صورتحساب</th>
                        <td>
                            <label class="woo-checkbox-label">
                                <input type="checkbox" name="sync_billing_email" value="1" <?php echo ($sync_billing_email) ? 'checked' : ''; ?>>
                                همگام‌سازی ایمیل صورتحساب با حساب کاربری
                            </label>
                            <span class="woo-help-text">ایمیل کاربر با فیلد billing_email همگام می‌شود</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">همگام‌سازی آدرس حمل‌ونقل</th>
                        <td>
                            <label class="woo-checkbox-label">
                                <input type="checkbox" name="sync_shipping_address" value="1" <?php echo ($sync_shipping_address) ? 'checked' : ''; ?>>
                                همگام‌سازی آدرس حمل‌ونقل با پروفایل کاربر
                            </label>
                            <span class="woo-help-text">آدرس‌های حمل‌ونقل از پروفایل کاربر با ووکامرس همگام می‌شود</span>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div style="margin-top: 20px;">
                <button type="submit" class="woo-submit-btn">💾 ذخیره تنظیمات ووکامرس</button>
            </div>
        </form>
        
    <?php endif; ?>
    
</div>