<?php
/**
 * تب حالت تعمیرات و ورود اجباری
 * 
 * @package LoginPro
 * @version 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// دریافت تنظیمات
// ==================================================

// تنظیمات اصلی
$maintenance_enabled = get_option('loginpro_maintenance_enabled', false);
$maintenance_mode = get_option('loginpro_maintenance_mode', 'maintenance');
$maintenance_title = get_option('loginpro_maintenance_title', 'سایت در دست تعمیرات است');
$maintenance_message = get_option('loginpro_maintenance_message', 'لطفاً مدتی بعد مجدداً تلاش کنید. با تشکر');
$maintenance_show_login = get_option('loginpro_maintenance_show_login', true);
$maintenance_show_countdown = get_option('loginpro_maintenance_show_countdown', false);
$maintenance_countdown_date = get_option('loginpro_maintenance_countdown_date', '');
$maintenance_allow_ips = get_option('loginpro_maintenance_allow_ips', '');
$maintenance_allow_roles = get_option('loginpro_maintenance_allow_roles', []);
$maintenance_redirect_url = get_option('loginpro_maintenance_redirect_url', '');
$maintenance_custom_css = get_option('loginpro_maintenance_custom_css', '');
$maintenance_custom_html = get_option('loginpro_maintenance_custom_html', '');
$maintenance_show_social = get_option('loginpro_maintenance_show_social', true);

// دریافت نقش‌های وردپرس
$wp_roles = wp_roles();
$role_names = [];
foreach ($wp_roles->role_names as $key => $name) {
    $role_names[$key] = $name;
}

// ==================================================
// پردازش ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_maintenance']) && isset($_POST['maintenance_nonce']) && wp_verify_nonce($_POST['maintenance_nonce'], 'maintenance_settings')) {
    
    $maintenance_enabled_val = isset($_POST['maintenance_enabled']) ? '1' : '0';
    update_option('loginpro_maintenance_enabled', $maintenance_enabled_val);
    
    if (isset($_POST['maintenance_mode'])) {
        update_option('loginpro_maintenance_mode', sanitize_text_field($_POST['maintenance_mode']));
    }
    if (isset($_POST['maintenance_title'])) {
        update_option('loginpro_maintenance_title', sanitize_text_field($_POST['maintenance_title']));
    }
    if (isset($_POST['maintenance_message'])) {
        update_option('loginpro_maintenance_message', wp_kses_post($_POST['maintenance_message']));
    }
    
    $maintenance_show_login_val = isset($_POST['maintenance_show_login']) ? '1' : '0';
    update_option('loginpro_maintenance_show_login', $maintenance_show_login_val);
    
    $maintenance_show_countdown_val = isset($_POST['maintenance_show_countdown']) ? '1' : '0';
    update_option('loginpro_maintenance_show_countdown', $maintenance_show_countdown_val);
    
    if (isset($_POST['maintenance_countdown_date'])) {
        update_option('loginpro_maintenance_countdown_date', sanitize_text_field($_POST['maintenance_countdown_date']));
    }
    if (isset($_POST['maintenance_allow_ips'])) {
        update_option('loginpro_maintenance_allow_ips', sanitize_text_field($_POST['maintenance_allow_ips']));
    }
    if (isset($_POST['maintenance_allow_roles'])) {
        update_option('loginpro_maintenance_allow_roles', array_map('sanitize_text_field', $_POST['maintenance_allow_roles']));
    } else {
        update_option('loginpro_maintenance_allow_roles', []);
    }
    if (isset($_POST['maintenance_redirect_url'])) {
        update_option('loginpro_maintenance_redirect_url', sanitize_url($_POST['maintenance_redirect_url']));
    }
    if (isset($_POST['maintenance_custom_css'])) {
        update_option('loginpro_maintenance_custom_css', wp_strip_all_tags($_POST['maintenance_custom_css']));
    }
    if (isset($_POST['maintenance_custom_html'])) {
        update_option('loginpro_maintenance_custom_html', wp_kses_post($_POST['maintenance_custom_html']));
    }
    
    $maintenance_show_social_val = isset($_POST['maintenance_show_social']) ? '1' : '0';
    update_option('loginpro_maintenance_show_social', $maintenance_show_social_val);
    
    // به‌روزرسانی متغیرها
    $maintenance_enabled = get_option('loginpro_maintenance_enabled', false);
    $maintenance_mode = get_option('loginpro_maintenance_mode', 'maintenance');
    $maintenance_allow_roles = get_option('loginpro_maintenance_allow_roles', []);
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات با موفقیت ذخیره شد.</p></div>';
}

// ==================================================
// HTML فرم
// ==================================================
?>
<style>
/* ===== استایل اصلی ===== */
.tab-maintenance-settings {
    margin: 20px 20px 0 0;
}

.loginpro-card {
    background: #fff;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 20px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.loginpro-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
    display: flex;
    align-items: center;
    gap: 10px;
}

.loginpro-card h3 .badge {
    font-size: 12px;
    background: #e8f5e9;
    color: #2e7d32;
    padding: 2px 12px;
    border-radius: 20px;
    font-weight: normal;
}

.loginpro-card h3 .badge.inactive {
    background: #fce4ec;
    color: #c62828;
}

.loginpro-card h3 .badge.warning {
    background: #fff3cd;
    color: #856404;
}

/* ===== فرم ===== */
.loginpro-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.loginpro-form-table th {
    width: 200px;
    text-align: right;
    padding: 12px 12px 12px 0;
    font-weight: 600;
    vertical-align: top;
    font-size: 13px;
    color: #1d2327;
}

.loginpro-form-table td {
    padding: 12px 0;
    vertical-align: middle;
}

.loginpro-form-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.loginpro-form-table tr:last-child {
    border-bottom: none;
}

/* ===== فیلدهای ورودی ===== */
.loginpro-form-table input[type="text"],
.loginpro-form-table input[type="url"],
.loginpro-form-table input[type="datetime-local"],
.loginpro-form-table select,
.loginpro-form-table textarea {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 100%;
    max-width: 350px;
    font-size: 13px;
    box-sizing: border-box;
    background: #fff;
    transition: border-color 0.2s;
    font-family: inherit;
}

.loginpro-form-table input[type="text"]:focus,
.loginpro-form-table input[type="url"]:focus,
.loginpro-form-table input[type="datetime-local"]:focus,
.loginpro-form-table select:focus,
.loginpro-form-table textarea:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.loginpro-form-table textarea {
    height: 100px;
    max-width: 500px;
    resize: vertical;
}

.loginpro-form-table input[type="datetime-local"] {
    max-width: 220px;
}

/* ===== چک‌باکس ===== */
.loginpro-checkbox-label {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    font-size: 13px;
    color: #333;
}

.loginpro-checkbox-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    min-width: 18px;
    cursor: pointer;
    accent-color: #2271b1;
    margin: 0;
}

/* ===== توضیحات ===== */
.description {
    color: #666;
    font-size: 11px;
    margin-top: 4px;
    display: block;
}

.description .highlight {
    color: #2271b1;
    font-weight: 500;
}

.description .danger {
    color: #dc3545;
    font-weight: 500;
}

/* ===== دکمه ذخیره ===== */
.loginpro-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.loginpro-submit-btn:hover {
    background: #135e96;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-1px);
}

/* ===== پیام موفقیت ===== */
.notice-success {
    background: #d4edda;
    color: #155724;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #28a745;
}

/* ===== پیش‌نمایش ===== */
.maintenance-preview {
    background: #f8f9fa;
    border: 2px dashed #dee2e6;
    border-radius: 12px;
    padding: 30px;
    text-align: center;
    margin-top: 15px;
}

.maintenance-preview .preview-title {
    font-size: 24px;
    font-weight: 700;
    color: #1a1a1a;
    margin-bottom: 10px;
}

.maintenance-preview .preview-message {
    color: #666;
    font-size: 16px;
}

.maintenance-preview .preview-login-btn {
    display: inline-block;
    margin-top: 20px;
    padding: 12px 30px;
    background: #2271b1;
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
}

/* ============================================== */
/* ===== رسپانسیو ===== */
/* ============================================== */

@media (max-width: 1024px) {
    .loginpro-form-table th {
        width: 160px;
        font-size: 12px;
    }
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="url"],
    .loginpro-form-table select,
    .loginpro-form-table textarea {
        max-width: 300px;
    }
}

@media (max-width: 782px) {
    .tab-maintenance-settings {
        margin: 10px 10px 0 0;
    }
    
    .loginpro-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .loginpro-card h3 {
        font-size: 16px;
    }
    
    .loginpro-form-table {
        display: block;
        width: 100%;
    }
    
    .loginpro-form-table tbody {
        display: block;
        width: 100%;
    }
    
    .loginpro-form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #eee;
    }
    
    .loginpro-form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .loginpro-form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
        color: #1d2327;
        border-bottom: none;
    }
    
    .loginpro-form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="url"],
    .loginpro-form-table input[type="datetime-local"],
    .loginpro-form-table select,
    .loginpro-form-table textarea {
        max-width: 100% !important;
        width: 100% !important;
        font-size: 15px;
        padding: 10px 12px;
    }
    
    .loginpro-checkbox-label {
        font-size: 14px;
        gap: 12px;
    }
    
    .loginpro-checkbox-label input[type="checkbox"] {
        width: 20px;
        height: 20px;
        min-width: 20px;
    }
    
    .loginpro-submit-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
        font-size: 15px;
    }
    
    .maintenance-preview {
        padding: 20px;
    }
    .maintenance-preview .preview-title {
        font-size: 20px;
    }
    .maintenance-preview .preview-message {
        font-size: 14px;
    }
}

@media (max-width: 480px) {
    .loginpro-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .loginpro-card h3 {
        font-size: 15px;
        flex-wrap: wrap;
    }
    
    .loginpro-form-table tr {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    
    .loginpro-form-table th {
        font-size: 12px;
    }
    
    .loginpro-form-table input[type="text"],
    .loginpro-form-table input[type="url"],
    .loginpro-form-table input[type="datetime-local"],
    .loginpro-form-table select,
    .loginpro-form-table textarea {
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 4px;
    }
    
    .loginpro-checkbox-label {
        font-size: 13px;
    }
    
    .loginpro-checkbox-label input[type="checkbox"] {
        width: 18px;
        height: 18px;
        min-width: 18px;
    }
    
    .loginpro-submit-btn {
        font-size: 14px;
        padding: 10px 16px;
    }
}
</style>

<div class="tab-maintenance-settings">
    
    <!-- ========================================== -->
    <!-- کارت اصلی -->
    <!-- ========================================== -->
    <div class="loginpro-card">
        <h3>
            🔒 حالت تعمیرات / ورود اجباری
            <span class="badge <?php echo $maintenance_enabled ? 'warning' : 'inactive'; ?>">
                <?php echo $maintenance_enabled ? 'فعال' : 'غیرفعال'; ?>
            </span>
        </h3>
        
        <form method="post" action="">
            <?php wp_nonce_field('maintenance_settings', 'maintenance_nonce'); ?>
            <input type="hidden" name="save_maintenance" value="1">
            
            <table class="loginpro-form-table">
                <!-- ===== فعالسازی ===== -->
                <tr>
                    <th>فعالسازی حالت</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="maintenance_enabled" value="1" <?php checked($maintenance_enabled, true); ?>>
                            <span>فعال باشد - <span class="danger">فقط کاربران لاگین شده می‌توانند سایت را ببینند</span></span>
                        </label>
                        <span class="description">با فعال کردن این گزینه، سایت برای کاربران غیرلاگین نمایش داده نمی‌شود</span>
                    </td>
                </tr>
                
                <!-- ===== نوع حالت ===== -->
                <tr>
                    <th>نوع حالت</th>
                    <td>
                        <select name="maintenance_mode">
                            <option value="maintenance" <?php selected($maintenance_mode, 'maintenance'); ?>>🔧 تعمیرات</option>
                            <option value="login_required" <?php selected($maintenance_mode, 'login_required'); ?>>🔐 ورود اجباری</option>
                            <option value="coming_soon" <?php selected($maintenance_mode, 'coming_soon'); ?>>🚀 به زودی</option>
                        </select>
                        <span class="description">
                            <strong>تعمیرات:</strong> پیام تعمیرات نمایش داده می‌شود<br>
                            <strong>ورود اجباری:</strong> کاربر باید لاگین کند تا سایت را ببیند<br>
                            <strong>به زودی:</strong> پیام به زودی نمایش داده می‌شود
                        </span>
                    </td>
                </tr>
                
                <!-- ===== عنوان ===== -->
                <tr>
                    <th>عنوان صفحه</th>
                    <td>
                        <input type="text" name="maintenance_title" value="<?php echo esc_attr($maintenance_title); ?>" placeholder="سایت در دست تعمیرات است">
                        <span class="description">عنوانی که در صفحه نمایش داده می‌شود</span>
                    </td>
                </tr>
                
                <!-- ===== پیام ===== -->
                <tr>
                    <th>پیام</th>
                    <td>
                        <textarea name="maintenance_message" rows="3" placeholder="لطفاً مدتی بعد مجدداً تلاش کنید"><?php echo esc_textarea($maintenance_message); ?></textarea>
                        <span class="description">پیامی که به کاربران نمایش داده می‌شود</span>
                    </td>
                </tr>
                
                <!-- ===== نمایش دکمه ورود ===== -->
                <tr>
                    <th>نمایش دکمه ورود</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="maintenance_show_login" value="1" <?php checked($maintenance_show_login, true); ?>>
                            <span>دکمه ورود در صفحه نمایش داده شود</span>
                        </label>
                        <span class="description">کاربران می‌توانند با کلیک روی دکمه وارد شوند</span>
                    </td>
                </tr>
                
                <!-- ===== نمایش شبکه‌های اجتماعی ===== -->
                <tr>
                    <th>نمایش شبکه‌های اجتماعی</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="maintenance_show_social" value="1" <?php checked($maintenance_show_social, true); ?>>
                            <span>دکمه‌های شبکه‌های اجتماعی در صفحه نمایش داده شوند</span>
                        </label>
                        <span class="description">اگر شبکه‌های اجتماعی فعال باشند، در صفحه نمایش داده می‌شوند</span>
                    </td>
                </tr>
                
                <!-- ===== شمارش معکوس ===== -->
                <tr>
                    <th>شمارش معکوس</th>
                    <td>
                        <label class="loginpro-checkbox-label">
                            <input type="checkbox" name="maintenance_show_countdown" value="1" <?php checked($maintenance_show_countdown, true); ?>>
                            <span>نمایش شمارش معکوس تا تاریخ مشخص</span>
                        </label>
                        <span class="description">یک تایمر شمارش معکوس در صفحه نمایش داده می‌شود</span>
                    </td>
                </tr>
                
                <!-- ===== تاریخ شمارش معکوس ===== -->
                <tr>
                    <th>تاریخ پایان</th>
                    <td>
                        <input type="datetime-local" name="maintenance_countdown_date" value="<?php echo esc_attr($maintenance_countdown_date); ?>">
                        <span class="description">تاریخ و زمانی که شمارش معکوس به آن ختم می‌شود</span>
                    </td>
                </tr>
                
                <!-- ===== IP های مجاز ===== -->
                <tr>
                    <th>IP های مجاز</th>
                    <td>
                        <input type="text" name="maintenance_allow_ips" value="<?php echo esc_attr($maintenance_allow_ips); ?>" placeholder="192.168.1.1, 10.0.0.1">
                        <span class="description">آدرس‌های IP که بدون لاگین می‌توانند سایت را ببینند (با کاما جدا کنید)</span>
                    </td>
                </tr>
                
                <!-- ===== نقش‌های مجاز ===== -->
                <tr>
                    <th>نقش‌های مجاز</th>
                    <td>
                        <?php foreach ($role_names as $key => $name): ?>
                        <label class="loginpro-checkbox-label" style="margin-bottom:5px;">
                            <input type="checkbox" name="maintenance_allow_roles[]" value="<?php echo esc_attr($key); ?>" <?php echo in_array($key, (array)$maintenance_allow_roles) ? 'checked' : ''; ?>>
                            <span><?php echo esc_html($name); ?></span>
                        </label>
                        <?php endforeach; ?>
                        <span class="description">نقش‌هایی که بدون نیاز به ورود مجدد می‌توانند سایت را ببینند</span>
                    </td>
                </tr>
                
                <!-- ===== آدرس بازگشت ===== -->
                <tr>
                    <th>آدرس بازگشت پس از ورود</th>
                    <td>
                        <input type="url" name="maintenance_redirect_url" value="<?php echo esc_attr($maintenance_redirect_url); ?>" placeholder="https://example.com/dashboard">
                        <span class="description">کاربران پس از لاگین به این آدرس هدایت می‌شوند</span>
                    </td>
                </tr>
                
                <!-- ===== CSS سفارشی ===== -->
                <tr>
                    <th>CSS سفارشی</th>
                    <td>
                        <textarea name="maintenance_custom_css" rows="4" placeholder="/* CSS سفارشی خود را اینجا بنویسید */"><?php echo esc_textarea($maintenance_custom_css); ?></textarea>
                        <span class="description">استایل‌های سفارشی برای صفحه</span>
                    </td>
                </tr>
                
                <!-- ===== HTML سفارشی ===== -->
                <tr>
                    <th>HTML سفارشی</th>
                    <td>
                        <textarea name="maintenance_custom_html" rows="4" placeholder="<!-- HTML سفارشی خود را اینجا بنویسید -->"><?php echo esc_textarea($maintenance_custom_html); ?></textarea>
                        <span class="description">محتوای سفارشی برای صفحه (در پایین نمایش داده می‌شود)</span>
                    </td>
                </tr>
            </table>
            
            <div style="margin-top:20px;display:flex;gap:10px;flex-wrap:wrap;">
                <button type="submit" class="loginpro-submit-btn">
                    💾 ذخیره تنظیمات
                </button>
                <button type="submit" name="preview_maintenance" value="1" class="loginpro-submit-btn" style="background:#6c757d;">
                    👁️ پیش‌نمایش
                </button>
            </div>
        </form>
    </div>
    
    <!-- ========================================== -->
    <!-- کارت پیش‌نمایش -->
    <!-- ========================================== -->
    <?php if (isset($_POST['preview_maintenance']) || $maintenance_enabled): ?>
    <div class="loginpro-card">
        <h3>👁️ پیش‌نمایش صفحه</h3>
        <div class="maintenance-preview">
            <?php
            $preview_mode = isset($_POST['preview_maintenance']) ? $maintenance_mode : 'maintenance';
            $preview_title = $maintenance_title;
            $preview_message = $maintenance_message;
            ?>
            
            <?php if (!empty($maintenance_custom_html)): ?>
                <?php echo wp_kses_post($maintenance_custom_html); ?>
            <?php endif; ?>
            
            <div class="preview-icon" style="font-size:64px;margin-bottom:15px;">
                <?php if ($preview_mode === 'coming_soon'): ?>
                    🚀
                <?php elseif ($preview_mode === 'login_required'): ?>
                    🔐
                <?php else: ?>
                    🔧
                <?php endif; ?>
            </div>
            
            <div class="preview-title">
                <?php echo esc_html($preview_title); ?>
            </div>
            
            <div class="preview-message">
                <?php echo wp_kses_post($preview_message); ?>
            </div>
            
            <?php if ($maintenance_show_countdown && !empty($maintenance_countdown_date)): ?>
                <div style="margin:20px 0;font-size:24px;font-weight:bold;color:#2271b1;font-family:monospace;">
                    ⏱️ <span id="preview-countdown">--:--:--</span>
                </div>
            <?php endif; ?>
            
            <?php if ($maintenance_show_login): ?>
                <a href="<?php echo wp_login_url($maintenance_redirect_url); ?>" class="preview-login-btn">
                    🔐 <?php _e('ورود به سایت', 'loginpro'); ?>
                </a>
            <?php endif; ?>
            
            <?php if ($maintenance_show_social): ?>
                <div style="margin-top:20px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
                    <?php if (get_option('loginpro_google_enabled', false)): ?>
                        <span style="padding:8px 20px;border:1px solid #db4437;border-radius:6px;color:#db4437;">G گوگل</span>
                    <?php endif; ?>
                    <?php if (get_option('loginpro_facebook_enabled', false)): ?>
                        <span style="padding:8px 20px;border:1px solid #1877f2;border-radius:6px;color:#1877f2;">f فیسبوک</span>
                    <?php endif; ?>
                    <?php if (get_option('loginpro_github_enabled', false)): ?>
                        <span style="padding:8px 20px;border:1px solid #333;border-radius:6px;color:#333;">GH گیت‌هاب</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($maintenance_custom_css)): ?>
                <style><?php echo wp_strip_all_tags($maintenance_custom_css); ?></style>
            <?php endif; ?>
            
            <?php if ($maintenance_show_countdown && !empty($maintenance_countdown_date)): ?>
            <script>
            (function() {
                var targetDate = new Date('<?php echo esc_js($maintenance_countdown_date); ?>').getTime();
                var el = document.getElementById('preview-countdown');
                if (!el) return;
                
                function updateCountdown() {
                    var now = new Date().getTime();
                    var diff = targetDate - now;
                    
                    if (diff <= 0) {
                        el.textContent = '00:00:00';
                        return;
                    }
                    
                    var days = Math.floor(diff / (1000 * 60 * 60 * 24));
                    var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    var seconds = Math.floor((diff % (1000 * 60)) / 1000);
                    
                    var parts = [];
                    if (days > 0) parts.push(String(days).padStart(2, '0') + 'd');
                    parts.push(String(hours).padStart(2, '0'));
                    parts.push(String(minutes).padStart(2, '0'));
                    parts.push(String(seconds).padStart(2, '0'));
                    
                    el.textContent = parts.join(':');
                }
                
                updateCountdown();
                setInterval(updateCountdown, 1000);
            })();
            </script>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- ========================================== -->
    <!-- کارت راهنما -->
    <!-- ========================================== -->
    <div class="loginpro-card" style="background:#f8f9fa;border:1px dashed #ccc;">
        <h3 style="border-bottom-color:#ddd;">ℹ️ راهنمای حالت تعمیرات</h3>
        <ul style="margin:0;padding:0 20px;line-height:2.2;font-size:13px;">
            <li>✅ با فعال‌سازی این حالت، <strong>سایت فقط برای کاربران لاگین شده</strong> قابل مشاهده است</li>
            <li>✅ کاربران غیرلاگین یک صفحه اختصاصی با پیام تعمیرات می‌بینند</li>
            <li>✅ می‌توانید <strong>IP های مجاز</strong> را مشخص کنید تا بدون لاگین هم سایت را ببینند</li>
            <li>✅ می‌توانید <strong>نقش‌های کاربری</strong> را مشخص کنید که نیازی به ورود مجدد ندارند</li>
            <li>✅ گزینه <strong>"به زودی"</strong> برای سایت‌های در حال توسعه مناسب است</li>
            <li>✅ با <strong>شمارش معکوس</strong> می‌توانید به کاربران نشان دهید سایت کی راه‌اندازی می‌شود</li>
            <li>⚠️ <strong>توجه:</strong> خود شما به عنوان ادمین سایت را می‌بینید (چون لاگین هستید)</li>
        </ul>
    </div>
</div>