<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب 🛡️ تنظیمات امنیتی
// ==================================================

$bf_max_attempts = get_option('loginpro_bf_max_attempts', 10);
$bf_lockout_minutes = get_option('loginpro_bf_lockout_minutes', 15);
$session_timeout = get_option('loginpro_session_timeout', 3600);
$max_sessions = get_option('loginpro_max_sessions', 5);

if (isset($_POST['save_security']) && isset($_POST['security_settings']) && wp_verify_nonce($_POST['security_settings'], 'security_settings')) {
    
    update_option('loginpro_bf_max_attempts', (int) $_POST['bf_max_attempts']);
    update_option('loginpro_bf_lockout_minutes', (int) $_POST['bf_lockout_minutes']);
    update_option('loginpro_session_timeout', (int) $_POST['session_timeout']);
    update_option('loginpro_max_sessions', (int) $_POST['max_sessions']);
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات امنیتی با موفقیت ذخیره شد.</p></div>';
    
    $bf_max_attempts = get_option('loginpro_bf_max_attempts', 10);
    $bf_lockout_minutes = get_option('loginpro_bf_lockout_minutes', 15);
    $session_timeout = get_option('loginpro_session_timeout', 3600);
    $max_sessions = get_option('loginpro_max_sessions', 5);
}
?>
<style>
.tab-security-settings {
    margin: 20px 20px 0 0;
}

.security-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.security-card h2 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.security-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 10px;
}

.security-form-table th {
    width: 220px;
    text-align: right;
    padding: 15px 15px 15px 0;
    font-weight: 600;
    vertical-align: top;
    font-size: 14px;
    color: #1d2327;
}

.security-form-table td {
    padding: 15px 0;
    vertical-align: middle;
}

.security-form-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.security-form-table tr:last-child {
    border-bottom: none;
}

.security-form-table input[type="number"] {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 120px;
    font-size: 14px;
    height: 42px;
    box-sizing: border-box;
    background: #fff;
}

.security-form-table input[type="number"]:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.security-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.security-submit-btn:hover {
    background: #135e96;
    box-shadow: 0 4px 12px rgba(34, 113, 177, 0.3);
    transform: translateY(-1px);
}

.security-help-text {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

@media (max-width: 1024px) {
    .security-form-table th {
        width: 180px;
        font-size: 13px;
    }
}

@media (max-width: 782px) {
    .tab-security-settings {
        margin: 10px 10px 0 0;
    }
    
    .security-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .security-card h2 {
        font-size: 16px;
    }
    
    .security-form-table {
        display: block;
        width: 100%;
    }
    
    .security-form-table tbody {
        display: block;
        width: 100%;
    }
    
    .security-form-table tr {
        display: block;
        width: 100%;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #eee;
    }
    
    .security-form-table tr:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    
    .security-form-table th {
        display: block;
        width: 100%;
        padding: 0 0 6px 0;
        font-weight: 600;
        font-size: 13px;
        color: #1d2327;
        border-bottom: none;
    }
    
    .security-form-table td {
        display: block;
        width: 100%;
        padding: 0;
    }
    
    .security-form-table input[type="number"] {
        max-width: 100% !important;
        width: 100% !important;
        height: 44px;
        font-size: 15px;
        padding: 10px 12px;
    }
    
    .security-submit-btn {
        width: 100%;
        justify-content: center;
        padding: 12px 20px;
        font-size: 15px;
    }
    
    .security-help-text {
        font-size: 11px;
        margin-top: 4px;
    }
}

@media (max-width: 480px) {
    .security-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .security-card h2 {
        font-size: 15px;
    }
    
    .security-form-table tr {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    
    .security-form-table th {
        font-size: 12px;
    }
    
    .security-form-table input[type="number"] {
        height: 40px;
        font-size: 14px;
        padding: 8px 10px;
        border-radius: 4px;
    }
    
    .security-submit-btn {
        font-size: 14px;
        padding: 10px 16px;
    }
    
    .security-help-text {
        font-size: 10px;
    }
}
</style>

<div class="tab-security-settings">
    
    <form method="post">
        <?php wp_nonce_field('security_settings', 'security_settings'); ?>
        <input type="hidden" name="save_security" value="1">
        
        <div class="security-card">
            <h2>🛡️ محافظت در برابر حملات Brute Force</h2>
            <table class="security-form-table">
                <tr>
                    <th scope="row">حداکثر تلاش ناموفق</th>
                    <td>
                        <input type="number" name="bf_max_attempts" value="<?php echo esc_attr($bf_max_attempts); ?>" min="1" max="50">
                        <span style="margin-right:5px;">تلاش</span>
                        <span class="security-help-text">تعداد دفعات مجاز برای وارد کردن رمز اشتباه قبل از قفل شدن</span>
                    </td>
                </tr>
                <tr>
                    <th scope="row">مدت زمان قفل شدن</th>
                    <td>
                        <input type="number" name="bf_lockout_minutes" value="<?php echo esc_attr($bf_lockout_minutes); ?>" min="1" max="1440">
                        <span style="margin-right:5px;">دقیقه</span>
                        <span class="security-help-text">مدت زمانی که کاربر پس از رسیدن به حداکثر تلاش قفل می‌شود</span>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="security-card">
            <h2>🔐 امنیت جلسه (Session)</h2>
            <table class="security-form-table">
                <tr>
                    <th scope="row">زمان خاتمه جلسه</th>
                    <td>
                        <input type="number" name="session_timeout" value="<?php echo esc_attr($session_timeout); ?>" min="60" max="86400" step="60">
                        <span style="margin-right:5px;">ثانیه</span>
                        <span class="security-help-text">مدت زمان بی‌حرکتی کاربر تا خروج خودکار (پیش‌فرض: 3600 ثانیه = 1 ساعت)</span>
                    </td>
                </tr>
                <tr>
                    <th scope="row">حداکثر جلسات همزمان</th>
                    <td>
                        <input type="number" name="max_sessions" value="<?php echo esc_attr($max_sessions); ?>" min="1" max="20">
                        <span style="margin-right:5px;">جلسه</span>
                        <span class="security-help-text">حداکثر تعداد دستگاه‌هایی که یک کاربر می‌تواند همزمان وارد شود</span>
                    </td>
                </tr>
            </table>
        </div>
        
        <div style="margin-top: 20px;">
            <button type="submit" class="security-submit-btn">💾 ذخیره تنظیمات امنیتی</button>
        </div>
    </form>
</div>