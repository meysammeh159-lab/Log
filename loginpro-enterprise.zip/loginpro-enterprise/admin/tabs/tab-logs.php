<?php
defined('ABSPATH') || exit;

global $wpdb;

$logs_table = $wpdb->prefix . 'loginpro_logs';
$logs_per_page = 20;
$current_page = isset($_GET['log_page']) ? max(1, intval($_GET['log_page'])) : 1;
$offset = ($current_page - 1) * $logs_per_page;
$filter_type = isset($_GET['log_type']) ? sanitize_text_field($_GET['log_type']) : '';

// حذف لاگ‌ها
if (isset($_POST['clear_logs']) && isset($_POST['clear_logs_nonce']) && wp_verify_nonce($_POST['clear_logs_nonce'], 'clear_logs')) {
    $wpdb->query("TRUNCATE TABLE $logs_table");
    echo '<div class="notice-success"><p>✅ تمام لاگ‌ها با موفقیت پاک شدند.</p></div>';
}

// ساخت شرط فیلتر
$where = '';
$where_sql = '';
if (!empty($filter_type) && $filter_type !== 'all') {
    $where = $wpdb->prepare(" WHERE type = %s", $filter_type);
    $where_sql = $wpdb->prepare(" AND type = %s", $filter_type);
}

// دریافت کل لاگ‌ها
$total_logs = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table $where");
$total_pages = ceil($total_logs / $logs_per_page);

// دریافت لاگ‌های صفحه جاری
$logs = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM $logs_table $where ORDER BY created_at DESC LIMIT %d OFFSET %d",
    $logs_per_page,
    $offset
));

// انواع لاگ برای فیلتر
$log_types = $wpdb->get_col("SELECT DISTINCT type FROM $logs_table");
?>
<style>
/* ===== استایل‌های اصلی ===== */
.tab-logs-settings {
    margin: 20px 20px 0 0;
}

.logs-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.logs-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

/* ===== هدر با فیلتر و دکمه حذف ===== */
.logs-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
}

.logs-filter {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.logs-filter select {
    padding: 6px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    height: 36px;
    font-size: 13px;
    background: #fff;
    min-width: 140px;
}

.logs-filter select:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.logs-filter .button {
    height: 36px;
    line-height: 34px;
    padding: 0 16px;
}

.logs-clear-btn {
    background: #dc3545 !important;
    color: #fff !important;
    border-color: #dc3545 !important;
    height: 36px;
    line-height: 34px;
    padding: 0 16px;
}

.logs-clear-btn:hover {
    background: #b02a37 !important;
    border-color: #b02a37 !important;
}

/* ===== پیام‌ها ===== */
.notice-success {
    background: #d4edda;
    color: #155724;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #28a745;
}

.notice-info {
    background: #d1ecf1;
    color: #0c5460;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #17a2b8;
}

/* ===== جدول ===== */
.wp-list-table {
    width: 100%;
    border-collapse: collapse;
}

.wp-list-table th {
    text-align: right;
    padding: 10px 12px !important;
    font-weight: 600;
    background: #f8f9fa;
    border-bottom: 2px solid #e2e8f0;
}

.wp-list-table td {
    padding: 8px 12px !important;
    vertical-align: middle;
    border-bottom: 1px solid #f0f0f0;
}

.wp-list-table tr:hover {
    background: #f9f9f9;
}

/* ===== بج نوع لاگ ===== */
.log-type-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 500;
    white-space: nowrap;
}

.log-type-login { background: #e3f2fd; color: #1565c0; }
.log-type-logout { background: #fff3e0; color: #e65100; }
.log-type-failed { background: #ffebee; color: #c62828; }
.log-type-error { background: #ffebee; color: #c62828; }
.log-type-security { background: #f3e5f5; color: #6a1b9a; }
.log-type-success { background: #e8f5e9; color: #2e7d32; }
.log-type-warning { background: #fff8e1; color: #f57f17; }
.log-type-info { background: #e0f7fa; color: #00838f; }

/* ===== صفحه‌بندی ===== */
.logs-pagination {
    margin-top: 20px;
    text-align: center;
}

.logs-pagination a {
    display: inline-block;
    padding: 5px 12px;
    margin: 0 3px;
    border-radius: 4px;
    text-decoration: none;
    background: #f1f1f1;
    color: #333;
    font-size: 13px;
    transition: all 0.2s;
}

.logs-pagination a:hover {
    background: #ddd;
}

.logs-pagination a.current {
    background: #2271b1;
    color: #fff;
}

.logs-pagination a.current:hover {
    background: #135e96;
}

/* ============================================== */
/* ===== رسپانسیو ===== */
/* ============================================== */

@media (max-width: 1024px) {
    .logs-card {
        padding: 20px;
    }
}

@media (max-width: 782px) {
    .tab-logs-settings {
        margin: 10px 10px 0 0;
    }
    
    .logs-card {
        padding: 16px 18px;
        border-radius: 8px;
    }
    
    .logs-card h3 {
        font-size: 16px;
    }
    
    /* ===== هدر فیلتر ===== */
    .logs-header {
        flex-direction: column;
        align-items: stretch;
        gap: 8px;
    }
    
    .logs-filter {
        flex-direction: column;
        align-items: stretch;
        width: 100%;
    }
    
    .logs-filter select {
        width: 100%;
        min-width: unset;
        height: 40px;
        font-size: 14px;
    }
    
    .logs-filter .button {
        width: 100%;
        text-align: center;
        height: 40px;
        line-height: 38px;
    }
    
    .logs-clear-btn {
        width: 100%;
        text-align: center;
        height: 40px;
        line-height: 38px;
    }
    
    /* ===== جدول به کارت ===== */
    .wp-list-table thead {
        display: none;
    }
    
    .wp-list-table tbody tr {
        display: block;
        margin-bottom: 12px;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px 12px;
        background: #fff;
    }
    
    .wp-list-table tbody tr td {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 5px 0 !important;
        border-bottom: 1px solid #f0f0f0;
        font-size: 13px;
    }
    
    .wp-list-table tbody tr td:last-child {
        border-bottom: none;
    }
    
    .wp-list-table tbody tr td:before {
        content: attr(data-label);
        font-weight: 600;
        font-size: 12px;
        color: #555;
        flex-shrink: 0;
        margin-left: 10px;
    }
    
    .wp-list-table tbody tr td:first-child {
        font-weight: 600;
        background: #f8f9fa;
        margin: -10px -12px 0 -12px;
        padding: 8px 12px !important;
        border-radius: 8px 8px 0 0;
        border-bottom: 1px solid #eee;
    }
    
    .wp-list-table tbody tr td:first-child:before {
        font-weight: 700;
    }
    
    .wp-list-table tbody tr td:last-child {
        padding-bottom: 0 !important;
    }
    
    /* ===== بج در موبایل ===== */
    .log-type-badge {
        font-size: 10px;
        padding: 2px 8px;
    }
    
    /* ===== صفحه‌بندی ===== */
    .logs-pagination a {
        padding: 4px 10px;
        font-size: 12px;
    }
}

@media (max-width: 480px) {
    .logs-card {
        padding: 12px 14px;
        border-radius: 6px;
    }
    
    .logs-card h3 {
        font-size: 15px;
    }
    
    .wp-list-table tbody tr {
        padding: 8px 10px;
    }
    
    .wp-list-table tbody tr td {
        font-size: 12px;
        padding: 4px 0 !important;
    }
    
    .wp-list-table tbody tr td:before {
        font-size: 11px;
        min-width: 50px;
    }
    
    .wp-list-table tbody tr td:first-child {
        margin: -8px -10px 0 -10px;
        padding: 6px 10px !important;
        font-size: 12px;
    }
    
    .log-type-badge {
        font-size: 9px;
        padding: 2px 6px;
    }
    
    .logs-filter select {
        font-size: 13px;
        height: 38px;
    }
    
    .logs-filter .button,
    .logs-clear-btn {
        font-size: 13px;
        height: 38px;
        line-height: 36px;
    }
    
    .logs-pagination a {
        padding: 3px 8px;
        font-size: 11px;
        margin: 0 2px;
    }
    
    .notice-success,
    .notice-info {
        font-size: 13px;
        padding: 10px 14px;
    }
}
</style>

<div class="tab-logs-settings">
    <div class="logs-card">
        <h3>📜 لاگ‌های امنیتی</h3>
        
        <div class="logs-header">
            <div class="logs-filter">
                <form method="get" style="display: flex; gap: 8px; flex-wrap: wrap; width: 100%;">
                    <input type="hidden" name="page" value="loginpro-dashboard">
                    <input type="hidden" name="tab" value="logs">
                    
                    <select name="log_type">
                        <option value="all" <?php selected($filter_type, 'all'); ?>>همه</option>
                        <?php foreach ($log_types as $type): ?>
                            <option value="<?php echo esc_attr($type); ?>" <?php selected($filter_type, $type); ?>>
                                <?php echo esc_html($type); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="button">🔍 فیلتر</button>
                </form>
            </div>
            
            <div>
                <form method="post" onsubmit="return confirm('آیا از پاک کردن تمام لاگ‌ها مطمئن هستید؟');">
                    <?php wp_nonce_field('clear_logs', 'clear_logs_nonce'); ?>
                    <input type="hidden" name="clear_logs" value="1">
                    <button type="submit" class="button logs-clear-btn">🗑️ پاک کردن تمام لاگ‌ها</button>
                </form>
            </div>
        </div>
        
        <?php if (empty($logs)): ?>
            <div class="notice-info"><p>📭 هیچ لاگی یافت نشد.</p></div>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>زمان</th>
                            <th>نوع</th>
                            <th>پیام</th>
                            <th>IP</th>
                            <th>کاربر</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td data-label="زمان"><?php echo esc_html($log->created_at); ?></td>
                            <td data-label="نوع">
                                <span class="log-type-badge log-type-<?php echo esc_attr($log->type); ?>">
                                    <?php echo esc_html($log->type); ?>
                                </span>
                            </td>
                            <td data-label="پیام"><?php echo esc_html($log->message); ?></td>
                            <td data-label="IP"><?php echo esc_html($log->ip_address); ?></td>
                            <td data-label="کاربر">
                                <?php 
                                if ($log->user_id) {
                                    $user = get_userdata($log->user_id);
                                    echo $user ? esc_html($user->user_login) : esc_html($log->user_id);
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($total_pages > 1): ?>
            <div class="logs-pagination">
                <?php
                for ($i = 1; $i <= $total_pages; $i++) {
                    $url = add_query_arg(array('log_page' => $i, 'tab' => 'logs', 'log_type' => $filter_type));
                    $active = $i == $current_page ? 'current' : '';
                    echo '<a href="' . esc_url($url) . '" class="' . $active . '">' . $i . '</a>';
                }
                ?>
            </div>
            <?php endif; ?>
            
            <p style="margin-top: 15px; color: #666; font-size: 12px; text-align: left;">
                📊 تعداد کل لاگ‌ها: <strong><?php echo number_format($total_logs); ?></strong>
            </p>
        <?php endif; ?>
    </div>
</div>