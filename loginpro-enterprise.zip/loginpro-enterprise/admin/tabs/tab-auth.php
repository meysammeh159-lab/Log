<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب 🔐 تنظیمات احراز هویت
// ==================================================

// دریافت مقادیر از دیتابیس
$method_email_password = get_option('loginpro_method_email_password', true);
$method_mobile_password = get_option('loginpro_method_mobile_password', true);
$method_email_otp = get_option('loginpro_method_email_otp', true);
$method_sms_otp = get_option('loginpro_method_sms_otp', true);
$method_magic_link = get_option('loginpro_method_magic_link', false);

// 🆕 WebAuthn
$method_webauthn = get_option('loginpro_method_webauthn', true);
$webauthn_force_login = get_option('loginpro_webauthn_force_login', false);
$webauthn_allow_register = get_option('loginpro_webauthn_allow_register', true);

// 🆕 Firebase
$method_firebase = get_option('loginpro_method_firebase', false);

// 🆕 WhatsApp
$method_whatsapp = get_option('loginpro_method_whatsapp', false);

$allow_registration = get_option('users_can_register', true);
$auto_login_register = get_option('loginpro_auto_login_register', true);

// ==================================================
// پردازش ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_auth']) && isset($_POST['auth_settings']) && wp_verify_nonce($_POST['auth_settings'], 'auth_settings')) {
    
    update_option('loginpro_method_email_password', isset($_POST['method_email_password']));
    update_option('loginpro_method_mobile_password', isset($_POST['method_mobile_password']));
    update_option('loginpro_method_email_otp', isset($_POST['method_email_otp']));
    update_option('loginpro_method_sms_otp', isset($_POST['method_sms_otp']));
    update_option('loginpro_method_magic_link', isset($_POST['method_magic_link']));
    
    // 🆕 WebAuthn
    update_option('loginpro_method_webauthn', isset($_POST['method_webauthn']));
    update_option('loginpro_webauthn_force_login', isset($_POST['webauthn_force_login']));
    update_option('loginpro_webauthn_allow_register', isset($_POST['webauthn_allow_register']));
    
    // 🆕 Firebase
    update_option('loginpro_method_firebase', isset($_POST['method_firebase']));
    
    // 🆕 WhatsApp
    update_option('loginpro_method_whatsapp', isset($_POST['method_whatsapp']));
    
    update_option('users_can_register', isset($_POST['allow_registration']));
    update_option('loginpro_auto_login_register', isset($_POST['auto_login_register']));
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات احراز هویت با موفقیت ذخیره شد.</p></div>';
    
    // به‌روزرسانی متغیرها
    $method_email_password = get_option('loginpro_method_email_password', true);
    $method_mobile_password = get_option('loginpro_method_mobile_password', true);
    $method_email_otp = get_option('loginpro_method_email_otp', true);
    $method_sms_otp = get_option('loginpro_method_sms_otp', true);
    $method_magic_link = get_option('loginpro_method_magic_link', false);
    $method_webauthn = get_option('loginpro_method_webauthn', true);
    $method_firebase = get_option('loginpro_method_firebase', false);
    $method_whatsapp = get_option('loginpro_method_whatsapp', false);
    $allow_registration = get_option('users_can_register', true);
    $auto_login_register = get_option('loginpro_auto_login_register', true);
}

// ==================================================
// HTML فرم
// ==================================================
?>
<style>
.tab-authentication-settings {
    margin: 20px 20px 0 0;
}

/* کارت اصلی */
.auth-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.auth-card h2 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
}

.auth-card .badge-new {
    background: #28a745;
    color: #fff;
    font-size: 10px;
    padding: 2px 8px;
    border-radius: 12px;
    margin-right: 5px;
    display: inline-block;
}

/* جدول فرم */
.auth-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.auth-form-table th {
    width: 220px;
    text-align: right;
    padding: 15px;
    font-weight: 600;
    vertical-align: top;
    background: #fafafa;
}

.auth-form-table td {
    padding: 15px;
    vertical-align: top;
}

/* چک‌باکس */
.auth-checkbox-label {
    display: inline-block;
}

.auth-checkbox-label input {
    margin-left: 5px;
}

/* دکمه */
.auth-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
}

.auth-submit-btn:hover {
    background: #135e96;
}

/* توضیحات */
.auth-help-text {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

.auth-description {
    color: #666;
    font-size: 13px;
    margin-bottom: 20px;
}

.auth-divider {
    border: none;
    border-top: 2px dashed #e0e0e0;
    margin: 20px 0;
}

/* Responsive */
@media (max-width: 768px) {
    .auth-form-table th,
    .auth-form-table td {
        display: block;
        width: 100%;
        padding: 10px;
    }
    
    .auth-form-table th {
        background: transparent;
        padding-bottom: 5px;
    }
    
    .auth-card {
        padding: 15px;
    }
}
</style>

<div class="tab-authentication-settings">
    
    <form method="post">
        <?php wp_nonce_field('auth_settings', 'auth_settings'); ?>
        <input type="hidden" name="save_auth" value="1">
        
        <!-- کارت 1: روش‌های ورود -->
        <div class="auth-card">
            <h2>🔐 روش‌های ورود</h2>
            <table class="auth-form-table">
                <tr>
                    <th scope="row">ورود با ایمیل و رمز عبور</th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_email_password" value="1" <?php echo ($method_email_password) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">ورود با استفاده از ایمیل و رمز عبور</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">ورود با موبایل و رمز عبور</th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_mobile_password" value="1" <?php echo ($method_mobile_password) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">ورود با استفاده از شماره موبایل و رمز عبور</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">ورود با کد یکبارمصرف (ایمیل)</th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_email_otp" value="1" <?php echo ($method_email_otp) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">ارسال کد تأیید به ایمیل کاربر</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">ورود با کد یکبارمصرف (پیامک)</th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_sms_otp" value="1" <?php echo ($method_sms_otp) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">ارسال کد تأیید به شماره موبایل کاربر</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">لینک جادویی (Magic Link)</th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_magic_link" value="1" <?php echo ($method_magic_link) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">ارسال لینک یکبارمصرف به ایمیل کاربر برای ورود بدون رمز عبور</p>
                    </td>
                </tr>
                
                <!-- 🆕 WebAuthn -->
                <tr style="background: #f0f8ff;">
                    <th scope="row">
                        🔐 احراز هویت بیومتریک (WebAuthn)
                        <span class="badge-new">جدید</span>
                    </th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_webauthn" value="1" <?php echo ($method_webauthn) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">ورود با اثر انگشت، Face ID یا Windows Hello</p>
                        
                        <div style="margin-top: 10px; padding: 12px; background: #f8f9fa; border-radius: 8px;">
                            <label style="display: block; margin-bottom: 5px;">
                                <input type="checkbox" name="webauthn_force_login" value="1" <?php echo ($webauthn_force_login) ? 'checked' : ''; ?>>
                                <strong>اجبار به ورود بیومتریک</strong>
                            </label>
                            <span class="auth-help-text">کاربران فقط با WebAuthn می‌توانند وارد شوند (رمز عبور غیرفعال می‌شود)</span>
                            
                            <label style="display: block; margin-top: 8px;">
                                <input type="checkbox" name="webauthn_allow_register" value="1" <?php echo ($webauthn_allow_register) ? 'checked' : ''; ?>>
                                <strong>اجازه ثبت دستگاه</strong>
                            </label>
                            <span class="auth-help-text">کاربران می‌توانند دستگاه‌های خود را برای ورود بیومتریک ثبت کنند</span>
                        </div>
                    </td>
                </tr>
                
                <!-- 🆕 Firebase -->
                <tr>
                    <th scope="row">
                        🔥 Firebase Phone Auth
                        <span class="badge-new">جدید</span>
                    </th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_firebase" value="1" <?php echo ($method_firebase) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">احراز هویت با شماره موبایل از طریق Firebase (بدون نیاز به درگاه پیامکی)</p>
                    </td>
                </tr>
                
                <!-- 🆕 WhatsApp -->
                <tr>
                    <th scope="row">
                        💬 WhatsApp
                        <span class="badge-new">جدید</span>
                    </th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="method_whatsapp" value="1" <?php echo ($method_whatsapp) ? 'checked' : ''; ?>>
                            فعال
                        </label>
                        <p class="auth-help-text">ارسال کد تأیید از طریق WhatsApp Business API</p>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 2: تنظیمات ثبت‌نام -->
        <div class="auth-card">
            <h2>📝 تنظیمات ثبت‌نام</h2>
            <table class="auth-form-table">
                <tr>
                    <th scope="row">اجازه ثبت‌نام</th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="allow_registration" value="1" <?php echo ($allow_registration) ? 'checked' : ''; ?>>
                            فعال کردن ثبت‌نام کاربر جدید
                        </label>
                        <p class="auth-help-text">به کاربران اجازه ثبت‌نام در سایت داده می‌شود</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">ورود خودکار بعد از ثبت‌نام</th>
                    <td>
                        <label class="auth-checkbox-label">
                            <input type="checkbox" name="auto_login_register" value="1" <?php echo ($auto_login_register) ? 'checked' : ''; ?>>
                            ورود خودکار کاربر بعد از ثبت‌نام
                        </label>
                        <p class="auth-help-text">کاربر بلافاصله بعد از ثبت‌نام وارد سایت می‌شود</p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div style="margin-top: 20px;">
            <button type="submit" class="auth-submit-btn">💾 ذخیره تنظیمات احراز هویت</button>
        </div>
    </form>
</div>