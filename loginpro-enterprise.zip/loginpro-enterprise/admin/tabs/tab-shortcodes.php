<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب 📝 شورت‌کدها
// ==================================================

$shortcodes = [
    'loginpro_login' => [
        'title' => 'فرم لاگین هوشمند',
        'description' => 'فرم ورود با قابلیت تشخیص ایمیل/نام کاربری/موبایل و ارسال کد تأیید (OTP)',
        'params' => 'redirect, class, label, force',
        'category' => 'فرم‌ها'
    ],
    'loginpro_smart_login' => [
        'title' => 'فرم لاگین هوشمند (نام مستعار)',
        'description' => 'همان فرم لاگین اصلی با قابلیت‌های پیشرفته',
        'params' => 'redirect, class, label, force',
        'category' => 'فرم‌ها'
    ],
    'loginpro_reset_password' => [
        'title' => 'بازیابی رمز عبور',
        'description' => 'فرم بازیابی رمز عبور از طریق ایمیل',
        'params' => 'class',
        'category' => 'فرم‌ها'
    ],
    'loginpro_logout' => [
        'title' => 'دکمه خروج',
        'description' => 'دکمه خروج از حساب کاربری (فقط برای کاربران وارد شده)',
        'params' => 'redirect, button_text, class',
        'category' => 'دکمه‌ها'
    ],
    'loginpro_modal_button' => [
        'title' => 'دکمه باز کردن مودال',
        'description' => 'دکمه باز کردن فرم لاگین در پنجره بازشو (مودال)',
        'params' => 'text, logged_in_text, icon, logged_in_icon, class',
        'category' => 'دکمه‌ها'
    ],
    'loginpro_profile' => [
        'title' => 'پروفایل کاربری',
        'description' => 'نمایش پروفایل کاربر (نام، ایمیل، موبایل و تاریخ عضویت)',
        'params' => 'class',
        'category' => 'پروفایل'
    ],
    'loginpro_user' => [
        'title' => 'داشبورد کامل کاربری',
        'description' => 'داشبورد کامل با تب‌های مختلف (اطلاعات شخصی، امنیت، فعالیت‌ها)',
        'params' => 'tabs, layout, class',
        'category' => 'پروفایل'
    ],
    'loginpro_security' => [
        'title' => 'تنظیمات امنیتی',
        'description' => 'تغییر رمز عبور و تنظیمات امنیتی حساب کاربری',
        'params' => 'show_password, class',
        'category' => 'امنیت'
    ],
    'loginpro_sessions' => [
        'title' => 'نشست‌های فعال',
        'description' => 'مدیریت نشست‌های فعال کاربر (خروج از راه دور)',
        'params' => 'class',
        'category' => 'مدیریت'
    ],
    'loginpro_history' => [
        'title' => 'تاریخچه ورود',
        'description' => 'نمایش تاریخچه ورودهای کاربر به سایت',
        'params' => 'limit, class',
        'category' => 'مدیریت'
    ],
];

$categories = [];
foreach ($shortcodes as $code => $info) {
    $cat = $info['category'];
    if (!isset($categories[$cat])) {
        $categories[$cat] = [];
    }
    $categories[$cat][$code] = $info;
}

// ==================================================
// حذف بخش ذخیره تنظیمات - دیگر نیازی نیست
// ==================================================
?>
<style>
.tab-shortcodes-settings {
    margin: 20px 20px 0 0;
}

.shortcodes-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.shortcodes-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
}

/* ===== آمار ===== */
.stats-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    margin-bottom: 25px;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
}

.stat-box {
    padding: 18px 20px;
    border-radius: 12px;
    color: white;
    text-align: center;
    transition: transform 0.2s;
}

.stat-box:hover {
    transform: translateY(-3px);
}

.stat-box .stat-number {
    font-size: 28px;
    font-weight: bold;
}

.stat-box .stat-label {
    font-size: 13px;
    margin-top: 5px;
    opacity: 0.9;
}

.stat-box:nth-child(1) { background: linear-gradient(135deg, #667eea, #764ba2); }
.stat-box:nth-child(2) { background: linear-gradient(135deg, #f093fb, #f5576c); }
.stat-box:nth-child(3) { background: linear-gradient(135deg, #4facfe, #00f2fe); }
.stat-box:nth-child(4) { background: linear-gradient(135deg, #43e97b, #38f9d7); }

/* ===== جدول ===== */
.shortcodes-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.shortcodes-table th {
    text-align: right;
    padding: 12px;
    font-weight: 600;
    background: #f8f9fa;
    border-bottom: 1px solid #e2e8f0;
}

.shortcodes-table td {
    padding: 12px;
    border-bottom: 1px solid #f0f0f0;
    vertical-align: top;
}

.shortcodes-table tr:hover {
    background: #f9f9f9;
}

/* ===== عنوان شورت‌کد و دکمه کپی در یک خط ===== */
.shortcode-title-wrapper {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: nowrap;
    white-space: nowrap;
}

.shortcode-code {
    background: #f1f5f9;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    direction: ltr;
    display: inline-block;
    font-family: monospace;
    white-space: nowrap;
    color: #1d2327;
}

.copy-btn {
    padding: 4px 12px;
    font-size: 12px;
    cursor: pointer;
    background: #2271b1;
    color: #fff;
    border: none;
    border-radius: 4px;
    transition: all 0.2s;
    white-space: nowrap;
    flex-shrink: 0;
}

.copy-btn:hover {
    background: #135e96;
}

.copy-btn.copied {
    background: #28a745;
}

.shortcode-description {
    color: #666;
    font-size: 12px;
    margin-top: 5px;
}

.shortcode-params {
    font-size: 11px;
    color: #888;
    margin-top: 5px;
    font-family: monospace;
}

.tips-box {
    background: #fefce8;
    border: 1px solid #fde047;
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
}

.tips-box h4 {
    margin: 0 0 10px 0;
}

.tips-box ul {
    margin: 0;
    padding-right: 20px;
}

.tips-box li {
    margin-bottom: 8px;
}

.tips-box code {
    background: #fff;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 12px;
}

/* ===== رسپانسیو ===== */
@media (max-width: 1024px) {
    .stats-container {
        max-width: 100%;
        gap: 12px;
    }
    .stat-box .stat-number {
        font-size: 24px;
    }
}

@media (max-width: 768px) {
    .tab-shortcodes-settings {
        margin: 10px 10px 0 0;
    }
    
    .shortcodes-card {
        padding: 15px;
    }
    
    .shortcodes-card h3 {
        font-size: 16px;
    }
    
    .stats-container {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }
    
    .stat-box {
        padding: 14px 16px;
    }
    
    .stat-box .stat-number {
        font-size: 22px;
    }
    
    .stat-box .stat-label {
        font-size: 12px;
    }
    
    .shortcodes-table th,
    .shortcodes-table td {
        display: block;
        width: 100%;
    }
    
    .shortcodes-table th {
        display: none;
    }
    
    .shortcodes-table td {
        padding: 10px;
        border-bottom: 1px solid #eee;
    }
    
    .shortcode-title-wrapper {
        flex-wrap: wrap;
        white-space: normal;
    }
    
    .shortcode-code {
        font-size: 12px;
        padding: 4px 8px;
    }
    
    .copy-btn {
        font-size: 11px;
        padding: 4px 10px;
    }
}

@media (max-width: 480px) {
    .stats-container {
        grid-template-columns: 1fr 1fr;
        gap: 8px;
    }
    
    .stat-box {
        padding: 12px 10px;
        border-radius: 8px;
    }
    
    .stat-box .stat-number {
        font-size: 18px;
    }
    
    .stat-box .stat-label {
        font-size: 11px;
    }
    
    .shortcodes-card {
        padding: 12px;
    }
    
    .shortcode-code {
        font-size: 11px;
        padding: 3px 6px;
    }
    
    .copy-btn {
        font-size: 10px;
        padding: 3px 8px;
    }
}
</style>

<div class="tab-shortcodes-settings">
    
    <div class="shortcodes-card">
        <h3>📝 شورت‌کدهای افزونه لاگین پرو</h3>
        <p class="description" style="margin-bottom: 20px;">با استفاده از شورت‌کدهای زیر، فرم‌های لاگین، ثبت‌نام و داشبورد را در صفحات خود نمایش دهید</p>
        
        <!-- آمار -->
        <div class="stats-container">
            <div class="stat-box">
                <div class="stat-number"><?php echo count($shortcodes); ?></div>
                <div class="stat-label">شورت‌کد فعال</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">100%</div>
                <div class="stat-label">پیشرفته و حرفه‌ای</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">📱</div>
                <div class="stat-label">واکنش‌گرا</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">⚡</div>
                <div class="stat-label">سریع و بهینه</div>
            </div>
        </div>
        
        <!-- نمایش شورت‌کدها به صورت گروهی -->
        <?php foreach ($categories as $cat_name => $cat_shortcodes): ?>
            <h4 style="margin: 25px 0 15px 0; padding-bottom: 8px; border-bottom: 2px solid #e2e8f0; color: #2c3e50;">
                📁 <?php echo esc_html($cat_name); ?> (<?php echo count($cat_shortcodes); ?>)
            </h4>
            
            <div style="overflow-x: auto;">
                <table class="shortcodes-table">
                    <thead>
                        <tr>
                            <th style="width: 35%;">شورت‌کد</th>
                            <th style="width: 65%;">توضیحات و پارامترها</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cat_shortcodes as $code => $info): ?>
                        <tr>
                            <td>
                                <div class="shortcode-title-wrapper">
                                    <code class="shortcode-code"><?php echo esc_html($code); ?></code>
                                    <button class="copy-btn" data-code="<?php echo esc_attr($code); ?>">📋 کپی</button>
                                </div>
                            </td>
                            <td>
                                <strong><?php echo esc_html($info['title']); ?></strong>
                                <div class="shortcode-description"><?php echo esc_html($info['description']); ?></div>
                                <?php if (!empty($info['params'])): ?>
                                    <div class="shortcode-params">
                                        📌 پارامترها: <code><?php echo esc_html($info['params']); ?></code>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; ?>
        
        <!-- نکات مهم -->
        <div class="tips-box">
            <h4>💡 نکات مهم</h4>
            <ul>
                <li>✅ برای نمایش فرم لاگین در صفحه، کافی است شورت‌کد <code>[loginpro_login]</code> را در صفحه قرار دهید.</li>
                <li>✅ پارامتر <code>redirect</code> آدرس هدایت بعد از لاگین/خروج را مشخص می‌کند.</li>
                <li>✅ پارامتر <code>class</code> برای افزودن کلاس CSS سفارشی به فرم استفاده می‌شود.</li>
                <li>✅ تمام فرم‌ها با موبایل، تبلت و دسکتاپ سازگار هستند (واکنش‌گرا).</li>
                <li>✅ می‌توانید ظاهر فرم‌ها را از بخش <strong>تنظیمات ظاهر</strong> شخصی‌سازی کنید.</li>
                <li>✅ شورت‌کد <code>[loginpro_modal_button]</code> برای باز کردن فرم در پنجره بازشو (مودال) استفاده می‌شود.</li>
                <li>✅ برای نمایش پروفایل کاربر از شورت‌کد <code>[loginpro_profile]</code> استفاده کنید.</li>
            </ul>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('.copy-btn').on('click', function() {
        var code = $(this).data('code');
        var fullCode = '[' + code + ']';
        var $btn = $(this);
        
        copyToClipboard(fullCode, $btn);
    });
    
    function copyToClipboard(text, $btn) {
        // استفاده از Clipboard API مدرن
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function() {
                showCopiedFeedback($btn);
            }).catch(function() {
                fallbackCopy(text, $btn);
            });
        } else {
            fallbackCopy(text, $btn);
        }
    }
    
    function fallbackCopy(text, $btn) {
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();
        try {
            document.execCommand('copy');
            showCopiedFeedback($btn);
        } catch(e) {
            alert('لطفاً به صورت دستی کپی کنید: ' + text);
        }
        $temp.remove();
    }
    
    function showCopiedFeedback($btn) {
        var originalText = $btn.html();
        $btn.html('✅ کپی شد!');
        $btn.addClass('copied');
        setTimeout(function() {
            $btn.html(originalText);
            $btn.removeClass('copied');
        }, 2000);
    }
});
</script>