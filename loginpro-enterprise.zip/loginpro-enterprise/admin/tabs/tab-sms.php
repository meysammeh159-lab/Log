<?php
defined('ABSPATH') || exit;

// بررسی وجود فایل loader
$loader_file = LOGINPRO_PLUGIN_DIR . 'includes/sms-provider-loader.php';

if (file_exists($loader_file)) {
    require_once $loader_file;
    $providers = LoginPro_SmsProviderLoader::discoverProviders();
} else {
    // اگر فایل loader وجود نداشت، درگاه‌های پیش‌فرض را تعریف کن
    $providers = [
        'smsir' => [
            'name' => 'SMS.ir - ایده پردازان',
            'description' => 'درگاه پیامک SMS.ir با کیفیت بالا',
            'settings_fields' => [
                'api_key' => ['type' => 'text', 'label' => 'کلید API', 'placeholder' => 'XXXX-XXXX-XXXX-XXXX', 'description' => 'کلید API خود را از پنل SMS.ir دریافت کنید'],
                'line_number' => ['type' => 'text', 'label' => 'شماره ارسال کننده', 'placeholder' => '3000XXX', 'description' => 'شماره خط اختصاصی یا عمومی خود را وارد کنید'],
                'message_template' => ['type' => 'textarea', 'label' => 'الگوی پیام', 'description' => 'متغیرها: %OTP% - {NAME} - {DOMAIN}']
            ]
        ],
        'kavenegar' => [
            'name' => 'Kavenegar - کاوه نگار',
            'description' => 'درگاه پیامک Kavenegar',
            'settings_fields' => [
                'api_key' => ['type' => 'text', 'label' => 'کلید API', 'placeholder' => 'XXXXXXXXXXXXXXXXXXXX', 'description' => 'کلید API خود را از پنل Kavenegar دریافت کنید'],
                'sender' => ['type' => 'text', 'label' => 'شماره ارسال کننده', 'placeholder' => '10008663', 'description' => 'شماره خط اختصاصی یا عمومی (پیش‌فرض: 10008663)'],
                'message_template' => ['type' => 'textarea', 'label' => 'الگوی پیام', 'description' => 'متغیرها: %OTP% - {NAME} - {DOMAIN}']
            ]
        ]
    ];
}

// ==================================================
// ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_sms']) && isset($_POST['sms_nonce']) && wp_verify_nonce($_POST['sms_nonce'], 'sms_settings')) {
    
    if (isset($_POST['resend_delay'])) {
        update_option('loginpro_sms_resend_delay', intval($_POST['resend_delay']));
    }
    
    if (isset($_POST['active_provider'])) {
        update_option('loginpro_sms_active_provider', sanitize_text_field($_POST['active_provider']));
    }
    
    foreach ($providers as $slug => $provider) {
        foreach ($provider['settings_fields'] as $field_name => $field) {
            $post_key = $slug . '_' . $field_name;
            if (isset($_POST[$post_key])) {
                update_option('loginpro_sms_' . $slug . '_' . $field_name, sanitize_text_field($_POST[$post_key]));
            }
        }
    }
    
    echo '<div class="notice-success"><p>✅ تنظیمات پیامک با موفقیت ذخیره شد.</p></div>';
}

// ==================================================
// دریافت مقادیر ذخیره شده
// ==================================================
$active_slug = get_option('loginpro_sms_active_provider', '');
$resend_delay = get_option('loginpro_sms_resend_delay', 90);

if (empty($active_slug) && !empty($providers)) {
    $first_slug = array_key_first($providers);
    $active_slug = $first_slug;
}
?>

<div class="loginpro-card">
    <h3>📱 تنظیمات درگاه پیامک</h3>
    <p class="description">مدیریت درگاه‌های ارسال پیامک برای کد یکبارمصرف (OTP)</p>
    
    <form method="post" action="">
        <?php wp_nonce_field('sms_settings', 'sms_nonce'); ?>
        
        <div class="loginpro-sub-card">
            <h4>⏱️ تنظیمات عمومی</h4>
            <table class="loginpro-form-table">
                <tr>
                    <th>زمان انتظار برای ارسال مجدد:</th>
                    <td>
                        <input type="number" name="resend_delay" value="<?php echo esc_attr($resend_delay); ?>" style="width: 100px;" min="30" max="300">
                        <span>ثانیه</span>
                     </div>
                 </div>
             </div>
        </div>
        
        <div class="loginpro-sub-card">
            <h4>📡 انتخاب درگاه پیامکی</h4>
            <table class="loginpro-form-table">
                <tr>
                    <th>درگاه فعال:</th>
                    <td>
                        <select name="active_provider" id="active_provider" style="min-width: 250px;">
                            <?php foreach ($providers as $slug => $provider): ?>
                                <option value="<?php echo esc_attr($slug); ?>" <?php selected($active_slug, $slug); ?>>
                                    <?php echo esc_html($provider['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                     </div>
                 </div>
             </div>
        </div>
        
        <?php foreach ($providers as $slug => $provider): ?>
            <div id="<?php echo esc_attr($slug); ?>_box" class="loginpro-sub-card" style="<?php echo $active_slug !== $slug ? 'display:none;' : ''; ?>">
                <h4>✅ تنظیمات <?php echo esc_html($provider['name']); ?></h4>
                <table class="loginpro-form-table">
                    <?php foreach ($provider['settings_fields'] as $field_name => $field): ?>
                        <tr>
                            <th><?php echo esc_html($field['label']); ?>:</th>
                            <td>
                                <?php
                                $field_value = get_option('loginpro_sms_' . $slug . '_' . $field_name, '');
                                $input_name = $slug . '_' . $field_name;
                                
                                if ($field['type'] === 'textarea') {
                                    echo '<textarea name="' . esc_attr($input_name) . '" rows="3" style="width: 100%; max-width: 400px;" placeholder="' . esc_attr($field['placeholder'] ?? '') . '">' . esc_textarea($field_value) . '</textarea>';
                                } elseif ($field['type'] === 'password') {
                                    echo '<input type="password" name="' . esc_attr($input_name) . '" value="' . esc_attr($field_value) . '" style="width: 100%; max-width: 400px;" placeholder="' . esc_attr($field['placeholder'] ?? '') . '">';
                                } else {
                                    echo '<input type="text" name="' . esc_attr($input_name) . '" value="' . esc_attr($field_value) . '" style="width: 100%; max-width: 400px;" placeholder="' . esc_attr($field['placeholder'] ?? '') . '">';
                                }
                                ?>
                                <?php if (isset($field['description'])): ?>
                                    <p class="description"><?php echo esc_html($field['description']); ?></p>
                                <?php endif; ?>
                             </div>
                         </div>
                    <?php endforeach; ?>
                 </div>
            </div>
        <?php endforeach; ?>
        
        <div style="margin-top: 20px;">
            <button type="submit" name="save_sms" class="loginpro-submit-btn">💾 ذخیره تنظیمات درگاه پیامک</button>
        </div>
    </form>
</div>

<style>
.loginpro-card {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid #e2e8f0;
}
.loginpro-sub-card {
    background: #f8fafc;
    border-radius: 10px;
    padding: 15px 20px;
    margin-bottom: 20px;
    border: 1px solid #e2e8f0;
}
.loginpro-sub-card h4 {
    margin: 0 0 15px 0;
    font-size: 16px;
    color: #1e293b;
}
.loginpro-form-table {
    width: 100%;
    border-collapse: collapse;
}
.loginpro-form-table th {
    width: 200px;
    text-align: right;
    padding: 10px;
    font-weight: 600;
    vertical-align: top;
}
.loginpro-form-table td {
    padding: 10px;
}
.loginpro-form-table input[type="text"],
.loginpro-form-table input[type="number"],
.loginpro-form-table textarea,
.loginpro-form-table select {
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    width: 100%;
    max-width: 400px;
}
.loginpro-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 24px;
    border-radius: 6px;
    cursor: pointer;
}
.loginpro-submit-btn:hover {
    background: #135e96;
}
.notice-success {
    background: #d4edda;
    color: #155724;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #28a745;
}
.description {
    color: #666;
    font-size: 12px;
    margin-top: 5px;
}
@media (max-width: 768px) {
    .loginpro-form-table th,
    .loginpro-form-table td {
        display: block;
        width: 100%;
        padding: 5px 0;
    }
    .loginpro-form-table input,
    .loginpro-form-table select,
    .loginpro-form-table textarea {
        max-width: 100% !important;
        width: 100% !important;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#active_provider').on('change', function() {
        var selected = $(this).val();
        <?php foreach ($providers as $slug => $provider): ?>
            $('#<?php echo $slug; ?>_box').hide();
        <?php endforeach; ?>
        $('#' + selected + '_box').show();
    });
});
</script>