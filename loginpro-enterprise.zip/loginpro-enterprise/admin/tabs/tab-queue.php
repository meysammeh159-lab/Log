<?php
defined('ABSPATH') || exit;

global $wpdb;

$queue_table = $wpdb->prefix . 'loginpro_queue';

$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$queue_table'") === $queue_table;

if (!$table_exists) {
    echo '<div class="notice-info"><p>⚠️ جدول صف هنوز ایجاد نشده است. لطفاً افزونه را غیرفعال و دوباره فعال کنید.</p></div>';
    return;
}

if (isset($_POST['run_worker']) && isset($_POST['queue_nonce']) && wp_verify_nonce($_POST['queue_nonce'], 'queue_action')) {
    $processed = 0;
    $pending_jobs = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$queue_table} WHERE available_at <= %d AND reserved_at IS NULL AND failed_at IS NULL ORDER BY available_at ASC LIMIT 10",
        time()
    ));
    
    foreach ($pending_jobs as $job) {
        $wpdb->update($queue_table, ['reserved_at' => time()], ['id' => $job->id]);
        $processed++;
    }
    
    echo '<div class="notice-success"><p>✅ ' . $processed . ' کار در صف پردازش شد.</p></div>';
}

if (isset($_POST['retry_failed']) && isset($_POST['queue_nonce']) && wp_verify_nonce($_POST['queue_nonce'], 'queue_action')) {
    $updated = $wpdb->query(
        "UPDATE {$queue_table} SET reserved_at = NULL, failed_at = NULL, attempts = 0 WHERE failed_at IS NOT NULL"
    );
    echo '<div class="notice-success"><p>✅ ' . $updated . ' کار ناموفق برای تلاش مجدد آماده شد.</p></div>';
}

if (isset($_POST['delete_failed']) && isset($_POST['queue_nonce']) && wp_verify_nonce($_POST['queue_nonce'], 'queue_action')) {
    $deleted = $wpdb->query("DELETE FROM {$queue_table} WHERE failed_at IS NOT NULL");
    echo '<div class="notice-success"><p>🗑️ ' . $deleted . ' کار ناموفق حذف شد.</p></div>';
}

if (isset($_POST['clear_all']) && isset($_POST['queue_nonce']) && wp_verify_nonce($_POST['queue_nonce'], 'queue_action')) {
    $deleted = $wpdb->query("TRUNCATE TABLE {$queue_table}");
    echo '<div class="notice-success"><p>🗑️ تمام کارهای صف پاک شدند.</p></div>';
}

$pending = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$queue_table} WHERE available_at <= " . time() . " AND reserved_at IS NULL AND failed_at IS NULL");
$processing = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$queue_table} WHERE reserved_at IS NOT NULL AND completed_at IS NULL AND failed_at IS NULL");
$completed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$queue_table} WHERE completed_at IS NOT NULL");
$failed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$queue_table} WHERE failed_at IS NOT NULL");

$failed_jobs = $wpdb->get_results("SELECT * FROM {$queue_table} WHERE failed_at IS NOT NULL ORDER BY failed_at DESC LIMIT 30");
$pending_jobs = $wpdb->get_results("SELECT * FROM {$queue_table} WHERE available_at <= " . time() . " AND reserved_at IS NULL AND failed_at IS NULL ORDER BY available_at ASC LIMIT 30");
?>
<style>
.tab-queue-settings {
    margin: 20px 20px 0 0;
}

.queue-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px 30px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.queue-card h3 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.queue-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-bottom: 25px;
}

.queue-stat {
    padding: 15px;
    border-radius: 12px;
    text-align: center;
}
.queue-stat .num { font-size: 28px; font-weight: 700; }
.queue-stat .label { font-size: 13px; color: #555; margin-top: 4px; }

.qs-blue { background: #e3f2fd; }
.qs-blue .num { color: #1565c0; }
.qs-orange { background: #fff3e0; }
.qs-orange .num { color: #e65100; }
.qs-green { background: #e8f5e9; }
.qs-green .num { color: #2e7d32; }
.qs-red { background: #ffebee; }
.qs-red .num { color: #c62828; }

.queue-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 30px;
}

.queue-actions .button { height: 38px; line-height: 36px; padding: 0 18px; }
.queue-actions .button-primary { background: #2271b1; color: #fff; border-color: #2271b1; }
.queue-actions .button-primary:hover { background: #135e96; }
.queue-actions .button-warning { background: #ffc107; color: #333; border-color: #ffc107; }
.queue-actions .button-danger { background: #dc3545; color: #fff; border-color: #dc3545; }
.queue-actions .button-danger:hover { background: #b02a37; }
.queue-actions .button-secondary { background: #6c757d; color: #fff; border-color: #6c757d; }

.notice-success {
    background: #d4edda;
    color: #155724;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #28a745;
}
.notice-info {
    background: #d1ecf1;
    color: #0c5460;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-right: 4px solid #17a2b8;
}

.wp-list-table th { font-weight: 600; }
.wp-list-table td { padding: 8px 10px !important; vertical-align: middle; }

.queue-subtitle { font-size: 14px; font-weight: 600; margin: 25px 0 12px 0; color: #1d2327; }
.queue-subtitle:first-of-type { margin-top: 0; }

.description { color: #666; font-size: 12px; margin-top: 5px; }
hr { margin: 25px 0; border: none; border-top: 1px solid #eee; }

@media (max-width: 1024px) {
    .queue-stats { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 782px) {
    .tab-queue-settings { margin: 10px 10px 0 0; }
    .queue-card { padding: 16px 18px; border-radius: 8px; }
    .queue-card h3 { font-size: 16px; }
    .queue-stats { grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .queue-stat { padding: 10px; }
    .queue-stat .num { font-size: 22px; }
    .queue-stat .label { font-size: 12px; }
    .queue-actions { flex-direction: column; }
    .queue-actions .button { width: 100%; text-align: center; }
    .wp-list-table thead { display: none; }
    .wp-list-table tbody tr { display: block; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 6px; padding: 8px; }
    .wp-list-table tbody tr td { display: flex; justify-content: space-between; padding: 4px 6px !important; border-bottom: 1px solid #f0f0f0; }
    .wp-list-table tbody tr td:last-child { border-bottom: none; }
    .wp-list-table tbody tr td:before { content: attr(data-label); font-weight: 600; font-size: 11px; color: #555; }
    .queue-subtitle { font-size: 13px; }
}

@media (max-width: 480px) {
    .queue-card { padding: 12px 14px; border-radius: 6px; }
    .queue-card h3 { font-size: 15px; }
    .queue-stats { grid-template-columns: 1fr 1fr; gap: 6px; }
    .queue-stat { padding: 8px; border-radius: 8px; }
    .queue-stat .num { font-size: 18px; }
    .queue-stat .label { font-size: 11px; }
    .wp-list-table tbody tr td { font-size: 12px; padding: 3px 4px !important; }
    .wp-list-table tbody tr td:before { font-size: 10px; }
    .queue-actions .button { font-size: 13px; height: 34px; line-height: 32px; }
}
</style>

<div class="tab-queue-settings">
    <div class="queue-card">
        <h3>⏳ مدیریت صف</h3>
        <p class="description">مدیریت و پردازش کارهای زمان‌بر مانند ارسال ایمیل، پیامک و واتساپ</p>
        
        <div class="queue-stats">
            <div class="queue-stat qs-blue">
                <div class="num"><?php echo $pending; ?></div>
                <div class="label">در انتظار</div>
            </div>
            <div class="queue-stat qs-orange">
                <div class="num"><?php echo $processing; ?></div>
                <div class="label">در حال پردازش</div>
            </div>
            <div class="queue-stat qs-green">
                <div class="num"><?php echo $completed; ?></div>
                <div class="label">تکمیل شده</div>
            </div>
            <div class="queue-stat qs-red">
                <div class="num"><?php echo $failed; ?></div>
                <div class="label">ناموفق</div>
            </div>
        </div>
        
        <form method="post" class="queue-actions">
            <?php wp_nonce_field('queue_action', 'queue_nonce'); ?>
            
            <button type="submit" name="run_worker" value="1" class="button button-primary">
                ▶️ اجرای پردازشگر صف
            </button>
            <button type="submit" name="retry_failed" value="1" class="button button-warning">
                🔄 تلاش مجدد کارهای ناموفق
            </button>
            <button type="submit" name="delete_failed" value="1" class="button button-danger">
                🗑️ حذف کارهای ناموفق
            </button>
            <button type="submit" name="clear_all" value="1" class="button button-secondary" onclick="return confirm('آیا از پاک کردن کامل صف مطمئن هستید؟')">
                ⚠️ پاک کردن کل صف
            </button>
        </form>
        
        <div class="queue-subtitle">❌ کارهای ناموفق</div>
        <?php if (empty($failed_jobs)): ?>
            <p class="description">هیچ کار ناموفقی وجود ندارد.</p>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr><th>شناسه</th><th>نوع کار</th><th>تعداد تلاش</th><th>زمان شکست</th><th>خطا</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($failed_jobs as $job): ?>
                        <tr>
                            <td data-label="شناسه"><?php echo $job->id; ?></td>
                            <td data-label="نوع کار"><?php echo esc_html($job->job); ?></td>
                            <td data-label="تعداد تلاش"><?php echo $job->attempts . '/' . $job->max_attempts; ?></td>
                            <td data-label="زمان شکست"><?php echo $job->failed_at ? date('Y-m-d H:i:s', $job->failed_at) : '-'; ?></td>
                            <td data-label="خطا"><?php echo esc_html(substr($job->error_message ?? '', 0, 50)); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <div class="queue-subtitle">⏳ کارهای در انتظار</div>
        <?php if (empty($pending_jobs)): ?>
            <p class="description">هیچ کار در انتظاری وجود ندارد.</p>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr><th>شناسه</th><th>نوع کار</th><th>زمان اجرا</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending_jobs as $job): ?>
                        <tr>
                            <td data-label="شناسه"><?php echo $job->id; ?></td>
                            <td data-label="نوع کار"><?php echo esc_html($job->job); ?></td>
                            <td data-label="زمان اجرا"><?php echo date('Y-m-d H:i:s', $job->available_at); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <hr>
        <p class="description">💡 صف برای پردازش کارهای زمان‌بر مانند ارسال ایمیل، پیامک و واتساپ استفاده می‌شود. کارها به صورت خودکار توسط cron پردازش می‌شوند.</p>
    </div>
</div>