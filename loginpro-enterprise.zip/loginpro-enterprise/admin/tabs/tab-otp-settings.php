<?php
defined('ABSPATH') || exit;

// ==================================================
// تنظیمات تب ⚙️ تنظیمات کد یکبارمصرف (OTP)
// ==================================================

// دریافت مقادیر از دیتابیس
$otp_length = get_option('loginpro_otp_length', 6);
$otp_expiry = get_option('loginpro_otp_expiry', 300);
$otp_max_attempts = get_option('loginpro_otp_max_attempts', 3);
$otp_resend_delay = get_option('loginpro_otp_resend_delay', 60);
$otp_channel_sms = get_option('loginpro_otp_channel_sms', true);
$otp_channel_whatsapp = get_option('loginpro_otp_channel_whatsapp', false);
$otp_channel_email = get_option('loginpro_otp_channel_email', true);
$otp_channel_firebase = get_option('loginpro_otp_channel_firebase', false);
$otp_default_channel = get_option('loginpro_otp_default_channel', 'sms');
$otp_sms_template = get_option('loginpro_otp_sms_template', 'کد تأیید شما: {code}');
$otp_whatsapp_template = get_option('loginpro_otp_whatsapp_template', 'کد تأیید شما: {code}');
$otp_email_subject = get_option('loginpro_otp_email_subject', 'کد تأیید شما');
$otp_email_template = get_option('loginpro_otp_email_template', '<h2>کد تأیید شما</h2><p>کد تأیید شما: <strong>{code}</strong></p><p>این کد تا 5 دقیقه معتبر است.</p>');
$otp_throttle_max_attempts = get_option('loginpro_otp_throttle_max_attempts', 5);
$otp_lockout_minutes = get_option('loginpro_otp_lockout_minutes', 60);
$otp_max_resends = get_option('loginpro_otp_max_resends', 5);

// ==================================================
// پردازش ذخیره تنظیمات
// ==================================================
if (isset($_POST['save_otp']) && isset($_POST['otp_settings']) && wp_verify_nonce($_POST['otp_settings'], 'otp_settings')) {
    
    update_option('loginpro_otp_length', (int) $_POST['otp_length']);
    update_option('loginpro_otp_expiry', (int) $_POST['otp_expiry']);
    update_option('loginpro_otp_max_attempts', (int) $_POST['otp_max_attempts']);
    update_option('loginpro_otp_resend_delay', (int) $_POST['otp_resend_delay']);
    update_option('loginpro_otp_channel_sms', isset($_POST['otp_channel_sms']));
    update_option('loginpro_otp_channel_whatsapp', isset($_POST['otp_channel_whatsapp']));
    update_option('loginpro_otp_channel_email', isset($_POST['otp_channel_email']));
    update_option('loginpro_otp_channel_firebase', isset($_POST['otp_channel_firebase']));
    update_option('loginpro_otp_default_channel', sanitize_text_field($_POST['otp_default_channel']));
    update_option('loginpro_otp_sms_template', sanitize_textarea_field($_POST['otp_sms_template']));
    update_option('loginpro_otp_whatsapp_template', sanitize_textarea_field($_POST['otp_whatsapp_template']));
    update_option('loginpro_otp_email_subject', sanitize_text_field($_POST['otp_email_subject']));
    update_option('loginpro_otp_email_template', wp_kses_post($_POST['otp_email_template']));
    update_option('loginpro_otp_throttle_max_attempts', (int) $_POST['otp_throttle_max_attempts']);
    update_option('loginpro_otp_lockout_minutes', (int) $_POST['otp_lockout_minutes']);
    update_option('loginpro_otp_max_resends', (int) $_POST['otp_max_resends']);
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات کد یکبارمصرف با موفقیت ذخیره شد.</p></div>';
    
    // به‌روزرسانی متغیرها
    $otp_length = get_option('loginpro_otp_length', 6);
    $otp_expiry = get_option('loginpro_otp_expiry', 300);
    $otp_max_attempts = get_option('loginpro_otp_max_attempts', 3);
    $otp_resend_delay = get_option('loginpro_otp_resend_delay', 60);
    $otp_channel_sms = get_option('loginpro_otp_channel_sms', true);
    $otp_channel_whatsapp = get_option('loginpro_otp_channel_whatsapp', false);
    $otp_channel_email = get_option('loginpro_otp_channel_email', true);
    $otp_channel_firebase = get_option('loginpro_otp_channel_firebase', false);
    $otp_default_channel = get_option('loginpro_otp_default_channel', 'sms');
    $otp_sms_template = get_option('loginpro_otp_sms_template', 'کد تأیید شما: {code}');
    $otp_whatsapp_template = get_option('loginpro_otp_whatsapp_template', 'کد تأیید شما: {code}');
    $otp_email_subject = get_option('loginpro_otp_email_subject', 'کد تأیید شما');
    $otp_email_template = get_option('loginpro_otp_email_template', '<h2>کد تأیید شما</h2><p>کد تأیید شما: <strong>{code}</strong></p><p>این کد تا 5 دقیقه معتبر است.</p>');
    $otp_throttle_max_attempts = get_option('loginpro_otp_throttle_max_attempts', 5);
    $otp_lockout_minutes = get_option('loginpro_otp_lockout_minutes', 60);
    $otp_max_resends = get_option('loginpro_otp_max_resends', 5);
}

// ==================================================
// ==================================================
// AJAX Handler برای تست ارسال OTP
// ==================================================
// ==================================================
add_action('wp_ajax_loginpro_test_otp_send', function() {
    if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_test_otp')) {
        wp_send_json_error(['message' => 'خطای امنیتی']);
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز']);
        return;
    }
    
    $mobile = sanitize_text_field($_POST['mobile']);
    $mobile = preg_replace('/[^0-9]/', '', $mobile);
    
    if (empty($mobile)) {
        wp_send_json_error(['message' => 'شماره موبایل را وارد کنید']);
        return;
    }
    
    if (strlen($mobile) === 10) {
        $mobile = '0' . $mobile;
    }
    
    // دریافت درگاه فعال
    $activeSlug = get_option('loginpro_sms_active_provider', '');
    
    if (empty($activeSlug)) {
        wp_send_json_error(['message' => 'درگاه فعال انتخاب نشده است. لطفاً ابتدا درگاه پیامک را تنظیم کنید.']);
        return;
    }
    
    // بارگذاری Provider
    $providers_dir = LOGINPRO_PLUGIN_DIR . 'modules/Providers/Sms/';
    if (!is_dir($providers_dir)) {
        $providers_dir = LOGINPRO_PLUGIN_DIR . 'Providers/Sms/';
    }
    
    $provider_file = $providers_dir . ucfirst($activeSlug) . 'Provider.php';
    if (!file_exists($provider_file)) {
        wp_send_json_error(['message' => 'فایل Provider وجود ندارد: ' . $activeSlug]);
        return;
    }
    
    require_once($provider_file);
    
    // پیدا کردن کلاس Provider
    $content = file_get_contents($provider_file);
    preg_match('/namespace\s+([^;]+);/', $content, $nsMatch);
    preg_match('/class\s+(\w+)/', $content, $classMatch);
    $fullClassName = trim($nsMatch[1] ?? '') . '\\' . ($classMatch[1] ?? '');
    
    if (!class_exists($fullClassName)) {
        wp_send_json_error(['message' => 'کلاس Provider یافت نشد']);
        return;
    }
    
    try {
        $instance = new $fullClassName();
        $otp_code = rand(100000, 999999);
        
        // دریافت قالب پیامک از تنظیمات
        $sms_template = get_option('loginpro_otp_sms_template', 'کد تأیید شما: {code}');
        $site_name = get_bloginfo('name');
        $message = str_replace(['{code}', '{site_name}'], [$otp_code, $site_name], $sms_template);
        
        if (method_exists($instance, 'send')) {
            $result = $instance->send($mobile, $message);
            
            if (isset($result['success']) && $result['success'] === true) {
                wp_send_json_success([
                    'message' => '✅ پیامک OTP با موفقیت ارسال شد به شماره ' . $mobile,
                    'code' => $otp_code
                ]);
            } else {
                wp_send_json_error(['message' => $result['message'] ?? 'خطای ناشناخته در ارسال']);
            }
        } else {
            wp_send_json_error(['message' => 'متد send() در درگاه وجود ندارد']);
        }
    } catch (Exception $e) {
        wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()]);
    }
});

// ==================================================
// ==================================================
// HTML Popup برای تست OTP
// ==================================================
// ==================================================
add_action('admin_footer', function() {
    ?>
    <div id="loginpro-test-otp-popup" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999999; align-items:center; justify-content:center;">
        <div style="background:#fff; border-radius:12px; padding:30px; max-width:450px; width:90%; box-shadow:0 10px 40px rgba(0,0,0,0.3); position:relative; direction:rtl;">
            <button onclick="closeOtpTestPopup()" style="position:absolute; top:10px; left:15px; background:none; border:none; font-size:24px; cursor:pointer; color:#999;">&times;</button>
            
            <h2 style="margin-top:0; margin-bottom:20px; color:#333;">📱 تست ارسال OTP</h2>
            
            <div id="test-otp-result" style="display:none; padding:12px 15px; border-radius:8px; margin-bottom:15px;"></div>
            
            <div style="margin-bottom:15px;">
                <label style="display:block; font-weight:600; margin-bottom:5px; color:#555;">شماره موبایل:</label>
                <input type="text" id="test-otp-mobile" placeholder="09123456789" style="width:100%; padding:10px 15px; border:1px solid #ddd; border-radius:8px; font-size:14px; box-sizing:border-box; direction:ltr;">
                <p style="font-size:12px; color:#999; margin-top:5px;">شماره موبایل مقصد برای دریافت کد OTP تست</p>
            </div>
            
            <div style="margin-bottom:15px; display:none;" id="test-otp-code-box">
                <label style="display:block; font-weight:600; margin-bottom:5px; color:#555;">کد ارسال شده:</label>
                <div style="background:#f0f7ff; padding:10px 15px; border-radius:8px; font-size:20px; font-weight:bold; text-align:center; color:#0d6efd; letter-spacing:5px; direction:ltr;" id="test-otp-code-display">------</div>
                <p style="font-size:12px; color:#999; margin-top:5px; text-align:center;">این کد فقط برای تست نمایش داده می‌شود</p>
            </div>
            
            <div style="display:flex; gap:10px;">
                <button onclick="sendOtpTestSms()" id="send-otp-test-btn" style="flex:1; background:#ef394e; color:#fff; border:none; padding:12px 20px; border-radius:8px; cursor:pointer; font-size:15px; font-weight:600; transition:all 0.2s;">
                    📨 ارسال OTP تست
                </button>
                <button onclick="closeOtpTestPopup()" style="background:#f0f0f0; color:#333; border:none; padding:12px 20px; border-radius:8px; cursor:pointer; font-size:15px; transition:all 0.2s;">
                    بستن
                </button>
            </div>
            
            <div id="test-otp-loading" style="display:none; text-align:center; margin-top:15px; color:#666;">
                <span style="display:inline-block; width:20px; height:20px; border:3px solid #f0f0f0; border-top-color:#ef394e; border-radius:50%; animation:spin 0.8s linear infinite;"></span>
                <span style="display:block; margin-top:5px;">در حال ارسال...</span>
            </div>
        </div>
    </div>
    
    <style>
        #loginpro-test-otp-popup {
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        #loginpro-test-otp-popup .notice-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        #loginpro-test-otp-popup .notice-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        #loginpro-test-otp-popup .notice-info {
            background: #cce5ff;
            color: #004085;
            border: 1px solid #b8daff;
        }
    </style>
    
    <script>
    function openOtpTestPopup() {
        document.getElementById('loginpro-test-otp-popup').style.display = 'flex';
        document.getElementById('test-otp-mobile').value = '';
        document.getElementById('test-otp-result').style.display = 'none';
        document.getElementById('test-otp-code-box').style.display = 'none';
        document.getElementById('send-otp-test-btn').disabled = false;
        document.getElementById('send-otp-test-btn').textContent = '📨 ارسال OTP تست';
        document.getElementById('test-otp-loading').style.display = 'none';
    }
    
    function closeOtpTestPopup() {
        document.getElementById('loginpro-test-otp-popup').style.display = 'none';
    }
    
    function sendOtpTestSms() {
        var mobile = document.getElementById('test-otp-mobile').value.trim();
        var resultDiv = document.getElementById('test-otp-result');
        var sendBtn = document.getElementById('send-otp-test-btn');
        var loadingDiv = document.getElementById('test-otp-loading');
        var codeBox = document.getElementById('test-otp-code-box');
        var codeDisplay = document.getElementById('test-otp-code-display');
        
        // اعتبارسنجی شماره
        var cleanMobile = mobile.replace(/[^0-9]/g, '');
        if (cleanMobile.length < 10) {
            resultDiv.style.display = 'block';
            resultDiv.className = 'notice-error';
            resultDiv.innerHTML = '❌ لطفاً شماره موبایل معتبر وارد کنید.';
            return;
        }
        
        // غیرفعال کردن دکمه
        sendBtn.disabled = true;
        sendBtn.textContent = '⏳ در حال ارسال...';
        loadingDiv.style.display = 'block';
        resultDiv.style.display = 'none';
        codeBox.style.display = 'none';
        
        var formData = new FormData();
        formData.append('action', 'loginpro_test_otp_send');
        formData.append('mobile', cleanMobile);
        formData.append('_nonce', '<?php echo wp_create_nonce('loginpro_test_otp'); ?>');
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            body: formData
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            loadingDiv.style.display = 'none';
            sendBtn.disabled = false;
            sendBtn.textContent = '📨 ارسال OTP تست';
            
            resultDiv.style.display = 'block';
            if (data.success) {
                resultDiv.className = 'notice-success';
                resultDiv.innerHTML = '✅ ' + (data.data.message || 'پیامک با موفقیت ارسال شد!');
                
                // نمایش کد ارسال شده
                if (data.data.code) {
                    codeBox.style.display = 'block';
                    codeDisplay.textContent = data.data.code;
                }
            } else {
                resultDiv.className = 'notice-error';
                resultDiv.innerHTML = '❌ ' + (data.data.message || 'خطا در ارسال پیامک');
            }
        })
        .catch(function(error) {
            loadingDiv.style.display = 'none';
            sendBtn.disabled = false;
            sendBtn.textContent = '📨 ارسال OTP تست';
            
            resultDiv.style.display = 'block';
            resultDiv.className = 'notice-error';
            resultDiv.innerHTML = '❌ خطا در ارتباط با سرور: ' + error;
        });
    }
    
    // بستن با کلید Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeOtpTestPopup();
        }
    });
    
    // بستن با کلیک روی پس‌زمینه
    document.addEventListener('click', function(e) {
        var popup = document.getElementById('loginpro-test-otp-popup');
        if (e.target === popup) {
            closeOtpTestPopup();
        }
    });
    </script>
    <?php
});

// ==================================================
// ==================================================
// HTML فرم
// ==================================================
// ==================================================
?>
<style>
.tab-otp-settings {
    margin: 20px 20px 0 0;
}

/* کارت اصلی */
.otp-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 12px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.otp-card h2 {
    margin-top: 0;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    font-weight: 600;
}

.otp-card .badge-new {
    background: #28a745;
    color: #fff;
    font-size: 10px;
    padding: 2px 8px;
    border-radius: 12px;
    margin-right: 5px;
    display: inline-block;
}

/* جدول فرم */
.otp-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.otp-form-table th {
    width: 220px;
    text-align: right;
    padding: 15px;
    font-weight: 600;
    vertical-align: top;
    background: #fafafa;
}

.otp-form-table td {
    padding: 15px;
    vertical-align: top;
}

/* فیلدها */
.otp-form-table input[type="text"],
.otp-form-table input[type="password"],
.otp-form-table input[type="number"],
.otp-form-table select,
.otp-form-table textarea {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    width: 100%;
    max-width: 350px;
    background: #fff;
}

.otp-form-table input:focus,
.otp-form-table select:focus,
.otp-form-table textarea:focus {
    border-color: #2271b1;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

.otp-input-small {
    width: 100px !important;
}

.otp-textarea-large {
    max-width: 500px !important;
    min-height: 80px;
    font-family: monospace;
}

/* چک‌باکس */
.otp-checkbox-label {
    display: inline-block;
    margin-left: 15px;
}

.otp-checkbox-label input {
    margin-left: 5px;
}

/* دکمه‌ها */
.otp-submit-btn {
    background: #2271b1;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
}

.otp-submit-btn:hover {
    background: #135e96;
}

/* دکمه تست با استایل جذاب */
.otp-test-btn {
    background: #28a745;
    color: #fff;
    border: none;
    padding: 10px 28px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.otp-test-btn:hover {
    background: #218838;
    transform: scale(1.02);
}

/* توضیحات */
.otp-help-text {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

.otp-description {
    color: #666;
    font-size: 13px;
    margin-bottom: 20px;
}

/* دکمه‌های فرم */
.otp-form-actions {
    margin-top: 20px;
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

/* Responsive */
@media (max-width: 768px) {
    .otp-form-table th,
    .otp-form-table td {
        display: block;
        width: 100%;
        padding: 10px;
    }
    
    .otp-form-table th {
        background: transparent;
        padding-bottom: 5px;
    }
    
    .otp-card {
        padding: 15px;
    }
    
    .otp-textarea-large {
        max-width: 100% !important;
    }
}
</style>

<div class="tab-otp-settings">
    
    <form method="post">
        <?php wp_nonce_field('otp_settings', 'otp_settings'); ?>
        <input type="hidden" name="save_otp" value="1">
        
        <!-- کارت 1: تنظیمات عمومی OTP -->
        <div class="otp-card">
            <h2>⚙️ تنظیمات عمومی OTP</h2>
            <table class="otp-form-table">
                <tr>
                    <th scope="row"><label for="otp_length">طول کد OTP</label></th>
                    <td>
                        <input type="number" name="otp_length" id="otp_length" value="<?php echo esc_attr($otp_length); ?>" min="4" max="8" class="otp-input-small">
                        <p class="otp-help-text">تعداد رقم کد یکبارمصرف (۴ تا ۸ رقم)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_expiry">زمان انقضای کد</label></th>
                    <td>
                        <input type="number" name="otp_expiry" id="otp_expiry" value="<?php echo esc_attr($otp_expiry); ?>" min="60" max="600" class="otp-input-small">
                        <p class="otp-help-text">زمان بر حسب ثانیه (پیش‌فرض: ۳۰۰ ثانیه = ۵ دقیقه)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_max_attempts">حداکثر تلاش برای تأیید</label></th>
                    <td>
                        <input type="number" name="otp_max_attempts" id="otp_max_attempts" value="<?php echo esc_attr($otp_max_attempts); ?>" min="1" max="10" class="otp-input-small">
                        <p class="otp-help-text">تعداد دفعات مجاز برای وارد کردن کد اشتباه</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_resend_delay">تأخیر بین ارسال مجدد</label></th>
                    <td>
                        <input type="number" name="otp_resend_delay" id="otp_resend_delay" value="<?php echo esc_attr($otp_resend_delay); ?>" min="30" max="300" class="otp-input-small">
                        <p class="otp-help-text">زمان انتظار برای ارسال مجدد کد (بر حسب ثانیه)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_max_resends">حداکثر ارسال مجدد</label></th>
                    <td>
                        <input type="number" name="otp_max_resends" id="otp_max_resends" value="<?php echo esc_attr($otp_max_resends); ?>" min="1" max="10" class="otp-input-small">
                        <p class="otp-help-text">تعداد دفعاتی که کاربر می‌تواند کد را مجدداً درخواست کند</p>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 2: کانال‌های ارسال OTP -->
        <div class="otp-card">
            <h2>📡 کانال‌های ارسال OTP</h2>
            <table class="otp-form-table">
                <tr>
                    <th scope="row">کانال پیامک (SMS)</th>
                    <td>
                        <label class="otp-checkbox-label">
                            <input type="checkbox" name="otp_channel_sms" value="1" <?php checked($otp_channel_sms, true); ?>>
                            فعال کردن ارسال کد از طریق پیامک
                        </label>
                        <p class="otp-help-text">برای فعالسازی، تنظیمات درگاه پیامک را تکمیل کنید</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">کانال واتساپ (WhatsApp)</th>
                    <td>
                        <label class="otp-checkbox-label">
                            <input type="checkbox" name="otp_channel_whatsapp" value="1" <?php checked($otp_channel_whatsapp, true); ?>>
                            فعال کردن ارسال کد از طریق واتساپ
                        </label>
                        <p class="otp-help-text">برای فعالسازی، تنظیمات درگاه واتساپ را تکمیل کنید</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">کانال ایمیل (Email)</th>
                    <td>
                        <label class="otp-checkbox-label">
                            <input type="checkbox" name="otp_channel_email" value="1" <?php checked($otp_channel_email, true); ?>>
                            فعال کردن ارسال کد از طریق ایمیل
                        </label>
                        <p class="otp-help-text">برای فعالسازی، تنظیمات درگاه ایمیل را تکمیل کنید</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        🔥 Firebase Phone Auth
                        <span class="badge-new">جدید</span>
                    </th>
                    <td>
                        <label class="otp-checkbox-label">
                            <input type="checkbox" name="otp_channel_firebase" value="1" <?php checked($otp_channel_firebase, true); ?>>
                            فعال کردن ارسال کد از طریق Firebase
                        </label>
                        <p class="otp-help-text">ارسال کد از طریق Firebase (بدون نیاز به درگاه پیامکی)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_default_channel">کانال پیش‌فرض</label></th>
                    <td>
                        <select name="otp_default_channel" id="otp_default_channel" class="otp-select">
                            <option value="sms" <?php selected($otp_default_channel, 'sms'); ?>>پیامک (SMS)</option>
                            <option value="whatsapp" <?php selected($otp_default_channel, 'whatsapp'); ?>>واتساپ (WhatsApp)</option>
                            <option value="email" <?php selected($otp_default_channel, 'email'); ?>>ایمیل (Email)</option>
                            <option value="firebase" <?php selected($otp_default_channel, 'firebase'); ?>>🔥 Firebase</option>
                        </select>
                        <p class="otp-help-text">کانالی که در صورت عدم انتخاب کاربر استفاده می‌شود</p>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 3: قالب پیام‌ها -->
        <div class="otp-card">
            <h2>✏️ قالب پیام‌ها</h2>
            <table class="otp-form-table">
                <tr>
                    <th scope="row"><label for="otp_sms_template">قالب پیامک</label></th>
                    <td>
                        <textarea name="otp_sms_template" id="otp_sms_template" rows="3" class="otp-textarea-large" style="direction: ltr; font-family: monospace;"><?php echo esc_textarea($otp_sms_template); ?></textarea>
                        <p class="otp-help-text">متغیرهای قابل استفاده: <code>{code}</code> - <code>{site_name}</code></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_whatsapp_template">قالب واتساپ</label></th>
                    <td>
                        <textarea name="otp_whatsapp_template" id="otp_whatsapp_template" rows="3" class="otp-textarea-large" style="direction: ltr; font-family: monospace;"><?php echo esc_textarea($otp_whatsapp_template); ?></textarea>
                        <p class="otp-help-text">متغیرهای قابل استفاده: <code>{code}</code> - <code>{site_name}</code></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_email_subject">موضوع ایمیل</label></th>
                    <td>
                        <input type="text" name="otp_email_subject" id="otp_email_subject" value="<?php echo esc_attr($otp_email_subject); ?>" class="otp-input" style="max-width: 400px;">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_email_template">قالب ایمیل</label></th>
                    <td>
                        <textarea name="otp_email_template" id="otp_email_template" rows="6" class="otp-textarea-large" style="font-family: monospace;"><?php echo esc_textarea($otp_email_template); ?></textarea>
                        <p class="otp-help-text">متغیرهای قابل استفاده: <code>{code}</code> - <code>{site_name}</code> - <code>{site_url}</code></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- کارت 4: تنظیمات امنیتی -->
        <div class="otp-card">
            <h2>🛡️ تنظیمات امنیتی</h2>
            <table class="otp-form-table">
                <tr>
                    <th scope="row"><label for="otp_throttle_max_attempts">حداکثر درخواست در ساعت</label></th>
                    <td>
                        <input type="number" name="otp_throttle_max_attempts" id="otp_throttle_max_attempts" value="<?php echo esc_attr($otp_throttle_max_attempts); ?>" min="1" max="50" class="otp-input-small">
                        <p class="otp-help-text">حداکثر تعداد درخواست OTP برای هر شناسه در یک ساعت</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="otp_lockout_minutes">مدت زمان قفل شدن</label></th>
                    <td>
                        <input type="number" name="otp_lockout_minutes" id="otp_lockout_minutes" value="<?php echo esc_attr($otp_lockout_minutes); ?>" min="5" max="1440" class="otp-input-small">
                        <p class="otp-help-text">مدت زمان قفل شدن پس از رسیدن به حداکثر تلاش (دقیقه)</p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="otp-form-actions">
            <button type="submit" name="save_otp" class="otp-submit-btn">💾 ذخیره تنظیمات OTP</button>
            <button type="button" id="test_otp_btn" class="otp-test-btn">📱 ارسال OTP تست</button>
        </div>
    </form>
    
    <div id="test_result" class="otp-test-result"></div>
</div>

<script>
jQuery(document).ready(function($) {
    // دکمه تست با Popup
    $('#test_otp_btn').on('click', function() {
        if (typeof openOtpTestPopup === 'function') {
            openOtpTestPopup();
        } else {
            alert('❌ خطا: تابع Popup پیدا نشد. لطفاً صفحه را Refresh کنید.');
        }
    });
});
</script>