<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class DashboardPage
{
    public function __construct() {
        // بدون هیچ اکشنی - فقط برای رندر کردن صفحه
    }

    public function renderPage(): void {
        $total_users = count_users()['total_users'];
        $active_sessions = $this->getActiveSessionsCount();
        $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
        
        // پردازش فرم‌ها
        $this->handleFormSubmissions();
        ?>
        <div class="wrap loginpro-dashboard-wrap">
            <!-- هدر -->
            <div class="loginpro-dashboard-header">
                <h1 class="loginpro-dashboard-title">🚀 <?php esc_html_e('لاگین پرو', 'loginpro'); ?></h1>
                <p class="loginpro-dashboard-subtitle"><?php esc_html_e('سیستم پیشرفته احراز هویت، OTP و امنیت', 'loginpro'); ?></p>
            </div>

            <!-- آمار -->
            <div class="loginpro-stats-grid">
                <div class="loginpro-stat-card"><div class="loginpro-stat-icon">👥</div><div class="loginpro-stat-number"><?php echo number_format($total_users); ?></div><div class="loginpro-stat-label"><?php esc_html_e('کاربران', 'loginpro'); ?></div></div>
                <div class="loginpro-stat-card"><div class="loginpro-stat-icon">🟢</div><div class="loginpro-stat-number"><?php echo $active_sessions; ?></div><div class="loginpro-stat-label"><?php esc_html_e('جلسات فعال', 'loginpro'); ?></div></div>
                <div class="loginpro-stat-card"><div class="loginpro-stat-icon">📱</div><div class="loginpro-stat-number"><?php echo get_option('loginpro_method_sms_otp', true) ? '✓' : '✗'; ?></div><div class="loginpro-stat-label"><?php esc_html_e('ورود با پیامک', 'loginpro'); ?></div></div>
                <div class="loginpro-stat-card"><div class="loginpro-stat-icon">✉️</div><div class="loginpro-stat-number"><?php echo get_option('loginpro_method_email_otp', true) ? '✓' : '✗'; ?></div><div class="loginpro-stat-label"><?php esc_html_e('ورود با ایمیل', 'loginpro'); ?></div></div>
            </div>

            
            <div class="loginpro-tabs-wrapper">
                <div class="loginpro-tabs-header">
                    <?php 
                    $tabs = [
                        'dashboard'   => __('📊 داشبورد', 'loginpro'),
                        'auth'        => __('🔐 احراز هویت', 'loginpro'),
                        'security'    => __('🛡️ امنیت', 'loginpro'),
                        'appearance'  => __('🎨 ظاهر', 'loginpro'),
                        'otp'         => __('📱 کد یکبارمصرف', 'loginpro'),
                        'captcha'     => __('🤖 کپچا', 'loginpro'),
                        'whatsapp'    => __('💬 واتساپ', 'loginpro'),
                        'email'       => __('📧 ایمیل', 'loginpro'),
                        'social'      => __('🌐 شبکه‌های اجتماعی', 'loginpro'),
                        'maintenance' => __('🔒 حالت تعمیرات', 'loginpro'),
                        'pages'       => __('📄 صفحات', 'loginpro'),
                        'profile-tabs'=> __('📑 تب‌های کاربری', 'loginpro'),
                        'user-activity'=> __('👥 فعالیت کاربران', 'loginpro'),
                        'logs'        => __('📜 لاگ‌ها', 'loginpro'),
                        'queue'       => __('⏳ مدیریت صف', 'loginpro'),
                        'woocommerce' => __('🛒 ووکامرس', 'loginpro'),
                        'shortcodes'  => __('📝 شورت‌کدها', 'loginpro'),
                        'system'      => __('ℹ️ اطلاعات سیستم', 'loginpro')
                    ]; 
                    foreach ($tabs as $key => $label): 
                        $active_class = ($current_tab == $key) ? 'active' : '';
                        $url = add_query_arg(['page' => 'loginpro', 'tab' => $key], admin_url('admin.php'));
                    ?>
                        <a href="<?php echo esc_url($url); ?>" class="loginpro-tab-btn <?php echo $active_class; ?>" data-tab="<?php echo esc_attr($key); ?>">
                            <?php echo esc_html($label); ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <div class="loginpro-tabs-content">
                    <?php if ($current_tab == 'dashboard'): ?>
                        <div class="loginpro-tab-pane active">
                            <?php $this->renderDashboardContent(); ?>
                        </div>
                    <?php elseif ($current_tab == 'system'): ?>
                        <div class="loginpro-tab-pane active">
                            <?php $this->renderSystemInfo(); ?>
                        </div>
                    <?php else: ?>
                        <div class="loginpro-tab-pane active">
                            <?php $this->renderTabFile($current_tab); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <style>
            .loginpro-dashboard-wrap { max-width: 1400px; margin: 20px 20px 0 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            .loginpro-dashboard-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 16px; padding: 30px; margin-bottom: 30px; color: #fff; }
            .loginpro-dashboard-title { font-size: 24px; margin: 0 0 8px 0; font-weight: 600; }
            .loginpro-dashboard-subtitle { opacity: 0.9; margin: 0; font-size: 14px; }
            .loginpro-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px; }
            @media (max-width: 900px) { .loginpro-stats-grid { grid-template-columns: repeat(2, 1fr); } }
            .loginpro-stat-card { background: #fff; border-radius: 16px; padding: 20px; text-align: center; border: 1px solid #e2e8f0; box-shadow: 0 1px 2px rgba(0,0,0,0.05); transition: transform 0.2s; }
            .loginpro-stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
            .loginpro-stat-icon { font-size: 40px; margin-bottom: 10px; }
            .loginpro-stat-number { font-size: 28px; font-weight: 700; color: #1e293b; }
            .loginpro-stat-label { color: #64748b; font-size: 14px; margin-top: 5px; }
            .loginpro-tabs-wrapper { background: #fff; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; }
            .loginpro-tabs-header { background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 12px 20px; display: flex; flex-wrap: wrap; gap: 8px; }
            .loginpro-tab-btn { background: transparent; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-size: 13px; color: #475569; text-decoration: none; display: inline-block; transition: all 0.2s; font-weight: 500; }
            .loginpro-tab-btn:hover { background: #e2e8f0; color: #1e293b; text-decoration: none; }
            .loginpro-tab-btn.active { background: #2271b1; color: #fff; }
            .loginpro-tabs-content { padding: 25px; background: #fff; }
            @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
            .loginpro-tab-pane { animation: fadeIn 0.3s ease; }
            .loginpro-card { background: #fff; border-radius: 12px; padding: 20px; margin-bottom: 20px; border: 1px solid #e2e8f0; }
            .loginpro-card h3 { margin: 0 0 15px 0; font-size: 18px; color: #1e293b; }
            @media (max-width: 768px) {
                .loginpro-dashboard-header { padding: 20px; }
                .loginpro-tabs-header { overflow-x: auto; flex-wrap: nowrap; }
                .loginpro-tab-btn { flex-shrink: 0; white-space: nowrap; }
                .loginpro-tabs-content { padding: 15px; }
            }
        </style>
        <?php
    }

    // محتوای تب داشبورد
    private function renderDashboardContent(): void {
        $maintenance_enabled = get_option('loginpro_maintenance_enabled', false);
        ?>
        <div class="loginpro-card">
            <h3><?php esc_html_e('📊 خوش آمدید به لاگین پرو', 'loginpro'); ?></h3>
            <p><?php esc_html_e('سیستم پیشرفته احراز هویت با قابلیت‌های زیر:', 'loginpro'); ?></p>
            <ul style="margin-top: 15px; line-height: 1.8;">
                <li>✅ <?php esc_html_e('ورود با رمز عبور (ایمیل/موبایل)', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('ورود با کد یکبارمصرف (OTP) از طریق پیامک، واتساپ و ایمیل', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('اتصال به درگاه‌های پیامک SMS.ir و Kavenegar', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('اتصال به واتساپ Meta (Business API)', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('کپچا (reCAPTCHA, hCaptcha, Turnstile)', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('شبکه های اجتماعی (Google OAuth)', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('اتصال با ووکامرس برای احراز هویت در تسویه حساب', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('سیستم امنیتی با قفل شدن پس از تلاش ناموفق', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('لاگ‌گیری کامل از فعالیت‌ها', 'loginpro'); ?></li>
                <li>✅ <?php esc_html_e('حالت تعمیرات و ورود اجباری', 'loginpro'); ?></li>
            </ul>
            
            <?php if ($maintenance_enabled): ?>
            <div style="margin-top:15px;padding:15px 20px;background:#fff3cd;border:1px solid #ffc107;border-radius:8px;">
                <span style="font-weight:bold;">🔒 <?php esc_html_e('وضعیت:', 'loginpro'); ?></span>
                <span style="color:#856404;"><?php esc_html_e('حالت تعمیرات فعال است - فقط کاربران لاگین شده می‌توانند سایت را ببینند', 'loginpro'); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    // اطلاعات سیستم
    private function renderSystemInfo(): void {
        $maintenance_enabled = get_option('loginpro_maintenance_enabled', false);
        ?>
        <div class="loginpro-card">
            <h3><?php esc_html_e('ℹ️ اطلاعات سیستم', 'loginpro'); ?></h3>
            <table class="widefat" style="margin-top: 15px;">
                <tr><th style="width:250px"><?php esc_html_e('نسخه پلاگین', 'loginpro'); ?></th><td><?php echo LOGINPRO_VERSION; ?></td></tr>
                <tr><th><?php esc_html_e('نسخه وردپرس', 'loginpro'); ?></th><td><?php echo get_bloginfo('version'); ?></td></tr>
                <tr><th><?php esc_html_e('نسخه PHP', 'loginpro'); ?></th><td><?php echo PHP_VERSION; ?></td></tr>
                <tr><th><?php esc_html_e('ووکامرس', 'loginpro'); ?></th><td><?php echo class_exists('WooCommerce') ? esc_html__('✅ فعال', 'loginpro') : esc_html__('❌ غیرفعال', 'loginpro'); ?></td></tr>
                <tr><th><?php esc_html_e('فعال بودن دیباگ', 'loginpro'); ?></th><td><?php echo defined('WP_DEBUG') && WP_DEBUG ? esc_html__('✅ فعال', 'loginpro') : esc_html__('❌ غیرفعال', 'loginpro'); ?></td></tr>
                <tr><th><?php esc_html_e('حافظه کش', 'loginpro'); ?></th><td><?php echo defined('WP_CACHE') && WP_CACHE ? esc_html__('✅ فعال', 'loginpro') : esc_html__('❌ غیرفعال', 'loginpro'); ?></td></tr>
                <tr><th><?php esc_html_e('حالت تعمیرات', 'loginpro'); ?></th><td><?php echo $maintenance_enabled ? '<span style="color:#dc3545;">🔒 ' . esc_html__('فعال', 'loginpro') . '</span>' : esc_html__('✅ غیرفعال', 'loginpro'); ?></td></tr>
            </table>
        </div>
        <?php
    }

private function renderTabFile($tab_key): void {
    // مسیرهای احتمالی
    $paths = [
        WP_PLUGIN_DIR . '/loginpro-enterprise/admin/tabs/' . $tab_key . '.php',
        WP_PLUGIN_DIR . '/loginpro-enterprise/admin/tabs/tab-' . $tab_key . '.php',
        WP_PLUGIN_DIR . '/loginpro/admin/tabs/' . $tab_key . '.php',
        WP_PLUGIN_DIR . '/loginpro/admin/tabs/tab-' . $tab_key . '.php',
    ];
    
    // برای تب pages مسیرهای خاص
    if ($tab_key === 'pages') {
        $paths = array_merge([
            WP_PLUGIN_DIR . '/loginpro-enterprise/admin/tabs/pages.php',
            WP_PLUGIN_DIR . '/loginpro-enterprise/admin/tabs/tab-pages.php',
        ], $paths);
    }
    
    $tab_file = null;
    foreach ($paths as $path) {
        if (file_exists($path)) {
            $tab_file = $path;
            break;
        }
    }
    
    if ($tab_file) {
        include $tab_file;
    } else {
        echo '<div class="loginpro-card" style="text-align:center;padding:40px;">';
        echo '<h3>⚠️ فایل یافت نشد</h3>';
        echo '<p>تب: <code>' . esc_html($tab_key) . '</code></p>';
        echo '<p style="font-size:12px;color:#999;">مسیرهای جستجو شده:</p>';
        echo '<ul style="text-align:right;font-size:11px;color:#999;">';
        foreach ($paths as $path) {
            echo '<li>' . esc_html($path) . ' - ' . (file_exists($path) ? '✅' : '❌') . '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }
}

    private function handleFormSubmissions(): void {
        // فرم‌های مختلف در فایل‌های تب خودشان پردازش می‌شوند
    }
    
    private function getActiveSessionsCount(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_sessions';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) return 0;
        return intval($wpdb->get_var("SELECT COUNT(*) FROM $table"));
    }
}