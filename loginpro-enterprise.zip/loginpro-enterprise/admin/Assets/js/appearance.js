/**
 * LoginPro Appearance Settings - JavaScript
 * مدیریت تنظیمات ظاهری - کاملاً بدون jQuery
 * 
 * @package LoginPro
 * @version 3.0.19
 */

(function () {
    'use strict';

    // ==================================================
    // ✅ جلوگیری از بارگذاری مجدد
    // ==================================================
    if (window.loginproAppearanceLoaded) {
        return;
    }
    window.loginproAppearanceLoaded = true;

    // ==================================================
    // ✅ متغیرهای عمومی
    // ==================================================
    var $ = window.jQuery || null;

    // ==================================================
    // ✅ ابزارهای کمکی
    // ==================================================
    var AppUtils = {
        /**
         * نمایش پیام
         */
        showMessage: function (element, message, type) {
            if (!element) return;
            element.textContent = message;
            element.className = 'loginpro-save-status';
            if (type) {
                element.classList.add(type);
            }
            element.style.display = 'block';

            // مخفی کردن خودکار پس از 5 ثانیه
            if (type === 'success') {
                setTimeout(function () {
                    element.style.display = 'none';
                }, 5000);
            }
        },

        /**
         * غیرفعال کردن دکمه
         */
        disableButton: function (button, text) {
            if (!button) return;
            button.disabled = true;
            button._originalText = button.textContent;
            button.textContent = text || 'در حال ذخیره...';
        },

        /**
         * فعال کردن دکمه
         */
        enableButton: function (button) {
            if (!button) return;
            button.disabled = false;
            if (button._originalText) {
                button.textContent = button._originalText;
            }
        },

        /**
         * Ajax درخواست با Fetch API
         */
        ajax: function (action, data, callback) {
            var formData = new FormData();
            formData.append('action', action);

            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                    formData.append(key, data[key]);
                }
            }

            var ajaxurl = window.ajaxurl || '/wp-admin/admin-ajax.php';

            fetch(ajaxurl, {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            })
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('HTTP error ' + response.status);
                    }
                    return response.json();
                })
                .then(function (data) {
                    if (typeof callback === 'function') {
                        callback(null, data);
                    }
                })
                .catch(function (error) {
                    if (typeof callback === 'function') {
                        callback(error, null);
                    }
                });
        },

        /**
         * دریافت مقدار فرم
         */
        getFormData: function (form) {
            var data = {};
            var inputs = form.querySelectorAll('input, select, textarea');
            inputs.forEach(function (input) {
                var name = input.name;
                if (!name) return;

                if (input.type === 'checkbox' || input.type === 'radio') {
                    if (input.checked) {
                        data[name] = input.value || '1';
                    } else if (input.type === 'checkbox') {
                        data[name] = '0';
                    }
                } else {
                    data[name] = input.value;
                }
            });
            return data;
        }
    };

    // ==================================================
    // ✅ Color Picker (بدون jQuery)
    // ==================================================
    function initColorPickers() {
        var pickers = document.querySelectorAll('.loginpro-color-picker');

        pickers.forEach(function (input) {
            if (input.dataset.initialized) return;
            input.dataset.initialized = 'true';

            // ایجاد wrapper
            var wrapper = document.createElement('div');
            wrapper.className = 'loginpro-color-picker-wrapper';
            wrapper.style.cssText = 'display:flex;align-items:center;gap:10px;';

            // ایجاد دکمه انتخاب رنگ
            var pickerBtn = document.createElement('button');
            pickerBtn.type = 'button';
            pickerBtn.className = 'loginpro-color-btn';
            pickerBtn.style.cssText = 'width:36px;height:36px;border-radius:6px;border:2px solid #ddd;cursor:pointer;padding:0;background:' + input.value + ';flex-shrink:0;';

            // ایجاد input مخفی
            var colorInput = document.createElement('input');
            colorInput.type = 'color';
            colorInput.value = input.value;
            colorInput.style.cssText = 'position:absolute;opacity:0;pointer-events:none;width:0;height:0;';

            // قرار دادن عناصر در wrapper
            input.parentNode.insertBefore(wrapper, input);
            wrapper.appendChild(input);
            wrapper.appendChild(pickerBtn);
            wrapper.appendChild(colorInput);

            // رویدادها
            pickerBtn.addEventListener('click', function () {
                colorInput.click();
            });

            colorInput.addEventListener('input', function () {
                var value = this.value;
                input.value = value;
                pickerBtn.style.background = value;

                // Trigger change event
                var event = new Event('change', { bubbles: true });
                input.dispatchEvent(event);
            });

            // همگام‌سازی با تغییر دستی
            input.addEventListener('change', function () {
                var value = this.value;
                pickerBtn.style.background = value;
                colorInput.value = value;
            });
        });
    }

    // ==================================================
    // ✅ Toggle Custom CSS
    // ==================================================
    function initToggleCss() {
        var toggleCss = document.getElementById('enable_custom_css');
        var cssContainer = document.getElementById('custom_css_container');

        if (toggleCss && cssContainer) {
            toggleCss.addEventListener('change', function () {
                cssContainer.style.display = this.checked ? 'block' : 'none';
            });
        }
    }

    // ==================================================
    // ✅ Upload Button (بدون jQuery)
    // ==================================================
    function initUploadButtons() {
        var uploadBtns = document.querySelectorAll('.loginpro-upload-btn');

        uploadBtns.forEach(function (btn) {
            if (btn.dataset.initialized) return;
            btn.dataset.initialized = 'true';

            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var target = this.dataset.target;
                var input = document.getElementById(target);

                // بررسی وجود wp.media
                if (typeof wp !== 'undefined' && wp.media) {
                    var frame = wp.media({
                        title: 'انتخاب تصویر',
                        button: {
                            text: 'استفاده از تصویر'
                        },
                        multiple: false
                    });

                    frame.on('select', function () {
                        var attachment = frame.state().get('selection').first().toJSON();
                        if (input) {
                            input.value = attachment.url;
                            // Trigger change event
                            var event = new Event('change', { bubbles: true });
                            input.dispatchEvent(event);
                        }
                    });

                    frame.open();
                } else {
                    alert('لطفاً media library را بارگذاری کنید.');
                }
            });
        });
    }

    // ==================================================
    // ✅ Form Submit
    // ==================================================
    function initFormSubmit() {
        var form = document.getElementById('loginpro-appearance-form');
        var statusEl = document.getElementById('loginpro-save-status');
        var submitBtn = document.getElementById('loginpro-save-appearance');

        if (!form) return;

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            if (submitBtn) {
                AppUtils.disableButton(submitBtn, 'در حال ذخیره...');
            }

            if (statusEl) {
                statusEl.style.display = 'block';
                AppUtils.showMessage(statusEl, 'در حال ذخیره...', '');
            }

            // جمع‌آوری داده‌ها
            var formData = AppUtils.getFormData(form);
            formData['action'] = 'loginpro_save_appearance';

            // اضافه کردن nonce
            var nonce = form.querySelector('input[name="appearance_nonce"]');
            if (nonce) {
                formData['_wpnonce'] = nonce.value;
            }

            // ارسال درخواست
            AppUtils.ajax('loginpro_save_appearance', formData, function (error, response) {
                if (submitBtn) {
                    AppUtils.enableButton(submitBtn);
                }

                if (statusEl) {
                    if (error) {
                        AppUtils.showMessage(statusEl, 'خطا در ارتباط با سرور', 'error');
                        return;
                    }

                    if (response && response.success) {
                        var msg = response.data && response.data.message
                            ? response.data.message
                            : 'تنظیمات با موفقیت ذخیره شد';
                        AppUtils.showMessage(statusEl, msg, 'success');
                    } else {
                        var errorMsg = response && response.data && response.data.message
                            ? response.data.message
                            : 'خطا در ذخیره تنظیمات';
                        AppUtils.showMessage(statusEl, errorMsg, 'error');
                    }
                }
            });
        });
    }

    // ==================================================
    // ✅ Preview Update (Live Preview)
    // ==================================================
    function initLivePreview() {
        var form = document.getElementById('loginpro-appearance-form');
        var previewFrame = document.querySelector('.loginpro-preview-iframe');

        if (!form || !previewFrame) return;

        // جمع‌آوری تنظیمات و به‌روزرسانی preview
        var inputs = form.querySelectorAll('input, select, textarea');
        var previewTimer = null;

        inputs.forEach(function (input) {
            input.addEventListener('change', function () {
                clearTimeout(previewTimer);
                previewTimer = setTimeout(function () {
                    updatePreview();
                }, 500);
            });

            input.addEventListener('input', function () {
                clearTimeout(previewTimer);
                previewTimer = setTimeout(function () {
                    updatePreview();
                }, 500);
            });
        });

        function updatePreview() {
            var data = AppUtils.getFormData(form);
            var previewUrl = previewFrame.src.split('?')[0];
            var params = new URLSearchParams();
            params.set('loginpro_preview', '1');

            // اضافه کردن تنظیمات به URL
            for (var key in data) {
                if (data.hasOwnProperty(key) && data[key]) {
                    params.set('preview_' + key, data[key]);
                }
            }

            previewFrame.src = previewUrl + '?' + params.toString();
        }
    }

    // ==================================================
    // ✅ Tab Navigation (برای admin)
    // ==================================================
    function initTabNavigation() {
        var tabs = document.querySelectorAll('.loginpro-admin-tab');
        var contents = document.querySelectorAll('.loginpro-tab-content');

        if (tabs.length === 0 || contents.length === 0) return;

        tabs.forEach(function (tab) {
            tab.addEventListener('click', function (e) {
                e.preventDefault();

                // Remove active class from all tabs
                tabs.forEach(function (t) {
                    t.classList.remove('active');
                });

                // Hide all contents
                contents.forEach(function (c) {
                    c.style.display = 'none';
                });

                // Activate current tab
                this.classList.add('active');
                var target = this.dataset.target;
                var content = document.getElementById(target);
                if (content) {
                    content.style.display = 'block';
                }
            });
        });
    }

    // ==================================================
    // ✅ مقداردهی اولیه
    // ==================================================
    function init() {
        // صبر برای بارگذاری کامل DOM
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                initColorPickers();
                initToggleCss();
                initUploadButtons();
                initFormSubmit();
                initLivePreview();
                initTabNavigation();
            });
        } else {
            initColorPickers();
            initToggleCss();
            initUploadButtons();
            initFormSubmit();
            initLivePreview();
            initTabNavigation();
        }
    }

    // اجرا
    init();

    console.log('LoginPro: Appearance settings loaded (Vanilla JS)');

})();