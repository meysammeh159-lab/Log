/**
 * LoginPro Admin JavaScript
 * مدیریت پنل مدیریت - کاملاً بدون jQuery
 * 
 * @package LoginPro
 * @version 3.0.19
 */

(function () {
    'use strict';

    // ==================================================
    // ✅ جلوگیری از بارگذاری مجدد
    // ==================================================
    if (window.loginproAdminLoaded) {
        return;
    }
    window.loginproAdminLoaded = true;

    // ==================================================
    // ✅ متغیرهای عمومی
    // ==================================================
    var loginpro = window.loginpro_admin || {};

    // ==================================================
    // ✅ ابزارهای کمکی
    // ==================================================
    var AdminUtils = {
        /**
         * نمایش پیام
         */
        showNotice: function (message, type) {
            var container = document.getElementById('loginpro-admin-notices');
            if (!container) {
                container = document.createElement('div');
                container.id = 'loginpro-admin-notices';
                var wrap = document.querySelector('.wrap');
                if (wrap) {
                    wrap.insertBefore(container, wrap.firstChild);
                }
            }

            var notice = document.createElement('div');
            notice.className = 'notice notice-' + (type || 'info') + ' is-dismissible';
            notice.innerHTML = '<p>' + message + '</p>';

            // دکمه بستن
            var dismissBtn = document.createElement('button');
            dismissBtn.type = 'button';
            dismissBtn.className = 'notice-dismiss';
            dismissBtn.innerHTML = '<span class="screen-reader-text">بستن</span>';
            dismissBtn.addEventListener('click', function () {
                notice.remove();
            });
            notice.appendChild(dismissBtn);

            container.appendChild(notice);

            // حذف خودکار بعد از 5 ثانیه
            setTimeout(function () {
                if (notice.parentNode) {
                    notice.remove();
                }
            }, 5000);
        },

        /**
         * Ajax درخواست
         */
        ajax: function (action, data, callback) {
            var formData = new FormData();
            formData.append('action', action);

            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                    formData.append(key, data[key]);
                }
            }

            var ajaxurl = window.ajaxurl || '/wp-admin/admin-ajax.php';

            fetch(ajaxurl, {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            })
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('HTTP error ' + response.status);
                    }
                    return response.json();
                })
                .then(function (data) {
                    if (typeof callback === 'function') {
                        callback(null, data);
                    }
                })
                .catch(function (error) {
                    if (typeof callback === 'function') {
                        callback(error, null);
                    }
                });
        },

        /**
         * دریافت مقدار فرم
         */
        getFormData: function (form) {
            var data = {};
            var inputs = form.querySelectorAll('input, select, textarea');
            inputs.forEach(function (input) {
                var name = input.name;
                if (!name) return;

                if (input.type === 'checkbox' || input.type === 'radio') {
                    if (input.checked) {
                        data[name] = input.value || '1';
                    } else if (input.type === 'checkbox') {
                        data[name] = '0';
                    }
                } else {
                    data[name] = input.value;
                }
            });
            return data;
        },

        /**
         * فرمت کردن تاریخ
         */
        formatDate: function (dateString) {
            if (!dateString) return '-';
            var date = new Date(dateString);
            if (isNaN(date.getTime())) return dateString;
            return date.toLocaleDateString('fa-IR') + ' ' + date.toLocaleTimeString('fa-IR');
        },

        /**
         * ایمن‌سازی متن برای HTML
         */
        escapeHtml: function (text) {
            if (!text) return '';
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    };

    // ==================================================
    // ✅ Tab Navigation
    // ==================================================
    function initTabs() {
        var tabs = document.querySelectorAll('.loginpro-admin-tab');
        var contents = document.querySelectorAll('.loginpro-tab-content');
        var hash = window.location.hash.replace('#', '');

        if (tabs.length === 0) return;

        // تابع تغییر تب
        function switchTab(tabId) {
            tabs.forEach(function (tab) {
                var isActive = tab.dataset.target === tabId || tab.dataset.tab === tabId;
                tab.classList.toggle('active', isActive);
            });

            contents.forEach(function (content) {
                var isActive = content.id === tabId || content.dataset.tab === tabId;
                content.style.display = isActive ? 'block' : 'none';
            });

            // به‌روزرسانی URL
            if (history.pushState) {
                var url = window.location.href.split('#')[0] + '#' + tabId;
                history.pushState(null, '', url);
            }
        }

        // کلیک روی تب
        tabs.forEach(function (tab) {
            tab.addEventListener('click', function (e) {
                e.preventDefault();
                var target = this.dataset.target || this.dataset.tab;
                if (target) {
                    switchTab(target);
                }
            });
        });

        // فعال‌سازی تب بر اساس hash
        if (hash) {
            var targetTab = document.querySelector('.loginpro-admin-tab[data-target="' + hash + '"], .loginpro-admin-tab[data-tab="' + hash + '"]');
            if (targetTab) {
                switchTab(hash);
            }
        } else {
            // فعال‌سازی اولین تب
            var firstTab = document.querySelector('.loginpro-admin-tab');
            if (firstTab) {
                var target = firstTab.dataset.target || firstTab.dataset.tab;
                if (target) {
                    switchTab(target);
                }
            }
        }

        // بازگشت با دکمه back
        window.addEventListener('hashchange', function () {
            var newHash = window.location.hash.replace('#', '');
            if (newHash) {
                var targetTab = document.querySelector('.loginpro-admin-tab[data-target="' + newHash + '"], .loginpro-admin-tab[data-tab="' + newHash + '"]');
                if (targetTab) {
                    switchTab(newHash);
                }
            }
        });
    }

    // ==================================================
    // ✅ Logs Table - Toggle Details
    // ==================================================
    function initLogsTable() {
        var toggleBtns = document.querySelectorAll('.loginpro-log-toggle');

        toggleBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var target = document.getElementById(this.dataset.target);
                if (target) {
                    if (target.style.display === 'none') {
                        target.style.display = 'table-row';
                        this.textContent = '▲ مخفی کردن جزئیات';
                    } else {
                        target.style.display = 'none';
                        this.textContent = '▼ نمایش جزئیات';
                    }
                }
            });
        });
    }

    // ==================================================
    // ✅ Confirmation Dialogs
    // ==================================================
    function initConfirmDialogs() {
        var confirmBtns = document.querySelectorAll('[data-confirm]');

        confirmBtns.forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                var message = this.dataset.confirm || 'آیا از انجام این عملیات مطمئن هستید؟';
                if (!confirm(message)) {
                    e.preventDefault();
                    return false;
                }
                return true;
            });
        });
    }

    // ==================================================
    // ✅ Form Validation
    // ==================================================
    function initFormValidation() {
        var forms = document.querySelectorAll('.loginpro-validate-form');

        forms.forEach(function (form) {
            form.addEventListener('submit', function (e) {
                var valid = true;
                var required = form.querySelectorAll('[required]');

                required.forEach(function (input) {
                    var value = input.value.trim();
                    var errorEl = input.parentNode.querySelector('.loginpro-field-error');

                    if (!errorEl) {
                        errorEl = document.createElement('span');
                        errorEl.className = 'loginpro-field-error';
                        errorEl.style.cssText = 'color:#dc3545;font-size:12px;display:block;margin-top:4px;';
                        input.parentNode.appendChild(errorEl);
                    }

                    if (!value) {
                        valid = false;
                        errorEl.textContent = 'این فیلد الزامی است';
                        input.style.borderColor = '#dc3545';
                    } else {
                        errorEl.textContent = '';
                        input.style.borderColor = '';
                    }

                    // اعتبارسنجی ایمیل
                    if (input.type === 'email' && value) {
                        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                        if (!emailRegex.test(value)) {
                            valid = false;
                            errorEl.textContent = 'ایمیل معتبر وارد کنید';
                            input.style.borderColor = '#dc3545';
                        }
                    }
                });

                if (!valid) {
                    e.preventDefault();
                    // اسکرول به اولین خطا
                    var firstError = form.querySelector('[style*="border-color: #dc3545"]');
                    if (firstError) {
                        firstError.focus();
                    }
                    return false;
                }
                return true;
            });
        });
    }

    // ==================================================
    // ✅ Ajax Form Submission (generic)
    // ==================================================
    function initAjaxForms() {
        var forms = document.querySelectorAll('.loginpro-ajax-form');

        forms.forEach(function (form) {
            if (form.dataset.ajaxInitialized) return;
            form.dataset.ajaxInitialized = 'true';

            form.addEventListener('submit', function (e) {
                e.preventDefault();

                var submitBtn = form.querySelector('button[type="submit"]');
                var messageEl = form.querySelector('.loginpro-form-message');

                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.textContent = 'در حال ارسال...';
                }

                var action = form.dataset.action || 'loginpro_ajax';
                var data = AdminUtils.getFormData(form);

                // Add nonce if exists
                var nonce = form.querySelector('[name="_wpnonce"], [name="nonce"]');
                if (nonce) {
                    data['_wpnonce'] = nonce.value;
                }

                AdminUtils.ajax(action, data, function (error, response) {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = submitBtn.dataset.originalText || 'ارسال';
                    }

                    if (messageEl) {
                        if (error) {
                            messageEl.textContent = 'خطا در ارتباط با سرور';
                            messageEl.style.color = '#dc3545';
                            messageEl.style.display = 'block';
                            return;
                        }

                        if (response && response.success) {
                            messageEl.textContent = response.data.message || 'عملیات با موفقیت انجام شد';
                            messageEl.style.color = '#198754';
                            messageEl.style.display = 'block';

                            // Reload on success if needed
                            if (form.dataset.reloadOnSuccess === 'true') {
                                setTimeout(function () {
                                    window.location.reload();
                                }, 1500);
                            }
                        } else {
                            messageEl.textContent = response.data.message || 'خطا در انجام عملیات';
                            messageEl.style.color = '#dc3545';
                            messageEl.style.display = 'block';
                        }
                    }
                });
            });
        });
    }

    // ==================================================
    // ✅ Dashboard Widgets
    // ==================================================
    function initDashboardWidgets() {
        // به‌روزرسانی خودکار آمار
        var statsElements = document.querySelectorAll('.loginpro-stat-number');
        if (statsElements.length === 0) return;

        // بارگذاری آمار از API
        var dashboardData = document.getElementById('loginpro-dashboard-data');
        if (dashboardData) {
            var data = JSON.parse(dashboardData.textContent || '{}');
            statsElements.forEach(function (el) {
                var key = el.dataset.stat;
                if (key && data[key] !== undefined) {
                    el.textContent = data[key];
                }
            });
        }
    }

    // ==================================================
    // ✅ Search/Filter Table
    // ==================================================
    function initTableSearch() {
        var searchInput = document.getElementById('loginpro-table-search');
        var table = document.getElementById('loginpro-data-table');

        if (!searchInput || !table) return;

        searchInput.addEventListener('input', function () {
            var query = this.value.toLowerCase().trim();
            var rows = table.querySelectorAll('tbody tr');

            rows.forEach(function (row) {
                var text = row.textContent.toLowerCase();
                row.style.display = text.indexOf(query) > -1 ? '' : 'none';
            });
        });
    }

    // ==================================================
    // ✅ Bulk Actions
    // ==================================================
    function initBulkActions() {
        var checkAll = document.getElementById('loginpro-check-all');
        var checkboxes = document.querySelectorAll('.loginpro-bulk-checkbox');
        var bulkAction = document.getElementById('loginpro-bulk-action');
        var applyBtn = document.getElementById('loginpro-bulk-apply');

        if (checkAll && checkboxes.length) {
            checkAll.addEventListener('change', function () {
                checkboxes.forEach(function (cb) {
                    cb.checked = checkAll.checked;
                });
            });
        }

        if (applyBtn && bulkAction) {
            applyBtn.addEventListener('click', function () {
                var action = bulkAction.value;
                if (!action) {
                    alert('لطفاً یک عملیات انتخاب کنید');
                    return;
                }

                var selected = [];
                checkboxes.forEach(function (cb) {
                    if (cb.checked) {
                        selected.push(cb.value);
                    }
                });

                if (selected.length === 0) {
                    alert('لطفاً حداقل یک مورد را انتخاب کنید');
                    return;
                }

                if (!confirm('آیا از انجام این عملیات روی ' + selected.length + ' مورد مطمئن هستید؟')) {
                    return;
                }

                // ارسال درخواست
                var data = {
                    action: 'loginpro_bulk_action',
                    bulk_action: action,
                    ids: selected.join(','),
                    _wpnonce: document.getElementById('loginpro_bulk_nonce')?.value || ''
                };

                AdminUtils.ajax('loginpro_bulk_action', data, function (error, response) {
                    if (error) {
                        alert('خطا در انجام عملیات');
                        return;
                    }

                    if (response && response.success) {
                        alert(response.data.message || 'عملیات با موفقیت انجام شد');
                        window.location.reload();
                    } else {
                        alert(response.data.message || 'خطا در انجام عملیات');
                    }
                });
            });
        }
    }

    // ==================================================
    // ✅ Tooltips
    // ==================================================
    function initTooltips() {
        var tooltips = document.querySelectorAll('[data-tooltip]');

        tooltips.forEach(function (el) {
            el.addEventListener('mouseenter', function (e) {
                var tooltip = document.createElement('div');
                tooltip.className = 'loginpro-tooltip';
                tooltip.textContent = this.dataset.tooltip;
                tooltip.style.cssText = 'position:fixed;background:#333;color:#fff;padding:6px 12px;border-radius:4px;font-size:12px;z-index:9999;max-width:250px;pointer-events:none;';

                var rect = this.getBoundingClientRect();
                tooltip.style.top = (rect.top - 30) + 'px';
                tooltip.style.left = (rect.left + rect.width / 2 - tooltip.offsetWidth / 2) + 'px';

                document.body.appendChild(tooltip);
                this._tooltip = tooltip;
            });

            el.addEventListener('mouseleave', function () {
                if (this._tooltip && this._tooltip.parentNode) {
                    this._tooltip.remove();
                }
            });
        });
    }

    // ==================================================
    // ✅ مقداردهی اولیه
    // ==================================================
    function init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                initTabs();
                initLogsTable();
                initConfirmDialogs();
                initFormValidation();
                initAjaxForms();
                initDashboardWidgets();
                initTableSearch();
                initBulkActions();
                initTooltips();
            });
        } else {
            initTabs();
            initLogsTable();
            initConfirmDialogs();
            initFormValidation();
            initAjaxForms();
            initDashboardWidgets();
            initTableSearch();
            initBulkActions();
            initTooltips();
        }
    }

    init();

    console.log('LoginPro: Admin JS loaded (Vanilla JS)');

})();