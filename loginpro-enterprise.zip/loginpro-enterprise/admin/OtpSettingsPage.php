<?php
namespace LoginPro\Admin;

class OtpSettingsPage
{
    public function __construct($container = null) {}

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_otp'])) {
            check_admin_referer('loginpro_otp');
            
            update_option('loginpro_otp_length', (int) $_POST['otp_length']);
            update_option('loginpro_otp_type', sanitize_text_field($_POST['otp_type']));
            update_option('loginpro_otp_expiry', (int) $_POST['otp_expiry']);
            update_option('loginpro_otp_max_attempts', (int) $_POST['otp_max_attempts']);
            update_option('loginpro_otp_resend_delay', (int) $_POST['otp_resend_delay']);
            update_option('loginpro_otp_channel_sms', isset($_POST['otp_channel_sms']));
            update_option('loginpro_otp_channel_whatsapp', isset($_POST['otp_channel_whatsapp']));
            update_option('loginpro_otp_channel_email', isset($_POST['otp_channel_email']));
            update_option('loginpro_otp_default_channel', sanitize_text_field($_POST['otp_default_channel']));
            update_option('loginpro_otp_sms_template', sanitize_textarea_field($_POST['otp_sms_template'] ?? 'کد تأیید شما: {code}'));
            update_option('loginpro_otp_whatsapp_template', sanitize_textarea_field($_POST['otp_whatsapp_template'] ?? 'کد تأیید شما: {code}'));
            update_option('loginpro_otp_email_subject', sanitize_text_field($_POST['otp_email_subject'] ?? 'کد تأیید شما'));
            update_option('loginpro_otp_email_template', wp_kses_post($_POST['otp_email_template'] ?? '<h2>کد تأیید شما</h2><p>کد تأیید شما: <strong>{code}</strong></p><p>این کد تا 5 دقیقه معتبر است.</p>'));
            update_option('loginpro_otp_throttle_max_attempts', (int) $_POST['otp_throttle_max_attempts']);
            update_option('loginpro_otp_lockout_minutes', (int) $_POST['otp_lockout_minutes']);
            
            echo '<div class="notice notice-success"><p>تنظیمات کد یکبارمصرف با موفقیت ذخیره شد.</p></div>';
        }
        
        $otp_length = get_option('loginpro_otp_length', 6);
        $otp_type = get_option('loginpro_otp_type', 'numeric');
        $otp_expiry = get_option('loginpro_otp_expiry', 300);
        $otp_max_attempts = get_option('loginpro_otp_max_attempts', 3);
        $otp_resend_delay = get_option('loginpro_otp_resend_delay', 60);
        $otp_channel_sms = get_option('loginpro_otp_channel_sms', true);
        $otp_channel_whatsapp = get_option('loginpro_otp_channel_whatsapp', false);
        $otp_channel_email = get_option('loginpro_otp_channel_email', true);
        $otp_default_channel = get_option('loginpro_otp_default_channel', 'sms');
        $otp_sms_template = get_option('loginpro_otp_sms_template', 'کد تأیید شما: {code}');
        $otp_whatsapp_template = get_option('loginpro_otp_whatsapp_template', 'کد تأیید شما: {code}');
        $otp_email_subject = get_option('loginpro_otp_email_subject', 'کد تأیید شما');
        $otp_email_template = get_option('loginpro_otp_email_template', '<h2>کد تأیید شما</h2><p>کد تأیید شما: <strong>{code}</strong></p><p>این کد تا 5 دقیقه معتبر است.</p>');
        $otp_throttle_max_attempts = get_option('loginpro_otp_throttle_max_attempts', 5);
        $otp_lockout_minutes = get_option('loginpro_otp_lockout_minutes', 60);
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1>تنظیمات کد یکبارمصرف (OTP)</h1>
            <p class="loginpro-description">تنظیمات مربوط به تولید، ارسال و اعتبارسنجی کدهای یکبارمصرف</p>
            
            <form method="post">
                <?php wp_nonce_field('loginpro_otp'); ?>
                
                <div class="loginpro-admin-card">
                    <h2>⚙️ تنظیمات عمومی OTP</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="otp_length">طول کد OTP</label></th>
                            <td>
                                <input type="number" name="otp_length" id="otp_length" value="<?php echo $otp_length; ?>" min="4" max="8" class="loginpro-input-small">
                                <p class="loginpro-description">تعداد رقم کد یکبارمصرف (۴ تا ۸ رقم)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_type">نوع کد OTP</label></th>
                            <td>
                                <select name="otp_type" id="otp_type" class="loginpro-select">
                                    <option value="numeric" <?php selected($otp_type, 'numeric'); ?>>عددی (فقط اعداد)</option>
                                    <option value="alphanumeric" <?php selected($otp_type, 'alphanumeric'); ?>>حروف و اعداد</option>
                                    <option value="alpha" <?php selected($otp_type, 'alpha'); ?>>فقط حروف</option>
                                </select>
                                <p class="loginpro-description">نوع کاراکترهای کد یکبارمصرف</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_expiry">زمان انقضای کد</label></th>
                            <td>
                                <input type="number" name="otp_expiry" id="otp_expiry" value="<?php echo $otp_expiry; ?>" min="60" max="600" class="loginpro-input-small">
                                <p class="loginpro-description">زمان بر حسب ثانیه (پیش‌فرض: ۳۰۰ ثانیه = ۵ دقیقه)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_max_attempts">حداکثر تلاش برای تأیید</label></th>
                            <td>
                                <input type="number" name="otp_max_attempts" id="otp_max_attempts" value="<?php echo $otp_max_attempts; ?>" min="1" max="10" class="loginpro-input-small">
                                <p class="loginpro-description">تعداد دفعات مجاز برای وارد کردن کد اشتباه</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_resend_delay">تأخیر بین ارسال مجدد</label></th>
                            <td>
                                <input type="number" name="otp_resend_delay" id="otp_resend_delay" value="<?php echo $otp_resend_delay; ?>" min="30" max="300" class="loginpro-input-small">
                                <p class="loginpro-description">زمان انتظار برای ارسال مجدد کد (بر حسب ثانیه)</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h2>📡 کانال‌های ارسال OTP</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">کانال پیامک (SMS)</th>
                            <td>
                                <label class="loginpro-checkbox-label">
                                    <input type="checkbox" name="otp_channel_sms" value="1" <?php checked($otp_channel_sms, true); ?>>
                                    فعال کردن ارسال کد از طریق پیامک
                                </label>
                                <p class="loginpro-description">برای فعالسازی، تنظیمات درگاه پیامک را تکمیل کنید</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">کانال واتساپ (WhatsApp)</th>
                            <td>
                                <label class="loginpro-checkbox-label">
                                    <input type="checkbox" name="otp_channel_whatsapp" value="1" <?php checked($otp_channel_whatsapp, true); ?>>
                                    فعال کردن ارسال کد از طریق واتساپ
                                </label>
                                <p class="loginpro-description">برای فعالسازی، تنظیمات درگاه واتساپ را تکمیل کنید</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">کانال ایمیل (Email)</th>
                            <td>
                                <label class="loginpro-checkbox-label">
                                    <input type="checkbox" name="otp_channel_email" value="1" <?php checked($otp_channel_email, true); ?>>
                                    فعال کردن ارسال کد از طریق ایمیل
                                </label>
                                <p class="loginpro-description">برای فعالسازی، تنظیمات درگاه ایمیل را تکمیل کنید</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_default_channel">کانال پیش‌فرض</label></th>
                            <td>
                                <select name="otp_default_channel" id="otp_default_channel" class="loginpro-select">
                                    <option value="sms" <?php selected($otp_default_channel, 'sms'); ?>>پیامک (SMS)</option>
                                    <option value="whatsapp" <?php selected($otp_default_channel, 'whatsapp'); ?>>واتساپ (WhatsApp)</option>
                                    <option value="email" <?php selected($otp_default_channel, 'email'); ?>>ایمیل (Email)</option>
                                </select>
                                <p class="loginpro-description">کانالی که در صورت عدم انتخاب کاربر استفاده می‌شود</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h2>✏️ قالب پیام‌ها</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="otp_sms_template">قالب پیامک</label></th>
                            <td>
                                <textarea name="otp_sms_template" id="otp_sms_template" rows="3" class="loginpro-textarea-large" style="direction: ltr;"><?php echo esc_textarea($otp_sms_template); ?></textarea>
                                <p class="loginpro-description">متغیرهای قابل استفاده: <code>{code}</code> - <code>{site_name}</code></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_whatsapp_template">قالب واتساپ</label></th>
                            <td>
                                <textarea name="otp_whatsapp_template" id="otp_whatsapp_template" rows="3" class="loginpro-textarea-large" style="direction: ltr;"><?php echo esc_textarea($otp_whatsapp_template); ?></textarea>
                                <p class="loginpro-description">متغیرهای قابل استفاده: <code>{code}</code> - <code>{site_name}</code></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_email_subject">موضوع ایمیل</label></th>
                            <td>
                                <input type="text" name="otp_email_subject" id="otp_email_subject" value="<?php echo esc_attr($otp_email_subject); ?>" class="loginpro-input loginpro-input-full">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_email_template">قالب ایمیل</label></th>
                            <td>
                                <textarea name="otp_email_template" id="otp_email_template" rows="6" class="loginpro-textarea-large" style="font-family: monospace;"><?php echo esc_textarea($otp_email_template); ?></textarea>
                                <p class="loginpro-description">متغیرهای قابل استفاده: <code>{code}</code> - <code>{site_name}</code> - <code>{site_url}</code></p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h2>🛡️ تنظیمات امنیتی</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="otp_throttle_max_attempts">حداکثر درخواست در ساعت</label></th>
                            <td>
                                <input type="number" name="otp_throttle_max_attempts" id="otp_throttle_max_attempts" value="<?php echo $otp_throttle_max_attempts; ?>" min="1" max="50" class="loginpro-input-small">
                                <p class="loginpro-description">حداکثر تعداد درخواست OTP برای هر شناسه در یک ساعت</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="otp_lockout_minutes">مدت زمان قفل شدن</label></th>
                            <td>
                                <input type="number" name="otp_lockout_minutes" id="otp_lockout_minutes" value="<?php echo $otp_lockout_minutes; ?>" min="5" max="1440" class="loginpro-input-small">
                                <p class="loginpro-description">مدت زمان قفل شدن پس از رسیدن به حداکثر تلاش (دقیقه)</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-form-actions">
                    <button type="submit" name="save_otp" class="button button-primary button-large">💾 ذخیره تنظیمات OTP</button>
                    <button type="button" id="test_otp" class="button button-secondary">📱 ارسال تست</button>
                </div>
            </form>
            
            <div id="test_result" class="loginpro-test-result loginpro-hidden"></div>
        </div>
        
        <?php 
        $admin_nonce = wp_create_nonce('loginpro_admin');
        ?>
        <script>
        var loginpro_admin_nonce = '<?php echo $admin_nonce; ?>';
        
        jQuery(document).ready(function($) {
            $('#test_otp').on('click', function() {
                var testMobile = prompt('شماره موبایل یا ایمیل تست را وارد کنید:', '');
                if (!testMobile) return;
                
                var resultDiv = $('#test_result');
                resultDiv.removeClass('loginpro-test-success loginpro-test-error').addClass('loginpro-test-info')
                    .html('⏳ در حال ارسال کد تست...').show();
                
                $.post(ajaxurl, {
                    action: 'loginpro_test_otp',
                    identifier: testMobile,
                    _nonce: loginpro_admin_nonce
                }, function(response) {
                    var message = response.message || response.data?.message || 'خطای ناشناخته';
                    
                    if (response.success) {
                        resultDiv.removeClass('loginpro-test-info loginpro-test-error').addClass('loginpro-test-success')
                            .html('✅ ' + message);
                    } else {
                        resultDiv.removeClass('loginpro-test-info loginpro-test-success').addClass('loginpro-test-error')
                            .html('❌ ' + message);
                    }
                    setTimeout(function() { resultDiv.fadeOut(); }, 5000);
                }).fail(function(xhr) {
                    var errorMsg = 'خطا در ارتباط با سرور';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMsg = xhr.responseJSON.message;
                    }
                    resultDiv.removeClass('loginpro-test-info loginpro-test-success').addClass('loginpro-test-error')
                        .html('❌ ' + errorMsg);
                    setTimeout(function() { resultDiv.fadeOut(); }, 5000);
                });
            });
        });
        </script>
        
        <style>
        .loginpro-admin-wrap { max-width: 960px; margin: 20px auto; }
        .loginpro-admin-card { background: #fff; border: 1px solid #c3c4c7; border-radius: 8px; padding: 20px 25px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .loginpro-admin-card h2 { margin-top: 0; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
        .loginpro-input-small { width: 100px; }
        .loginpro-input-full { width: 100%; max-width: 400px; }
        .loginpro-textarea-large { width: 100%; max-width: 500px; }
        .loginpro-select { min-width: 200px; }
        .loginpro-description { color: #646970; font-size: 13px; margin-top: 5px; }
        .loginpro-checkbox-label { display: block; padding: 5px 0; cursor: pointer; }
        .loginpro-checkbox-label input { margin-left: 8px; }
        .loginpro-form-actions { margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap; }
        .loginpro-test-result { margin-top: 15px; padding: 12px 15px; border-radius: 6px; font-weight: 500; }
        .loginpro-hidden { display: none; }
        .loginpro-test-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .loginpro-test-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .loginpro-test-info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
        </style>
        <?php
    }
}