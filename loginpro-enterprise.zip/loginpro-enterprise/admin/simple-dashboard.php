<?php
// تست ساده - مسیر: admin/simple-dashboard.php
function loginpro_simple_dashboard() {
    ?>
    <div class="wrap">
        <h1>📊 داشبورد لاگین پرو</h1>
        
        <div class="notice notice-success">
            <p>✅ افزونه با موفقیت فعال شد! فایل تست کار می‌کند.</p>
        </div>
        
        <div class="nav-tab-wrapper">
            <a href="?page=loginpro&tab=dashboard" class="nav-tab nav-tab-active">📊 داشبورد</a>
            <a href="?page=loginpro&tab=sms" class="nav-tab">📱 پیامک</a>
            <a href="?page=loginpro&tab=settings" class="nav-tab">⚙️ تنظیمات</a>
        </div>
        
        <div style="background:#fff; padding:20px; border:1px solid #ddd; margin-top:20px;">
            <?php
            $tab = isset($_GET['tab']) ? $_GET['tab'] : 'dashboard';
            
            if ($tab == 'dashboard') {
                echo '<h2>📊 داشبورد اصلی</h2>';
                echo '<p>به پنل مدیریت لاگین پرو خوش آمدید.</p>';
                echo '<ul><li>✅ سیستم احراز هویت فعال است</li><li>✅ ماژول OTP آماده است</li><li>✅ درگاه پیامک قابل تنظیم است</li></ul>';
            } elseif ($tab == 'sms') {
                echo '<h2>📱 تنظیمات پیامک</h2>';
                
                // ذخیره تنظیمات
                if (isset($_POST['save_sms'])) {
                    update_option('sms_api_key', sanitize_text_field($_POST['sms_api_key']));
                    echo '<div class="notice-success"><p>✅ تنظیمات ذخیره شد.</p></div>';
                }
                
                $api_key = get_option('sms_api_key', '');
                ?>
                <form method="post">
                    <table class="form-table">
                        <tr><th>کلید API:</th><td><input type="text" name="sms_api_key" value="<?php echo esc_attr($api_key); ?>" style="width:300px;"></div> </div>
                    </table>
                    <button type="submit" name="save_sms" class="button button-primary">💾 ذخیره تنظیمات</button>
                </form>
                <?php
            } else {
                echo '<h2>⚙️ تنظیمات</h2>';
                echo '<p>تنظیمات در حال تکمیل است...</p>';
            }
            ?>
        </div>
    </div>
    
    <style>
        .notice-success { background: #d4edda; color: #155724; padding: 12px; border-radius: 6px; margin: 15px 0; border-left: 4px solid #28a745; }
        .nav-tab-wrapper { margin-bottom: 20px; }
    </style>
    <?php
}