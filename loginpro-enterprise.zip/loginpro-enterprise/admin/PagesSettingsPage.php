<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class PagesSettingsPage
{
    private $container;

    public function __construct($container = null)
    {
        $this->container = $container;
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        // ذخیره تنظیمات
        if (isset($_POST['save_pages_settings']) && check_admin_referer('loginpro_pages_settings')) {
            $this->saveSettings();
            echo '<div class="notice notice-success is-dismissible"><p>تنظیمات صفحات با موفقیت ذخیره شد.</p></div>';
        }
        
        $settings = $this->getSettings();
        
        // تعیین تب فعال از طریق GET یا cookie
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1>تنظیمات صفحات و فرم‌های لاگین</h1>
            <p class="loginpro-description">تنظیمات مربوط به صفحات ورود، ثبت‌نام، پروفایل و نحوه نمایش فرم‌ها</p>
            
            <h2 class="nav-tab-wrapper" id="loginpro-tabs">
                <a href="#general" class="nav-tab <?php echo $active_tab == 'general' ? 'nav-tab-active' : ''; ?>" data-tab="general">
                    <span class="dashicons dashicons-admin-settings"></span> عمومی
                </a>
                <a href="#modal-button" class="nav-tab <?php echo $active_tab == 'modal-button' ? 'nav-tab-active' : ''; ?>" data-tab="modal-button">
                    <span class="dashicons dashicons-welcome-widgets-menus"></span> دکمه مودال
                </a>
                <a href="#display" class="nav-tab <?php echo $active_tab == 'display' ? 'nav-tab-active' : ''; ?>" data-tab="display">
                    <span class="dashicons dashicons-desktop"></span> نحوه نمایش
                </a>
                <a href="#pages" class="nav-tab <?php echo $active_tab == 'pages' ? 'nav-tab-active' : ''; ?>" data-tab="pages">
                    <span class="dashicons dashicons-admin-page"></span> لینک صفحات
                </a>
                <a href="#redirects" class="nav-tab <?php echo $active_tab == 'redirects' ? 'nav-tab-active' : ''; ?>" data-tab="redirects">
                    <span class="dashicons dashicons-controls-forward"></span> هدایت‌ها
                </a>
            </h2>
            
            <form method="post" id="pagesSettingsForm">
                <?php wp_nonce_field('loginpro_pages_settings'); ?>
                <input type="hidden" name="save_pages_settings" value="1">
                
                <!-- تب 1: عمومی -->
                <div id="tab-general" class="tab-content" style="<?php echo $active_tab == 'general' ? 'display: block;' : 'display: none;'; ?>">
                    <div class="loginpro-admin-card">
                        <h3>🔐 صفحه ورود وردپرس (wp-login.php)</h3>
                        <table class="form-table">
                            <tr>
                                <th scope="row">استفاده از فرم لاگین‌پرو</th>
                                <td>
                                    <label style="display:block;margin-bottom:10px;">
                                        <input type="radio" name="wp_login_mode" value="replace" <?php checked($settings['wp_login_mode'], 'replace'); ?>>
                                        <strong>🔁 جایگزینی کامل</strong>
                                        <p class="description">صفحه wp-login.php به طور کامل با فرم لاگین‌پرو جایگزین می‌شود</p>
                                    </label>
                                    <label style="display:block;margin-bottom:10px;">
                                        <input type="radio" name="wp_login_mode" value="override" <?php checked($settings['wp_login_mode'], 'override'); ?>>
                                        <strong>🎨 تغییر ظاهر</strong>
                                        <p class="description">فقط ظاهر صفحه wp-login تغییر می‌کند (رنگ‌ها، لوگو و...)</p>
                                    </label>
                                    <label style="display:block;margin-bottom:10px;">
                                        <input type="radio" name="wp_login_mode" value="default" <?php checked($settings['wp_login_mode'], 'default'); ?>>
                                        <strong>⚙️ حالت پیش‌فرض</strong>
                                        <p class="description">هیچ تغییری در wp-login ایجاد نمی‌شود</p>
                                    </label>
                                 </a>
                            </tr>
                            <tr>
                                <th scope="row">لوگو در صفحه wp-login</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="wp_login_custom_logo" value="1" <?php checked($settings['wp_login_custom_logo'], true); ?>>
                                        استفاده از لوگوی سفارشی سایت در صفحه ورود
                                    </label>
                                 </a>
                            </tr>
                            <tr>
                                <th scope="row">لینک بازگشت به سایت</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="wp_login_back_link" value="1" <?php checked($settings['wp_login_back_link'], true); ?>>
                                        نمایش لینک «بازگشت به سایت» در صفحه ورود
                                    </label>
                                 </a>
                            </tr>
                        </table>
                    </div>
                </div>
                
<!-- تب 2: دکمه مودال -->
<div id="tab-modal-button" class="tab-content" style="<?php echo $active_tab == 'modal-button' ? 'display: block;' : 'display: none;'; ?>">
    <div class="loginpro-admin-card">
        <h3>🔘 شورت‌کد دکمه مودال</h3>
        <p>برای نمایش دکمه باز کردن مودال لاگین در هر نقطه از سایت، از شورت‌کد زیر استفاده کنید:</p>
        
        <div style="background:#f0f7ff;padding:15px;margin:15px 0;border-radius:8px;">
            <code style="background:#fff;padding:8px 12px;border-radius:6px;display:inline-block;">[loginpro_modal_button]</code>
            <code style="background:#fff;padding:8px 12px;border-radius:6px;display:inline-block;margin-right:10px;">[loginpro_modal_button text="ورود / ثبت‌نام" class="my-button" icon="🔐"]</code>
        </div>
        
        <table class="form-table">
            <tr>
                <th scope="row">پارامترهای شورت‌کد</th>
                <td>
                    <ul style="margin:0;padding-right:20px;">
                        <li><code>text</code> - متن دکمه (پیش‌فرض: "ورود / ثبت‌نام")</li>
                        <li><code>logged_in_text</code> - متن دکمه برای کاربر وارد شده (پیش‌فرض: "پنل کاربری")</li>
                        <li><code>class</code> - کلاس CSS سفارشی برای دکمه</li>
                        <li><code>icon</code> - آیکون دکمه برای کاربر مهمان</li>
                        <li><code>logged_in_icon</code> - آیکون دکمه برای کاربر وارد شده</li>
                    </ul>
                </td>
            </tr>
        </table>
    </div>
</div>
                <!-- تب 3: نحوه نمایش -->
                <div id="tab-display" class="tab-content" style="<?php echo $active_tab == 'display' ? 'display: block;' : 'display: none;'; ?>">
                    <div class="loginpro-admin-card">
                        <h3>📱 نوع نمایش فرم لاگین</h3>
                        <table class="form-table">
                            <tr>
                                <th scope="row">نحوه نمایش پیش‌فرض</th>
                                <td>
                                    <label style="display:block;margin-bottom:10px;">
                                        <input type="radio" name="display_type" value="page" <?php checked($settings['display_type'], 'page'); ?>>
                                        <span>📄 صفحه مجزا</span>
                                        <p class="description">فرم در یک صفحه جداگانه نمایش داده می‌شود</p>
                                    </label>
                                    <label style="display:block;margin-bottom:10px;">
                                        <input type="radio" name="display_type" value="modal" <?php checked($settings['display_type'], 'modal'); ?>>
                                        <span>🪟 مودال (پنجره بازشو)</span>
                                        <p class="description">فرم در یک پنجره بازشو نمایش داده می‌شود</p>
                                    </label>
                                 </a>
                            </tr>
                        </table>
                        
                        <div id="modal_settings" style="margin-top:20px;padding-top:15px;border-top:1px solid #eee; <?php echo $settings['display_type'] == 'page' ? 'display:none;' : ''; ?>">
                            <h4>⚙️ تنظیمات مودال</h4>
                            <table class="form-table">
                                <tr>
                                    <th scope="row">عرض مودال</th>
                                    <td>
                                        <input type="number" name="modal_width" value="<?php echo esc_attr($settings['modal_width']); ?>" style="width:80px;"> px
                                        <p class="description">عرض پنجره مودال (پیش‌فرض: 500px)</p>
                                     </a>
                                </tr>
                                <tr>
                                    <th scope="row">گردی گوشه مودال</th>
                                    <td>
                                        <input type="number" name="modal_border_radius" value="<?php echo esc_attr($settings['modal_border_radius']); ?>" style="width:80px;"> px
                                        <p class="description">گردی گوشه پنجره مودال (پیش‌فرض: 16px)</p>
                                     </a>
                                </tr>
                                <tr>
                                    <th scope="row">بستن با کلیک بیرون</th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="modal_close_on_click" value="1" <?php checked($settings['modal_close_on_click'], true); ?>>
                                            بستن مودال با کلیک روی قسمت بیرونی
                                        </label>
                                     </a>
                                </tr>
                                <tr>
                                    <th scope="row">بستن با دکمه ESC</th>
                                    <td>
                                        <label>
                                            <input type="checkbox" name="modal_close_on_esc" value="1" <?php checked($settings['modal_close_on_esc'], true); ?>>
                                            بستن مودال با فشردن دکمه ESC
                                        </label>
                                     </a>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- تب 4: لینک صفحات -->
                <div id="tab-pages" class="tab-content" style="<?php echo $active_tab == 'pages' ? 'display: block;' : 'display: none;'; ?>">
                    <div class="loginpro-admin-card">
                        <h3>🔗 لینک صفحات</h3>
                        <p class="description">صفحاتی که شورت‌کدهای لاگین‌پرو در آنها قرار دارند</p>
                        
                        <table class="form-table">
                            <?php
                            $page_fields = [
                                'login_page_id' => 'صفحه ورود',
                                'register_page_id' => 'صفحه ثبت‌نام',
                                'profile_page_id' => 'پروفایل کاربری',
                                'reset_page_id' => 'بازیابی رمز عبور',
                            ];
                            
                            foreach ($page_fields as $field => $label):
                            ?>
                            <tr>
                                <th scope="row"><label><?php echo $label; ?></label></th>
                                <td>
                                    <?php
                                    wp_dropdown_pages([
                                        'name' => $field,
                                        'id' => $field,
                                        'show_option_none' => '— انتخاب صفحه —',
                                        'option_none_value' => '',
                                        'selected' => $settings[$field],
                                    ]);
                                    ?>
                                    <p class="description">
                                        صفحه‌ای که شورت‌کد <code>[loginpro_<?php echo str_replace('_page_id', '', $field); ?>]</code> در آن قرار دارد
                                    </p>
                                 </a>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                        
                        <div style="margin-top:20px;">
                            <button type="button" id="create_pages" class="button button-secondary">📄 ایجاد خودکار صفحات</button>
                        </div>
                    </div>
                </div>
                
                <!-- تب 5: هدایت‌ها -->
                <div id="tab-redirects" class="tab-content" style="<?php echo $active_tab == 'redirects' ? 'display: block;' : 'display: none;'; ?>">
                    <div class="loginpro-admin-card">
                        <h3>🔄 هدایت بعد از عملیات</h3>
                        <table class="form-table">
                            <tr>
                                <th scope="row">هدایت بعد از ورود</th>
                                <td>
                                    <select name="login_redirect" id="login_redirect_select" style="min-width:200px;">
                                        <option value="default" <?php selected($settings['login_redirect'], 'default'); ?>>صفحه پیش‌فرض (همان صفحه)</option>
                                        <option value="profile" <?php selected($settings['login_redirect'], 'profile'); ?>>پروفایل کاربری</option>
                                        <option value="home" <?php selected($settings['login_redirect'], 'home'); ?>>صفحه اصلی</option>
                                        <option value="custom" <?php selected($settings['login_redirect'], 'custom'); ?>>آدرس دلخواه</option>
                                    </select>
                                    <input type="url" name="login_redirect_url" value="<?php echo esc_url($settings['login_redirect_url']); ?>" placeholder="https://example.com" id="login_redirect_url" style="width:100%;margin-top:10px;<?php echo $settings['login_redirect'] != 'custom' ? 'display:none;' : ''; ?>">
                                 </a>
                            </tr>
                            <tr>
                                <th scope="row">هدایت بعد از ثبت‌نام</th>
                                <td>
                                    <select name="register_redirect" id="register_redirect_select" style="min-width:200px;">
                                        <option value="default" <?php selected($settings['register_redirect'], 'default'); ?>>صفحه پیش‌فرض (همان صفحه)</option>
                                        <option value="profile" <?php selected($settings['register_redirect'], 'profile'); ?>>پروفایل کاربری</option>
                                        <option value="home" <?php selected($settings['register_redirect'], 'home'); ?>>صفحه اصلی</option>
                                        <option value="custom" <?php selected($settings['register_redirect'], 'custom'); ?>>آدرس دلخواه</option>
                                    </select>
                                    <input type="url" name="register_redirect_url" value="<?php echo esc_url($settings['register_redirect_url']); ?>" placeholder="https://example.com" id="register_redirect_url" style="width:100%;margin-top:10px;<?php echo $settings['register_redirect'] != 'custom' ? 'display:none;' : ''; ?>">
                                 </a>
                            </tr>
                            <tr>
                                <th scope="row">هدایت بعد از خروج</th>
                                <td>
                                    <select name="logout_redirect" id="logout_redirect_select" style="min-width:200px;">
                                        <option value="default" <?php selected($settings['logout_redirect'], 'default'); ?>>صفحه پیش‌فرض (همان صفحه)</option>
                                        <option value="login" <?php selected($settings['logout_redirect'], 'login'); ?>>صفحه ورود</option>
                                        <option value="home" <?php selected($settings['logout_redirect'], 'home'); ?>>صفحه اصلی</option>
                                        <option value="custom" <?php selected($settings['logout_redirect'], 'custom'); ?>>آدرس دلخواه</option>
                                    </select>
                                    <input type="url" name="logout_redirect_url" value="<?php echo esc_url($settings['logout_redirect_url']); ?>" placeholder="https://example.com" id="logout_redirect_url" style="width:100%;margin-top:10px;<?php echo $settings['logout_redirect'] != 'custom' ? 'display:none;' : ''; ?>">
                                 </a>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <div style="margin-top:20px;padding:10px 0;">
                    <button type="submit" class="button button-primary button-large">💾 ذخیره تنظیمات صفحات</button>
                </div>
            </form>
        </div>
        
        <style>
        .nav-tab-wrapper {
            margin-bottom: 0;
            border-bottom: 1px solid #c3c4c7;
        }
        .nav-tab {
            padding: 8px 15px;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            cursor: pointer;
        }
        .nav-tab .dashicons {
            font-size: 16px;
            width: 16px;
            height: 16px;
        }
        .nav-tab-active {
            background: #fff;
            border-bottom-color: #fff;
        }
        .tab-content {
            background: #fff;
            border: 1px solid #c3c4c7;
            border-top: none;
            padding: 20px;
            border-radius: 0 0 8px 8px;
        }
        .loginpro-admin-card {
            background: #fff;
        }
        .loginpro-admin-card h3 {
            margin-top: 0;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .form-table th {
            width: 220px;
        }
        .description {
            color: #666;
            font-size: 12px;
            margin-top: 5px;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // ==================================================
            // تابع تغییر تب‌ها
            // ==================================================
            function switchTab(tabId) {
                // مخفی کردن همه تب‌ها
                $('.tab-content').hide();
                // نمایش تب انتخاب شده
                $('#tab-' + tabId).show();
                // غیرفعال کردن کلاس active از همه تب‌ها
                $('.nav-tab').removeClass('nav-tab-active');
                // فعال کردن کلاس active برای تب انتخاب شده
                $('.nav-tab[data-tab="' + tabId + '"]').addClass('nav-tab-active');
                // تغییر URL بدون رفرش صفحه
                if (typeof window.history.pushState === 'function') {
                    var url = new URL(window.location.href);
                    url.searchParams.set('tab', tabId);
                    window.history.pushState({}, '', url);
                }
            }
            
            // رویداد کلیک روی تب‌ها
            $('.nav-tab').on('click', function(e) {
                e.preventDefault();
                var tabId = $(this).data('tab');
                if (tabId) {
                    switchTab(tabId);
                }
            });
            
            // بررسی تب فعال از URL در هنگام لود صفحه
            var urlParams = new URLSearchParams(window.location.search);
            var activeTab = urlParams.get('tab');
            if (activeTab && $('#tab-' + activeTab).length) {
                switchTab(activeTab);
            }
            
            // ==================================================
            // سایر توابع
            // ==================================================
            
            // نمایش/مخفی کردن فیلد آدرس دلخواه
            $('#login_redirect_select').on('change', function() {
                $('#login_redirect_url').toggle($(this).val() === 'custom');
            });
            $('#register_redirect_select').on('change', function() {
                $('#register_redirect_url').toggle($(this).val() === 'custom');
            });
            $('#logout_redirect_select').on('change', function() {
                $('#logout_redirect_url').toggle($(this).val() === 'custom');
            });
            
            // نمایش/مخفی کردن تنظیمات مودال
            $('input[name="display_type"]').on('change', function() {
                $('#modal_settings').toggle($(this).val() !== 'page');
            });
            
            // آپدیت پیش‌نمایش دکمه
            function updatePreview() {
                var guestText = $('input[name="modal_btn_text"]').val() || 'ورود / ثبت‌نام';
                var guestIcon = $('input[name="modal_btn_icon"]').val() || '🔐';
                var loggedText = $('input[name="modal_btn_logged_text"]').val() || 'پنل کاربری';
                var loggedIcon = $('input[name="modal_btn_logged_icon"]').val() || '👤';
                
                $('#preview_guest_btn').html(guestIcon + ' ' + guestText);
                $('#preview_logged_btn').html(loggedIcon + ' ' + loggedText);
            }
            
            $(document).on('change keyup', 'input[name="modal_btn_text"], input[name="modal_btn_icon"], input[name="modal_btn_logged_text"], input[name="modal_btn_logged_icon"]', updatePreview);
            
            // ایجاد خودکار صفحات
            $('#create_pages').on('click', function() {
                if (confirm('آیا از ایجاد خودکار صفحات مورد نیاز مطمئن هستید؟')) {
                    $.post(ajaxurl, {
                        action: 'loginpro_create_pages',
                        _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'
                    }, function(response) {
                        if (response.success) {
                            alert(response.data?.message || 'صفحات با موفقیت ایجاد شدند');
                            location.reload();
                        } else {
                            alert('خطا: ' + (response.data?.message || 'مشخص نیست'));
                        }
                    }).fail(function() {
                        alert('خطا در ارتباط با سرور');
                    });
                }
            });
        });
        </script>
        <?php
    }
    
    private function getSettings()
    {
        return [
            // تنظیمات wp-login
            'wp_login_mode' => get_option('loginpro_wp_login_mode', 'default'),
            'wp_login_custom_logo' => get_option('loginpro_wp_login_custom_logo', true),
            'wp_login_back_link' => get_option('loginpro_wp_login_back_link', true),
            
            // تنظیمات نمایش
            'display_type' => get_option('loginpro_display_type', 'modal'),
            'modal_width' => get_option('loginpro_modal_width', 500),
            'modal_border_radius' => get_option('loginpro_modal_border_radius', 16),
            'modal_close_on_click' => get_option('loginpro_modal_close_on_click', true),
            'modal_close_on_esc' => get_option('loginpro_modal_close_on_esc', true),
            
            // تنظیمات دکمه مودال
            'modal_btn_text' => get_option('loginpro_modal_btn_text', 'ورود / ثبت‌نام'),
            'modal_btn_logged_text' => get_option('loginpro_modal_btn_logged_text', 'پنل کاربری'),
            'modal_btn_icon' => get_option('loginpro_modal_btn_icon', '🔐'),
            'modal_btn_logged_icon' => get_option('loginpro_modal_btn_logged_icon', '👤'),
            
            // صفحات
            'login_page_id' => get_option('loginpro_login_page_id', 0),
            'register_page_id' => get_option('loginpro_register_page_id', 0),
            'profile_page_id' => get_option('loginpro_profile_page_id', 0),
            'reset_page_id' => get_option('loginpro_reset_page_id', 0),
            
            // هدایت‌ها
            'login_redirect' => get_option('loginpro_login_redirect', 'default'),
            'login_redirect_url' => get_option('loginpro_login_redirect_url', ''),
            'register_redirect' => get_option('loginpro_register_redirect', 'default'),
            'register_redirect_url' => get_option('loginpro_register_redirect_url', ''),
            'logout_redirect' => get_option('loginpro_logout_redirect', 'default'),
            'logout_redirect_url' => get_option('loginpro_logout_redirect_url', '')
        ];
    }
    
    private function saveSettings()
    {
        // تنظیمات wp-login
        if (isset($_POST['wp_login_mode'])) {
            update_option('loginpro_wp_login_mode', sanitize_text_field($_POST['wp_login_mode']));
        }
        update_option('loginpro_wp_login_custom_logo', isset($_POST['wp_login_custom_logo']));
        update_option('loginpro_wp_login_back_link', isset($_POST['wp_login_back_link']));
        
        // تنظیمات نمایش
        if (isset($_POST['display_type'])) {
            update_option('loginpro_display_type', sanitize_text_field($_POST['display_type']));
        }
        if (isset($_POST['modal_width'])) {
            update_option('loginpro_modal_width', (int) $_POST['modal_width']);
        }
        if (isset($_POST['modal_border_radius'])) {
            update_option('loginpro_modal_border_radius', (int) $_POST['modal_border_radius']);
        }
        update_option('loginpro_modal_close_on_click', isset($_POST['modal_close_on_click']));
        update_option('loginpro_modal_close_on_esc', isset($_POST['modal_close_on_esc']));
        
        // تنظیمات دکمه مودال
        if (isset($_POST['modal_btn_text'])) {
            update_option('loginpro_modal_btn_text', sanitize_text_field($_POST['modal_btn_text']));
        }
        if (isset($_POST['modal_btn_logged_text'])) {
            update_option('loginpro_modal_btn_logged_text', sanitize_text_field($_POST['modal_btn_logged_text']));
        }
        if (isset($_POST['modal_btn_icon'])) {
            update_option('loginpro_modal_btn_icon', sanitize_text_field($_POST['modal_btn_icon']));
        }
        if (isset($_POST['modal_btn_logged_icon'])) {
            update_option('loginpro_modal_btn_logged_icon', sanitize_text_field($_POST['modal_btn_logged_icon']));
        }
        
        // صفحات
        $page_fields = ['login_page_id', 'register_page_id', 'profile_page_id', 'reset_page_id'];
        foreach ($page_fields as $field) {
            if (isset($_POST[$field])) {
                update_option('loginpro_' . $field, (int) $_POST[$field]);
            }
        }
        
        // هدایت‌ها
        if (isset($_POST['login_redirect'])) {
            update_option('loginpro_login_redirect', sanitize_text_field($_POST['login_redirect']));
        }
        if (isset($_POST['login_redirect_url'])) {
            update_option('loginpro_login_redirect_url', esc_url_raw($_POST['login_redirect_url']));
        }
        if (isset($_POST['register_redirect'])) {
            update_option('loginpro_register_redirect', sanitize_text_field($_POST['register_redirect']));
        }
        if (isset($_POST['register_redirect_url'])) {
            update_option('loginpro_register_redirect_url', esc_url_raw($_POST['register_redirect_url']));
        }
        if (isset($_POST['logout_redirect'])) {
            update_option('loginpro_logout_redirect', sanitize_text_field($_POST['logout_redirect']));
        }
        if (isset($_POST['logout_redirect_url'])) {
            update_option('loginpro_logout_redirect_url', esc_url_raw($_POST['logout_redirect_url']));
        }
    }
}