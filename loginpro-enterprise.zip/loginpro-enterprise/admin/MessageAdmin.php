<?php
/**
 * Message Admin Class - با فرم ارسال پیام
 * 
 * @package LoginPro
 * @version 3.0.14
 */

namespace LoginPro\Admin;

use Exception;

defined('ABSPATH') || exit;

class MessageAdmin {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('wp_ajax_loginpro_send_message', [$this, 'send_message']);
        add_action('wp_ajax_loginpro_get_messages', [$this, 'get_messages']);
    }
    
    public function add_admin_menu() {
        add_submenu_page(
            'loginpro',
            __('مدیریت پیام‌ها', 'loginpro'),
            __('پیام‌ها', 'loginpro'),
            'manage_options',
            'loginpro-messages',
            [$this, 'render_admin_page']
        );
    }
    
    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('شما دسترسی لازم را ندارید', 'loginpro'));
        }
        
        $nonce = wp_create_nonce('admin_messages_' . get_current_user_id());
        ?>
        <div class="wrap" data-nonce="<?php echo esc_attr($nonce); ?>">
            <h1><?php esc_html_e('📨 مدیریت پیام‌ها', 'loginpro'); ?></h1>
            
            <!-- ========================================== -->
            <!-- فرم ارسال پیام جدید -->
            <!-- ========================================== -->
            <div class="card" style="max-width:900px;margin:20px 0;background:#fff;padding:25px;border-radius:12px;border:1px solid #ddd;">
                <h2><?php esc_html_e('✉️ ارسال پیام جدید', 'loginpro'); ?></h2>
                
                <div id="message-form-container">
                    <div id="message-form-notice" style="display:none;padding:12px 16px;border-radius:8px;margin-bottom:15px;"></div>
                    
                    <form id="loginpro-send-message-form" method="post">
                        <table class="form-table">
                            <!-- ========================================== -->
                            <!-- انتخاب گروه گیرنده -->
                            <!-- ========================================== -->
                            <tr>
                                <th scope="row">
                                    <label><?php esc_html_e('گروه گیرنده', 'loginpro'); ?></label>
                                </th>
                                <td>
                                    <select id="msg_user_filter" name="user_filter" style="width:100%;max-width:400px;height:40px;padding:0 10px;">
                                        <option value="all">📋 <?php esc_html_e('تمام کاربران', 'loginpro'); ?></option>
                                        <option value="specific">🎯 <?php esc_html_e('انتخاب دستی', 'loginpro'); ?></option>
                                    </select>
                                    <p class="description"><?php esc_html_e('گروه کاربرانی که پیام برای آنها ارسال می‌شود', 'loginpro'); ?></p>
                                </td>
                            </tr>
                            
                            <!-- ========================================== -->
                            <!-- انتخاب دستی کاربران -->
                            <!-- ========================================== -->
                            <tr id="msg_users_row" style="display:none;">
                                <th scope="row">
                                    <label for="msg_selected_users"><?php esc_html_e('انتخاب کاربران', 'loginpro'); ?></label>
                                </th>
                                <td>
                                    <select id="msg_selected_users" name="selected_users[]" multiple style="width:100%;max-width:400px;height:120px;padding:5px;">
                                        <?php
                                        $users = get_users(['number' => 500, 'orderby' => 'display_name']);
                                        foreach ($users as $user) {
                                            if ($user->ID == get_current_user_id()) continue;
                                            echo '<option value="' . esc_attr($user->ID) . '">' . esc_html($user->display_name . ' (' . $user->user_email . ')') . '</option>';
                                        }
                                        ?>
                                    </select>
                                    <p class="description"><?php esc_html_e('برای انتخاب چند کاربر، کلید Ctrl یا Cmd را نگه دارید', 'loginpro'); ?></p>
                                    <p class="description" style="color:#999;font-size:12px;"><?php esc_html_e('تعداد کاربران انتخاب شده: ', 'loginpro'); ?><span id="selected_users_count">0</span></p>
                                </td>
                            </tr>
                            
                            <!-- ========================================== -->
                            <!-- تعداد گیرندگان -->
                            <!-- ========================================== -->
                            <tr>
                                <th scope="row">
                                    <label><?php esc_html_e('تعداد گیرندگان', 'loginpro'); ?></label>
                                </th>
                                <td>
                                    <strong id="recipient_count" style="font-size:18px;color:<?php echo esc_attr(get_option('loginpro_primary_color', '#ef394e')); ?>;">
                                        <?php echo count(get_users(['fields' => 'ID'])); ?>
                                    </strong>
                                    <span style="color:#666;"><?php esc_html_e('نفر', 'loginpro'); ?></span>
                                    <span id="recipient_list" style="display:block;font-size:12px;color:#999;margin-top:5px;"><?php esc_html_e('تمام کاربران', 'loginpro'); ?></span>
                                    <input type="hidden" id="msg_recipient_ids" name="recipient_ids" value="all">
                                </td>
                            </tr>
                            
                            <!-- ========================================== -->
                            <!-- موضوع -->
                            <!-- ========================================== -->
                            <tr>
                                <th scope="row">
                                    <label for="msg_subject"><?php esc_html_e('موضوع', 'loginpro'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="msg_subject" name="subject" style="width:100%;max-width:500px;height:40px;padding:0 10px;" placeholder="<?php esc_attr_e('موضوع پیام', 'loginpro'); ?>">
                                </td>
                            </tr>
                            
                            <!-- ========================================== -->
                            <!-- متن پیام -->
                            <!-- ========================================== -->
                            <tr>
                                <th scope="row">
                                    <label for="msg_content"><?php esc_html_e('متن پیام', 'loginpro'); ?></label>
                                </th>
                                <td>
                                    <textarea id="msg_content" name="message" rows="6" style="width:100%;max-width:600px;padding:10px;" placeholder="<?php esc_attr_e('متن پیام را وارد کنید...', 'loginpro'); ?>"></textarea>
                                    <p class="description"><?php esc_html_e('حداکثر 1000 کاراکتر', 'loginpro'); ?></p>
                                </td>
                            </tr>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" id="loginpro-send-msg-btn" class="button button-primary button-large">
                                📤 <?php esc_html_e('ارسال پیام', 'loginpro'); ?>
                            </button>
                            <span id="msg-send-loading" style="display:none;margin-left:10px;color:#666;"><?php esc_html_e('در حال ارسال...', 'loginpro'); ?></span>
                        </p>
                    </form>
                </div>
            </div>
            
            <!-- ========================================== -->
            <!-- لیست پیام‌ها -->
            <!-- ========================================== -->
            <div class="card" style="max-width:900px;margin:20px 0;background:#fff;padding:25px;border-radius:12px;border:1px solid #ddd;">
                <h2><?php esc_html_e('📋 لیست پیام‌ها', 'loginpro'); ?></h2>
                <div id="msg-list">
                    <?php echo $this->get_messages_list(); ?>
                </div>
            </div>
        </div>
        
        <style>
            .msg-row { border-bottom:1px solid #eee; }
            .msg-row td { padding:10px; vertical-align:middle; }
            .msg-status { display:inline-block;padding:2px 12px;border-radius:12px;font-size:11px;color:#fff; }
            .msg-status-read { background:#28a745; }
            .msg-status-unread { background:#ffc107;color:#333; }
            #message-form-notice { padding:12px 16px;border-radius:8px;margin-bottom:15px; }
            #message-form-notice.success { background:#f0fff4;color:#28a745;border:1px solid #c3e6cb; }
            #message-form-notice.error { background:#fff5f5;color:#dc3545;border:1px solid #f5c6cb; }
            #message-form-notice.info { background:#e3f2fd;color:#0d47a1;border:1px solid #90caf9; }
        </style>
        
        <script type="text/javascript">
        (function() {
            'use strict';
            
            var container = document.querySelector('.wrap');
            var nonce = container ? container.getAttribute('data-nonce') : '';
            var form = document.getElementById('loginpro-send-message-form');
            var btn = document.getElementById('loginpro-send-msg-btn');
            var loading = document.getElementById('msg-send-loading');
            var notice = document.getElementById('message-form-notice');
            
            var userFilter = document.getElementById('msg_user_filter');
            var usersRow = document.getElementById('msg_users_row');
            var selectedUsers = document.getElementById('msg_selected_users');
            var recipientsCount = document.getElementById('recipient_count');
            var recipientList = document.getElementById('recipient_list');
            var recipientIds = document.getElementById('msg_recipient_ids');
            var selectedCount = document.getElementById('selected_users_count');
            
            // ==========================================
            // مدیریت نمایش فیلدها بر اساس انتخاب
            // ==========================================
            userFilter.addEventListener('change', function() {
                var value = this.value;
                usersRow.style.display = (value === 'specific') ? 'table-row' : 'none';
                
                if (value === 'all') {
                    var totalUsers = <?php echo count(get_users(['fields' => 'ID'])); ?>;
                    recipientsCount.textContent = totalUsers;
                    recipientList.textContent = 'تمام کاربران';
                    recipientIds.value = 'all';
                } else {
                    recipientsCount.textContent = '0';
                    recipientList.textContent = 'لطفاً کاربران را انتخاب کنید';
                    recipientIds.value = '';
                    updateSelectedCount();
                }
            });
            
            // ==========================================
            // به‌روزرسانی تعداد کاربران انتخاب شده
            // ==========================================
            function updateSelectedCount() {
                var selected = selectedUsers.selectedOptions;
                var count = selected.length;
                var names = [];
                var ids = [];
                
                for (var i = 0; i < selected.length; i++) {
                    names.push(selected[i].text);
                    ids.push(selected[i].value);
                }
                
                if (selectedCount) selectedCount.textContent = count;
                recipientsCount.textContent = count;
                recipientList.textContent = names.join('، ');
                recipientIds.value = ids.join(',');
            }
            
            // ==========================================
            // تغییر انتخاب کاربران
            // ==========================================
            if (selectedUsers) {
                selectedUsers.addEventListener('change', updateSelectedCount);
            }
            
            // ==========================================
            // نمایش پیام
            // ==========================================
            function showNotice(message, type) {
                if (!notice) return;
                notice.style.display = 'block';
                notice.className = type;
                notice.textContent = message;
                setTimeout(function() {
                    notice.style.display = 'none';
                }, 5000);
            }
            
            // ==========================================
            // ارسال فرم
            // ==========================================
            if (form) {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    var filter = userFilter.value;
                    var subject = document.getElementById('msg_subject').value.trim();
                    var message = document.getElementById('msg_content').value.trim();
                    var ids = recipientIds.value;
                    
                    if (!ids || ids === '') {
                        showNotice('لطفاً گیرنده(های) را انتخاب کنید', 'error');
                        return;
                    }
                    
                    if (!subject) {
                        showNotice('لطفاً موضوع را وارد کنید', 'error');
                        return;
                    }
                    
                    if (!message) {
                        showNotice('لطفاً متن پیام را وارد کنید', 'error');
                        return;
                    }
                    
                    if (message.length > 1000) {
                        showNotice('متن پیام نباید بیشتر از 1000 کاراکتر باشد', 'error');
                        return;
                    }
                    
                    btn.disabled = true;
                    btn.textContent = '...';
                    loading.style.display = 'inline';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_send_message');
                    formData.append('_nonce', nonce);
                    formData.append('recipient_ids', ids);
                    formData.append('filter', filter);
                    formData.append('subject', subject);
                    formData.append('message', message);
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        btn.disabled = false;
                        btn.textContent = '📤 ارسال پیام';
                        loading.style.display = 'none';
                        
                        if (response.success) {
                            showNotice(response.data.message, 'success');
                            document.getElementById('msg_subject').value = '';
                            document.getElementById('msg_content').value = '';
                            
                            setTimeout(function() {
                                location.reload();
                            }, 2000);
                        } else {
                            showNotice(response.data.message, 'error');
                        }
                    })
                    .catch(function(error) {
                        btn.disabled = false;
                        btn.textContent = '📤 ارسال پیام';
                        loading.style.display = 'none';
                        showNotice('خطا در ارتباط با سرور: ' + error.message, 'error');
                    });
                });
            }
            
            // ==========================================
            // مقداردهی اولیه
            // ==========================================
            if (userFilter.value === 'specific') {
                usersRow.style.display = 'table-row';
            }
            
        })();
        </script>
        <?php
    }
    
    private function get_messages_list() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_messages';
        
        // بررسی وجود جدول
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            return '<p style="color:#999;">' . esc_html__('جدول پیام‌ها هنوز ایجاد نشده است.', 'loginpro') . '</p>';
        }
        
        $messages = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC LIMIT 50");
        
        if (empty($messages)) {
            return '<p style="color:#999;text-align:center;padding:30px 0;">' . esc_html__('📭 هیچ پیامی وجود ندارد.', 'loginpro') . '</p>';
        }
        
        $output = '<table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width:15%;">' . esc_html__('فرستنده', 'loginpro') . '</th>
                    <th style="width:15%;">' . esc_html__('گیرنده', 'loginpro') . '</th>
                    <th style="width:30%;">' . esc_html__('موضوع', 'loginpro') . '</th>
                    <th style="width:15%;">' . esc_html__('وضعیت', 'loginpro') . '</th>
                    <th style="width:25%;">' . esc_html__('تاریخ', 'loginpro') . '</th>
                </tr>
            </thead>
            <tbody>';
        
        foreach ($messages as $msg) {
            $from_user = get_userdata($msg->from_user_id);
            $to_user = get_userdata($msg->to_user_id);
            $from_name = $from_user ? $from_user->display_name : __('سیستم', 'loginpro');
            $to_name = $to_user ? $to_user->display_name : __('سیستم', 'loginpro');
            
            $status_class = $msg->is_read ? 'msg-status-read' : 'msg-status-unread';
            $status_text = $msg->is_read ? __('خوانده شده', 'loginpro') : __('خوانده نشده', 'loginpro');
            
            $output .= '<tr class="msg-row">
                <td>' . esc_html($from_name) . '</td>
                <td>' . esc_html($to_name) . '</td>
                <td><strong>' . esc_html($msg->subject) . '</strong></td>
                <td><span class="msg-status ' . $status_class . '">' . $status_text . '</span></td>
                <td>' . esc_html(date_i18n('j F Y ساعت H:i', strtotime($msg->created_at))) . '</td>
            </tr>';
        }
        
        $output .= '</tbody></table>';
        return $output;
    }
    
    public function send_message() {
        try {
            $user_id = get_current_user_id();
            
            // بررسی Nonce
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
            if (!wp_verify_nonce($nonce, 'admin_messages_' . $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید'], 403);
                return;
            }
            
            $recipient_ids = isset($_POST['recipient_ids']) ? $_POST['recipient_ids'] : '';
            $filter = sanitize_text_field($_POST['filter'] ?? 'all');
            $subject = sanitize_text_field($_POST['subject'] ?? '');
            $message = sanitize_textarea_field($_POST['message'] ?? '');
            
            if (empty($recipient_ids) || empty($subject) || empty($message)) {
                wp_send_json_error(['message' => 'لطفاً تمام فیلدها را پر کنید']);
                return;
            }
            
            // دریافت لیست کاربران
            if ($filter === 'all') {
                $users = get_users(['fields' => 'ID']);
                $user_ids = wp_list_pluck($users, 'ID');
            } else {
                $user_ids = array_map('intval', explode(',', $recipient_ids));
            }
            
            if (empty($user_ids)) {
                wp_send_json_error(['message' => 'هیچ کاربری برای ارسال پیام یافت نشد']);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_messages';
            
            // بررسی وجود جدول
            if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
                $this->create_messages_table();
            }
            
            $success_count = 0;
            $error_count = 0;
            
            foreach ($user_ids as $to_user_id) {
                $result = $wpdb->insert($table, [
                    'from_user_id' => $user_id,
                    'to_user_id' => $to_user_id,
                    'subject' => $subject,
                    'message' => $message,
                    'is_read' => 0,
                    'created_at' => current_time('mysql')
                ], ['%d', '%d', '%s', '%s', '%d', '%s']);
                
                if ($result) {
                    $success_count++;
                } else {
                    $error_count++;
                }
            }
            
            if ($success_count > 0) {
                wp_send_json_success([
                    'message' => sprintf(
                        __('✅ پیام با موفقیت برای %s کاربر ارسال شد', 'loginpro'),
                        number_format($success_count)
                    )
                ]);
            } else {
                wp_send_json_error(['message' => '❌ خطا در ارسال پیام']);
            }
            
        } catch (Exception $e) {
            wp_send_json_error(['message' => '❌ خطا: ' . $e->getMessage()], 500);
        }
    }
    
    public function get_messages() {
        try {
            $user_id = get_current_user_id();
            
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
            if (!wp_verify_nonce($nonce, 'admin_messages_' . $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید'], 403);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_messages';
            $messages = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE to_user_id = %d OR from_user_id = %d ORDER BY created_at DESC LIMIT 50",
                $user_id, $user_id
            ));
            
            wp_send_json_success(['messages' => $messages]);
            
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    private function create_messages_table() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_messages';
        $charset = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            from_user_id bigint(20) NOT NULL,
            to_user_id bigint(20) NOT NULL,
            subject varchar(255) NOT NULL,
            message text NOT NULL,
            is_read tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY from_user_id (from_user_id),
            KEY to_user_id (to_user_id)
        ) $charset;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}