<?php
namespace LoginPro\Admin;

class EmailProvidersPage
{
    private $container;
    private $nonceAction = 'loginpro_email_settings';

    public function __construct($container = null)
    {
        $this->container = $container;
        add_action('wp_ajax_loginpro_test_email', [$this, 'testEmail']);
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if (isset($_POST['save_email_settings']) && check_admin_referer($this->nonceAction)) {
            $this->saveSettings();
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('تنظیمات ایمیل با موفقیت ذخیره شد.', 'loginpro') . '</p></div>';
        }
        
        $selected = get_option('loginpro_email_default_provider', 'smtp');
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1><?php esc_html_e('تنظیمات درگاه ایمیل', 'loginpro'); ?></h1>
            <p class="loginpro-description"><?php esc_html_e('تنظیمات سرویس‌های ارسال ایمیل - فقط درگاه SMTP قابل تنظیم است', 'loginpro'); ?></p>
            
            <form method="post" class="loginpro-form">
                <?php wp_nonce_field($this->nonceAction); ?>
                
                <!-- انتخاب درگاه ایمیل -->
                <div class="loginpro-admin-card">
                    <h3 class="loginpro-card-title">📡 <?php esc_html_e('انتخاب درگاه ایمیل', 'loginpro'); ?></h3>
                    <div class="loginpro-form-row">
                        <div class="loginpro-form-label"><?php esc_html_e('درگاه ایمیل', 'loginpro'); ?></div>
                        <div class="loginpro-form-control">
                            <select name="default_provider" id="provider_select" class="loginpro-select" style="width: 300px;">
                                <option value="smtp" <?php selected($selected, 'smtp'); ?>>SMTP (اس ام تی پی)</option>
                                <option value="sendgrid" disabled>SendGrid (به زودی)</option>
                                <option value="mailgun" disabled>Mailgun (به زودی)</option>
                                <option value="ses" disabled>Amazon SES (به زودی)</option>
                                <option value="postmark" disabled>Postmark (به زودی)</option>
                            </select>
                            <span class="loginpro-help-text loginpro-help-info">ℹ️ <?php esc_html_e('تنها درگاه SMTP در حال حاضر فعال است.', 'loginpro'); ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- تنظیمات SMTP -->
                <div id="smtp_box" class="loginpro-admin-card">
                    <h3 class="loginpro-card-title">✅ <?php esc_html_e('تنظیمات SMTP', 'loginpro'); ?></h3>
                    
                    <div class="loginpro-settings-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <!-- ستون راست -->
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('سرور SMTP', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="text" name="smtp_host" value="<?php echo esc_attr(get_option('loginpro_email_smtp_host', 'smtp.gmail.com')); ?>" class="loginpro-input loginpro-input-full" placeholder="smtp.gmail.com">
                                    <span class="loginpro-help-text"><?php esc_html_e('مثال: smtp.gmail.com یا mail.yourdomain.com', 'loginpro'); ?></span>
                                </div>
                            </div>
                            
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('نام کاربری', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="text" name="smtp_username" value="<?php echo esc_attr(get_option('loginpro_email_smtp_username', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="info@site.com">
                                    <span class="loginpro-help-text"><?php esc_html_e('معمولاً ایمیل شما', 'loginpro'); ?></span>
                                </div>
                            </div>
                            
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('رمز عبور', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="password" name="smtp_password" value="<?php echo esc_attr(get_option('loginpro_email_smtp_password', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="••••••••">
                                    <span class="loginpro-help-text"><?php esc_html_e('رمز عبور ایمیل یا رمز برنامه (App Password)', 'loginpro'); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- ستون چپ -->
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('پورت', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="number" name="smtp_port" value="<?php echo esc_attr(get_option('loginpro_email_smtp_port', 587)); ?>" class="loginpro-input loginpro-input-full" placeholder="587" style="max-width: 200px;">
                                    <span class="loginpro-help-text"><?php esc_html_e('معمولاً 587 برای TLS و 465 برای SSL', 'loginpro'); ?></span>
                                </div>
                            </div>
                            
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('رمزنگاری', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <select name="smtp_encryption" class="loginpro-select loginpro-input-full" style="max-width: 200px;">
                                        <option value="tls" <?php selected(get_option('loginpro_email_smtp_encryption', 'tls'), 'tls'); ?>>TLS (توصیه شده)</option>
                                        <option value="ssl" <?php selected(get_option('loginpro_email_smtp_encryption', 'tls'), 'ssl'); ?>>SSL</option>
                                        <option value="none" <?php selected(get_option('loginpro_email_smtp_encryption', 'tls'), 'none'); ?>><?php esc_html_e('هیچکدام', 'loginpro'); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <hr style="margin: 20px 0;">
                    
                    <div class="loginpro-settings-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('ایمیل فرستنده', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="email" name="smtp_from_email" value="<?php echo esc_attr(get_option('loginpro_email_smtp_from_email', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="noreply@site.com">
                                    <span class="loginpro-help-text"><?php esc_html_e('ایمیلی که از طرف آن ایمیل ارسال می‌شود', 'loginpro'); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('نام فرستنده', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="text" name="smtp_from_name" value="<?php echo esc_attr(get_option('loginpro_email_smtp_from_name', get_bloginfo('name'))); ?>" class="loginpro-input loginpro-input-full" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>">
                                    <span class="loginpro-help-text"><?php esc_html_e('نامی که در ایمیل نمایش داده می‌شود', 'loginpro'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- تنظیمات جایگزین -->
                <div class="loginpro-admin-card">
                    <h3 class="loginpro-card-title">⚙️ <?php esc_html_e('تنظیمات جایگزین (در صورت خطا)', 'loginpro'); ?></h3>
                    <div class="loginpro-form-row">
                        <div class="loginpro-form-label"><?php esc_html_e('سرویس جایگزین', 'loginpro'); ?></div>
                        <div class="loginpro-form-control">
                            <select name="fallback_provider" class="loginpro-select" style="width: 300px;">
                                <option value=""><?php esc_html_e('هیچکدام - فقط SMTP', 'loginpro'); ?></option>
                                <option value="smtp" <?php selected(get_option('loginpro_email_fallback_provider', ''), 'smtp'); ?>>SMTP (همان سرویس اصلی)</option>
                            </select>
                            <span class="loginpro-help-text"><?php esc_html_e('در حال حاضر فقط SMTP پشتیبانی می‌شود', 'loginpro'); ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- تست ایمیل -->
                <div class="loginpro-admin-card">
                    <h3 class="loginpro-card-title">📧 <?php esc_html_e('تست تنظیمات ایمیل', 'loginpro'); ?></h3>
                    <div class="loginpro-form-row">
                        <div class="loginpro-form-label"><?php esc_html_e('ایمیل مقصد', 'loginpro'); ?></div>
                        <div class="loginpro-form-control">
                            <div class="loginpro-test-group" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                                <input type="email" id="test_email" placeholder="test@example.com" class="loginpro-input" style="width: 300px;">
                                <button type="button" id="send_test_email" class="button button-primary">📨 <?php esc_html_e('ارسال ایمیل تست', 'loginpro'); ?></button>
                            </div>
                            <span class="loginpro-help-text"><?php esc_html_e('قبل از تست، تنظیمات SMTP را ذخیره کنید.', 'loginpro'); ?></span>
                        </div>
                    </div>
                    <div id="test_result" class="loginpro-test-result" style="display: none; margin-top: 15px; padding: 12px; border-radius: 8px;"></div>
                </div>
                
                <div class="loginpro-form-actions" style="margin-top: 20px;">
                    <button type="submit" name="save_email_settings" class="button button-primary button-large">💾 <?php esc_html_e('ذخیره تنظیمات ایمیل', 'loginpro'); ?></button>
                </div>
            </form>
        </div>
        
        <style>
        .loginpro-admin-card {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .loginpro-admin-card h3 {
            margin-top: 0;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 1px solid #eee;
            font-size: 18px;
        }
        .loginpro-form-row {
            margin-bottom: 18px;
            display: flex;
            flex-wrap: wrap;
            align-items: flex-start;
        }
        .loginpro-form-label {
            width: 140px;
            font-weight: 600;
            padding-top: 8px;
            color: #23282d;
        }
        .loginpro-form-control {
            flex: 1;
            min-width: 250px;
        }
        .loginpro-input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            background: #fff;
        }
        .loginpro-input:focus {
            border-color: #2271b1;
            outline: none;
            box-shadow: 0 0 0 1px #2271b1;
        }
        .loginpro-input-full {
            width: 100%;
            max-width: 400px;
        }
        .loginpro-select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #fff;
            font-size: 14px;
        }
        .loginpro-help-text {
            display: block;
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .loginpro-help-info {
            color: #00669b;
            background: #e5f5fa;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
        }
        hr {
            border: none;
            border-top: 1px solid #eee;
            margin: 20px 0;
        }
        .loginpro-test-result {
            margin-top: 15px;
            padding: 12px;
            border-radius: 8px;
        }
        .loginpro-test-result.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .loginpro-test-result.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .loginpro-test-result.info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .notice-success {
            border-left-color: #46b450;
        }
        @media (max-width: 768px) {
            .loginpro-settings-grid {
                grid-template-columns: 1fr !important;
            }
            .loginpro-form-row {
                flex-direction: column;
            }
            .loginpro-form-label {
                width: 100%;
                margin-bottom: 8px;
            }
            .loginpro-form-control {
                width: 100%;
            }
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#send_test_email').on('click', function() {
                var email = $('#test_email').val();
                var resultDiv = $('#test_result');
                var button = $(this);
                
                if (!email) {
                    alert('<?php esc_html_e('لطفاً ایمیل مقصد را وارد کنید.', 'loginpro'); ?>');
                    return;
                }
                
                button.prop('disabled', true).text('⏳ <?php esc_html_e('در حال ارسال...', 'loginpro'); ?>');
                
                resultDiv.removeClass('success error info').addClass('info')
                    .html('⏳ <?php esc_html_e('در حال ارسال ایمیل تست... این فرآیند ممکن است چند ثانیه طول بکشد.', 'loginpro'); ?>').show();
                
                $.post(ajaxurl, {
                    action: 'loginpro_test_email',
                    email: email,
                    _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'
                }, function(response) {
                    button.prop('disabled', false).text('📨 <?php esc_html_e('ارسال ایمیل تست', 'loginpro'); ?>');
                    
                    if (response.success) {
                        resultDiv.removeClass('info error').addClass('success')
                            .html('✅ ' + response.message + '<br><br>📧 <?php esc_html_e('لطفاً صندوق ورودی ایمیل خود را بررسی کنید.', 'loginpro'); ?>');
                    } else {
                        resultDiv.removeClass('info success').addClass('error')
                            .html('❌ ' + response.message);
                    }
                }).fail(function() {
                    button.prop('disabled', false).text('📨 <?php esc_html_e('ارسال ایمیل تست', 'loginpro'); ?>');
                    resultDiv.removeClass('info success').addClass('error')
                        .html('❌ <?php esc_html_e('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.', 'loginpro'); ?>');
                });
            });
        });
        </script>
        <?php
    }
    
    private function saveSettings(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], $this->nonceAction)) {
            return;
        }
        
        // Default provider (فقط SMTP)
        update_option('loginpro_email_default_provider', 'smtp');
        
        // Fallback provider
        if (isset($_POST['fallback_provider'])) {
            update_option('loginpro_email_fallback_provider', sanitize_text_field($_POST['fallback_provider']));
        }
        
        // SMTP settings
        if (isset($_POST['smtp_host'])) {
            update_option('loginpro_email_smtp_host', sanitize_text_field($_POST['smtp_host']));
        }
        if (isset($_POST['smtp_port'])) {
            update_option('loginpro_email_smtp_port', (int) $_POST['smtp_port']);
        }
        if (isset($_POST['smtp_username'])) {
            update_option('loginpro_email_smtp_username', sanitize_text_field($_POST['smtp_username']));
        }
        if (isset($_POST['smtp_password']) && !empty($_POST['smtp_password'])) {
            update_option('loginpro_email_smtp_password', sanitize_text_field($_POST['smtp_password']));
        }
        if (isset($_POST['smtp_encryption'])) {
            update_option('loginpro_email_smtp_encryption', sanitize_text_field($_POST['smtp_encryption']));
        }
        if (isset($_POST['smtp_from_email'])) {
            update_option('loginpro_email_smtp_from_email', sanitize_email($_POST['smtp_from_email']));
        }
        if (isset($_POST['smtp_from_name'])) {
            update_option('loginpro_email_smtp_from_name', sanitize_text_field($_POST['smtp_from_name']));
        }
    }
    
    public function testEmail(): void
    {
        check_ajax_referer('loginpro_admin', '_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('دسترسی غیرمجاز', 'loginpro')]);
        }
        
        $email = sanitize_email($_POST['email']);
        
        if (empty($email) || !is_email($email)) {
            wp_send_json_error(['message' => __('ایمیل مقصد معتبر نیست', 'loginpro')]);
        }
        
        $subject = __('🧪 ایمیل تست - لاگین پرو', 'loginpro');
        $message = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Tahoma, Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; }
                .header { background: #ef394e; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; margin: -20px -20px 20px -20px; }
                .content { padding: 20px; }
                .footer { text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #999; }
                .success { color: #28a745; font-weight: bold; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2 style="margin: 0; color: white;">✨ لاگین پرو ✨</h2>
                </div>
                <div class="content">
                    <h3>🎉 ایمیل تست با موفقیت ارسال شد!</h3>
                    <p>اگر این ایمیل را مشاهده می‌کنید، یعنی تنظیمات SMTP شما <span class="success">به درستی کار می‌کند</span>.</p>
                    <p><strong>تنظیمات فعلی:</strong></p>
                    <ul>
                        <li>سرویس: <strong>SMTP</strong></li>
                        <li>سرور: <strong>' . esc_html(get_option('loginpro_email_smtp_host', 'smtp.gmail.com')) . '</strong></li>
                        <li>پورت: <strong>' . esc_html(get_option('loginpro_email_smtp_port', 587)) . '</strong></li>
                        <li>رمزنگاری: <strong>' . esc_html(get_option('loginpro_email_smtp_encryption', 'tls')) . '</strong></li>
                        <li>ایمیل فرستنده: <strong>' . esc_html(get_option('loginpro_email_smtp_from_email', '')) . '</strong></li>
                        <li>زمان ارسال: <strong>' . current_time('Y-m-d H:i:s') . '</strong></li>
                    </ul>
                    <p>✅ سیستم ارسال ایمیل شما آماده است.</p>
                </div>
                <div class="footer">
                    <p>این ایمیل توسط افزونه لاگین پرو ارسال شده است.</p>
                    <p>&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '</p>
                </div>
            </div>
        </body>
        </html>
        ';
        
        add_filter('wp_mail_content_type', function() {
            return 'text/html';
        });
        
        $from_email = get_option('loginpro_email_smtp_from_email', '');
        $from_name = get_option('loginpro_email_smtp_from_name', get_bloginfo('name'));
        
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        
        if (!empty($from_email)) {
            $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
        }
        
        $sent = wp_mail($email, $subject, $message, $headers);
        
        if ($sent) {
            wp_send_json_success(['message' => __('✅ ایمیل تست با موفقیت ارسال شد! صندوق ورودی خود را بررسی کنید.', 'loginpro')]);
        } else {
            wp_send_json_error(['message' => __('❌ ارسال ایمیل تست ناموفق بود. تنظیمات SMTP را بررسی کنید.', 'loginpro')]);
        }
    }
}