<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class QueuePage {
    
    private $container;
    
    public function __construct($container = null) {
        $this->container = $container;
    }
    
    public function render(): void {
        $this->renderPage();
    }
    
    public function renderPage() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'loginpro_queue';
        
        // بررسی وجود جدول
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
        
        if (!$table_exists) {
            echo '<div class="wrap"><div class="notice notice-warning"><p>' . 
                 esc_html__('جدول صف هنوز ایجاد نشده است. لطفاً افزونه را غیرفعال و دوباره فعال کنید.', 'loginpro') . 
                 '</p></div></div>';
            return;
        }
        
        $pending = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE available_at <= " . time() . " AND reserved_at IS NULL AND failed_at IS NULL");
        $processing = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE reserved_at IS NOT NULL AND completed_at IS NULL");
        $completed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE completed_at IS NOT NULL");
        $failed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE failed_at IS NOT NULL");
        
        $failedJobs = $wpdb->get_results("SELECT * FROM {$table} WHERE failed_at IS NOT NULL ORDER BY failed_at DESC LIMIT 50");
        $pendingJobs = $wpdb->get_results("SELECT * FROM {$table} WHERE available_at <= " . time() . " AND reserved_at IS NULL AND failed_at IS NULL ORDER BY available_at ASC LIMIT 50");
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1><?php esc_html_e('مدیریت صف', 'loginpro'); ?></h1>
            
            <div class="loginpro-queue-stats">
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number pending"><?php echo (int) $pending; ?></div>
                    <div><?php esc_html_e('در انتظار', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number processing"><?php echo (int) $processing; ?></div>
                    <div><?php esc_html_e('در حال پردازش', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number completed"><?php echo (int) $completed; ?></div>
                    <div><?php esc_html_e('تکمیل شده', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number failed"><?php echo (int) $failed; ?></div>
                    <div><?php esc_html_e('ناموفق', 'loginpro'); ?></div>
                </div>
            </div>
            
            <div class="loginpro-form-row loginpro-gap-10 loginpro-mb-20">
                <button id="run-queue-worker" class="button button-primary"><?php esc_html_e('اجرای پردازشگر صف', 'loginpro'); ?></button>
                <button id="retry-failed" class="button"><?php esc_html_e('تلاش مجدد برای کارهای ناموفق', 'loginpro'); ?></button>
                <button id="delete-failed" class="button"><?php esc_html_e('حذف کارهای ناموفق', 'loginpro'); ?></button>
                <button id="clear-queue" class="button"><?php esc_html_e('پاک کردن همه کارها', 'loginpro'); ?></button>
            </div>
            
            <div class="loginpro-admin-card loginpro-mb-20">
                <h3><?php esc_html_e('کارهای ناموفق', 'loginpro'); ?></h3>
                <?php if (empty($failedJobs)): ?>
                    <p><?php esc_html_e('هیچ کار ناموفقی وجود ندارد.', 'loginpro'); ?></p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr><th><?php esc_html_e('شناسه', 'loginpro'); ?></th><th><?php esc_html_e('نام کار', 'loginpro'); ?></th><th><?php esc_html_e('تلاش‌ها', 'loginpro'); ?></th><th><?php esc_html_e('زمان شکست', 'loginpro'); ?></th><th><?php esc_html_e('عملیات', 'loginpro'); ?></th></a>
                        </thead>
                        <tbody>
                        <?php foreach ($failedJobs as $job): ?>
                            <tr>
                                <td><?php echo (int) $job->id; ?></a>
                                <td><?php echo esc_html($job->job); ?></a>
                                <td><?php echo (int) $job->attempts . '/' . (int) $job->max_attempts; ?></a>
                                <td><?php echo $job->failed_at ? esc_html(date('Y-m-d H:i:s', (int) $job->failed_at)) : '-'; ?></a>
                                <td><button class="button button-small retry-job" data-id="<?php echo (int) $job->id; ?>"><?php esc_html_e('تلاش مجدد', 'loginpro'); ?></button> <button class="button button-small delete-job" data-id="<?php echo (int) $job->id; ?>"><?php esc_html_e('حذف', 'loginpro'); ?></button></a>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            
            <div class="loginpro-admin-card">
                <h3><?php esc_html_e('کارهای در انتظار', 'loginpro'); ?></h3>
                <?php if (empty($pendingJobs)): ?>
                    <p><?php esc_html_e('هیچ کار در انتظاری وجود ندارد.', 'loginpro'); ?></p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead><tr><th><?php esc_html_e('شناسه', 'loginpro'); ?></th><th><?php esc_html_e('نام کار', 'loginpro'); ?></th><th><?php esc_html_e('زمان قابل اجرا', 'loginpro'); ?></th></tr></thead>
                        <tbody>
                        <?php foreach ($pendingJobs as $job): ?>
                            <tr>
                                <td><?php echo (int) $job->id; ?></a>
                                <td><?php echo esc_html($job->job); ?></a>
                                <td><?php echo esc_html(date('Y-m-d H:i:s', (int) $job->available_at)); ?></a>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            
            <div id="queue-message" class="loginpro-test-result loginpro-hidden"></div>
        </div>
        
        <style>
        .loginpro-queue-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .loginpro-queue-stat {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
        }
        .loginpro-queue-stat-number {
            font-size: 28px;
            font-weight: bold;
        }
        .loginpro-queue-stat-number.pending { color: #2271b1; }
        .loginpro-queue-stat-number.processing { color: #f0b849; }
        .loginpro-queue-stat-number.completed { color: #00a32a; }
        .loginpro-queue-stat-number.failed { color: #d63638; }
        .loginpro-hidden { display: none; }
        .loginpro-mb-20 { margin-bottom: 20px; }
        .loginpro-gap-10 { gap: 10px; }
        .loginpro-test-result { margin-top: 15px; padding: 10px; border-radius: 4px; }
        .loginpro-test-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .loginpro-test-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            function showMessage(message, isError) {
                var msgDiv = $('#queue-message');
                msgDiv.removeClass('loginpro-test-success loginpro-test-error')
                    .addClass(isError ? 'loginpro-test-error' : 'loginpro-test-success')
                    .html(message).show();
                setTimeout(function() { msgDiv.fadeOut(); }, 3000);
            }
            
            $('#run-queue-worker').on('click', function() {
                $.post(ajaxurl, {action: 'loginpro_queue_action', task: 'run_worker', _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                    showMessage(response.message, !response.success);
                });
            });
            
            $('#retry-failed').on('click', function() {
                if (confirm('<?php esc_html_e('آیا از تلاش مجدد برای همه کارهای ناموفق مطمئن هستید؟', 'loginpro'); ?>')) {
                    $.post(ajaxurl, {action: 'loginpro_queue_action', task: 'retry_failed', _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                        showMessage(response.message, !response.success);
                        setTimeout(function() { location.reload(); }, 1500);
                    });
                }
            });
            
            $('#delete-failed').on('click', function() {
                if (confirm('<?php esc_html_e('آیا از حذف همه کارهای ناموفق مطمئن هستید؟', 'loginpro'); ?>')) {
                    $.post(ajaxurl, {action: 'loginpro_queue_action', task: 'delete_failed', _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                        showMessage(response.message, !response.success);
                        setTimeout(function() { location.reload(); }, 1500);
                    });
                }
            });
            
            $('#clear-queue').on('click', function() {
                if (confirm('<?php esc_html_e('آیا از پاک کردن همه کارهای صف مطمئن هستید؟', 'loginpro'); ?>')) {
                    $.post(ajaxurl, {action: 'loginpro_queue_action', task: 'clear_all', _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                        showMessage(response.message, !response.success);
                        setTimeout(function() { location.reload(); }, 1500);
                    });
                }
            });
            
            $('.retry-job').on('click', function() {
                var jobId = $(this).data('id');
                $.post(ajaxurl, {action: 'loginpro_queue_action', task: 'retry_job', job_id: jobId, _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                    showMessage(response.message, !response.success);
                    setTimeout(function() { location.reload(); }, 1500);
                });
            });
            
            $('.delete-job').on('click', function() {
                var jobId = $(this).data('id');
                if (confirm('<?php esc_html_e('آیا از حذف این کار مطمئن هستید؟', 'loginpro'); ?>')) {
                    $.post(ajaxurl, {action: 'loginpro_queue_action', task: 'delete_job', job_id: jobId, _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                        showMessage(response.message, !response.success);
                        setTimeout(function() { location.reload(); }, 1500);
                    });
                }
            });
        });
        </script>
        <?php
    }
}