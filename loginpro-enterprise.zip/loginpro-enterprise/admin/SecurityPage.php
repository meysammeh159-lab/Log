<?php
namespace LoginPro\Admin;

class SecurityPage
{
    public function __construct($container = null) {}

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_security'])) {
            check_admin_referer('loginpro_security');
            update_option('loginpro_bf_max_attempts', (int) $_POST['bf_max_attempts']);
            update_option('loginpro_bf_lockout_minutes', (int) $_POST['bf_lockout_minutes']);
            update_option('loginpro_session_timeout', (int) $_POST['session_timeout']);
            update_option('loginpro_max_sessions', (int) $_POST['max_sessions']);
            echo '<div class="notice notice-success"><p>تنظیمات امنیتی ذخیره شد.</p></div>';
        }
        
        $bf_max_attempts = get_option('loginpro_bf_max_attempts', 10);
        $bf_lockout_minutes = get_option('loginpro_bf_lockout_minutes', 15);
        $session_timeout = get_option('loginpro_session_timeout', 3600);
        $max_sessions = get_option('loginpro_max_sessions', 5);
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1>تنظیمات امنیتی</h1>
            <p class="loginpro-description">تنظیمات مربوط به امنیت، قفل شدن و محافظت در برابر حملات</p>
            
            <form method="post">
                <?php wp_nonce_field('loginpro_security'); ?>
                
                <div class="loginpro-admin-card">
                    <h2>محافظت در برابر حملات Brute Force</h2>
                    <table class="form-table">
                        <tr>
                            <th>حداکثر تلاش ناموفق</th>
                            <td><input type="number" name="bf_max_attempts" value="<?php echo $bf_max_attempts; ?>" class="loginpro-input-small"> تلاش</a>
                        </tr>
                        <tr>
                            <th>مدت زمان قفل شدن</th>
                            <td><input type="number" name="bf_lockout_minutes" value="<?php echo $bf_lockout_minutes; ?>" class="loginpro-input-small"> دقیقه</a>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h2>امنیت جلسه (Session)</h2>
                    <table class="form-table">
                        <tr>
                            <th>زمان خاتمه جلسه</th>
                            <td><input type="number" name="session_timeout" value="<?php echo $session_timeout; ?>" class="loginpro-input-small"> ثانیه</a>
                        </tr>
                        <tr>
                            <th>حداکثر جلسات همزمان</th>
                            <td><input type="number" name="max_sessions" value="<?php echo $max_sessions; ?>" class="loginpro-input-small"> جلسه</a>
                        </tr>
                    </table>
                </div>
                
                <button type="submit" name="save_security" class="button button-primary">💾 ذخیره تنظیمات</button>
            </form>
        </div>
        <?php
    }
}