<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class UserActivityPage {
    
    private $container;
    
    public function __construct($container = null) {
        $this->container = $container;
    }
    
    public function render(): void {
        $this->renderPage();
    }
    
    public function renderPage() {
        $users = get_users();
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1><?php esc_html_e('مانیتور فعالیت کاربران', 'loginpro'); ?></h1>
            <p class="loginpro-description"><?php esc_html_e('مشاهده و مدیریت فعالیت کاربران سایت', 'loginpro'); ?></p>
            
            <div class="loginpro-activity-grid">
                <div class="loginpro-activity-card">
                    <div class="loginpro-activity-number"><?php echo (int) count($users); ?></div>
                    <div class="loginpro-activity-label"><?php esc_html_e('کل کاربران', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-activity-card">
                    <div class="loginpro-activity-number">0</div>
                    <div class="loginpro-activity-label"><?php esc_html_e('آنلاین', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-activity-card">
                    <div class="loginpro-activity-number">0</div>
                    <div class="loginpro-activity-label"><?php esc_html_e('فعالیت مشکوک', 'loginpro'); ?></div>
                </div>
            </div>
            
            <div class="loginpro-admin-card">
                <h3><?php esc_html_e('لیست کاربران', 'loginpro'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('کاربر', 'loginpro'); ?></th>
                            <th><?php esc_html_e('ایمیل', 'loginpro'); ?></th>
                            <th><?php esc_html_e('نقش', 'loginpro'); ?></th>
                            <th><?php esc_html_e('عملیات', 'loginpro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo get_avatar($user->ID, 32); ?> <?php echo esc_html($user->display_name); ?></td>
                            <td><?php echo esc_html($user->user_email); ?></td>
                            <td><?php echo esc_html(implode(', ', $user->roles)); ?></td>
                            <td><a href="<?php echo esc_url(admin_url('user-edit.php?user_id=' . $user->ID)); ?>" class="button button-small"><?php esc_html_e('ویرایش', 'loginpro'); ?></a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <style>
        .loginpro-activity-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .loginpro-activity-card {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
        }
        .loginpro-activity-number {
            font-size: 28px;
            font-weight: bold;
            color: #2271b1;
        }
        .loginpro-activity-label {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
        </style>
        <?php
    }
}