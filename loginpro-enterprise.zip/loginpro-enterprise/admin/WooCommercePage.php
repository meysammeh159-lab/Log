<?php
namespace LoginPro\Admin;

class WooCommercePage
{
    private $container;

    public function __construct($container = null)
    {
        $this->container = $container;
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if (!class_exists('WooCommerce')) {
            echo '<div class="wrap loginpro-admin-wrap"><div class="notice notice-warning"><p>ووکامرس نصب و فعال نیست.</p></div></div>';
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_woocommerce']) && check_admin_referer('loginpro_woocommerce_settings')) {
            $this->saveSettings();
        }
        
        $settings = $this->getSettings();
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1>اتصال با ووکامرس</h1>
            <p class="loginpro-description">تنظیمات لاگین‌پرو برای تسویه حساب و بخش حساب کاربری ووکامرس</p>
            
            <form method="post">
                <?php wp_nonce_field('loginpro_woocommerce_settings'); ?>
                
                <div class="loginpro-woo-section loginpro-admin-card">
                    <h3>تأیید OTP در تسویه حساب</h3>
                    <table class="form-table">
                        <tr><th>فعال کردن OTP در تسویه حساب</th>
                        <td><label class="loginpro-checkbox-label"><input type="checkbox" name="checkout_otp_enabled" value="1" <?php checked($settings['checkout_otp_enabled'], true); ?>> نیاز به تأیید OTP قبل از تکمیل خرید</label></td></tr>
                        <tr><th>کانال ارسال OTP</th>
                        <td><select name="checkout_otp_channel" class="loginpro-select"><option value="sms" <?php selected($settings['checkout_otp_channel'], 'sms'); ?>>پیامک</option><option value="whatsapp" <?php selected($settings['checkout_otp_channel'], 'whatsapp'); ?>>واتساپ</option><option value="email" <?php selected($settings['checkout_otp_channel'], 'email'); ?>>ایمیل</option></select></a></td>
                        <tr><th>رد شدن برای کاربران وارد شده</th>
                        <td><label class="loginpro-checkbox-label"><input type="checkbox" name="skip_logged_in" value="1" <?php checked($settings['skip_logged_in'], true); ?>> رد شدن از تأیید OTP برای کاربرانی که وارد شده‌اند</label></a></td>
                    </table>
                </div>
                
                <div class="loginpro-woo-section loginpro-admin-card">
                    <h3>ایجاد خودکار کاربر</h3>
                    <table class="form-table">
                        <tr><th>ایجاد خودکار حساب</th>
                        <td><label class="loginpro-checkbox-label"><input type="checkbox" name="auto_create_user" value="1" <?php checked($settings['auto_create_user'], true); ?>> ایجاد خودکار حساب کاربری بعد از تأیید OTP</label></a></td>
                        <tr><th>نقش کاربر</th>
                        <td><select name="auto_user_role" class="loginpro-select"><?php wp_dropdown_roles($settings['auto_user_role']); ?></select></a></td>
                        <tr><th>ارسال ایمیل خوشآمدگویی</th>
                        <td><label class="loginpro-checkbox-label"><input type="checkbox" name="send_welcome_email" value="1" <?php checked($settings['send_welcome_email'], true); ?>> ارسال ایمیل خوشآمدگویی به کاربران جدید</label></a></td>
                    </a>
                </div>
                
                <div class="loginpro-woo-section loginpro-admin-card">
                    <h3>همگام‌سازی حساب</h3>
                    <table class="form-table">
                        <tr><th>همگام‌سازی تلفن صورتحساب</th>
                        <td><label class="loginpro-checkbox-label"><input type="checkbox" name="sync_billing_phone" value="1" <?php checked($settings['sync_billing_phone'], true); ?>> همگام‌سازی شماره تلفن صورتحساب با شماره موبایل کاربر</label></td>
                        <tr><th>همگام‌سازی ایمیل صورتحساب</th>
                        <td><label class="loginpro-checkbox-label"><input type="checkbox" name="sync_billing_email" value="1" <?php checked($settings['sync_billing_email'], true); ?>> همگام‌سازی ایمیل صورتحساب با حساب کاربری</label></td>
                        <tr><th>همگام‌سازی آدرس حمل‌ونقل</th>
                        <td><label class="loginpro-checkbox-label"><input type="checkbox" name="sync_shipping_address" value="1" <?php checked($settings['sync_shipping_address'], true); ?>> همگام‌سازی آدرس حمل‌ونقل با پروفایل کاربر</label></td>
                    </a>
                </div>
                
                <div class="loginpro-form-actions">
                    <button type="submit" name="save_woocommerce" class="button button-primary button-large">💾 ذخیره تنظیمات ووکامرس</button>
                </div>
            </form>
        </div>
        <?php
    }
    
    private function getSettings() {
        return [
            'checkout_otp_enabled' => get_option('loginpro_woo_checkout_otp', false),
            'checkout_otp_channel' => get_option('loginpro_woo_otp_channel', 'sms'),
            'skip_logged_in' => get_option('loginpro_woo_skip_logged_in', true),
            'auto_create_user' => get_option('loginpro_woo_auto_create_user', true),
            'auto_user_role' => get_option('loginpro_woo_auto_user_role', 'customer'),
            'send_welcome_email' => get_option('loginpro_woo_send_welcome_email', true),
            'sync_billing_phone' => get_option('loginpro_woo_sync_billing_phone', true),
            'sync_billing_email' => get_option('loginpro_woo_sync_billing_email', true),
            'sync_shipping_address' => get_option('loginpro_woo_sync_shipping_address', false)
        ];
    }
    
    private function saveSettings() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        update_option('loginpro_woo_checkout_otp', isset($_POST['checkout_otp_enabled']));
        update_option('loginpro_woo_otp_channel', sanitize_text_field($_POST['checkout_otp_channel']));
        update_option('loginpro_woo_skip_logged_in', isset($_POST['skip_logged_in']));
        update_option('loginpro_woo_auto_create_user', isset($_POST['auto_create_user']));
        update_option('loginpro_woo_auto_user_role', sanitize_text_field($_POST['auto_user_role']));
        update_option('loginpro_woo_send_welcome_email', isset($_POST['send_welcome_email']));
        update_option('loginpro_woo_sync_billing_phone', isset($_POST['sync_billing_phone']));
        update_option('loginpro_woo_sync_billing_email', isset($_POST['sync_billing_email']));
        update_option('loginpro_woo_sync_shipping_address', isset($_POST['sync_shipping_address']));
        
        echo '<div class="notice notice-success"><p>تنظیمات ووکامرس ذخیره شد.</p></div>';
    }
}