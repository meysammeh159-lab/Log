<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class DashboardWidget
{
    public function __construct()
    {
        add_action('wp_dashboard_setup', [$this, 'add_dashboard_widget']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_loginpro_get_dashboard_new_count', [$this, 'ajax_get_new_count']);
    }
    
    public function add_dashboard_widget()
    {
        wp_add_dashboard_widget(
            'loginpro_tickets_widget',
            '🎫 تیکت‌های پشتیبانی',
            [$this, 'render_widget']
        );
    }
    
    public function enqueue_scripts($hook)
    {
        if ($hook !== 'index.php') return;
        ?>
        <script>
        jQuery(document).ready(function($) {
            function checkNewTickets() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'loginpro_get_dashboard_new_count',
                        _nonce: '<?php echo wp_create_nonce('loginpro_dashboard'); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data.new_count > 0) {
                            $('#loginpro_tickets_widget .inside').prepend('<div style="background:#dc3545;color:#fff;padding:10px;text-align:center;margin:-12px -12px 10px -12px;">🔔 ' + response.data.new_count + ' پیام جدید</div>');
                        }
                    }
                });
            }
            setInterval(checkNewTickets, 30000);
            setTimeout(checkNewTickets, 3000);
        });
        </script>
        <?php
    }
    
    public function render_widget()
    {
        echo '<div style="padding:10px;text-align:center;">در حال بارگذاری...</div>';
    }
    
    public function ajax_get_new_count()
    {
        if (!check_ajax_referer('loginpro_dashboard', '_nonce', false)) {
            wp_send_json_error();
            return;
        }
        
        global $wpdb;
        $tickets_table = $wpdb->prefix . 'loginpro_tickets';
        $replies_table = $tickets_table . '_replies';
        
        $new_count = $wpdb->get_var("
            SELECT COUNT(*) FROM {$tickets_table} t
            WHERE EXISTS (
                SELECT 1 FROM {$replies_table} r 
                WHERE r.ticket_id = t.id AND r.is_admin = 0 
                AND r.created_at > IFNULL(t.admin_last_seen, t.created_at)
            )
        ");
        
        wp_send_json_success(['new_count' => intval($new_count)]);
    }
}