<?php
namespace LoginPro\Admin;

class AuthenticationPage
{
    public function __construct($container = null) {}

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_auth'])) {
            check_admin_referer('loginpro_auth');
            update_option('loginpro_method_email_password', isset($_POST['method_email_password']));
            update_option('loginpro_method_mobile_password', isset($_POST['method_mobile_password']));
            update_option('loginpro_method_email_otp', isset($_POST['method_email_otp']));
            update_option('loginpro_method_sms_otp', isset($_POST['method_sms_otp']));
            update_option('loginpro_method_magic_link', isset($_POST['method_magic_link']));
            update_option('users_can_register', isset($_POST['allow_registration']));
            update_option('loginpro_auto_login_register', isset($_POST['auto_login_register']));
            echo '<div class="notice notice-success"><p>تنظیمات با موفقیت ذخیره شد.</p></div>';
        }
        
        $method_email_password = get_option('loginpro_method_email_password', true);
        $method_mobile_password = get_option('loginpro_method_mobile_password', true);
        $method_email_otp = get_option('loginpro_method_email_otp', true);
        $method_sms_otp = get_option('loginpro_method_sms_otp', true);
        $method_magic_link = get_option('loginpro_method_magic_link', false);
        $allow_registration = get_option('users_can_register', true);
        $auto_login_register = get_option('loginpro_auto_login_register', true);
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1>تنظیمات احراز هویت</h1>
            <p class="loginpro-description">تنظیمات مربوط به روش‌های ورود و ثبت‌نام کاربران</p>
            
            <form method="post" class="loginpro-form">
                <?php wp_nonce_field('loginpro_auth'); ?>
                
                <div class="loginpro-admin-card">
                    <h2 class="loginpro-card-title">روش‌های ورود</h2>
                    <table class="loginpro-admin-table">
                        <tr>
                            <th>ورود با ایمیل و رمز عبور</th>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="method_email_password" value="1" <?php checked($method_email_password, true); ?>> فعال</label></td>
                        </tr>
                        <tr>
                            <th>ورود با موبایل و رمز عبور</th>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="method_mobile_password" value="1" <?php checked($method_mobile_password, true); ?>> فعال</label></td>
                        </tr>
                        <tr>
                            <th>ورود با کد یکبارمصرف (ایمیل)</th>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="method_email_otp" value="1" <?php checked($method_email_otp, true); ?>> فعال</label></td>
                        </tr>
                        <tr>
                            <th>ورود با کد یکبارمصرف (پیامک)</th>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="method_sms_otp" value="1" <?php checked($method_sms_otp, true); ?>> فعال</label></td>
                        </tr>
                        <tr>
                            <th>لینک جادویی (Magic Link)</th>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="method_magic_link" value="1" <?php checked($method_magic_link, true); ?>> فعال</label></td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-admin-card">
                    <h2 class="loginpro-card-title">تنظیمات ثبت‌نام</h2>
                    <table class="loginpro-admin-table">
                        <tr>
                            <th>اجازه ثبت‌نام</th>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="allow_registration" value="1" <?php checked($allow_registration, true); ?>> فعال کردن ثبت‌نام کاربر جدید</label></td>
                        </tr>
                        <tr>
                            <th>ورود خودکار بعد از ثبت‌نام</th>
                            <td><label class="loginpro-checkbox-label"><input type="checkbox" name="auto_login_register" value="1" <?php checked($auto_login_register, true); ?>> ورود خودکار کاربر بعد از ثبت‌نام</label></td>
                        </tr>
                    </table>
                </div>
                
                <div class="loginpro-form-actions">
                    <button type="submit" name="save_auth" class="button button-primary">💾 ذخیره تنظیمات</button>
                </div>
            </form>
        </div>
        <?php
    }
}