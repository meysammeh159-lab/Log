<?php
namespace LoginPro\Admin;

class WhatsAppProvidersPage
{
    private $container;
    private $nonceAction = 'loginpro_whatsapp_settings';

    public function __construct($container = null)
    {
        $this->container = $container;
        add_action('wp_ajax_loginpro_test_whatsapp', [$this, 'testWhatsApp']);
        add_action('wp_ajax_loginpro_test_whatsapp_connection', [$this, 'testConnection']);
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        if (isset($_POST['save_whatsapp_settings']) && check_admin_referer($this->nonceAction)) {
            $this->saveSettings();
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('تنظیمات واتساپ با موفقیت ذخیره شد.', 'loginpro') . '</p></div>';
        }
        
        $selected = get_option('loginpro_whatsapp_default_provider', 'meta');
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1><?php esc_html_e('تنظیمات واتساپ', 'loginpro'); ?></h1>
            <p class="loginpro-description"><?php esc_html_e('تنظیمات درگاه‌های ارسال پیام واتساپ', 'loginpro'); ?></p>
            
            <form method="post" class="loginpro-form">
                <?php wp_nonce_field($this->nonceAction); ?>
                
                <div class="loginpro-admin-card">
                    <h3 class="loginpro-card-title">📡 <?php esc_html_e('انتخاب درگاه واتساپ', 'loginpro'); ?></h3>
                    <div class="loginpro-form-row">
                        <div class="loginpro-form-label"><?php esc_html_e('درگاه پیش‌فرض', 'loginpro'); ?></div>
                        <div class="loginpro-form-control">
                            <select name="default_provider" id="provider_select" class="loginpro-select" style="width: 300px;">
                                <option value="meta" <?php selected($selected, 'meta'); ?>><?php esc_html_e('Meta Cloud API (WhatsApp Business)', 'loginpro'); ?></option>
                                <option value="twilio" <?php selected($selected, 'twilio'); ?> disabled><?php esc_html_e('Twilio WhatsApp (به زودی)', 'loginpro'); ?></option>
                                <option value="greenapi" <?php selected($selected, 'greenapi'); ?> disabled><?php esc_html_e('Green API (به زودی)', 'loginpro'); ?></option>
                            </select>
                            <span class="loginpro-help-text loginpro-help-info">ℹ️ <?php esc_html_e('تنها درگاه Meta Cloud API در حال حاضر فعال است.', 'loginpro'); ?></span>
                            <p class="loginpro-help-text loginpro-help-warning">⚠️ <?php esc_html_e('افزونه مسئولیتی در قبال هیچ یک از پنل‌های واتساپ ندارد.', 'loginpro'); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Meta Cloud API Box -->
                <div id="meta_box" class="provider_box loginpro-admin-card" <?php echo $selected != 'meta' ? 'style="display:none;"' : ''; ?>>
                    <h3 class="loginpro-card-title">✅ <?php esc_html_e('تنظیمات Meta Cloud API - WhatsApp Business', 'loginpro'); ?></h3>
                    <p class="loginpro-help-text"><?php esc_html_e('برای دریافت اطلاعات به', 'loginpro'); ?> <a href="https://developers.facebook.com/apps/" target="_blank">developers.facebook.com</a> <?php esc_html_e('مراجعه کنید.', 'loginpro'); ?></p>
                    
                    <div class="loginpro-settings-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('توکن دسترسی (Access Token)', 'loginpro'); ?> <span style="color:red;">*</span></div>
                                <div class="loginpro-form-control">
                                    <input type="text" name="meta_access_token" value="<?php echo esc_attr(get_option('loginpro_whatsapp_meta_access_token', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="EAxxxxxxxxxxxxxxxx">
                                    <span class="loginpro-help-text"><?php esc_html_e('توکن دسترسی بلندمدت از Meta Business Suite', 'loginpro'); ?></span>
                                </div>
                            </div>
                            
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('شناسه شماره تلفن (Phone Number ID)', 'loginpro'); ?> <span style="color:red;">*</span></div>
                                <div class="loginpro-form-control">
                                    <input type="text" name="meta_phone_number_id" value="<?php echo esc_attr(get_option('loginpro_whatsapp_meta_phone_number_id', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="123456789012345">
                                    <span class="loginpro-help-text"><?php esc_html_e('شناسه شماره تلفنی که در Meta Business ثبت شده است', 'loginpro'); ?></span>
                                </div>
                            </div>
                            
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('شناسه بیزینس (Business Account ID)', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="text" name="meta_business_account_id" value="<?php echo esc_attr(get_option('loginpro_whatsapp_meta_business_account_id', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="123456789012345">
                                    <span class="loginpro-help-text"><?php esc_html_e('اختیاری - شناسه حساب بیزینس Meta', 'loginpro'); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('شناسه اپلیکیشن (App ID)', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="text" name="meta_app_id" value="<?php echo esc_attr(get_option('loginpro_whatsapp_meta_app_id', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="123456789012345">
                                    <span class="loginpro-help-text"><?php esc_html_e('شناسه اپلیکیشن Meta', 'loginpro'); ?></span>
                                </div>
                            </div>
                            
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('شناسه اپلیکیشن مخفی (App Secret)', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="password" name="meta_app_secret" value="<?php echo esc_attr(get_option('loginpro_whatsapp_meta_app_secret', '')); ?>" class="loginpro-input loginpro-input-full" placeholder="****************">
                                    <span class="loginpro-help-text"><?php esc_html_e('در صورت تمایل خالی بگذارید تا تغییر نکند', 'loginpro'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="loginpro-form-row">
                        <div class="loginpro-form-label"><?php esc_html_e('الگوی پیام (Message Template)', 'loginpro'); ?></div>
                        <div class="loginpro-form-control">
                            <textarea name="meta_message_template" rows="4" class="loginpro-input loginpro-input-full" style="font-family: monospace; resize: vertical;"><?php echo esc_textarea(get_option('loginpro_whatsapp_meta_message_template', '✅ کد تأیید شما: %OTP%')); ?></textarea>
                            <span class="loginpro-help-text"><?php esc_html_e('متغیرهای قابل استفاده:', 'loginpro'); ?> <code>%OTP%</code> - <code>{NAME}</code> - <code>{DOMAIN}</code></span>
                        </div>
                    </div>
                </div>
                
                <!-- تنظیمات پیشرفته -->
                <div class="loginpro-admin-card">
                    <h3 class="loginpro-card-title">⚙️ <?php esc_html_e('تنظیمات پیشرفته', 'loginpro'); ?></h3>
                    
                    <div class="loginpro-settings-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('ترتیب سقوط (Fallback Order)', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <select name="fallback_order" class="loginpro-select">
                                        <option value="whatsapp,sms" <?php selected(get_option('loginpro_whatsapp_fallback_order', 'whatsapp,sms'), 'whatsapp,sms'); ?>>واتساپ → پیامک</option>
                                        <option value="whatsapp,email" <?php selected(get_option('loginpro_whatsapp_fallback_order', 'whatsapp,sms'), 'whatsapp,email'); ?>>واتساپ → ایمیل</option>
                                        <option value="whatsapp,sms,email" <?php selected(get_option('loginpro_whatsapp_fallback_order', 'whatsapp,sms'), 'whatsapp,sms,email'); ?>>واتساپ → پیامک → ایمیل</option>
                                    </select>
                                    <span class="loginpro-help-text"><?php esc_html_e('در صورت عدم موفقیت واتساپ، از کانال بعدی استفاده می‌شود', 'loginpro'); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="loginpro-settings-col">
                            <div class="loginpro-form-row">
                                <div class="loginpro-form-label"><?php esc_html_e('تعداد تلاش مجدد', 'loginpro'); ?></div>
                                <div class="loginpro-form-control">
                                    <input type="number" name="retry_attempts" value="<?php echo esc_attr(get_option('loginpro_whatsapp_retry_attempts', 3)); ?>" min="1" max="5" class="loginpro-input" style="width: 80px;">
                                    <span class="loginpro-help-text"><?php esc_html_e('بار', 'loginpro'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="loginpro-form-row">
                        <div class="loginpro-form-label"><?php esc_html_e('زمان انتظار بین تلاش‌ها', 'loginpro'); ?></div>
                        <div class="loginpro-form-control">
                            <input type="number" name="retry_delay" value="<?php echo esc_attr(get_option('loginpro_whatsapp_retry_delay', 60)); ?>" min="10" max="300" class="loginpro-input" style="width: 80px;">
                            <span class="loginpro-help-text"><?php esc_html_e('ثانیه', 'loginpro'); ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- تست واتساپ -->
                <div class="loginpro-admin-card">
                    <h3 class="loginpro-card-title">📱 <?php esc_html_e('تست تنظیمات درگاه واتساپ', 'loginpro'); ?></h3>
                    
                    <div class="loginpro-form-row">
                        <div class="loginpro-form-label"><?php esc_html_e('شماره موبایل تست', 'loginpro'); ?></div>
                        <div class="loginpro-form-control">
                            <div class="loginpro-test-group" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                                <div style="display: flex; align-items: center;">
                                    <span style="background: #f5f5f5; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px 0 0 6px; border-right: none;">98+</span>
                                    <input type="text" id="test_mobile_number" placeholder="9123456789" class="loginpro-input" style="width: 200px; border-radius: 0 6px 6px 0; margin-left: 0;">
                                </div>
                                <button type="button" id="send_test_whatsapp" class="button button-primary">📨 <?php esc_html_e('ارسال پیام تست', 'loginpro'); ?></button>
                                <button type="button" id="test_connection" class="button button-secondary">🔌 <?php esc_html_e('تست اتصال درگاه', 'loginpro'); ?></button>
                            </div>
                            <span class="loginpro-help-text"><?php esc_html_e('شماره موبایل را بدون صفر و کد کشور وارد کنید (مثال: 9123456789)', 'loginpro'); ?></span>
                        </div>
                    </div>
                    
                    <div id="test_result" class="loginpro-test-result" style="display: none; margin-top: 15px; padding: 12px; border-radius: 8px;"></div>
                </div>
                
                <div class="loginpro-form-actions" style="margin-top: 20px;">
                    <button type="submit" name="save_whatsapp_settings" class="button button-primary button-large">💾 <?php esc_html_e('ذخیره تنظیمات واتساپ', 'loginpro'); ?></button>
                </div>
            </form>
        </div>
        
        <style>
        .loginpro-admin-card {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .loginpro-admin-card h3 {
            margin-top: 0;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 1px solid #eee;
            font-size: 18px;
        }
        .loginpro-form-row {
            margin-bottom: 18px;
            display: flex;
            flex-wrap: wrap;
            align-items: flex-start;
        }
        .loginpro-form-label {
            width: 200px;
            font-weight: 600;
            padding-top: 8px;
            color: #23282d;
        }
        .loginpro-form-control {
            flex: 1;
            min-width: 250px;
        }
        .loginpro-input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            background: #fff;
        }
        .loginpro-input:focus {
            border-color: #2271b1;
            outline: none;
            box-shadow: 0 0 0 1px #2271b1;
        }
        .loginpro-input-full {
            width: 100%;
            max-width: 450px;
        }
        .loginpro-select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #fff;
            font-size: 14px;
        }
        .loginpro-help-text {
            display: block;
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .loginpro-help-info {
            color: #00669b;
            background: #e5f5fa;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
        }
        .loginpro-help-warning {
            color: #856404;
            background: #fff3cd;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
        }
        .loginpro-test-result {
            margin-top: 15px;
            padding: 12px;
            border-radius: 8px;
        }
        .loginpro-test-result.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .loginpro-test-result.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .loginpro-test-result.info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        textarea.loginpro-input-full {
            height: 100px;
            resize: vertical;
        }
        @media (max-width: 768px) {
            .loginpro-settings-grid {
                grid-template-columns: 1fr !important;
            }
            .loginpro-form-row {
                flex-direction: column;
            }
            .loginpro-form-label {
                width: 100%;
                margin-bottom: 8px;
            }
            .loginpro-form-control {
                width: 100%;
            }
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#provider_select').on('change', function() {
                var val = $(this).val();
                $('.provider_box').hide();
                $('#' + val + '_box').show();
            });
            
            $('#send_test_whatsapp').on('click', function() {
                var number = $('#test_mobile_number').val();
                var provider = $('#provider_select').val();
                var resultDiv = $('#test_result');
                var button = $(this);
                
                if (!number) {
                    alert('<?php esc_html_e('لطفاً شماره موبایل را وارد کنید.', 'loginpro'); ?>');
                    return;
                }
                
                var fullNumber = '98' + number.replace(/^0+/, '');
                
                button.prop('disabled', true).text('⏳ <?php esc_html_e('در حال ارسال...', 'loginpro'); ?>');
                
                resultDiv.removeClass('success error info').addClass('info')
                    .html('⏳ <?php esc_html_e('در حال ارسال پیام تست واتساپ...', 'loginpro'); ?>').show();
                
                $.post(ajaxurl, {
                    action: 'loginpro_test_whatsapp',
                    provider: provider,
                    number: fullNumber,
                    _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'
                }, function(response) {
                    button.prop('disabled', false).text('📨 <?php esc_html_e('ارسال پیام تست', 'loginpro'); ?>');
                    
                    if (response.success) {
                        resultDiv.removeClass('info error').addClass('success')
                            .html('✅ ' + response.message);
                    } else {
                        resultDiv.removeClass('info success').addClass('error')
                            .html('❌ ' + response.message);
                    }
                    setTimeout(function() { resultDiv.fadeOut(); }, 5000);
                }).fail(function() {
                    button.prop('disabled', false).text('📨 <?php esc_html_e('ارسال پیام تست', 'loginpro'); ?>');
                    resultDiv.removeClass('info success').addClass('error')
                        .html('❌ <?php esc_html_e('خطا در ارتباط با سرور', 'loginpro'); ?>');
                    setTimeout(function() { resultDiv.fadeOut(); }, 5000);
                });
            });
            
            $('#test_connection').on('click', function() {
                var provider = $('#provider_select').val();
                var resultDiv = $('#test_result');
                var button = $(this);
                
                button.prop('disabled', true).text('🔌 <?php esc_html_e('در حال تست...', 'loginpro'); ?>');
                
                resultDiv.removeClass('success error info').addClass('info')
                    .html('⏳ <?php esc_html_e('در حال بررسی اتصال به درگاه...', 'loginpro'); ?>').show();
                
                $.post(ajaxurl, {
                    action: 'loginpro_test_whatsapp_connection',
                    provider: provider,
                    _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'
                }, function(response) {
                    button.prop('disabled', false).text('🔌 <?php esc_html_e('تست اتصال درگاه', 'loginpro'); ?>');
                    
                    if (response.success) {
                        resultDiv.removeClass('info error').addClass('success')
                            .html('✅ ' + response.message);
                    } else {
                        resultDiv.removeClass('info success').addClass('error')
                            .html('❌ ' + response.message);
                    }
                    setTimeout(function() { resultDiv.fadeOut(); }, 5000);
                }).fail(function() {
                    button.prop('disabled', false).text('🔌 <?php esc_html_e('تست اتصال درگاه', 'loginpro'); ?>');
                    resultDiv.removeClass('info success').addClass('error')
                        .html('❌ <?php esc_html_e('خطا در ارتباط با سرور', 'loginpro'); ?>');
                    setTimeout(function() { resultDiv.fadeOut(); }, 5000);
                });
            });
        });
        </script>
        <?php
    }
    
    private function saveSettings(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], $this->nonceAction)) {
            return;
        }
        
        // درگاه پیش‌فرض
        if (isset($_POST['default_provider'])) {
            update_option('loginpro_whatsapp_default_provider', sanitize_text_field($_POST['default_provider']));
        }
        
        // تنظیمات پیشرفته
        if (isset($_POST['fallback_order'])) {
            update_option('loginpro_whatsapp_fallback_order', sanitize_text_field($_POST['fallback_order']));
        }
        if (isset($_POST['retry_attempts'])) {
            update_option('loginpro_whatsapp_retry_attempts', (int) $_POST['retry_attempts']);
        }
        if (isset($_POST['retry_delay'])) {
            update_option('loginpro_whatsapp_retry_delay', (int) $_POST['retry_delay']);
        }
        
        // Meta settings
        if (isset($_POST['meta_access_token'])) {
            update_option('loginpro_whatsapp_meta_access_token', sanitize_text_field($_POST['meta_access_token']));
        }
        if (isset($_POST['meta_phone_number_id'])) {
            update_option('loginpro_whatsapp_meta_phone_number_id', sanitize_text_field($_POST['meta_phone_number_id']));
        }
        if (isset($_POST['meta_business_account_id'])) {
            update_option('loginpro_whatsapp_meta_business_account_id', sanitize_text_field($_POST['meta_business_account_id']));
        }
        if (isset($_POST['meta_app_id'])) {
            update_option('loginpro_whatsapp_meta_app_id', sanitize_text_field($_POST['meta_app_id']));
        }
        if (isset($_POST['meta_app_secret']) && !empty($_POST['meta_app_secret'])) {
            update_option('loginpro_whatsapp_meta_app_secret', sanitize_text_field($_POST['meta_app_secret']));
        }
        if (isset($_POST['meta_message_template'])) {
            update_option('loginpro_whatsapp_meta_message_template', wp_kses_post($_POST['meta_message_template']));
        }
    }
    
    public function testWhatsApp(): void
    {
        check_ajax_referer('loginpro_admin', '_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('دسترسی غیرمجاز', 'loginpro')]);
        }
        
        $number = sanitize_text_field($_POST['number']);
        $provider = sanitize_text_field($_POST['provider']);
        
        if (empty($number)) {
            wp_send_json_error(['message' => __('شماره موبایل معتبر نیست', 'loginpro')]);
        }
        
        $otp = rand(100000, 999999);
        $template = get_option('loginpro_whatsapp_meta_message_template', '✅ کد تأیید شما: %OTP%');
        
        $message = str_replace('%OTP%', $otp, $template);
        $message = str_replace('{NAME}', get_bloginfo('name'), $message);
        $message = str_replace('{DOMAIN}', parse_url(home_url(), PHP_URL_HOST), $message);
        
        if ($provider === 'meta') {
            $sent = $this->sendMetaWhatsApp($number, $message);
        } else {
            wp_send_json_error(['message' => __('درگاه انتخاب شده پشتیبانی نمی‌شود', 'loginpro')]);
        }
        
        if ($sent) {
            wp_send_json_success(['message' => __('✅ پیام تست واتساپ با موفقیت ارسال شد! کد: ', 'loginpro') . $otp]);
        } else {
            wp_send_json_error(['message' => __('❌ ارسال پیام تست ناموفق بود. تنظیمات را بررسی کنید.', 'loginpro')]);
        }
    }
    
    public function testConnection(): void
    {
        check_ajax_referer('loginpro_admin', '_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('دسترسی غیرمجاز', 'loginpro')]);
        }
        
        $provider = sanitize_text_field($_POST['provider']);
        
        if ($provider === 'meta') {
            $access_token = get_option('loginpro_whatsapp_meta_access_token', '');
            $phone_number_id = get_option('loginpro_whatsapp_meta_phone_number_id', '');
            
            if (empty($access_token) || empty($phone_number_id)) {
                wp_send_json_error(['message' => __('تنظیمات Meta کامل نیست. توکن دسترسی و شماره تلفن را وارد کنید.', 'loginpro')]);
            }
            
            $url = "https://graph.facebook.com/v17.0/{$phone_number_id}";
            $response = wp_remote_get($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $access_token
                ],
                'timeout' => 30
            ]);
            
            if (is_wp_error($response)) {
                wp_send_json_error(['message' => __('خطا در اتصال: ', 'loginpro') . $response->get_error_message()]);
            }
            
            $body = json_decode(wp_remote_retrieve_body($response), true);
            
            if (isset($body['id'])) {
                wp_send_json_success(['message' => __('✅ اتصال به Meta Cloud API برقرار است. شماره تلفن تأیید شد.', 'loginpro')]);
            } else {
                $error = $body['error']['message'] ?? __('خطا در اعتبارسنجی', 'loginpro');
                wp_send_json_error(['message' => __('❌ اتصال ناموفق: ', 'loginpro') . $error]);
            }
        } else {
            wp_send_json_error(['message' => __('درگاه انتخاب شده پشتیبانی نمی‌شود', 'loginpro')]);
        }
    }
    
    private function sendMetaWhatsApp($number, $message): bool
    {
        $access_token = get_option('loginpro_whatsapp_meta_access_token', '');
        $phone_number_id = get_option('loginpro_whatsapp_meta_phone_number_id', '');
        
        if (empty($access_token) || empty($phone_number_id)) {
            return false;
        }
        
        // تبدیل شماره به فرمت بین‌المللی
        if (substr($number, 0, 2) === '98') {
            $number = $number;
        } else {
            $number = '98' . preg_replace('/^0+/', '', $number);
        }
        
        $url = "https://graph.facebook.com/v17.0/{$phone_number_id}/messages";
        
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $number,
            'type' => 'text',
            'text' => [
                'body' => $message
            ]
        ];
        
        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($data),
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        return isset($body['messages']) && !empty($body['messages']);
    }
}