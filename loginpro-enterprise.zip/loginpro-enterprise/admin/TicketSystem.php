<?php
/**
 * Admin Ticket System - با قابلیت مشاهده و پاسخ به تیکت
 * 
 * @package LoginPro
 * @version 3.0.16
 */

defined('ABSPATH') || exit;

class LoginPro_Admin_Ticket_System {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('wp_ajax_loginpro_admin_delete_ticket', [$this, 'admin_delete_ticket']);
        add_action('wp_ajax_loginpro_admin_update_ticket', [$this, 'admin_update_ticket']);
        add_action('wp_ajax_loginpro_admin_get_ticket_stats', [$this, 'admin_get_ticket_stats']);
        add_action('wp_ajax_loginpro_admin_reply_ticket', [$this, 'admin_reply_ticket']);
        add_action('wp_ajax_loginpro_admin_get_ticket_detail', [$this, 'admin_get_ticket_detail']);
    }
    
    public function add_admin_menu() {
        add_submenu_page(
            'loginpro',
            __('مدیریت تیکت‌ها', 'loginpro'),
            $this->get_menu_title(),
            'manage_options',
            'loginpro-tickets',
            [$this, 'render_admin_page']
        );
    }
    
    private function get_menu_title() {
        $count = $this->get_pending_tickets_count();
        $title = __('تیکتها', 'loginpro');
        
        if ($count > 0) {
            $title .= ' <span class="awaiting-mod" style="background:#ef394e;color:#fff;font-size:10px;padding:2px 8px;border-radius:10px;animation:blink 1s infinite;display:inline-block;min-width:20px;text-align:center;">' . $count . '</span>';
            $title .= ' <span style="font-size:9px;color:#ef394e;font-weight:normal;">' . __('جدید', 'loginpro') . '</span>';
        }
        
        return $title;
    }
    
    private function get_pending_tickets_count() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            return 0;
        }
        
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'pending'");
        return intval($count);
    }
    
    private function get_total_tickets_count() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            return 0;
        }
        
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        return intval($count);
    }
    
    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('شما دسترسی لازم را ندارید', 'loginpro'));
        }
        
        $nonce = wp_create_nonce('admin_tickets_' . get_current_user_id());
        
        $stats = $this->get_ticket_stats();
        $total_tickets = $this->get_total_tickets_count();
        $pending_count = $stats['pending'];
        ?>
        <div class="wrap" data-nonce="<?php echo esc_attr($nonce); ?>">
            <h1><?php esc_html_e('🎫 مدیریت تیکت‌های پشتیبانی', 'loginpro'); ?></h1>
            
            <!-- آمار -->
            <div id="ticket-stats" style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin:20px 0;">
                <div class="ticket-stat-card" style="background:#fff;padding:20px;border-radius:12px;border-right:5px solid #6c757d;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <div style="font-size:13px;color:#999;"><?php esc_html_e('تیکتها', 'loginpro'); ?></div>
                            <div id="stat-total" style="font-size:32px;font-weight:700;color:#6c757d;"><?php echo number_format($total_tickets); ?></div>
                        </div>
                        <div style="font-size:40px;">📋</div>
                    </div>
                    <div style="font-size:12px;color:#999;margin-top:8px;">
                        <?php esc_html_e('مجموع تیکت‌ها', 'loginpro'); ?>
                        <?php if ($pending_count > 0): ?>
                            <span style="display:inline-block;background:#dc3545;color:#fff;font-size:10px;padding:2px 10px;border-radius:10px;animation:blink 1.5s infinite;margin-right:5px;">
                                <?php echo esc_html($pending_count); ?> <?php esc_html_e('جدید', 'loginpro'); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="ticket-stat-card" style="background:#fff;padding:20px;border-radius:12px;border-right:5px solid #ffc107;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <div style="font-size:13px;color:#999;"><?php esc_html_e('در حال بررسی', 'loginpro'); ?></div>
                            <div id="stat-open" style="font-size:32px;font-weight:700;color:#ffc107;"><?php echo number_format($stats['open']); ?></div>
                        </div>
                        <div style="font-size:40px;">🔍</div>
                    </div>
                    <div style="font-size:12px;color:#999;margin-top:8px;">
                        <?php esc_html_e('در دست بررسی', 'loginpro'); ?>
                    </div>
                </div>
                
                <div class="ticket-stat-card" style="background:#fff;padding:20px;border-radius:12px;border-right:5px solid #28a745;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <div style="font-size:13px;color:#999;"><?php esc_html_e('پایان یافته', 'loginpro'); ?></div>
                            <div id="stat-closed" style="font-size:32px;font-weight:700;color:#28a745;"><?php echo number_format($stats['closed']); ?></div>
                        </div>
                        <div style="font-size:40px;">✅</div>
                    </div>
                    <div style="font-size:12px;color:#999;margin-top:8px;">
                        <?php esc_html_e('بسته شده', 'loginpro'); ?>
                    </div>
                </div>
            </div>
            
            <!-- پیام -->
            <div id="admin-ticket-message" style="display:none;margin:15px 0;padding:12px 16px;border-radius:8px;"></div>
            
            <!-- لیست تیکت‌ها -->
            <div id="admin-ticket-list" style="background:#fff;padding:20px;border-radius:12px;border:1px solid #ddd;">
                <?php echo $this->get_admin_tickets(); ?>
            </div>
        </div>
        
        <!-- ========================================== -->
        <!-- مودال مشاهده و پاسخ به تیکت -->
        <!-- ========================================== -->
        <div id="ticket-modal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:999999;align-items:center;justify-content:center;backdrop-filter:blur(4px);">
            <div style="background:#fff;border-radius:16px;width:90%;max-width:700px;max-height:90vh;overflow-y:auto;padding:30px;box-shadow:0 20px 60px rgba(0,0,0,0.3);direction:rtl;position:relative;">
                
                <button id="ticket-modal-close" style="position:absolute;top:12px;left:16px;background:none;border:none;font-size:28px;color:#999;cursor:pointer;padding:4px 8px;">✕</button>
                
                <h2 id="ticket-modal-title" style="margin:0 0 20px;font-size:20px;">📋 <?php _e('مشاهده تیکت', 'loginpro'); ?></h2>
                
                <div id="ticket-modal-content">
                    <div style="text-align:center;padding:40px;color:#999;">
                        ⏳ <?php _e('در حال بارگذاری...', 'loginpro'); ?>
                    </div>
                </div>
                
                <hr style="margin:20px 0;border:none;border-top:1px solid #eee;">
                
                <!-- فرم پاسخ -->
                <div id="ticket-reply-section">
                    <h3 style="margin:0 0 10px;font-size:16px;">✏️ <?php _e('پاسخ به تیکت', 'loginpro'); ?></h3>
                    <textarea id="ticket-reply-text" rows="4" placeholder="<?php _e('پاسخ خود را وارد کنید...', 'loginpro'); ?>" style="width:100%;padding:12px 15px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;font-family:inherit;resize:vertical;"></textarea>
                    <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap;">
                        <button id="ticket-reply-submit" style="background:#ef394e;color:#fff;border:none;padding:10px 30px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:500;">
                            📤 <?php _e('ارسال پاسخ', 'loginpro'); ?>
                        </button>
                        <button id="ticket-reply-close" style="background:#6c757d;color:#fff;border:none;padding:10px 30px;border-radius:8px;cursor:pointer;font-size:14px;">
                            ❌ <?php _e('بستن', 'loginpro'); ?>
                        </button>
                    </div>
                    <div id="ticket-reply-message" style="margin-top:10px;display:none;padding:10px;border-radius:8px;"></div>
                </div>
            </div>
        </div>
        
        <style>
            @keyframes blink {
                0%, 100% { opacity: 1; transform: scale(1); }
                50% { opacity: 0.4; transform: scale(0.95); }
            }
            
            .ticket-stat-card {
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            .ticket-stat-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 8px 25px rgba(0,0,0,0.12) !important;
            }
            
            .ticket-status {
                display: inline-block;
                padding: 3px 14px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: 600;
                color: #fff;
            }
            .ticket-status-pending {
                background: #dc3545;
                animation: blink 1.5s infinite;
            }
            .ticket-status-open {
                background: #ffc107;
                color: #333;
            }
            .ticket-status-closed {
                background: #28a745;
            }
            
            .ticket-row {
                border-bottom: 1px solid #f0f0f0;
                transition: background 0.2s;
            }
            .ticket-row:hover {
                background: #f8f9fa;
            }
            .ticket-row td {
                padding: 12px 10px;
                vertical-align: middle;
            }
            
            .ticket-actions button {
                margin: 0 3px;
                padding: 5px 14px;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 12px;
                transition: all 0.2s;
            }
            .ticket-actions button:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            }
            .ticket-actions .btn-close {
                background: #28a745;
                color: #fff;
            }
            .ticket-actions .btn-open {
                background: #ffc107;
                color: #333;
            }
            .ticket-actions .btn-delete {
                background: #dc3545;
                color: #fff;
            }
            .ticket-actions .btn-view {
                background: #17a2b8;
                color: #fff;
            }
            .ticket-actions .btn-pending {
                background: #dc3545;
                color: #fff;
            }
            
            .ticket-row-new {
                background: #fff5f5 !important;
                border-right: 3px solid #dc3545;
            }
            .ticket-row-new:hover {
                background: #ffebeb !important;
            }
            
            /* استایل پیام‌های تیکت در مودال */
            .ticket-message-item {
                padding: 12px 16px;
                border-radius: 10px;
                margin-bottom: 10px;
                border-right: 3px solid #ddd;
            }
            .ticket-message-item.admin {
                background: #e7f3ff;
                border-right-color: #17a2b8;
            }
            .ticket-message-item.user {
                background: #f8f9fa;
                border-right-color: #6c757d;
            }
            .ticket-message-item .meta {
                font-size: 12px;
                color: #999;
                margin-bottom: 4px;
            }
            .ticket-message-item .meta strong {
                color: #333;
            }
            .ticket-message-item .content {
                font-size: 14px;
                color: #333;
                line-height: 1.7;
                white-space: pre-wrap;
            }
            
            @media (max-width: 768px) {
                #ticket-stats {
                    grid-template-columns: 1fr !important;
                }
                .ticket-actions {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 5px;
                }
                .ticket-actions button {
                    font-size: 11px;
                    padding: 4px 10px;
                }
                #ticket-modal > div {
                    padding: 20px;
                    width: 95%;
                }
            }
        </style>
        
        <script type="text/javascript">
        (function() {
            'use strict';
            
            var container = document.querySelector('.wrap');
            var nonce = container ? container.getAttribute('data-nonce') : '';
            var msg = document.getElementById('admin-ticket-message');
            var modal = document.getElementById('ticket-modal');
            var modalContent = document.getElementById('ticket-modal-content');
            var modalTitle = document.getElementById('ticket-modal-title');
            var replyText = document.getElementById('ticket-reply-text');
            var replySubmit = document.getElementById('ticket-reply-submit');
            var replyClose = document.getElementById('ticket-reply-close');
            var replyMessage = document.getElementById('ticket-reply-message');
            var modalClose = document.getElementById('ticket-modal-close');
            var currentTicketId = null;
            
            function showMsg(message, isError) {
                if (!msg) return;
                msg.style.display = 'block';
                msg.style.padding = '12px 16px';
                msg.style.borderRadius = '8px';
                if (isError) {
                    msg.style.backgroundColor = '#fff5f5';
                    msg.style.color = '#dc3545';
                    msg.style.border = '1px solid #f5c6cb';
                    msg.textContent = '❌ ' + message;
                } else {
                    msg.style.backgroundColor = '#f0fff4';
                    msg.style.color = '#28a745';
                    msg.style.border = '1px solid #c3e6cb';
                    msg.textContent = '✅ ' + message;
                }
                setTimeout(function() { msg.style.display = 'none'; }, 5000);
            }
            
            // ==========================================
            // باز کردن مودال مشاهده تیکت
            // ==========================================
            function openTicketModal(ticketId) {
                if (!ticketId) return;
                currentTicketId = ticketId;
                
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
                
                modalContent.innerHTML = '<div style="text-align:center;padding:40px;color:#999;">⏳ <?php _e('در حال بارگذاری...', 'loginpro'); ?></div>';
                replyText.value = '';
                replyMessage.style.display = 'none';
                replyMessage.textContent = '';
                
                var formData = new FormData();
                formData.append('action', 'loginpro_admin_get_ticket_detail');
                formData.append('_nonce', nonce);
                formData.append('ticket_id', ticketId);
                
                fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(res) { return res.json(); })
                .then(function(response) {
                    if (response.success) {
                        renderTicketDetail(response.data);
                    } else {
                        modalContent.innerHTML = '<div style="text-align:center;padding:40px;color:#dc3545;">❌ ' + 
                            (response.data && response.data.message ? response.data.message : 'خطا در بارگذاری تیکت') + 
                            '</div>';
                    }
                })
                .catch(function(error) {
                    modalContent.innerHTML = '<div style="text-align:center;padding:40px;color:#dc3545;">❌ ' + 
                        'خطا در ارتباط با سرور: ' + error.message + 
                        '</div>';
                });
            }
            
            // ==========================================
            // رندر جزئیات تیکت
            // ==========================================
            function renderTicketDetail(data) {
                var html = '';
                
                // اطلاعات تیکت
                html += '<div style="margin-bottom:15px;padding:15px;background:#f8f9fa;border-radius:10px;">';
                html += '<div style="display:flex;justify-content:space-between;flex-wrap:wrap;">';
                html += '<div><strong>#' + data.id + '</strong> - ' + escHtml(data.title) + '</div>';
                html += '<div><span class="ticket-status ticket-status-' + data.status + '">' + getStatusLabel(data.status) + '</span></div>';
                html += '</div>';
                html += '<div style="font-size:13px;color:#999;margin-top:5px;">';
                html += '👤 ' + escHtml(data.user_name) + ' | 📅 ' + data.created_at;
                if (data.priority) {
                    html += ' | 🎯 ' + getPriorityLabel(data.priority);
                }
                if (data.attachment) {
                    html += ' | 📎 <a href="' + escHtml(data.attachment) + '" target="_blank" style="color:#ef394e;text-decoration:none;">دانلود فایل</a>';
                }
                html += '</div>';
                html += '</div>';
                
                // پیام‌ها
                if (data.messages && data.messages.length > 0) {
                    data.messages.forEach(function(msg) {
                        var isAdmin = msg.is_admin == 1;
                        html += '<div class="ticket-message-item ' + (isAdmin ? 'admin' : 'user') + '">';
                        html += '<div class="meta"><strong>' + (isAdmin ? '👤 مدیریت' : escHtml(msg.sender_name)) + '</strong> - ' + msg.created_at + '</div>';
                        html += '<div class="content">' + escHtml(msg.message) + '</div>';
                        if (msg.attachment) {
                            html += '<div style="margin-top:5px;"><a href="' + escHtml(msg.attachment) + '" target="_blank" style="color:#ef394e;text-decoration:none;font-size:13px;">📎 دانلود فایل</a></div>';
                        }
                        html += '</div>';
                    });
                } else {
                    html += '<div style="text-align:center;padding:20px;color:#999;">' + escHtml(data.message) + '</div>';
                }
                
                modalContent.innerHTML = html;
                modalTitle.textContent = '📋 تیکت #' + data.id + ' - ' + data.title;
            }
            
            function escHtml(text) {
                var div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
            
            function getStatusLabel(status) {
                var labels = {
                    'pending': 'جدید',
                    'open': 'در حال بررسی',
                    'closed': 'پایان یافته'
                };
                return labels[status] || status;
            }
            
            function getPriorityLabel(priority) {
                var labels = {
                    'low': 'کم 🟢',
                    'normal': 'عادی 🟡',
                    'high': 'بالا 🟠',
                    'urgent': 'فوری 🔴'
                };
                return labels[priority] || priority;
            }
            
            // ==========================================
            // ارسال پاسخ به تیکت
            // ==========================================
            function submitReply() {
                if (!currentTicketId) return;
                
                var reply = replyText.value.trim();
                if (!reply) {
                    replyMessage.style.display = 'block';
                    replyMessage.style.background = '#fff5f5';
                    replyMessage.style.color = '#dc3545';
                    replyMessage.style.border = '1px solid #f5c6cb';
                    replyMessage.textContent = '<?php _e('لطفاً متن پاسخ را وارد کنید.', 'loginpro'); ?>';
                    return;
                }
                
                replySubmit.disabled = true;
                replySubmit.textContent = '<?php _e('در حال ارسال...', 'loginpro'); ?>';
                replyMessage.style.display = 'none';
                
                var formData = new FormData();
                formData.append('action', 'loginpro_admin_reply_ticket');
                formData.append('_nonce', nonce);
                formData.append('ticket_id', currentTicketId);
                formData.append('reply', reply);
                
                fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(res) { return res.json(); })
                .then(function(response) {
                    replySubmit.disabled = false;
                    replySubmit.textContent = '📤 <?php _e('ارسال پاسخ', 'loginpro'); ?>';
                    
                    replyMessage.style.display = 'block';
                    if (response.success) {
                        replyMessage.style.background = '#f0fff4';
                        replyMessage.style.color = '#28a745';
                        replyMessage.style.border = '1px solid #c3e6cb';
                        replyMessage.textContent = '✅ ' + (response.data.message || 'پاسخ با موفقیت ارسال شد.');
                        replyText.value = '';
                        
                        // بارگذاری مجدد تیکت
                        setTimeout(function() {
                            if (currentTicketId) {
                                openTicketModal(currentTicketId);
                            }
                            // به‌روزرسانی لیست
                            location.reload();
                        }, 1500);
                    } else {
                        replyMessage.style.background = '#fff5f5';
                        replyMessage.style.color = '#dc3545';
                        replyMessage.style.border = '1px solid #f5c6cb';
                        replyMessage.textContent = '❌ ' + (response.data && response.data.message ? response.data.message : 'خطا در ارسال پاسخ');
                    }
                })
                .catch(function(error) {
                    replySubmit.disabled = false;
                    replySubmit.textContent = '📤 <?php _e('ارسال پاسخ', 'loginpro'); ?>';
                    replyMessage.style.display = 'block';
                    replyMessage.style.background = '#fff5f5';
                    replyMessage.style.color = '#dc3545';
                    replyMessage.style.border = '1px solid #f5c6cb';
                    replyMessage.textContent = '❌ خطا در ارتباط با سرور: ' + error.message;
                });
            }
            
            // ==========================================
            // بستن مودال
            // ==========================================
            function closeModal() {
                modal.style.display = 'none';
                document.body.style.overflow = '';
                currentTicketId = null;
                replyText.value = '';
                replyMessage.style.display = 'none';
            }
            
            // ==========================================
            // به‌روزرسانی آمار
            // ==========================================
            function updateStats() {
                var formData = new FormData();
                formData.append('action', 'loginpro_admin_get_ticket_stats');
                formData.append('_nonce', nonce);
                
                fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(res) { return res.json(); })
                .then(function(response) {
                    if (response.success) {
                        var stats = response.data;
                        document.getElementById('stat-total').textContent = stats.total;
                        document.getElementById('stat-open').textContent = stats.open;
                        document.getElementById('stat-closed').textContent = stats.closed;
                    }
                })
                .catch(function(error) {
                    console.error('Error updating stats:', error);
                });
            }
            
            // ==========================================
            // رویدادها
            // ==========================================
            
            // دکمه مشاهده
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('btn-view')) {
                    e.preventDefault();
                    var ticketId = e.target.getAttribute('data-ticket-id');
                    if (ticketId) {
                        openTicketModal(ticketId);
                    }
                }
            });
            
            // دکمه‌های تغییر وضعیت
            document.addEventListener('click', function(e) {
                var target = e.target;
                
                if (target.classList.contains('btn-pending') || 
                    target.classList.contains('btn-open') || 
                    target.classList.contains('btn-close')) {
                    
                    e.preventDefault();
                    var ticketId = target.getAttribute('data-ticket-id');
                    var status = target.classList.contains('btn-pending') ? 'pending' :
                                target.classList.contains('btn-open') ? 'open' : 'closed';
                    
                    if (!ticketId) return;
                    
                    var statusText = status === 'pending' ? 'جدید' :
                                    status === 'open' ? 'در حال بررسی' : 'پایان یافته';
                    
                    if (!confirm('آیا از تغییر وضعیت این تیکت به "' + statusText + '" اطمینان دارید؟')) return;
                    
                    target.disabled = true;
                    target.textContent = '...';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_admin_update_ticket');
                    formData.append('_nonce', nonce);
                    formData.append('ticket_id', ticketId);
                    formData.append('status', status);
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            showMsg(response.data.message, false);
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        } else {
                            showMsg(response.data.message, true);
                            target.disabled = false;
                            target.textContent = target.dataset.originalText || 'تغییر';
                        }
                    })
                    .catch(function(error) {
                        showMsg('خطا در ارتباط با سرور: ' + error.message, true);
                        target.disabled = false;
                        target.textContent = target.dataset.originalText || 'تغییر';
                    });
                }
            });
            
            // دکمه حذف
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('btn-delete')) {
                    e.preventDefault();
                    var ticketId = e.target.getAttribute('data-ticket-id');
                    if (!ticketId) return;
                    if (!confirm('<?php echo esc_js(__('آیا از حذف این تیکت اطمینان دارید؟', 'loginpro')); ?>')) return;
                    
                    e.target.disabled = true;
                    e.target.textContent = 'در حال...';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_admin_delete_ticket');
                    formData.append('_nonce', nonce);
                    formData.append('ticket_id', ticketId);
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            showMsg(response.data.message, false);
                            var row = e.target.closest('tr');
                            if (row) row.remove();
                            updateStats();
                        } else {
                            showMsg(response.data.message, true);
                            e.target.disabled = false;
                            e.target.textContent = 'حذف';
                        }
                    })
                    .catch(function(error) {
                        showMsg('خطا در ارتباط با سرور: ' + error.message, true);
                        e.target.disabled = false;
                        e.target.textContent = 'حذف';
                    });
                }
            });
            
            // بستن مودال
            if (modalClose) {
                modalClose.addEventListener('click', closeModal);
            }
            
            if (replyClose) {
                replyClose.addEventListener('click', closeModal);
            }
            
            // کلیک خارج از مودال
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    closeModal();
                }
            });
            
            // ESC برای بستن مودال
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && modal.style.display === 'flex') {
                    closeModal();
                }
            });
            
            // ارسال پاسخ
            if (replySubmit) {
                replySubmit.addEventListener('click', submitReply);
            }
            
            // Enter در textarea (Ctrl+Enter)
            if (replyText) {
                replyText.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter' && e.ctrlKey) {
                        e.preventDefault();
                        submitReply();
                    }
                });
            }
            
            // به‌روزرسانی خودکار
            setInterval(updateStats, 30000);
            setTimeout(updateStats, 1000);
            
        })();
        </script>
        <?php
    }
    
    private function get_ticket_stats() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        
        $stats = [
            'total' => 0,
            'pending' => 0,
            'open' => 0,
            'closed' => 0
        ];
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            return $stats;
        }
        
        $stats['total'] = intval($wpdb->get_var("SELECT COUNT(*) FROM $table"));
        
        $results = $wpdb->get_results("SELECT status, COUNT(*) as count FROM $table GROUP BY status");
        
        foreach ($results as $row) {
            if (isset($stats[$row->status])) {
                $stats[$row->status] = intval($row->count);
            }
        }
        
        return $stats;
    }
    
    private function get_admin_tickets() {
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_tickets';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            return '<p style="color:#999;text-align:center;padding:40px 0;">' . 
                   esc_html__('جدول تیکت‌ها هنوز ایجاد نشده است.', 'loginpro') . 
                   '</p>';
        }
        
        $tickets = $wpdb->get_results("SELECT * FROM $table ORDER BY 
            CASE status 
                WHEN 'pending' THEN 1 
                WHEN 'open' THEN 2 
                WHEN 'closed' THEN 3 
            END, created_at DESC");
        
        if (empty($tickets)) {
            return '<div style="text-align:center;padding:50px 20px;color:#999;">
                        <div style="font-size:60px;margin-bottom:15px;">🎫</div>
                        <h3 style="color:#333;margin:0 0 10px;">' . esc_html__('هیچ تیکتی ثبت نشده است', 'loginpro') . '</h3>
                        <p style="margin:0;">' . esc_html__('وقتی کاربران تیکت ایجاد کنند، در اینجا نمایش داده می‌شوند.', 'loginpro') . '</p>
                    </div>';
        }
        
        $output = '<table class="wp-list-table widefat fixed striped" style="margin-top:15px;">
            <thead>
                <tr>
                    <th style="width:50px;">#' . esc_html__('شناسه', 'loginpro') . '</th>
                    <th>' . esc_html__('کاربر', 'loginpro') . '</th>
                    <th>' . esc_html__('موضوع', 'loginpro') . '</th>
                    <th style="width:120px;">' . esc_html__('وضعیت', 'loginpro') . '</th>
                    <th style="width:150px;">' . esc_html__('تاریخ', 'loginpro') . '</th>
                    <th style="width:280px;">' . esc_html__('عملیات', 'loginpro') . '</th>
                </tr>
            </thead>
            <tbody>';
        
        foreach ($tickets as $ticket) {
            $user = get_userdata($ticket->user_id);
            $username = $user ? $user->display_name : __('کاربر حذف شده', 'loginpro');
            $status_class = 'ticket-status-' . $ticket->status;
            
            $status_labels = [
                'pending' => __('جدید', 'loginpro'),
                'open' => __('در حال بررسی', 'loginpro'),
                'closed' => __('پایان یافته', 'loginpro')
            ];
            $status_label = isset($status_labels[$ticket->status]) ? $status_labels[$ticket->status] : $ticket->status;
            
            $row_class = ($ticket->status === 'pending') ? 'ticket-row ticket-row-new' : 'ticket-row';
            
            $action_buttons = '';
            if ($ticket->status === 'pending') {
                $action_buttons .= '<button class="btn-open" data-ticket-id="' . esc_attr($ticket->id) . '">🔍 ' . esc_html__('بررسی', 'loginpro') . '</button>';
            } elseif ($ticket->status === 'open') {
                $action_buttons .= '<button class="btn-close" data-ticket-id="' . esc_attr($ticket->id) . '">✅ ' . esc_html__('بستن', 'loginpro') . '</button>';
            } elseif ($ticket->status === 'closed') {
                $action_buttons .= '<button class="btn-open" data-ticket-id="' . esc_attr($ticket->id) . '">🔄 ' . esc_html__('بازگشایی', 'loginpro') . '</button>';
            }
            
            $output .= '<tr class="' . $row_class . '">
                <td>' . esc_html($ticket->id) . '</td>
                <td>
                    <strong>' . esc_html($username) . '</strong>
                    ' . ($user ? '<br><span style="font-size:11px;color:#999;">' . esc_html($user->user_email) . '</span>' : '') . '
                </td>
                <td>
                    <strong>' . esc_html($ticket->title) . '</strong>
                    <div style="font-size:12px;color:#666;margin-top:3px;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                        ' . esc_html(wp_trim_words($ticket->message, 10)) . '
                    </div>
                </td>
                <td><span class="ticket-status ' . esc_attr($status_class) . '">' . esc_html($status_label) . '</span></td>
                <td>' . esc_html(date_i18n('j F Y ساعت H:i', strtotime($ticket->created_at))) . '</td>
                <td class="ticket-actions">
                    <button class="btn-view" data-ticket-id="' . esc_attr($ticket->id) . '">👁️ ' . esc_html__('مشاهده', 'loginpro') . '</button>
                    ' . $action_buttons . '
                    <button class="btn-delete" data-ticket-id="' . esc_attr($ticket->id) . '">🗑️ ' . esc_html__('حذف', 'loginpro') . '</button>
                </td>
            </tr>';
        }
        
        $output .= '</tbody></table>';
        return $output;
    }
    
    public function admin_get_ticket_stats() {
        try {
            $user_id = get_current_user_id();
            
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
            if (!wp_verify_nonce($nonce, 'admin_tickets_' . $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید'], 403);
                return;
            }
            
            $stats = $this->get_ticket_stats();
            wp_send_json_success($stats);
            
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    public function admin_delete_ticket() {
        try {
            $user_id = get_current_user_id();
            
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
            if (!wp_verify_nonce($nonce, 'admin_tickets_' . $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید'], 403);
                return;
            }
            
            $ticket_id = intval($_POST['ticket_id'] ?? 0);
            if (!$ticket_id) {
                wp_send_json_error(['message' => 'شناسه تیکت نامعتبر']);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $ticket = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE id = %d",
                $ticket_id
            ));
            
            if (!$ticket) {
                wp_send_json_error(['message' => 'تیکت یافت نشد']);
                return;
            }
            
            if (!empty($ticket->attachment)) {
                $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $ticket->attachment);
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }
            
            $deleted = $wpdb->delete(
                $table,
                ['id' => $ticket_id],
                ['%d']
            );
            
            if ($deleted) {
                wp_send_json_success(['message' => 'تیکت با موفقیت حذف شد']);
            } else {
                wp_send_json_error(['message' => 'خطا در حذف تیکت']);
            }
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    public function admin_update_ticket() {
        try {
            $user_id = get_current_user_id();
            
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
            if (!wp_verify_nonce($nonce, 'admin_tickets_' . $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید'], 403);
                return;
            }
            
            $ticket_id = intval($_POST['ticket_id'] ?? 0);
            $status = sanitize_text_field($_POST['status'] ?? '');
            
            if (!$ticket_id || !in_array($status, ['pending', 'open', 'closed'])) {
                wp_send_json_error(['message' => 'اطلاعات نامعتبر']);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $updated = $wpdb->update(
                $table,
                ['status' => $status, 'updated_at' => current_time('mysql')],
                ['id' => $ticket_id],
                ['%s', '%s'],
                ['%d']
            );
            
            if ($updated !== false) {
                wp_send_json_success(['message' => 'وضعیت تیکت با موفقیت تغییر کرد']);
            } else {
                wp_send_json_error(['message' => 'خطا در تغییر وضعیت تیکت']);
            }
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    // ==========================================
    // دریافت جزئیات تیکت (برای مودال)
    // ==========================================
    public function admin_get_ticket_detail() {
        try {
            $user_id = get_current_user_id();
            
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
            if (!wp_verify_nonce($nonce, 'admin_tickets_' . $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید'], 403);
                return;
            }
            
            $ticket_id = intval($_POST['ticket_id'] ?? 0);
            if (!$ticket_id) {
                wp_send_json_error(['message' => 'شناسه تیکت نامعتبر']);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $ticket = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE id = %d",
                $ticket_id
            ));
            
            if (!$ticket) {
                wp_send_json_error(['message' => 'تیکت یافت نشد']);
                return;
            }
            
            $user = get_userdata($ticket->user_id);
            
            $data = [
                'id' => $ticket->id,
                'title' => $ticket->title,
                'message' => $ticket->message,
                'status' => $ticket->status,
                'priority' => $ticket->priority ?? 'normal',
                'attachment' => $ticket->attachment ?? '',
                'user_name' => $user ? $user->display_name : __('کاربر حذف شده', 'loginpro'),
                'user_email' => $user ? $user->user_email : '',
                'created_at' => date_i18n('j F Y ساعت H:i', strtotime($ticket->created_at)),
                'messages' => [
                    [
                        'is_admin' => 0,
                        'sender_name' => $user ? $user->display_name : __('کاربر', 'loginpro'),
                        'message' => $ticket->message,
                        'created_at' => date_i18n('j F Y ساعت H:i', strtotime($ticket->created_at)),
                        'attachment' => $ticket->attachment ?? ''
                    ]
                ]
            ];
            
            // اگر پاسخ وجود دارد
            if (!empty($ticket->reply)) {
                $data['messages'][] = [
                    'is_admin' => 1,
                    'sender_name' => __('مدیریت', 'loginpro'),
                    'message' => $ticket->reply,
                    'created_at' => $ticket->reply_date ? date_i18n('j F Y ساعت H:i', strtotime($ticket->reply_date)) : '',
                    'attachment' => ''
                ];
            }
            
            wp_send_json_success($data);
            
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    // ==========================================
    // ارسال پاسخ به تیکت
    // ==========================================
    public function admin_reply_ticket() {
        try {
            $user_id = get_current_user_id();
            
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
            if (!wp_verify_nonce($nonce, 'admin_tickets_' . $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید'], 403);
                return;
            }
            
            $ticket_id = intval($_POST['ticket_id'] ?? 0);
            $reply = isset($_POST['reply']) ? sanitize_textarea_field($_POST['reply']) : '';
            
            if (!$ticket_id || empty($reply)) {
                wp_send_json_error(['message' => 'اطلاعات نامعتبر']);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            $updated = $wpdb->update(
                $table,
                [
                    'reply' => $reply,
                    'reply_date' => current_time('mysql'),
                    'status' => 'open',
                    'updated_at' => current_time('mysql')
                ],
                ['id' => $ticket_id],
                ['%s', '%s', '%s', '%s'],
                ['%d']
            );
            
            if ($updated !== false) {
                wp_send_json_success(['message' => 'پاسخ با موفقیت ارسال شد']);
            } else {
                wp_send_json_error(['message' => 'خطا در ارسال پاسخ']);
            }
            
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
}

// نمونه‌سازی کلاس
if (class_exists('LoginPro_Admin_Ticket_System')) {
    new LoginPro_Admin_Ticket_System();
}