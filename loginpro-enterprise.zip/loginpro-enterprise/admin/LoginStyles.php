<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class LoginStyles
{
    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'addDynamicStyles'], 999);
        add_action('login_enqueue_scripts', [$this, 'addDynamicStyles'], 999);
    }
    
    public function addDynamicStyles()
    {
        $settings = $this->getSettings();
        
        $custom_css = "
        /* ==================================================
           استایل‌های داینامیک لاگین‌پرو
           ================================================== */
        
        /* کل فرم کارت */
        .loginpro-smart-card {
            background: {$settings['background_color']} !important;
            border-radius: {$settings['border_radius']}px !important;
            border: 1px solid {$settings['border_color']} !important;
            width: {$settings['form_width']} !important;
            max-width: 100% !important;
            font-family: {$settings['font_family']} !important;
            overflow: hidden !important;
        }
        
        /* هدر فرم (قسمتی که عنوان و زیرنویس دارد) */
        .loginpro-card-header {
            background: {$settings['background_color']} !important;
            text-align: center !important;
            padding: 30px 25px 20px 25px !important;
            border-bottom: 1px solid {$settings['border_color']} !important;
        }
        
        .loginpro-card-header h2 {
            color: {$settings['text_color']} !important;
            font-size: {$settings['title_font_size']}px !important;
            margin: 0 0 8px 0 !important;
            font-weight: 600 !important;
        }
        
        .loginpro-card-header p {
            color: {$settings['subtitle_color']} !important;
            font-size: {$settings['normal_font_size']}px !important;
            margin: 0 !important;
        }
        
        /* بدنه فرم (جایی که فیلدها و دکمه قرار دارد) */
        .loginpro-card-body {
            background: {$settings['background_color']} !important;
            padding: 25px !important;
        }
        
        /* گروه فیلدهای ورودی */
        .loginpro-input-group {
            margin-bottom: 20px !important;
            width: 100% !important;
        }
        
        /* فیلدهای ورودی */
        .loginpro-input-group input,
        .loginpro-float-group input,
        .loginpro-input {
            width: 100% !important;
            height: {$settings['input_height']}px !important;
            padding: 0 16px !important;
            border: 1px solid {$settings['border_color']} !important;
            border-radius: 12px !important;
            font-size: {$settings['normal_font_size']}px !important;
            background: {$settings['background_color']} !important;
            color: {$settings['text_color']} !important;
            box-sizing: border-box !important;
            text-align: right !important;
            direction: rtl !important;
        }
        
        .loginpro-input-group input:focus,
        .loginpro-float-group input:focus,
        .loginpro-input:focus {
            border-color: {$settings['primary_color']} !important;
            outline: none !important;
            box-shadow: 0 0 0 3px {$settings['primary_color']}20 !important;
        }
        
        /* دکمه اصلی */
        .loginpro-btn-primary,
        .loginpro-submit-btn,
        .loginpro-reset-btn {
            width: 100% !important;
            height: {$settings['button_height']}px !important;
            background: {$settings['button_color']} !important;
            color: #ffffff !important;
            border: none !important;
            border-radius: 12px !important;
            font-size: {$settings['button_font_size']}px !important;
            font-weight: 600 !important;
            cursor: pointer !important;
            transition: all 0.3s ease !important;
            text-align: center !important;
        }
        
        .loginpro-btn-primary:hover,
        .loginpro-submit-btn:hover,
        .loginpro-reset-btn:hover {
            background: {$settings['button_hover_color']} !important;
            transform: translateY(-1px) !important;
        }
        
        /* لینک‌ها */
        .loginpro-links a,
        .loginpro-password-link,
        .loginpro-forgot-link,
        .loginpro-back-link a {
            color: {$settings['primary_color']} !important;
            text-decoration: none !important;
            font-size: 13px !important;
        }
        
        .loginpro-links a:hover,
        .loginpro-password-link:hover,
        .loginpro-forgot-link:hover {
            color: {$settings['button_hover_color']} !important;
            text-decoration: underline !important;
        }
        
        /* دکمه‌های روش (ورود با رمز / کد یکبارمصرف) */
        .loginpro-method-buttons {
            display: flex !important;
            gap: 15px !important;
            margin-bottom: 20px !important;
        }
        
        .loginpro-method-buttons .loginpro-btn-secondary {
            flex: 1 !important;
            height: 45px !important;
            background: #f5f5f5 !important;
            border: 1px solid {$settings['border_color']} !important;
            border-radius: 12px !important;
            font-size: 14px !important;
            cursor: pointer !important;
        }
        
        /* پیام خطا */
        .loginpro-error-message {
            background: {$settings['error_color']}10 !important;
            border: 1px solid {$settings['error_color']} !important;
            color: {$settings['error_color']} !important;
            padding: 12px !important;
            border-radius: 12px !important;
            margin-bottom: 20px !important;
            font-size: 13px !important;
            text-align: center !important;
        }
        
        /* پیام موفقیت */
        .loginpro-success-message {
            background: {$settings['success_color']}10 !important;
            border: 1px solid {$settings['success_color']} !important;
            color: {$settings['success_color']} !important;
            padding: 12px !important;
            border-radius: 12px !important;
            margin-bottom: 20px !important;
            font-size: 13px !important;
            text-align: center !important;
        }
        
        /* کد OTP */
        .loginpro-otp-inputs {
            display: flex !important;
            gap: 12px !important;
            justify-content: center !important;
            margin-bottom: 25px !important;
            direction: ltr !important;
        }
        /* تمام فیلدهای ورودی در تمام فرم‌ها */
.loginpro-smart-card input,
.loginpro-floating-form input,
.loginpro-reset-form input,
.loginpro-card-body input,
.loginpro-input-group input,
.loginpro-float-group input,
.loginpro-field input,
.loginpro-otp-inputs input,
.loginpro-code-inputs input,
input.loginpro-input,
.loginpro-form-container input,
.loginpro-modal-content input {
    width: 100% !important;
    height: {$settings['input_height']}px !important;
    padding: 0 16px !important;
    border: 1px solid {$settings['border_color']} !important;
    border-radius: 12px !important;
    font-size: {$settings['normal_font_size']}px !important;
    background-color: #ffffff !important;
    background: #ffffff !important;
    color: {$settings['text_color']} !important;
    box-sizing: border-box !important;
    text-align: right !important;
    direction: rtl !important;
}

/* حالت فوکوس */
.loginpro-smart-card input:focus,
.loginpro-floating-form input:focus,
.loginpro-reset-form input:focus,
.loginpro-card-body input:focus,
.loginpro-input-group input:focus,
.loginpro-float-group input:focus,
.loginpro-field input:focus,
.loginpro-otp-inputs input:focus,
.loginpro-code-inputs input:focus,
input.loginpro-input:focus {
    background-color: #ffffff !important;
    background: #ffffff !important;
    border-color: {$settings['primary_color']} !important;
    outline: none !important;
    box-shadow: 0 0 0 3px {$settings['primary_color']}20 !important;
}
        .loginpro-otp-inputs input {
            width: 52px !important;
            height: 58px !important;
            text-align: center !important;
            font-size: 24px !important;
            font-weight: bold !important;
            border: 1px solid {$settings['border_color']} !important;
            border-radius: 12px !important;
            background: {$settings['background_color']} !important;
        }
        
        .loginpro-otp-inputs input:focus {
            border-color: {$settings['primary_color']} !important;
            outline: none !important;
        }
        
        /* تایمر */
        .loginpro-timer {
            text-align: center !important;
            font-size: 13px !important;
            margin: 15px 0 !important;
            color: {$settings['subtitle_color']} !important;
        }
        
        .loginpro-resend-code {
            background: none !important;
            border: none !important;
            cursor: pointer !important;
            color: {$settings['primary_color']} !important;
            font-size: 13px !important;
        }
        
        /* لوگو */
        .loginpro-logo {
            text-align: center !important;
            margin-bottom: 20px !important;
        }
        
        .loginpro-logo img {
            max-width: {$settings['logo_width']}px !important;
            max-height: {$settings['logo_height']}px !important;
            width: auto !important;
            height: auto !important;
        }
        
        /* CSS سفارشی کاربر */
        {$settings['custom_css']}
        ";
        
        wp_add_inline_style('loginpro-form', $custom_css);
        
        // همچنین برای صفحه لاگین وردپرس
        if (did_action('login_enqueue_scripts')) {
            echo "<style>{$custom_css}</style>";
        }
    }
    
    private function getSettings(): array
    {
        return [
            'primary_color' => get_option('loginpro_primary_color', '#ef394e'),
            'button_color' => get_option('loginpro_button_color', '#ef394e'),
            'button_hover_color' => get_option('loginpro_button_hover_color', '#e02e43'),
            'error_color' => get_option('loginpro_error_color', '#dc3545'),
            'success_color' => get_option('loginpro_success_color', '#28a745'),
            'background_color' => get_option('loginpro_background_color', '#ffffff'),
            'text_color' => get_option('loginpro_text_color', '#1a1a1a'),
            'subtitle_color' => get_option('loginpro_subtitle_color', '#6c6c6c'),
            'border_color' => get_option('loginpro_border_color', '#e0e0e0'),
            'form_width' => get_option('loginpro_form_width', '450px'),
            'border_radius' => get_option('loginpro_border_radius', 20),
            'input_height' => get_option('loginpro_input_height', 48),
            'button_height' => get_option('loginpro_button_height', 48),
            'font_family' => get_option('loginpro_font_family', 'IRANSans, Vazir, Tahoma, sans-serif'),
            'title_font_size' => get_option('loginpro_title_font_size', 24),
            'normal_font_size' => get_option('loginpro_normal_font_size', 15),
            'button_font_size' => get_option('loginpro_button_font_size', 16),
            'logo_width' => get_option('loginpro_logo_width', '150'),
            'logo_height' => get_option('loginpro_logo_height', 'auto'),
            'custom_css' => get_option('loginpro_custom_css', '')
        ];
    }
}