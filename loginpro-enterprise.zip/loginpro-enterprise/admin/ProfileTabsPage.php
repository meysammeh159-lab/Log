<?php
/**
 * Profile Tabs Page Class
 * مدیریت تب‌های داشبورد کاربری
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Admin;

defined('ABSPATH') || exit;

// ✅ جلوگیری از بارگذاری دوگانه
if (class_exists('LoginPro\Admin\ProfileTabsPage')) {
    return;
}

use LoginPro\Security\NonceManager;
use LoginPro\Security\PermissionChecker;

/**
 * کلاس مدیریت تب‌های پروفایل کاربری
 */
class ProfileTabsPage {
    
    /**
     * @var string $option_name نام آپشن در دیتابیس
     */
    private $option_name = 'loginpro_user_dashboard_tabs';
    
    /**
     * @var array $default_tabs تب‌های پیش‌فرض
     */
    private $default_tabs = [
        'account_details' => '👤 اطلاعات حساب کاربری',
        'messages'        => '✉️ پیام‌ها',
        'addresses'       => '📍 آدرس‌ها',
        'orders'          => '🛒 سفارش‌ها',
        'wishlist'        => '❤️ لیست‌های من',
        'downloads'       => '📥 دانلودها',
        'subscription'    => '📋 اشتراک',
        'gifts'           => '🎁 هدیه‌ها',
        'tickets'         => '🎫 تیکت‌های پشتیبانی',
        'reviews'         => '💬 دیدگاه و پرسش‌ها',
        'recent_views'    => '👁️ بازدیدهای اخیر',
        'logout'          => '🚪 خروج از حساب',
    ];
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->register_hooks();
    }
    
    /**
     * ثبت هوک‌ها
     */
    private function register_hooks() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'save_settings']);
        add_filter('loginpro_user_tabs', [$this, 'filter_user_tabs']);
    }
    
    /**
     * افزودن به منوی ادمین
     */
    public function add_admin_menu() {
        add_submenu_page(
            'loginpro',
            __('تنظیمات تب‌های داشبورد', 'loginpro'),
            __('تب‌های داشبورد', 'loginpro'),
            'manage_options',
            'loginpro-profile-tabs',
            [$this, 'render_admin_page']
        );
    }
    
    /**
     * رندر صفحه تنظیمات
     */
    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('شما دسترسی لازم را ندارید', 'loginpro'));
        }
        
        $active_tabs = $this->get_active_tabs();
        $all_tabs = $this->get_all_tabs();
        $message = '';
        
        // بررسی پیام ذخیره‌سازی
        if (isset($_GET['saved']) && $_GET['saved'] === '1') {
            $message = '<div class="notice notice-success is-dismissible"><p>✅ تنظیمات با موفقیت ذخیره شد.</p></div>';
        }
        
        // بارگذاری فایل تنظیمات (tab-profile-tabs.php)
        $tab_file = LOGINPRO_TABS_DIR . 'tab-profile-tabs.php';
        if (file_exists($tab_file)) {
            // متغیرهایی که در فایل تنظیمات استفاده می‌شوند
            $option_name = $this->option_name;
            $all_tabs = $all_tabs;
            $active_tabs = $active_tabs;
            $nonce_action = 'loginpro_user_tabs';
            
            include $tab_file;
        } else {
            // نمایش فرم ساده اگر فایل تنظیمات وجود نداشت
            $this->render_simple_form($all_tabs, $active_tabs);
        }
    }
    
    /**
     * فرم ساده (در صورت عدم وجود tab-profile-tabs.php)
     */
    private function render_simple_form($all_tabs, $active_tabs) {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('تنظیمات تب‌های داشبورد کاربری', 'loginpro'); ?></h1>
            
            <form method="post">
                <?php wp_nonce_field('loginpro_user_tabs'); ?>
                
                <div style="background:#fff;padding:20px;border-radius:8px;border:1px solid #ccd0d4;">
                    <h3><?php esc_html_e('انتخاب تب‌های فعال', 'loginpro'); ?></h3>
                    
                    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px;margin:15px 0;">
                        <?php foreach ($all_tabs as $key => $label): ?>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:#f8f9fa;border-radius:6px;cursor:pointer;">
                                <input type="checkbox" name="<?php echo esc_attr($this->option_name); ?>[]" 
                                       value="<?php echo esc_attr($key); ?>" 
                                       <?php checked(in_array($key, $active_tabs)); ?>>
                                <?php echo esc_html($label); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    
                    <button type="submit" name="save_tabs" class="button button-primary">
                        <?php esc_html_e('ذخیره تنظیمات', 'loginpro'); ?>
                    </button>
                </div>
            </form>
        </div>
        <style>
        .wrap { margin: 20px 20px 0 0; max-width: 1200px; }
        .wrap label:hover { background: #e9ecef !important; }
        @media (max-width: 600px) {
            .wrap div[style*="grid-template-columns"] { grid-template-columns: 1fr 1fr !important; }
        }
        </style>
        <?php
    }
    
    /**
     * ذخیره تنظیمات
     */
    public function save_settings() {
        if (!isset($_POST['save_tabs'])) {
            return;
        }
        
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (!check_admin_referer('loginpro_user_tabs')) {
            return;
        }
        
        $tabs = isset($_POST[$this->option_name]) ? (array) $_POST[$this->option_name] : [];
        $tabs = array_map('sanitize_text_field', $tabs);
        $tabs = array_intersect($tabs, array_keys($this->get_all_tabs()));
        
        update_option($this->option_name, $tabs);
        
        wp_safe_redirect(add_query_arg(['saved' => '1']));
        exit;
    }
    
    /**
     * دریافت تب‌های فعال
     */
    public function get_active_tabs() {
        $saved = get_option($this->option_name, null);
        
        if ($saved === null) {
            // اگر تنظیمات ذخیره نشده، همه تب‌ها فعال باشند
            return array_keys($this->get_all_tabs());
        }
        
        return is_array($saved) ? $saved : [];
    }
    
    /**
     * دریافت همه تب‌ها
     */
    public function get_all_tabs() {
        $tabs = apply_filters('loginpro_user_tabs_list', $this->default_tabs);
        return $tabs;
    }
    
    /**
     * فیلتر تب‌های کاربر
     */
    public function filter_user_tabs($tabs) {
        $active_tabs = $this->get_active_tabs();
        $all_tabs = $this->get_all_tabs();
        
        $filtered = [];
        foreach ($active_tabs as $key) {
            if (isset($all_tabs[$key])) {
                $filtered[$key] = $all_tabs[$key];
            }
        }
        
        return $filtered;
    }
    
    /**
     * دریافت تب‌ها برای نمایش در فرانت‌اند
     */
    public function get_tabs_for_display($user_id = null) {
        $tabs = $this->get_active_tabs();
        $all_tabs = $this->get_all_tabs();
        
        $result = [];
        foreach ($tabs as $key) {
            if (isset($all_tabs[$key])) {
                $result[$key] = [
                    'label' => $all_tabs[$key],
                    'key' => $key,
                    'icon' => $this->get_tab_icon($key),
                ];
            }
        }
        
        return $result;
    }
    
    /**
     * دریافت آیکون تب
     */
    private function get_tab_icon($key) {
        $icons = [
            'account_details' => '👤',
            'messages' => '✉️',
            'addresses' => '📍',
            'orders' => '🛒',
            'wishlist' => '❤️',
            'downloads' => '📥',
            'subscription' => '📋',
            'gifts' => '🎁',
            'tickets' => '🎫',
            'reviews' => '💬',
            'recent_views' => '👁️',
            'logout' => '🚪',
        ];
        
        return isset($icons[$key]) ? $icons[$key] : '📄';
    }
}

// ==================================================
// ✅ مقداردهی اولیه - فقط اگر کلاس وجود نداشته باشد
// ==================================================

if (!class_exists('LoginPro\Admin\ProfileTabsPage')) {
    new \LoginPro\Admin\ProfileTabsPage();
}
?>