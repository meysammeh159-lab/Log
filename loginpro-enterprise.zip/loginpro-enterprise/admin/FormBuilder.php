<?php
namespace LoginPro\Admin;

use LoginPro\Core\Container;

class FormBuilder {
    private $container;
    private $fields = [];
    private $sections = [];
    
    public function __construct(Container $container) {
        $this->container = $container;
    }
    
    public function createForm($id, $options = []) {
        $defaults = [
            'method' => 'post',
            'action' => '',
            'class' => 'loginpro-form',
            'enctype' => 'application/x-www-form-urlencoded'
        ];
        
        $options = array_merge($defaults, $options);
        
        ob_start();
        ?>
        <form id="<?php echo esc_attr($id); ?>" 
              method="<?php echo esc_attr($options['method']); ?>" 
              action="<?php echo esc_attr($options['action']); ?>" 
              class="<?php echo esc_attr($options['class']); ?>"
              enctype="<?php echo esc_attr($options['enctype']); ?>">
            <?php wp_nonce_field('loginpro_form_' . $id, 'loginpro_nonce'); ?>
            <?php echo $this->renderSections(); ?>
            <div class="form-actions">
                <button type="submit" class="button button-primary">
                    <?php echo esc_html($options['submit_text'] ?? __('Submit', 'loginpro')); ?>
                </button>
            </div>
        </form>
        <?php
        return ob_get_clean();
    }
    
    public function addSection($id, $title, $description = '') {
        $this->sections[$id] = [
            'title' => $title,
            'description' => $description,
            'fields' => []
        ];
        
        return $this;
    }
    
    public function addField($sectionId, $id, $label, $type = 'text', $options = []) {
        if (!isset($this->sections[$sectionId])) {
            $this->sections[$sectionId] = ['title' => '', 'description' => '', 'fields' => []];
        }
        
        $this->sections[$sectionId]['fields'][$id] = [
            'label' => $label,
            'type' => $type,
            'options' => $options
        ];
        
        return $this;
    }
    
    private function renderSections() {
        $html = '';
        
        foreach ($this->sections as $sectionId => $section) {
            $html .= '<div class="form-section" id="section-' . esc_attr($sectionId) . '">';
            
            if ($section['title']) {
                $html .= '<h3>' . esc_html($section['title']) . '</h3>';
            }
            
            if ($section['description']) {
                $html .= '<p class="section-description">' . esc_html($section['description']) . '</p>';
            }
            
            $html .= '<table class="form-table">';
            
            foreach ($section['fields'] as $fieldId => $field) {
                $html .= $this->renderField($fieldId, $field);
            }
            
            $html .= '</table>';
            $html .= '</div>';
        }
        
        return $html;
    }
    
    private function renderField($id, $field) {
        $value = get_option('loginpro_' . $id, $field['options']['default'] ?? '');
        
        ob_start();
        ?>
        <tr>
            <th scope="row">
                <label for="<?php echo esc_attr($id); ?>">
                    <?php echo esc_html($field['label']); ?>
                </label>
            </th>
            <td>
                <?php echo $this->renderInput($id, $field['type'], $field['options'], $value); ?>
                <?php if (!empty($field['options']['description'])): ?>
                    <p class="description"><?php echo esc_html($field['options']['description']); ?></p>
                <?php endif; ?>
            </td>
        </tr>
        <?php
        return ob_get_clean();
    }
    
    private function renderInput($id, $type, $options, $value) {
        $name = 'loginpro_' . $id;
        
        switch ($type) {
            case 'text':
            case 'url':
            case 'email':
            case 'number':
                return sprintf(
                    '<input type="%s" id="%s" name="%s" class="loginpro-input loginpro-input-regular" value="%s">',
                    $type,
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr($value)
                );
                
            case 'password':
                return sprintf(
                    '<input type="password" id="%s" name="%s" class="loginpro-input loginpro-input-regular" value="%s">',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr($value)
                );
                
            case 'checkbox':
                return sprintf(
                    '<input type="checkbox" id="%s" name="%s" value="1" %s>',
                    esc_attr($id),
                    esc_attr($name),
                    checked(1, $value, false)
                );
                
            case 'select':
                $html = sprintf('<select id="%s" name="%s" class="loginpro-select">', esc_attr($id), esc_attr($name));
                foreach ($options['choices'] as $optionValue => $optionLabel) {
                    $html .= sprintf(
                        '<option value="%s" %s>%s</option>',
                        esc_attr($optionValue),
                        selected($value, $optionValue, false),
                        esc_html($optionLabel)
                    );
                }
                $html .= '</select>';
                return $html;
                
            case 'textarea':
                return sprintf(
                    '<textarea id="%s" name="%s" rows="%s" class="loginpro-textarea loginpro-textarea-large">%s</textarea>',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr($options['rows'] ?? 5),
                    esc_textarea($value)
                );
                
            case 'color':
                return sprintf(
                    '<input type="color" id="%s" name="%s" class="loginpro-color-input" value="%s">',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr($value)
                );
                
            case 'media':
                return $this->renderMediaField($id, $name, $value);
                
            default:
                return sprintf(
                    '<input type="text" id="%s" name="%s" class="loginpro-input loginpro-input-regular" value="%s">',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr($value)
                );
        }
    }
    
    private function renderMediaField($id, $name, $value) {
        ob_start();
        ?>
        <div class="loginpro-media-field">
            <input type="text" id="<?php echo esc_attr($id); ?>" 
                   name="<?php echo esc_attr($name); ?>" 
                   class="loginpro-input loginpro-input-regular" value="<?php echo esc_attr($value); ?>">
            <button type="button" class="button upload-media-btn" data-target="<?php echo esc_attr($id); ?>">
                <?php _e('Upload', 'loginpro'); ?>
            </button>
            <?php if ($value): ?>
                <button type="button" class="button remove-media-btn" data-target="<?php echo esc_attr($id); ?>">
                    <?php _e('Remove', 'loginpro'); ?>
                </button>
                <div class="loginpro-media-preview">
                    <img src="<?php echo esc_url($value); ?>">
                </div>
            <?php endif; ?>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('.upload-media-btn').on('click', function() {
                var target = $(this).data('target');
                var customUploader = wp.media({
                    title: '<?php _e('Select Image', 'loginpro'); ?>',
                    button: { text: '<?php _e('Use this image', 'loginpro'); ?>' },
                    multiple: false
                });
                customUploader.on('select', function() {
                    var attachment = customUploader.state().get('selection').first().toJSON();
                    $('#' + target).val(attachment.url);
                });
                customUploader.open();
            });
            
            $('.remove-media-btn').on('click', function() {
                var target = $(this).data('target');
                $('#' + target).val('');
                $(this).siblings('.loginpro-media-preview').remove();
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    public function buildDynamicForm($config) {
        if (isset($config['sections'])) {
            foreach ($config['sections'] as $section) {
                $this->addSection($section['id'], $section['title'], $section['description'] ?? '');
                
                foreach ($section['fields'] as $field) {
                    $this->addField(
                        $section['id'],
                        $field['id'],
                        $field['label'],
                        $field['type'],
                        $field['options'] ?? []
                    );
                }
            }
        }
        
        return $this->createForm($config['id'], $config['form_options'] ?? []);
    }
}