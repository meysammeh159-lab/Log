<?php
namespace LoginPro\Admin;

class ShortcodesPage
{
    public function __construct($container = null) {}

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        ?>
        <div class="wrap loginpro-shortcodes-wrap">
            <!-- هدر زیبا -->
            <div class="loginpro-shortcodes-header">
                <div class="loginpro-shortcodes-header-content">
                    <h1 class="loginpro-shortcodes-title">
                        <span class="dashicons dashicons-editor-code"></span>
                        شورت‌کدهای افزونه لاگین‌پرو
                    </h1>
                    <p class="loginpro-shortcodes-subtitle">
                        با استفاده از شورت‌کدهای زیر، فرم‌های لاگین، ثبت‌نام و داشبورد را در صفحات خود نمایش دهید
                    </p>
                </div>
            </div>

            <!-- کارت‌های آمار -->
            <div class="loginpro-shortcodes-stats">
                <div class="loginpro-stat-card">
                    <div class="loginpro-stat-number">8+</div>
                    <div class="loginpro-stat-label">شورت‌کد فعال</div>
                </div>
                <div class="loginpro-stat-card">
                    <div class="loginpro-stat-number">100%</div>
                    <div class="loginpro-stat-label">پیشرفته و حرفه‌ای</div>
                </div>
                <div class="loginpro-stat-card">
                    <div class="loginpro-stat-number">📱</div>
                    <div class="loginpro-stat-label">واکنش‌گرا</div>
                </div>
                <div class="loginpro-stat-card">
                    <div class="loginpro-stat-number">⚡</div>
                    <div class="loginpro-stat-label">سریع و بهینه</div>
                </div>
            </div>

            <!-- جدول شورت‌کدها -->
            <div class="loginpro-shortcodes-table-wrapper">
                <table class="wp-list-table widefat fixed striped loginpro-shortcodes-table">
                    <thead>
                        <tr>
                            <th width="35%">شورت‌کد</th>
                            <th width="50%">توضیحات</th>
                            <th width="15%">دسته‌بندی</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_login]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_login]">📋 کپی</button>
                            </div> 
                            <td>
                                <strong>فرم لاگین هوشمند</strong>
                                <div class="loginpro-shortcode-desc">فرم ورود با قابلیت تشخیص ایمیل/نام کاربری/موبایل و ارسال کد تأیید (OTP)</div>
                                <div class="loginpro-shortcode-params">پارامترها: <code>redirect</code>, <code>class</code>, <code>label</code></div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-login">ورود</span></div>
                        </tr>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_register]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_register]">📋 کپی</button>
                             </div>
                            <td>
                                <strong>فرم ثبت‌نام کاربری</strong>
                                <div class="loginpro-shortcode-desc">فرم ثبت‌نام کاربر جدید با اعتبارسنجی پیشرفته و کپچا</div>
                                <div class="loginpro-shortcode-params">پارامترها: <code>redirect</code>, <code>role</code>, <code>class</code></div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-register">ثبت‌نام</span></div>
                        </tr>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_user]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_user]">📋 کپی</button>
                             </div>
                            <td>
                                <strong>داشبورد کامل کاربری</strong>
                                <div class="loginpro-shortcode-desc">داشبورد کامل با تب‌های مختلف (اطلاعات شخصی، امنیت، فعالیت‌ها)</div>
                                <div class="loginpro-shortcode-params">پارامترها: <code>tabs</code>, <code>layout</code>, <code>class</code></div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-dashboard">داشبورد</span></div>
                        </tr>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_dashboard]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_dashboard]">📋 کپی</button>
                             </div>
                            <td>
                                <strong>داشبورد ساده کاربری</strong>
                                <div class="loginpro-shortcode-desc">نسخه ساده داشبورد با نمایش اطلاعات پایه کاربر</div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-dashboard">داشبورد</span></div>
                        </tr>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_profile]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_profile]">📋 کپی</button>
                             </div>
                            <td>
                                <strong>پروفایل کاربری</strong>
                                <div class="loginpro-shortcode-desc">نمایش و ویرایش پروفایل کاربر (نام، ایمیل، آواتار و ...)</div>
                                <div class="loginpro-shortcode-params">پارامترها: <code>show_avatar</code>, <code>show_basic_info</code>, <code>class</code></div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-profile">پروفایل</span></div>
                        </tr>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_security]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_security]">📋 کپی</button>
                             </div>
                            <td>
                                <strong>تنظیمات امنیتی</strong>
                                <div class="loginpro-shortcode-desc">تغییر رمز عبور، فعال‌سازی احراز دو مرحله‌ای و تنظیمات امنیتی</div>
                                <div class="loginpro-shortcode-params">پارامترها: <code>show_2fa</code>, <code>show_password</code>, <code>class</code></div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-security">امنیت</span></div>
                        </tr>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_logout]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_logout]">📋 کپی</button>
                             </div>
                            <td>
                                <strong>دکمه خروج</strong>
                                <div class="loginpro-shortcode-desc">دکمه خروج از حساب کاربری (فقط برای کاربران وارد شده)</div>
                                <div class="loginpro-shortcode-params">پارامترها: <code>redirect</code>, <code>button_text</code>, <code>class</code></div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-logout">خروج</span></div>
                        </tr>
                        <tr>
                            <td>
                                <code class="loginpro-shortcode">[loginpro_reset_password]</code>
                                <button class="button button-small loginpro-copy-btn" data-code="[loginpro_reset_password]">📋 کپی</button>
                             </div>
                            <td>
                                <strong>بازیابی رمز عبور</strong>
                                <div class="loginpro-shortcode-desc">فرم بازیابی رمز عبور از طریق ایمیل یا پیامک</div>
                             </div>
                            <td><span class="loginpro-badge loginpro-badge-security">بازیابی</span></div>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- مثال‌های کاربردی -->
            <div class="loginpro-examples-box">
                <h3 class="loginpro-examples-title">
                    <span class="dashicons dashicons-lightbulb"></span>
                    مثال‌های کاربردی
                </h3>
                <div class="loginpro-examples-grid">
                    <div class="loginpro-example-item">
                        <div class="loginpro-example-title">صفحه ورود با هدایت به داشبورد</div>
                        <code class="loginpro-example-code">[loginpro_login redirect="/dashboard"]</code>
                        <button class="button button-small loginpro-copy-btn" data-code='[loginpro_login redirect="/dashboard"]'>📋 کپی شورت‌کد</button>
                    </div>
                    <div class="loginpro-example-item">
                        <div class="loginpro-example-title">دکمه خروج با متن دلخواه</div>
                        <code class="loginpro-example-code">[loginpro_logout button_text="🚪 خروج از حساب" redirect="/"]</code>
                        <button class="button button-small loginpro-copy-btn" data-code='[loginpro_logout button_text="🚪 خروج از حساب" redirect="/"]'>📋 کپی شورت‌کد</button>
                    </div>
                    <div class="loginpro-example-item">
                        <div class="loginpro-example-title">پروفایل بدون آواتار</div>
                        <code class="loginpro-example-code">[loginpro_profile show_avatar="no"]</code>
                        <button class="button button-small loginpro-copy-btn" data-code='[loginpro_profile show_avatar="no"]'>📋 کپی شورت‌کد</button>
                    </div>
                    <div class="loginpro-example-item">
                        <div class="loginpro-example-title">ثبت‌نام کاربر با نقش خاص</div>
                        <code class="loginpro-example-code">[loginpro_register role="subscriber" redirect="/welcome"]</code>
                        <button class="button button-small loginpro-copy-btn" data-code='[loginpro_register role="subscriber" redirect="/welcome"]'>📋 کپی شورت‌کد</button>
                    </div>
                </div>
            </div>

            <!-- نکات مهم -->
            <div class="loginpro-tips-box">
                <h3 class="loginpro-tips-title">
                    <span class="dashicons dashicons-info"></span>
                    نکات مهم
                </h3>
                <ul class="loginpro-tips-list">
                    <li>✅ برای نمایش فرم لاگین در صفحه، کافی است شورت‌کد <code>[loginpro_login]</code> را در صفحه قرار دهید.</li>
                    <li>✅ پارامتر <code>redirect</code> آدرس هدایت بعد از لاگین/ثبت‌نام/خروج را مشخص می‌کند.</li>
                    <li>✅ پارامتر <code>class</code> برای افزودن کلاس CSS سفارشی به فرم استفاده می‌شود.</li>
                    <li>✅ تمام فرم‌ها با موبایل، تبلت و دسکتاپ سازگار هستند (واکنش‌گرا).</li>
                    <li>✅ می‌توانید ظاهر فرم‌ها را از بخش <strong>تنظیمات ظاهر</strong> در منوی ادمین شخصی‌سازی کنید.</li>
                    <li>✅ تمام متن‌های فرم (عنوان، زیرنویس، متن راهنما) در بخش <strong>تنظیمات ظاهر → تب متن‌ها</strong> قابل ویرایش هستند.</li>
                </ul>
            </div>
        </div>

        <style>
            /* استایل‌های صفحه شورت‌کد */
            .loginpro-shortcodes-wrap {
                max-width: 1400px;
                margin: 20px 20px 0 0;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            }

            /* هدر */
            .loginpro-shortcodes-header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 16px;
                padding: 35px 30px;
                margin-bottom: 30px;
                color: white;
            }

            .loginpro-shortcodes-title {
                font-size: 28px;
                font-weight: 700;
                margin: 0 0 10px 0;
                display: flex;
                align-items: center;
                gap: 10px;
            }

            .loginpro-shortcodes-title .dashicons {
                font-size: 32px;
                width: 32px;
                height: 32px;
            }

            .loginpro-shortcodes-subtitle {
                font-size: 15px;
                opacity: 0.9;
                margin: 0;
            }

            /* کارت‌های آمار */
            .loginpro-shortcodes-stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }

            .loginpro-stat-card {
                background: white;
                border-radius: 12px;
                padding: 20px;
                text-align: center;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08);
                border: 1px solid #e2e8f0;
                transition: transform 0.2s;
            }

            .loginpro-stat-card:hover {
                transform: translateY(-3px);
                box-shadow: 0 4px 15px rgba(0,0,0,0.12);
            }

            .loginpro-stat-number {
                font-size: 32px;
                font-weight: 800;
                background: linear-gradient(135deg, #667eea, #764ba2);
                -webkit-background-clip: text;
                background-clip: text;
                color: transparent;
                margin-bottom: 8px;
            }

            .loginpro-stat-label {
                color: #64748b;
                font-size: 14px;
                font-weight: 500;
            }

            /* جدول */
            .loginpro-shortcodes-table-wrapper {
                background: white;
                border-radius: 16px;
                overflow: hidden;
                margin-bottom: 30px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            }

            .loginpro-shortcodes-table th {
                background: #f8fafc;
                font-weight: 700;
                font-size: 14px;
            }

            .loginpro-shortcode {
                background: #f1f5f9;
                padding: 6px 12px;
                border-radius: 8px;
                font-family: monospace;
                font-size: 13px;
                color: #d63384;
                direction: ltr;
                display: inline-block;
                margin-left: 8px;
            }

            .loginpro-shortcode-desc {
                color: #475569;
                font-size: 13px;
                margin: 6px 0;
            }

            .loginpro-shortcode-params {
                font-size: 11px;
                color: #94a3b8;
                margin-top: 5px;
            }

            .loginpro-shortcode-params code {
                background: none;
                padding: 0;
                color: #667eea;
            }

            /* بج‌ها */
            .loginpro-badge {
                display: inline-block;
                padding: 4px 12px;
                border-radius: 30px;
                font-size: 11px;
                font-weight: 600;
            }

            .loginpro-badge-login { background: #e0f2fe; color: #0369a1; }
            .loginpro-badge-register { background: #dcfce7; color: #15803d; }
            .loginpro-badge-dashboard { background: #fff3e0; color: #b45309; }
            .loginpro-badge-profile { background: #d1fae5; color: #047857; }
            .loginpro-badge-security { background: #f3e8ff; color: #6b21a5; }
            .loginpro-badge-logout { background: #fee2e2; color: #b91c1c; }

            /* دکمه کپی */
            .loginpro-copy-btn {
                margin-right: 8px;
                vertical-align: middle;
            }

            /* بخش مثال‌ها */
            .loginpro-examples-box {
                background: linear-gradient(135deg, #f8fafc, #f1f5f9);
                border-radius: 16px;
                padding: 25px;
                margin-bottom: 25px;
            }

            .loginpro-examples-title {
                font-size: 20px;
                font-weight: 700;
                color: #1e293b;
                margin: 0 0 20px 0;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .loginpro-examples-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 15px;
            }

            .loginpro-example-item {
                background: white;
                border-radius: 12px;
                padding: 15px;
                border: 1px solid #e2e8f0;
            }

            .loginpro-example-title {
                font-weight: 600;
                color: #334155;
                margin-bottom: 10px;
                font-size: 14px;
            }

            .loginpro-example-code {
                background: #f1f5f9;
                padding: 8px 12px;
                border-radius: 8px;
                font-family: monospace;
                font-size: 12px;
                direction: ltr;
                display: inline-block;
                margin-bottom: 10px;
                width: 100%;
                overflow-x: auto;
                white-space: nowrap;
            }

            /* بخش نکات */
            .loginpro-tips-box {
                background: #fefce8;
                border-radius: 16px;
                padding: 25px;
                border: 1px solid #fde047;
            }

            .loginpro-tips-title {
                font-size: 18px;
                font-weight: 700;
                color: #854d0e;
                margin: 0 0 15px 0;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .loginpro-tips-list {
                margin: 0;
                padding-right: 20px;
            }

            .loginpro-tips-list li {
                margin: 8px 0;
                line-height: 1.6;
                color: #713f12;
            }

            .loginpro-tips-list code {
                background: #fde68a;
                padding: 2px 6px;
                border-radius: 4px;
                font-size: 12px;
            }

            /* ریسپانسیو */
            @media (max-width: 768px) {
                .loginpro-shortcodes-title { font-size: 22px; }
                .loginpro-shortcodes-header { padding: 25px 20px; }
                .loginpro-example-code { font-size: 10px; white-space: normal; }
            }
        </style>

        <script>
        jQuery(document).ready(function($) {
            $('.loginpro-copy-btn').on('click', function() {
                var code = $(this).data('code');
                var $temp = $('<textarea>');
                $('body').append($temp);
                $temp.val(code).select();
                document.execCommand('copy');
                $temp.remove();
                
                var $btn = $(this);
                var originalText = $btn.html();
                $btn.html('✅ کپی شد!');
                setTimeout(function() {
                    $btn.html(originalText);
                }, 2000);
            });
        });
        </script>
        <?php
    }
}