<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class LogsPage
{
    private $container;
    private $nonceAction = 'loginpro_admin';

    public function __construct($container = null)
    {
        $this->container = $container;
    }

    public function render(): void
    {
        $this->renderPage();
    }

    public function renderPage(): void
    {
        global $wpdb;
        
        $table = $wpdb->prefix . 'loginpro_security_events';
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
        
        if (!$tableExists) {
            echo '<div class="wrap"><div class="notice notice-warning"><p>' . 
                 esc_html__('جدول لاگ‌های امنیتی هنوز ایجاد نشده است. لطفاً افزونه را غیرفعال و دوباره فعال کنید.', 'loginpro') . 
                 '</p></div></div>';
            return;
        }
        
        $critical = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE severity = 'critical'");
        $warning = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE severity = 'warning'");
        $info = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE severity = 'info'");
        $total = $critical + $warning + $info;
        
        $events = $wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 50");
        ?>
        <div class="wrap loginpro-admin-wrap">
            <h1><?php esc_html_e('لاگ‌های امنیتی', 'loginpro'); ?></h1>
            
            <div class="loginpro-queue-stats">
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number" style="color:#d63638;"><?php echo (int) $critical; ?></div>
                    <div><?php esc_html_e('رویدادهای بحرانی', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number" style="color:#f0b849;"><?php echo (int) $warning; ?></div>
                    <div><?php esc_html_e('هشدارها', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number" style="color:#2271b1;"><?php echo (int) $info; ?></div>
                    <div><?php esc_html_e('رویدادهای اطلاعاتی', 'loginpro'); ?></div>
                </div>
                <div class="loginpro-queue-stat">
                    <div class="loginpro-queue-stat-number"><?php echo (int) $total; ?></div>
                    <div><?php esc_html_e('کل رویدادها', 'loginpro'); ?></div>
                </div>
            </div>
            
            <div class="loginpro-form-row loginpro-gap-10" style="margin-bottom:20px;">
                <select id="log-filter-type" class="loginpro-select">
                    <option value=""><?php esc_html_e('همه رویدادها', 'loginpro'); ?></option>
                    <option value="login_success"><?php esc_html_e('ورود موفق', 'loginpro'); ?></option>
                    <option value="login_failed"><?php esc_html_e('ورود ناموفق', 'loginpro'); ?></option>
                    <option value="otp_sent"><?php esc_html_e('ارسال OTP', 'loginpro'); ?></option>
                    <option value="otp_verified"><?php esc_html_e('تأیید OTP', 'loginpro'); ?></option>
                    <option value="password_changed"><?php esc_html_e('تغییر رمز', 'loginpro'); ?></option>
                </select>
                <select id="log-filter-severity" class="loginpro-select">
                    <option value=""><?php esc_html_e('همه سطوح', 'loginpro'); ?></option>
                    <option value="critical"><?php esc_html_e('بحرانی', 'loginpro'); ?></option>
                    <option value="warning"><?php esc_html_e('هشدار', 'loginpro'); ?></option>
                    <option value="info"><?php esc_html_e('اطلاعاتی', 'loginpro'); ?></option>
                </select>
                <button id="apply-filters" class="button"><?php esc_html_e('اعمال فیلتر', 'loginpro'); ?></button>
                <button id="export-logs" class="button"><?php esc_html_e('خروجی CSV', 'loginpro'); ?></button>
                <button id="clear-logs" class="button"><?php esc_html_e('پاک کردن لاگ‌های قدیمی', 'loginpro'); ?></button>
            </div>
            
            <div class="loginpro-admin-card">
                <h3><?php esc_html_e('رویدادهای امنیتی', 'loginpro'); ?></h3>
                <table class="wp-list-table widefat fixed striped" id="logs-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('زمان', 'loginpro'); ?></th>
                            <th><?php esc_html_e('نوع رویداد', 'loginpro'); ?></th>
                            <th><?php esc_html_e('سطح', 'loginpro'); ?></th>
                            <th><?php esc_html_e('کاربر', 'loginpro'); ?></th>
                            <th><?php esc_html_e('آی‌پی', 'loginpro'); ?></th>
                            <th><?php esc_html_e('جزئیات', 'loginpro'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="logs-table-body">
                        <?php foreach ($events as $event): ?>
                        <tr>
                            <td><?php echo esc_html($event->created_at); ?></td>
                            <td><?php echo esc_html($event->event_type); ?></td>
                            <td><span class="loginpro-severity-<?php echo esc_attr($event->severity); ?>"><?php echo esc_html($event->severity); ?></span></td>
                            <td><?php 
                                $user = $event->user_id ? get_userdata($event->user_id) : null;
                                echo $user ? esc_html($user->user_login) : ( $event->user_id ? esc_html($event->user_id) : '-' ); 
                            ?></td>
                            <td><?php echo esc_html($event->ip_address); ?></td>
                            <td><button class="button button-small view-details" data-id="<?php echo (int) $event->id; ?>"><?php esc_html_e('نمایش', 'loginpro'); ?></button></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="log-details-modal" class="loginpro-modal" style="display:none;">
            <div class="loginpro-modal-content">
                <div class="loginpro-modal-header">
                    <h3><?php esc_html_e('جزئیات رویداد', 'loginpro'); ?></h3>
                    <span class="loginpro-modal-close close-modal">&times;</span>
                </div>
                <div id="log-details-content" class="loginpro-modal-body"></div>
            </div>
        </div>
        
        <style>
        .loginpro-queue-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .loginpro-queue-stat {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
        }
        .loginpro-queue-stat-number {
            font-size: 28px;
            font-weight: bold;
        }
        .loginpro-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999999;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loginpro-modal-content {
            background: #fff;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow: auto;
        }
        .loginpro-modal-header {
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .loginpro-modal-close {
            cursor: pointer;
            font-size: 24px;
        }
        .loginpro-modal-body {
            padding: 20px;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#apply-filters').on('click', function() {
                var eventType = $('#log-filter-type').val();
                var severity = $('#log-filter-severity').val();
                
                $.get(ajaxurl, {
                    action: 'loginpro_logs_action', 
                    task: 'filter', 
                    event_type: eventType, 
                    severity: severity, 
                    _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'
                }, function(response) {
                    if (response.success) $('#logs-table-body').html(response.html);
                });
            });
            
            $('#export-logs').on('click', function() {
                window.location.href = ajaxurl + '?action=loginpro_logs_action&task=export&_nonce=<?php echo wp_create_nonce('loginpro_admin'); ?>';
            });
            
            $('#clear-logs').on('click', function() {
                if (confirm('<?php esc_html_e('آیا از پاک کردن لاگ‌های قدیمی (بیشتر از 90 روز) مطمئن هستید؟', 'loginpro'); ?>')) {
                    $.post(ajaxurl, {action: 'loginpro_logs_action', task: 'clear', _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                        if (response.success) location.reload();
                    });
                }
            });
            
            $(document).on('click', '.view-details', function() {
                var eventId = $(this).data('id');
                $.get(ajaxurl, {action: 'loginpro_logs_action', task: 'details', event_id: eventId, _nonce: '<?php echo wp_create_nonce('loginpro_admin'); ?>'}, function(response) {
                    if (response.success) {
                        $('#log-details-content').html(response.html);
                        $('#log-details-modal').show();
                    }
                });
            });
            
            $('.close-modal, #log-details-modal').on('click', function(e) {
                if (e.target === this) $('#log-details-modal').hide();
            });
        });
        </script>
        <?php
    }
    
    public function handleAjax(): void
    {
        if (!check_ajax_referer('loginpro_admin', '_nonce', false)) {
            wp_send_json_error(['message' => __('خطای امنیتی', 'loginpro')]);
            return;
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('دسترسی غیرمجاز.', 'loginpro')]);
            return;
        }
        
        global $wpdb;
        $task = sanitize_text_field($_GET['task'] ?? $_POST['task'] ?? '');
        
        switch ($task) {
            case 'filter':
                $where = [];
                $params = [];
                
                if (!empty($_GET['event_type'])) {
                    $where[] = 'event_type = %s';
                    $params[] = sanitize_text_field($_GET['event_type']);
                }
                if (!empty($_GET['severity'])) {
                    $where[] = 'severity = %s';
                    $params[] = sanitize_text_field($_GET['severity']);
                }
                
                $whereSql = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                $query = "SELECT * FROM {$wpdb->prefix}loginpro_security_events {$whereSql} ORDER BY created_at DESC LIMIT 100";
                
                if (!empty($params)) {
                    $events = $wpdb->get_results($wpdb->prepare($query, $params));
                } else {
                    $events = $wpdb->get_results($query);
                }
                
                ob_start();
                foreach ($events as $event): ?>
                    <tr>
                        <td><?php echo esc_html($event->created_at); ?></td>
                        <td><?php echo esc_html($event->event_type); ?></td>
                        <td><span class="loginpro-severity-<?php echo esc_attr($event->severity); ?>"><?php echo esc_html($event->severity); ?></span></td>
                        <td><?php 
                            $user = $event->user_id ? get_userdata($event->user_id) : null;
                            echo $user ? esc_html($user->user_login) : ( $event->user_id ? esc_html($event->user_id) : '-' ); 
                        ?></td>
                        <td><?php echo esc_html($event->ip_address); ?></td>
                        <td><button class="button button-small view-details" data-id="<?php echo (int) $event->id; ?>"><?php esc_html_e('نمایش', 'loginpro'); ?></button></td>
                    </tr>
                <?php endforeach;
                $html = ob_get_clean();
                wp_send_json_success(['html' => $html]);
                break;
                
            case 'details':
                $eventId = (int) ($_GET['event_id'] ?? 0);
                $event = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}loginpro_security_events WHERE id = %d",
                    $eventId
                ));
                
                if (!$event) {
                    wp_send_json_error(['message' => __('رویداد یافت نشد.', 'loginpro')]);
                    return;
                }
                
                $user = $event->user_id ? get_userdata($event->user_id) : null;
                $details = json_decode($event->details, true);
                
                $html = '<table class="widefat loginpro-admin-table">';
                $html .= '<tr><th>' . esc_html__('شناسه', 'loginpro') . '</th><td>' . (int) $event->id . '</td></tr>';
                $html .= '<tr><th>' . esc_html__('نوع رویداد', 'loginpro') . '</th><td>' . esc_html($event->event_type) . '</td></tr>';
                $html .= '<tr><th>' . esc_html__('سطح', 'loginpro') . '</th><td>' . esc_html($event->severity) . '</td></tr>';
                $html .= '<tr><th>' . esc_html__('کاربر', 'loginpro') . '</th><td>' . ($user ? esc_html($user->user_login) : ( $event->user_id ? esc_html($event->user_id) : '-' )) . '</td></tr>';
                $html .= '<tr><th>' . esc_html__('آی‌پی', 'loginpro') . '</th><td>' . esc_html($event->ip_address) . '</td></tr>';
                $html .= '<tr><th>' . esc_html__('زمان', 'loginpro') . '</th><td>' . esc_html($event->created_at) . '</td></tr>';
                $html .= '<tr><th>' . esc_html__('جزئیات', 'loginpro') . '</th><td><pre>' . esc_html(print_r($details, true)) . '</pre></td></tr>';
                $html .= '</table>';
                
                wp_send_json_success(['html' => $html]);
                break;
                
            case 'export':
                $events = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}loginpro_security_events ORDER BY created_at DESC");
                header('Content-Type: text/csv; charset=utf-8');
                header('Content-Disposition: attachment; filename="loginpro-security-logs-' . date('Y-m-d') . '.csv"');
                
                $output = fopen('php://output', 'w');
                fputcsv($output, ['شناسه', 'نوع رویداد', 'سطح', 'کاربر', 'آی‌پی', 'زمان', 'جزئیات']);
                
                foreach ($events as $event) {
                    fputcsv($output, [
                        $event->id,
                        $event->event_type,
                        $event->severity,
                        $event->user_id,
                        $event->ip_address,
                        $event->created_at,
                        $event->details
                    ]);
                }
                fclose($output);
                exit;
                break;
                
            case 'clear':
                $deleted = $wpdb->query("DELETE FROM {$wpdb->prefix}loginpro_security_events WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)");
                wp_send_json_success(['message' => sprintf(esc_html__('%d لاگ حذف شد.', 'loginpro'), (int) $deleted)]);
                break;
                
            default:
                wp_send_json_error(['message' => __('دستور نامعتبر.', 'loginpro')]);
        }
    }
}