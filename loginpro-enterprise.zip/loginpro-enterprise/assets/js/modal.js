/**
 * مدیریت مودال لاگین پرو
 * @package LoginPro
 */

(function () {
    'use strict';

    if (window.loginproModalLoaded) return;
    window.loginproModalLoaded = true;

    // ✅ بررسی وجود loginpro_ajax
    if (typeof loginpro_ajax === 'undefined') {
        console.error('LoginPro: loginpro_ajax is not defined!');
        // تلاش برای ایجاد آن
        window.loginpro_ajax = {
            ajax_url: '/wp-admin/admin-ajax.php',
            nonce: ''
        };
    }

    var overlay = document.getElementById('loginpro-modal-overlay');
    var closeBtn = document.getElementById('loginpro-modal-close');
    var content = document.getElementById('loginpro-modal-content');

    if (!overlay || !content) {
        console.warn('LoginPro: Modal elements not found');
        return;
    }

    console.log('LoginPro: Modal initialized with ajax:', loginpro_ajax);

    function openModal() {
        overlay.className = 'active';
        document.body.style.overflow = 'hidden';
        loadLoginForm();
    }

    function closeModal() {
        overlay.className = '';
        document.body.style.overflow = '';
    }

    function loadLoginForm() {
        content.innerHTML = '<div style="text-align:center;padding:40px 20px;">' +
            '<div style="font-size:48px;margin-bottom:20px;">⏳</div>' +
            '<h3 style="margin:0 0 10px;color:#1a1a1a;">در حال بارگذاری...</h3>' +
            '<p style="color:#666;font-size:14px;">لطفاً چند لحظه صبر کنید</p>' +
            '</div>';

        var formData = new FormData();
        formData.append('action', 'loginpro_get_modal_form');
        formData.append('_nonce', loginpro_ajax.nonce || '');

        fetch(loginpro_ajax.ajax_url, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(function (response) {
            if (!response.ok) {
                throw new Error('HTTP error ' + response.status);
            }
            return response.json();
        })
        .then(function (data) {
            console.log('Modal response:', data);
            
            if (data.success) {
                content.innerHTML = data.data.html;
                var scripts = content.querySelectorAll('script');
                scripts.forEach(function (script) {
                    var newScript = document.createElement('script');
                    if (script.src) {
                        newScript.src = script.src;
                    } else {
                        newScript.textContent = script.textContent;
                    }
                    document.head.appendChild(newScript);
                });
            } else {
                showError(data.message || data.data?.message || 'خطا در بارگذاری فرم');
            }
        })
        .catch(function (error) {
            console.error('Modal error:', error);
            showError('خطا در ارتباط با سرور: ' + error.message);
        });
    }

    function showError(message) {
        content.innerHTML = '<div style="text-align:center;padding:30px;">' +
            '<div style="font-size:48px;margin-bottom:20px;">❌</div>' +
            '<h3 style="color:#dc3545;margin:0 0 10px;">خطا</h3>' +
            '<p style="color:#666;font-size:14px;">' + message + '</p>' +
            '<button onclick="location.reload()" style="margin-top:15px;background:#ef394e;color:#fff;border:none;border-radius:8px;padding:10px 24px;cursor:pointer;font-size:14px;">🔄 تلاش مجدد</button>' +
            '</div>';
    }

    // رویدادها
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }

    overlay.addEventListener('click', function (e) {
        if (e.target === this) {
            closeModal();
        }
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && overlay.className === 'active') {
            closeModal();
        }
    });

    document.addEventListener('click', function (e) {
        var trigger = e.target.closest('[data-loginpro-trigger="true"]');
        if (trigger) {
            e.preventDefault();
            openModal();
        }
    });

    if (overlay.className === 'active') {
        loadLoginForm();
    }

    console.log('LoginPro: Modal initialized successfully');

})();