/**
 * LoginPro — Support Tickets
 * مسیر: /wp-content/plugins/loginpro-enterprise/assets/js/tickets.js
 *
 * این فایل به‌صورت کامل مستقل از HTML عمل می‌کند:
 * - هیچ کد inline در PHP وجود ندارد.
 * - از Event Delegation روی document استفاده می‌شود، بنابراین:
 *      ✔ با افزونه‌های Delay JS (مثل WP Rocket / LiteSpeed / Perfmatters) سازگار است
 *      ✔ با Minify JS مشکلی ندارد چون هیچ selector شکننده‌ای ندارد
 *      ✔ برای المان‌هایی که بعداً به DOM اضافه می‌شوند هم کار می‌کند (مودال، فرم پاسخ و ...)
 * - تمام تنظیمات (ajaxUrl, nonce, رنگ اصلی, متن‌ها) از طریق wp_localize_script
 *   در آبجکت سراسری `LoginProTickets` تزریق می‌شود (به‌جای هاردکد در PHP).
 */

(function () {
    'use strict';

    // اگر داده‌های لازم توسط wp_localize_script تزریق نشده باشند، متوقف شو
    if (typeof window.LoginProTickets === 'undefined') {
        return;
    }

    var CFG = window.LoginProTickets;
    var AJAX_URL = CFG.ajaxUrl;
    var NONCE = CFG.nonce;
    var I18N = CFG.i18n || {};

    function t(key, fallback) {
        return (I18N && I18N[key]) ? I18N[key] : fallback;
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    function qs(selector, ctx) {
        return (ctx || document).querySelector(selector);
    }

    function qsa(selector, ctx) {
        return Array.prototype.slice.call((ctx || document).querySelectorAll(selector));
    }

    function escapeHtml(text) {
        if (!text) return '';
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function ajaxPost(action, params, isFormData) {
        var body;

        if (isFormData) {
            body = params; // already a FormData instance
            body.append('action', action);
            body.append('_nonce', NONCE);
        } else {
            body = new FormData();
            body.append('action', action);
            body.append('_nonce', NONCE);
            Object.keys(params || {}).forEach(function (key) {
                body.append(key, params[key]);
            });
        }

        return fetch(AJAX_URL, {
            method: 'POST',
            body: body,
            credentials: 'same-origin'
        }).then(function (res) {
            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }
            return res.json();
        });
    }

    function showResponseBox(box, message, isSuccess) {
        if (!box) return;
        box.style.display = 'block';
        box.textContent = message;
        if (isSuccess) {
            box.style.background = '#f0fff4';
            box.style.color = '#28a745';
            box.style.border = '1px solid #c3e6cb';
        } else {
            box.style.background = '#fff5f5';
            box.style.color = '#dc3545';
            box.style.border = '1px solid #f5c6cb';
        }
    }

    // ------------------------------------------------------------------
    // New ticket form (show / hide / submit)
    // ------------------------------------------------------------------

    function resetNewTicketForm(root) {
        var subject = qs('#loginpro-ticket-subject', root);
        var message = qs('#loginpro-ticket-message', root);
        var fileInput = qs('#loginpro-ticket-file', root);
        var fileDisplay = qs('#loginpro-ticket-file-name', root);
        var priority = qs('#loginpro-ticket-priority', root);
        var department = qs('#loginpro-ticket-department', root);
        var response = qs('#loginpro-ticket-response', root);

        if (subject) subject.value = '';
        if (message) message.value = '';
        if (fileInput) fileInput.value = '';
        if (fileDisplay) fileDisplay.textContent = '';
        if (priority) priority.value = 'normal';
        if (department) department.value = 'general';
        if (response) {
            response.style.display = 'none';
            response.textContent = '';
        }
    }

    function submitNewTicket(root) {
        var subject = qs('#loginpro-ticket-subject', root);
        var message = qs('#loginpro-ticket-message', root);
        var priority = qs('#loginpro-ticket-priority', root);
        var department = qs('#loginpro-ticket-department', root);
        var fileInput = qs('#loginpro-ticket-file', root);
        var response = qs('#loginpro-ticket-response', root);
        var submitBtn = qs('#loginpro-ticket-submit-btn', root);

        if (!subject || !message || !response) return;

        var subjectVal = subject.value.trim();
        var messageVal = message.value.trim();

        if (!subjectVal || !messageVal) {
            showResponseBox(response, t('fillRequired', 'لطفاً موضوع و متن تیکت را وارد کنید.'), false);
            return;
        }

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = t('sending', 'در حال ارسال...');
        }

        var formData = new FormData();
        formData.append('subject', subjectVal);
        formData.append('message', messageVal);
        formData.append('priority', priority ? priority.value : 'normal');
        formData.append('department', department ? department.value : 'general');

        if (fileInput && fileInput.files && fileInput.files.length > 0) {
            formData.append('ticket_file', fileInput.files[0]);
        }

        ajaxPost('loginpro_submit_ticket', formData, true)
            .then(function (data) {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = t('sendTicket', '📤 ارسال تیکت');
                }

                if (data.success) {
                    showResponseBox(response, (data.data && data.data.message) || t('ticketSent', 'تیکت با موفقیت ثبت شد.'), true);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1500);
                } else {
                    showResponseBox(response, (data.data && data.data.message) || t('ticketError', 'خطا در ثبت تیکت.'), false);
                }
            })
            .catch(function (err) {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = t('sendTicket', '📤 ارسال تیکت');
                }
                showResponseBox(response, t('serverError', 'خطا در ارتباط با سرور.'), false);
                console.error('LoginPro ticket submit error:', err);
            });
    }

    // ------------------------------------------------------------------
    // Ticket detail modal
    // ------------------------------------------------------------------

    var statusLabels = {
        open: 'در حال بررسی',
        pending: 'در انتظار پاسخ',
        closed: 'بسته شده',
        resolved: 'حل شده'
    };
    var statusColors = { open: '#28a745', pending: '#ffc107', closed: '#6c757d', resolved: '#17a2b8' };
    var priorityLabels = { low: 'کم', normal: 'عادی', high: 'بالا', urgent: 'فوری' };
    var priorityColors = { low: '#28a745', normal: '#ffc107', high: '#fd7e14', urgent: '#dc3545' };

    function openModal() {
        var modal = qs('#loginpro-user-ticket-modal');
        if (!modal) return;
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        var modal = qs('#loginpro-user-ticket-modal');
        if (!modal) return;
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }

    function loadTicketDetail(ticketId) {
        var modalContent = qs('#loginpro-user-modal-content');
        if (!modalContent || !ticketId) return;

        openModal();
        modalContent.innerHTML = '<div style="text-align:center;padding:30px;color:#999;">⏳ ' + t('loading', 'در حال بارگذاری...') + '</div>';

        ajaxPost('loginpro_user_get_ticket_detail', { ticket_id: ticketId })
            .then(function (data) {
                if (data.success) {
                    renderTicketDetail(data.data);
                } else {
                    modalContent.innerHTML = '<div style="text-align:center;padding:30px;color:#dc3545;">❌ ' +
                        escapeHtml((data.data && data.data.message) || t('loadError', 'خطا در بارگذاری')) +
                        '</div>';
                }
            })
            .catch(function (err) {
                modalContent.innerHTML = '<div style="text-align:center;padding:30px;color:#dc3545;">❌ ' + t('serverError', 'خطا در ارتباط با سرور') + '</div>';
                console.error('LoginPro ticket detail error:', err);
            });
    }

    function renderTicketDetail(ticket) {
        var modalContent = qs('#loginpro-user-modal-content');
        if (!modalContent) return;

        var html = '';

        html += '<div style="margin-bottom:15px;padding:12px 16px;background:#f8f9fa;border-radius:10px;">';
        html += '<div style="display:flex;justify-content:space-between;flex-wrap:wrap;">';
        html += '<div><strong>#' + escapeHtml(ticket.id) + '</strong> - ' + escapeHtml(ticket.title) + '</div>';
        html += '<span style="font-size:12px;color:#999;">' + escapeHtml(ticket.created_at) + '</span>';
        html += '</div>';
        html += '<div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;">';
        html += '<span style="display:inline-block;font-size:11px;padding:2px 14px;border-radius:20px;background:' + (statusColors[ticket.status] || '#6c757d') + ';color:#fff;">' + (statusLabels[ticket.status] || escapeHtml(ticket.status)) + '</span>';
        html += '<span style="display:inline-block;font-size:10px;padding:2px 10px;border-radius:20px;background:' + (priorityColors[ticket.priority] || '#6c757d') + ';color:#fff;">' + (priorityLabels[ticket.priority] || escapeHtml(ticket.priority)) + '</span>';
        html += '</div></div>';

        html += '<div style="margin-bottom:15px;"><h4 style="margin:0 0 10px;font-size:15px;">📝 ' + t('conversation', 'مکالمات') + '</h4>';

        if (ticket.messages && ticket.messages.length > 0) {
            ticket.messages.forEach(function (msg) {
                html += '<div style="background:' + (msg.is_admin ? '#e8f5e9' : '#f0f4f8') + ';padding:12px 16px;border-radius:8px;margin-bottom:10px;border-right:3px solid ' + (msg.is_admin ? '#28a745' : '#ef394e') + ';">';
                html += '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:5px;">';
                html += '<strong style="font-size:13px;">' + (msg.is_admin ? '📩 ' + t('support', 'پشتیبانی') : '👤 ' + escapeHtml(msg.sender_name)) + '</strong>';
                html += '<span style="font-size:11px;color:#999;">' + escapeHtml(msg.created_at) + '</span>';
                html += '</div>';
                html += '<p style="margin:0;font-size:14px;color:#333;line-height:1.6;white-space:pre-wrap;">' + escapeHtml(msg.message) + '</p>';
                if (msg.attachment) {
                    html += '<div style="margin-top:5px;"><a href="' + escapeHtml(msg.attachment) + '" target="_blank" rel="noopener" style="color:#ef394e;text-decoration:none;font-size:13px;">📎 ' + t('downloadFile', 'دانلود فایل') + '</a></div>';
                }
                html += '</div>';
            });
        }
        html += '</div>';

        if (ticket.status !== 'closed') {
            html += '<div style="margin-top:15px;padding-top:15px;border-top:1px solid #eee;">';
            html += '<label style="display:block;margin-bottom:8px;font-weight:500;">' + t('yourReply', 'پاسخ خود را وارد کنید:') + '</label>';
            html += '<textarea id="loginpro-ticket-reply-input" rows="3" style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;font-family:inherit;" placeholder="' + t('replyPlaceholder', 'متن پاسخ خود را وارد کنید...') + '"></textarea>';
            html += '<div style="display:flex;gap:10px;margin-top:10px;flex-wrap:wrap;">';
            html += '<button type="button" data-action="reply-ticket" data-ticket-id="' + escapeHtml(ticket.id) + '" style="background:' + CFG.primaryColor + ';color:#fff;border:none;padding:8px 24px;border-radius:8px;cursor:pointer;font-size:14px;">📤 ' + t('sendReply', 'ارسال پاسخ') + '</button>';
            html += '<button type="button" data-action="close-ticket" data-ticket-id="' + escapeHtml(ticket.id) + '" style="background:#6c757d;color:#fff;border:none;padding:8px 20px;border-radius:8px;cursor:pointer;font-size:14px;">🔒 ' + t('closeTicket', 'بستن تیکت') + '</button>';
            html += '</div></div>';
        }

        if (ticket.status === 'closed' && ticket.avg_rating > 0) {
            html += '<div style="margin-top:15px;padding-top:15px;border-top:1px solid #eee;text-align:center;">';
            html += '<p style="font-size:14px;color:#666;">⭐ ' + t('avgRating', 'امتیاز متوسط') + ': ' + escapeHtml(ticket.avg_rating) + ' / 5</p>';
            html += '</div>';
        } else if (ticket.status === 'closed' && ticket.avg_rating == 0) {
            html += '<div style="margin-top:15px;padding-top:15px;border-top:1px solid #eee;">';
            html += '<p style="margin-bottom:10px;font-weight:500;">' + t('rateTicket', 'به این تیکت امتیاز دهید:') + '</p>';
            html += '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
            for (var i = 1; i <= 5; i++) {
                html += '<button type="button" class="loginpro-rate-btn" data-action="rate-ticket" data-ticket-id="' + escapeHtml(ticket.id) + '" data-rating="' + i + '" style="background:#f8f9fa;border:1px solid #ddd;padding:8px 16px;border-radius:6px;cursor:pointer;font-size:16px;transition:all 0.3s;">⭐ ' + i + '</button>';
            }
            html += '</div></div>';
        }

        modalContent.innerHTML = html;
    }

    function submitReply(ticketId) {
        var replyInput = qs('#loginpro-ticket-reply-input');
        if (!replyInput) return;

        var reply = replyInput.value.trim();
        if (!reply) {
            window.alert(t('replyRequired', 'لطفاً متن پاسخ را وارد کنید.'));
            return;
        }

        ajaxPost('loginpro_user_reply_ticket', { ticket_id: ticketId, reply: reply })
            .then(function (data) {
                window.alert((data.data && data.data.message) || (data.success ? t('replySent', 'پاسخ ارسال شد.') : t('replyError', 'خطا در ارسال پاسخ.')));
                if (data.success) {
                    loadTicketDetail(ticketId);
                }
            })
            .catch(function () {
                window.alert(t('serverError', 'خطا در ارتباط با سرور.'));
            });
    }

    function closeTicket(ticketId) {
        if (!window.confirm(t('confirmClose', 'آیا مطمئن هستید که می‌خواهید این تیکت را ببندید؟'))) {
            return;
        }

        ajaxPost('loginpro_user_close_ticket', { ticket_id: ticketId })
            .then(function (data) {
                window.alert((data.data && data.data.message) || '');
                if (data.success) {
                    loadTicketDetail(ticketId);
                    setTimeout(function () { window.location.reload(); }, 1200);
                }
            })
            .catch(function () {
                window.alert(t('serverError', 'خطا در ارتباط با سرور.'));
            });
    }

    function rateTicket(ticketId, rating) {
        ajaxPost('loginpro_user_rate_ticket', { ticket_id: ticketId, rating: rating })
            .then(function (data) {
                window.alert((data.data && data.data.message) || '');
                if (data.success) {
                    loadTicketDetail(ticketId);
                }
            })
            .catch(function () {
                window.alert(t('serverError', 'خطا در ارتباط با سرور.'));
            });
    }

    // ------------------------------------------------------------------
    // Event delegation — works even for dynamically injected markup
    // and regardless of when this script executes relative to DOMContentLoaded
    // (important for Delay JS / execute-on-interaction setups)
    // ------------------------------------------------------------------

    document.addEventListener('click', function (e) {
        var target = e.target.closest('[data-action]');
        if (!target) {
            // clicks outside the modal box should close it
            if (e.target.id === 'loginpro-user-ticket-modal') {
                closeModal();
            }
            return;
        }

        var action = target.getAttribute('data-action');
        var wrapper = target.closest('.loginpro-tickets-wrapper') || document;

        switch (action) {
            case 'show-new-ticket-form':
                resetNewTicketForm(wrapper);
                var form = qs('#loginpro-new-ticket-form', wrapper);
                var showBtn = qs('#loginpro-show-ticket-btn', wrapper);
                if (form) form.style.display = 'block';
                if (showBtn) showBtn.style.display = 'none';
                break;

            case 'cancel-new-ticket-form':
                var form2 = qs('#loginpro-new-ticket-form', wrapper);
                var showBtn2 = qs('#loginpro-show-ticket-btn', wrapper);
                if (form2) form2.style.display = 'none';
                if (showBtn2) showBtn2.style.display = 'inline-block';
                break;

            case 'submit-new-ticket':
                submitNewTicket(wrapper);
                break;

            case 'view-ticket':
                loadTicketDetail(target.getAttribute('data-ticket-id'));
                break;

            case 'close-modal':
                closeModal();
                break;

            case 'reply-ticket':
                submitReply(target.getAttribute('data-ticket-id'));
                break;

            case 'close-ticket':
                closeTicket(target.getAttribute('data-ticket-id'));
                break;

            case 'rate-ticket':
                rateTicket(target.getAttribute('data-ticket-id'), target.getAttribute('data-rating'));
                break;
        }
    });

    // File name preview (change event, delegated)
    document.addEventListener('change', function (e) {
        if (e.target && e.target.id === 'loginpro-ticket-file') {
            var display = qs('#loginpro-ticket-file-name');
            if (!display) return;
            if (e.target.files && e.target.files.length > 0) {
                display.textContent = '📎 ' + e.target.files[0].name + ' (' + (e.target.files[0].size / 1024).toFixed(1) + ' KB)';
            } else {
                display.textContent = '';
            }
        }
    });

    // Enter key on new-ticket form fields should not submit unexpectedly (no <form> tag is used)
})();
