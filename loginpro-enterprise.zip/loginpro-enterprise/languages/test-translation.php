<?php
/**
 * test-translation-simple.php
 * اجرا: https://your-site.com/wp-content/plugins/loginpro-enterprise/languages/test-translation-simple.php
 * 
 * ✅ این نسخه نیازی به وردپرس ندارد و فقط فایل‌های MO را بررسی می‌کند
 */

echo "<!DOCTYPE html>";
echo "<html dir='ltr'>";
echo "<head><meta charset='UTF-8'><title>🧪 بررسی فایل‌های ترجمه LoginPro</title>";
echo "<style>
    body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f5f5f5; padding: 30px; }
    .container { max-width: 900px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
    h1 { color: #333; border-bottom: 2px solid #ef394e; padding-bottom: 15px; }
    .info { background: #e3f2fd; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-right: 4px solid #2196f3; }
    .success { background: #d4edda; padding: 15px; border-radius: 8px; margin: 10px 0; border-right: 4px solid #28a745; }
    .error { background: #f8d7da; padding: 15px; border-radius: 8px; margin: 10px 0; border-right: 4px solid #dc3545; }
    table { width: 100%; border-collapse: collapse; margin: 15px 0; }
    th { background: #f8f9fa; text-align: left; padding: 10px; border-bottom: 2px solid #dee2e6; }
    td { padding: 10px; border-bottom: 1px solid #dee2e6; }
    tr:hover { background: #f8f9fa; }
    .badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; }
    .badge-success { background: #28a745; color: #fff; }
    .badge-danger { background: #dc3545; color: #fff; }
    .file-list { list-style: none; padding: 0; }
    .file-list li { padding: 8px 0; border-bottom: 1px solid #eee; }
    .file-list .found { color: #28a745; }
    .file-list .not-found { color: #dc3545; }
    .file-list .size { color: #666; font-size: 12px; }
</style>";
echo "</head><body>";

echo "<div class='container'>";
echo "<h1>🧪 بررسی فایل‌های ترجمه LoginPro</h1>";

// پوشه جاری
$lang_dir = __DIR__;
echo "<div class='info'>";
echo "📁 <strong>پوشه زبان:</strong> " . htmlspecialchars($lang_dir) . "<br>";
echo "</div>";

// لیست زبان‌ها
$languages = [
    'fa_IR' => '🇮🇷 فارسی',
    'en_US' => '🇺🇸 English',
    'ar_SA' => '🇸🇦 العربية',
    'tr_TR' => '🇹🇷 Türkçe',
    'de_DE' => '🇩🇪 Deutsch',
    'zh_CN' => '🇨🇳 中文',
];

echo "<h2>📁 فایل‌های ترجمه</h2>";
echo "<ul class='file-list'>";

$found_count = 0;
foreach ($languages as $code => $name) {
    $mo_file = $lang_dir . '/loginpro-' . $code . '.mo';
    $po_file = $lang_dir . '/loginpro-' . $code . '.po';
    
    $mo_exists = file_exists($mo_file);
    $po_exists = file_exists($po_file);
    
    if ($mo_exists || $po_exists) {
        $found_count++;
        $size = $mo_exists ? filesize($mo_file) : 0;
        $info = '';
        if ($mo_exists) {
            $info = ' (MO: ' . round($size/1024, 2) . ' KB)';
        }
        if ($po_exists && !$mo_exists) {
            $info = ' (فقط PO)';
        }
        echo '<li class="found">✅ <strong>' . htmlspecialchars($code) . '</strong> - ' . htmlspecialchars($name) . htmlspecialchars($info) . '</li>';
    } else {
        echo '<li class="not-found">❌ <strong>' . htmlspecialchars($code) . '</strong> - ' . htmlspecialchars($name) . ' - فایل ترجمه پیدا نشد</li>';
    }
}
echo "</ul>";

if ($found_count === 0) {
    echo '<div class="error">⚠️ هیچ فایل ترجمه‌ای پیدا نشد!<br>';
    echo '💡 مطمئن شوید فایل‌ها در پوشه <code>languages/</code> قرار دارند و با فرمت <code>loginpro-{lang}.mo</code> نامگذاری شده‌اند.</div>';
} else {
    echo '<div class="success">✅ ' . $found_count . ' از ' . count($languages) . ' زبان دارای فایل ترجمه هستند.</div>';
}

// ==================================================
// استخراج ترجمه‌ها از فایل‌های MO
// ==================================================

echo "<h2>📖 نمونه ترجمه‌ها</h2>";

foreach ($languages as $code => $name) {
    $mo_file = $lang_dir . '/loginpro-' . $code . '.mo';
    if (!file_exists($mo_file)) continue;
    
    echo "<h3>🌍 " . htmlspecialchars($code) . " - " . htmlspecialchars($name) . "</h3>";
    
    // خواندن فایل MO
    $content = file_get_contents($mo_file);
    if (strlen($content) < 20) {
        echo "<div class='error'>❌ فایل MO خالی یا خراب است</div>";
        continue;
    }
    
    // استخراج ترجمه‌ها
    $translations = [];
    $count = unpack('V', substr($content, 8, 4))[1];
    
    if ($count > 0) {
        $orig_offset = 28;
        $trans_offset = 28 + ($count * 8);
        
        $display_count = 0;
        echo "<table>";
        echo "<thead><tr><th>متن اصلی</th><th>ترجمه</th></tr></thead>";
        echo "<tbody>";
        
        for ($i = 0; $i < min($count, 20); $i++) {
            $orig_pos = $orig_offset + ($i * 8);
            $trans_pos = $trans_offset + ($i * 8);
            
            $orig_len = unpack('V', substr($content, $orig_pos, 4))[1];
            $orig_data_offset = unpack('V', substr($content, $orig_pos + 4, 4))[1];
            $trans_len = unpack('V', substr($content, $trans_pos, 4))[1];
            $trans_data_offset = unpack('V', substr($content, $trans_pos + 4, 4))[1];
            
            $orig_text = substr($content, $orig_data_offset, $orig_len);
            $trans_text = substr($content, $trans_data_offset, $trans_len);
            
            if (!empty($orig_text) && !empty($trans_text) && $orig_text !== $trans_text) {
                $display_count++;
                echo "<tr>";
                echo "<td>" . htmlspecialchars($orig_text) . "</td>";
                echo "<td><strong>" . htmlspecialchars($trans_text) . "</strong></td>";
                echo "</tr>";
            }
        }
        
        echo "</tbody></table>";
        echo "<p><small>نمایش " . $display_count . " ترجمه از " . $count . " ترجمه موجود</small></p>";
    } else {
        echo "<div class='error'>❌ هیچ ترجمه‌ای در این فایل پیدا نشد</div>";
    }
}

echo "<hr>";
echo "<div class='info'>";
echo "💡 <strong>نکات:</strong><br>";
echo "1️⃣ فایل‌های MO باید در پوشه <code>languages/</code> قرار داشته باشند<br>";
echo "2️⃣ نام فایل‌ها باید به صورت <code>loginpro-{lang}.mo</code> باشد<br>";
echo "3️⃣ برای ایجاد فایل‌های MO از <code>msgfmt</code> یا Poedit استفاده کنید<br>";
echo "4️⃣ بعد از اضافه کردن فایل‌ها، این صفحه را رفرش کنید";
echo "</div>";

echo "</div>";
echo "</body></html>";