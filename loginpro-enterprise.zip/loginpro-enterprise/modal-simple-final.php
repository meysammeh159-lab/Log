<?php
/**
 * مودال لاگین ساده - نسخه نهایی (بدون وابستگی به jQuery)
 * 
 * @package LoginPro
 * @version 3.0.0
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ دریافت تنظیمات از دیتابیس
// ==================================================
$loginpro_modal_config = get_option('loginpro_appearance_settings', []);

// تنظیمات پیش‌فرض
$defaults = [
    'primary_color' => '#ef394e',
    'secondary_color' => '#c62828',
    'background_color' => '#ffffff',
    'modal_border_radius' => 24,
    'font_family' => 'IRANSans, Tahoma, sans-serif',
    'modal_btn_bg_color' => '#ef394e',
    'modal_btn_text_color' => '#ffffff',
    'modal_btn_border_radius' => 8,
];

$loginpro_modal_config = wp_parse_args($loginpro_modal_config, $defaults);

// ==================================================
// ✅ HTML مودال
// ==================================================
function loginpro_modal_html() {
    // دسترسی به تنظیمات
    global $loginpro_modal_config;
    
    if (is_user_logged_in()) {
        return;
    }
    
    $primary_color = $loginpro_modal_config['primary_color'] ?? '#ef394e';
    $background_color = $loginpro_modal_config['background_color'] ?? '#ffffff';
    $border_radius = $loginpro_modal_config['modal_border_radius'] ?? 24;
    $font_family = $loginpro_modal_config['font_family'] ?? 'IRANSans, Tahoma, sans-serif';
    
    // ایجاد nonce و ajax url
    $ajax_nonce = wp_create_nonce('loginpro_ajax_nonce');
    $ajax_url = admin_url('admin-ajax.php');
    
    // ✅ دریافت تنظیمات مودال برای ارسال به JS
    $modal_close_on_click = (int) get_option('loginpro_modal_close_on_click', 1);
    $modal_close_on_esc = (int) get_option('loginpro_modal_close_on_esc', 1);
    
    ?>
    <!-- مودال اصلی -->
    <div id="loginpro-modal-overlay" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:999999;backdrop-filter:blur(4px);align-items:center;justify-content:center;">
        <div id="loginpro-modal-container" style="background:<?php echo esc_attr($background_color); ?>;border-radius:<?php echo esc_attr($border_radius); ?>px;width:90%;max-width:420px;max-height:90vh;overflow-y:auto;padding:0;position:relative;box-shadow:0 20px 60px rgba(0,0,0,0.3);font-family:<?php echo esc_attr($font_family); ?>;direction:rtl;">
            
            <button id="loginpro-modal-close" style="position:absolute;top:12px;left:16px;background:none;border:none;font-size:28px;color:#999;cursor:pointer;z-index:10;transition:color 0.3s;line-height:1;padding:4px 8px;">✕</button>
            
            <div id="loginpro-modal-body" style="padding:30px;">
                <div id="loginpro-modal-content">
                    <!-- ✅ پیام ساده بارگذاری -->
                    <div style="text-align:center;padding:20px;color:#999;font-size:14px;">
                        ⏳ <?php _e('در حال بارگذاری...', 'loginpro'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        /* جلوگیری از اسکرول صفحه زیر مودال */
        body.modal-open {
            overflow: hidden !important;
            position: fixed !important;
            width: 100% !important;
        }
        
        #loginpro-modal-overlay.active {
            display: flex !important;
            animation: loginproFadeIn 0.2s ease;
        }
        
        @keyframes loginproFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        #loginpro-modal-container {
            animation: loginproSlideIn 0.2s ease;
        }
        
        @keyframes loginproSlideIn {
            from {
                opacity: 0;
                transform: scale(0.95) translateY(10px);
            }
            to {
                opacity: 1;
                transform: scale(1) translateY(0);
            }
        }
        
        #loginpro-modal-close:hover {
            color: #333;
        }
        
        #loginpro-modal-container::-webkit-scrollbar {
            width: 6px;
        }
        #loginpro-modal-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        #loginpro-modal-container::-webkit-scrollbar-thumb {
            background: <?php echo esc_attr($primary_color); ?>;
            border-radius: 10px;
        }
        
        @media (max-width: 480px) {
            #loginpro-modal-body {
                padding: 20px 16px;
            }
            #loginpro-modal-container {
                max-height: 95vh;
            }
        }
    </style>
    
    <!-- ✅ ارسال تنظیمات به JS از طریق data attribute -->
    <script type="text/javascript">
    (function() {
        'use strict';
        
        if (window.loginproModalLoaded) return;
        window.loginproModalLoaded = true;
        
        // ✅ تنظیمات از PHP به JS
        var modalConfig = {
            ajaxUrl: '<?php echo esc_js($ajax_url); ?>',
            nonce: '<?php echo esc_js($ajax_nonce); ?>',
            primaryColor: '<?php echo esc_js($primary_color); ?>',
            closeOnClick: <?php echo $modal_close_on_click ? 'true' : 'false'; ?>,
            closeOnEsc: <?php echo $modal_close_on_esc ? 'true' : 'false'; ?>
        };
        
        var overlay = document.getElementById('loginpro-modal-overlay');
        var closeBtn = document.getElementById('loginpro-modal-close');
        var content = document.getElementById('loginpro-modal-content');
        
        // ==========================================
        // توابع باز و بسته کردن مودال - نسخه نهایی با جلوگیری از اسکرول
        // ==========================================
        function openModal() {
            if (overlay) {
                overlay.className = 'active';
                
                // ✅ جلوگیری کامل از اسکرول صفحه
                var scrollY = window.scrollY;
                document.body.style.position = 'fixed';
                document.body.style.top = '-' + scrollY + 'px';
                document.body.style.left = '0';
                document.body.style.right = '0';
                document.body.style.width = '100%';
                document.body.style.overflow = 'hidden';
                
                // ذخیره موقعیت برای بازگشت
                window._loginproScrollY = scrollY;
                
                // بارگذاری سریع فرم
                loadLoginForm();
            }
        }
        
        function closeModal() {
            if (overlay) {
                overlay.className = '';
                
                // ✅ بازگرداندن اسکرول
                document.body.style.position = '';
                document.body.style.top = '';
                document.body.style.left = '';
                document.body.style.right = '';
                document.body.style.width = '';
                document.body.style.overflow = '';
                
                if (window._loginproScrollY !== undefined) {
                    window.scrollTo(0, window._loginproScrollY);
                    delete window._loginproScrollY;
                }
            }
        }
        
        // ==========================================
        // رویدادهای مودال با تنظیمات
        // ==========================================
        if (closeBtn) {
            closeBtn.addEventListener('click', closeModal);
        }
        
        if (overlay) {
            overlay.addEventListener('click', function(e) {
                // فقط اگر تنظیمات اجازه دهد
                if (e.target === this && modalConfig.closeOnClick === true) {
                    closeModal();
                }
            });
        }
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && overlay && overlay.className === 'active') {
                if (modalConfig.closeOnEsc === true) {
                    closeModal();
                }
            }
        });
        
        // ==========================================
        // باز شدن با کلیک روی دکمه
        // ==========================================
        document.addEventListener('click', function(e) {
            var trigger = e.target.closest('[data-loginpro-trigger="true"]');
            if (trigger) {
                e.preventDefault();
                openModal();
            }
        });
        
 // ==========================================
// بارگذاری فرم لاگین - نسخه کامل از login-form.php
// ==========================================
function loadLoginForm() {
    if (!content) return;

    // نمایش پیام ساده
    content.innerHTML = '<div style="text-align:center;padding:20px;color:#999;font-size:14px;">⏳ <?php _e('در حال بارگذاری...', 'loginpro'); ?></div>';

    var formData = new FormData();
    formData.append('action', 'loginpro_get_modal_form');
    formData.append('_nonce', modalConfig.nonce);

    var controller = new AbortController();
    var timeoutId = setTimeout(function() {
        controller.abort();
    }, 10000);

    fetch(modalConfig.ajaxUrl, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
        signal: controller.signal,
        headers: {
            'Accept': 'application/json',
            'Cache-Control': 'no-cache'
        }
    })
    .then(function(response) {
        clearTimeout(timeoutId);
        if (!response.ok) {
            throw new Error('HTTP error ' + response.status);
        }
        return response.json();
    })
    .then(function(data) {
        if (data.success) {
            // ✅ استفاده از HTML فرم کامل
            content.innerHTML = data.data.html;
            initFormScripts();
        } else {
            showError(data.data.message || '<?php _e('خطا در بارگذاری فرم', 'loginpro'); ?>');
        }
    })
    .catch(function(error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            showError('<?php _e('زمان بارگذاری به پایان رسید. لطفاً دوباره تلاش کنید.', 'loginpro'); ?>');
        } else {
            console.error('LoginPro: Error loading form:', error);
            showError('<?php _e('خطا در ارتباط با سرور: ', 'loginpro'); ?>' + error.message);
        }
    });
}
        
        // ==========================================
        // نمایش خطا
        // ==========================================
        function showError(message) {
            if (!content) return;
            content.innerHTML = '<div style="text-align:center;padding:30px;">' +
                '<div style="font-size:48px;margin-bottom:20px;">❌</div>' +
                '<h3 style="color:#dc3545;margin:0 0 10px;"><?php _e('خطا', 'loginpro'); ?></h3>' +
                '<p style="color:#666;font-size:14px;margin-bottom:20px;">' + message + '</p>' +
                '<button onclick="location.reload()" style="background:' + modalConfig.primaryColor + ';color:#fff;border:none;border-radius:8px;padding:10px 24px;cursor:pointer;font-size:14px;">🔄 <?php _e('تلاش مجدد', 'loginpro'); ?></button>' +
                '</div>';
        }
        
        // ==========================================
        // اجرای اسکریپت‌های فرم
        // ==========================================
        function initFormScripts() {
            var scripts = content.querySelectorAll('script');
            scripts.forEach(function(script) {
                var newScript = document.createElement('script');
                if (script.src) {
                    newScript.src = script.src;
                    newScript.async = false;
                } else {
                    newScript.textContent = script.textContent;
                }
                document.head.appendChild(newScript);
            });
        }
        
        // ==========================================
        // اگر مودال از قبل باز بود
        // ==========================================
        if (overlay && overlay.className === 'active') {
            loadLoginForm();
        }
        
        console.log('LoginPro: Modal initialized with config:', modalConfig);
        
    })();
    </script>
    <?php
}

// ==================================================
// ✅ فرم جایگزین برای نمایش در صورت عدم وجود فایل اصلی
// ==================================================
if (!function_exists('loginpro_get_fallback_login_form')) {
    function loginpro_get_fallback_login_form() {
        $primary_color = get_option('loginpro_primary_color', '#ef394e');
        $ajax_url = admin_url('admin-ajax.php');
        $nonce = wp_create_nonce('loginpro_ajax_nonce');
        
        ob_start();
        ?>
        <style>
            .loginpro-fallback-form {
                padding: 20px;
                font-family: IRANSans, Tahoma, sans-serif;
                direction: rtl;
            }
            .loginpro-fallback-form h3 {
                text-align: center;
                margin: 0 0 20px;
                color: #1a1a1a;
            }
            .loginpro-fallback-form .input-group {
                margin-bottom: 15px;
            }
            .loginpro-fallback-form input {
                width: 100%;
                padding: 12px 15px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 16px;
                box-sizing: border-box;
                font-family: inherit;
                transition: border-color 0.3s;
            }
            .loginpro-fallback-form input:focus {
                outline: none;
                border-color: <?php echo esc_attr($primary_color); ?>;
            }
            .loginpro-fallback-form .btn-primary {
                width: 100%;
                padding: 14px;
                background: <?php echo esc_attr($primary_color); ?>;
                color: #fff;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                cursor: pointer;
                transition: opacity 0.3s;
                font-family: inherit;
            }
            .loginpro-fallback-form .btn-primary:hover {
                opacity: 0.9;
            }
            .loginpro-fallback-form .btn-primary:disabled {
                opacity: 0.6;
                cursor: not-allowed;
            }
            .loginpro-fallback-form .message {
                margin-bottom: 15px;
                padding: 10px 15px;
                border-radius: 6px;
                display: none;
                text-align: center;
            }
            .loginpro-fallback-form .message.error {
                display: block;
                background: #fff5f5;
                color: #dc3545;
                border: 1px solid #f5c6cb;
            }
            .loginpro-fallback-form .message.success {
                display: block;
                background: #f0fff4;
                color: #28a745;
                border: 1px solid #c3e6cb;
            }
            .loginpro-fallback-form .footer-text {
                margin-top: 15px;
                text-align: center;
                font-size: 13px;
                color: #999;
            }
        </style>
        
        <div class="loginpro-fallback-form">
            <h3>🔐 <?php _e('ورود / ثبت‌نام', 'loginpro'); ?></h3>
            
            <div id="loginpro-fallback-message" class="message"></div>
            
            <div class="input-group">
                <input type="text" id="loginpro-fallback-identifier" placeholder="<?php _e('ایمیل یا شماره موبایل', 'loginpro'); ?>" dir="ltr">
            </div>
            
            <button id="loginpro-fallback-submit" class="btn-primary">
                <?php _e('دریافت کد تایید', 'loginpro'); ?>
            </button>
            
            <div class="footer-text">
                <?php _e('نسخه ساده - فرم کامل در حال بارگذاری است', 'loginpro'); ?>
            </div>
        </div>
        
        <script>
        (function() {
            var submitBtn = document.getElementById('loginpro-fallback-submit');
            var identifierInput = document.getElementById('loginpro-fallback-identifier');
            var messageEl = document.getElementById('loginpro-fallback-message');
            var ajaxUrl = '<?php echo esc_js($ajax_url); ?>';
            var nonce = '<?php echo esc_js($nonce); ?>';
            
            function showMessage(msg, type) {
                messageEl.className = 'message ' + type;
                messageEl.textContent = msg;
                setTimeout(function() {
                    messageEl.className = 'message';
                }, 5000);
            }
            
            submitBtn.addEventListener('click', function() {
                var identifier = identifierInput.value.trim();
                
                if (!identifier) {
                    showMessage('<?php _e('لطفا ایمیل یا شماره موبایل را وارد کنید', 'loginpro'); ?>', 'error');
                    return;
                }
                
                submitBtn.disabled = true;
                submitBtn.textContent = '<?php _e('در حال بررسی...', 'loginpro'); ?>';
                
                var formData = new FormData();
                formData.append('action', 'loginpro_check_identifier');
                formData.append('identifier', identifier);
                formData.append('is_mobile', identifier.match(/^09[0-9]{9}$/) ? '1' : '0');
                formData.append('_nonce', nonce);
                
                fetch(ajaxUrl, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(res) { 
                    if (!res.ok) {
                        throw new Error('HTTP error ' + res.status);
                    }
                    return res.json(); 
                })
                .then(function(data) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = '<?php _e('دریافت کد تایید', 'loginpro'); ?>';
                    
                    if (data.success) {
                        showMessage('<?php _e('کد تایید ارسال شد! (شبیه‌سازی)', 'loginpro'); ?>', 'success');
                        identifierInput.value = '';
                    } else {
                        var msg = data.data && data.data.message ? data.data.message : '<?php _e('خطا در ارسال کد', 'loginpro'); ?>';
                        showMessage(msg, 'error');
                    }
                })
                .catch(function(error) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = '<?php _e('دریافت کد تایید', 'loginpro'); ?>';
                    showMessage('<?php _e('خطا در ارتباط با سرور: ', 'loginpro'); ?>' + error.message, 'error');
                    console.error('LoginPro AJAX error:', error);
                });
            });
            
            identifierInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    submitBtn.click();
                }
            });
            
            identifierInput.focus();
        })();
        </script>
        <?php
        return ob_get_clean();
    }
}