<?php
namespace LoginPro\Includes;

use Exception;

defined('ABSPATH') || exit;

class SmsProviderLoader
{
    private static $instance = null;
    private $providers = [];
    
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct()
    {
        $this->loadProviders();
    }
    
    /**
     * بارگذاری خودکار تمام درگاه‌ها از پوشه modules/Providers/Sms
     */
    private function loadProviders()
    {
        // مسیرهای احتمالی برای درگاه‌ها
        $paths = [
            LOGINPRO_PLUGIN_DIR . 'modules/Providers/Sms/',
            LOGINPRO_PLUGIN_DIR . 'Providers/Sms/',
        ];
        
        $foundDir = '';
        foreach ($paths as $path) {
            if (is_dir($path)) {
                $foundDir = $path;
                break;
            }
        }
        
        if (empty($foundDir)) {
            return;
        }
        
        // پیدا کردن تمام فایل‌های Provider
        $files = glob($foundDir . '*Provider.php');
        
        foreach ($files as $file) {
            // include فایل
            require_once $file;
            
            $fileName = basename($file, '.php');
            
            // نام‌های احتمالی کلاس
            $possibleClassNames = [
                'LoginPro\\Modules\\Providers\\Sms\\' . $fileName,
                'LoginPro\\Providers\\Sms\\' . $fileName,
            ];
            
            foreach ($possibleClassNames as $className) {
                if (class_exists($className)) {
                    try {
                        // بررسی وجود متدهای مورد نیاز
                        if (method_exists($className, 'getSlug') && 
                            method_exists($className, 'getName') && 
                            method_exists($className, 'getDescription')) {
                            
                            $slug = $className::getSlug();
                            $this->providers[$slug] = [
                                'class' => $className,
                                'name' => $className::getName(),
                                'description' => $className::getDescription(),
                                'settings_fields' => method_exists($className, 'getSettingsFields') ? $className::getSettingsFields() : [],
                                'is_configured' => $this->isProviderConfigured($className)
                            ];
                        }
                    } catch (Exception $e) {
                        error_log('LoginPro: Error loading provider ' . $fileName . ' - ' . $e->getMessage());
                    }
                    break;
                }
            }
        }
    }
    
    /**
     * بررسی پیکربندی درگاه
     */
    private function isProviderConfigured($className): bool
    {
        try {
            $instance = new $className();
            if (method_exists($instance, 'isConfigured')) {
                return $instance->isConfigured();
            }
        } catch (Exception $e) {
            return false;
        }
        return false;
    }
    
    /**
     * دریافت لیست تمام درگاه‌ها
     */
    public function getProviders(): array
    {
        return $this->providers;
    }
    
    /**
     * دریافت یک درگاه خاص
     */
    public function getProvider($slug)
    {
        return isset($this->providers[$slug]) ? $this->providers[$slug] : null;
    }
    
    /**
     * دریافت درگاه فعال
     */
    public function getActiveProvider()
    {
        $activeSlug = get_option('loginpro_sms_active_provider', '');
        if (!empty($activeSlug) && isset($this->providers[$activeSlug])) {
            return $this->providers[$activeSlug];
        }
        
        // اگر درگاهی فعال نیست، اولین درگاه را برگردان
        $first = reset($this->providers);
        return $first ?: null;
    }
    
    /**
     * دریافت اسلاگ درگاه فعال
     */
    public function getActiveProviderSlug()
    {
        $active = $this->getActiveProvider();
        return $active ? array_search($active, $this->providers) : '';
    }
}