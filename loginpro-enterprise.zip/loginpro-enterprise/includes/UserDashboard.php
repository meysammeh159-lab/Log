<?php
/**
 * User Dashboard Class for LoginPro
 * مدیریت داشبورد کاربری با رویکرد امن و مدرن
 * 
 * @package LoginPro
 * @version 3.0.19
 */

defined('ABSPATH') || exit;

if (!class_exists('LoginPro_UserDashboard')):

class LoginPro_UserDashboard {
    
    /**
     * @var string Tab key untuk menyimpan preferensi
     */
    private $tab_meta_key = 'loginpro_dashboard_tab';
    
    /**
     * @var array Daftar tab yang diizinkan
     */
    private $allowed_tabs = [
        'profile',
        'security', 
        'activity',
        'tickets',
        'messages',
        'settings'
    ];
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', [$this, 'init']);
        add_action('wp_ajax_loginpro_dashboard_ajax', [$this, 'handle_ajax']);
        add_action('wp_ajax_loginpro_update_profile', [$this, 'update_profile']);
        add_action('wp_ajax_loginpro_change_password', [$this, 'change_password']);
        add_action('wp_ajax_loginpro_get_activity', [$this, 'get_activity']);
    }
    
    /**
     * Initialize dashboard
     */
    public function init() {
        // Nonce verification untuk semua request AJAX
        // (ditangani di masing-masing method)
    }
    
    /**
     * Render dashboard utama
     */
    public function render_dashboard() {
        // Cek user login
        if (!is_user_logged_in()) {
            return $this->render_login_required();
        }
        
        $current_user = wp_get_current_user();
        $current_tab = $this->get_current_tab();
        
        ob_start();
        ?>
        <div class="loginpro-dashboard-wrap">
            <?php $this->render_tabs($current_tab); ?>
            <div class="loginpro-dashboard-content">
                <?php $this->render_tab_content($current_tab, $current_user); ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render tabs navigation
     */
    private function render_tabs($current_tab) {
        $tabs = $this->get_tabs();
        $nonce_base = wp_create_nonce('loginpro_dashboard_tab');
        ?>
        <div class="loginpro-dashboard-tabs" role="tablist">
            <?php foreach ($tabs as $tab_id => $tab_label): 
                $is_active = ($current_tab === $tab_id);
                $tab_url = add_query_arg([
                    'tab' => $tab_id,
                    '_wpnonce' => wp_create_nonce('loginpro_dashboard_tab_' . $tab_id)
                ], remove_query_arg(['tab', '_wpnonce']));
            ?>
                <a href="<?php echo esc_url($tab_url); ?>" 
                   class="loginpro-tab <?php echo $is_active ? 'active' : ''; ?>" 
                   data-tab="<?php echo esc_attr($tab_id); ?>"
                   role="tab"
                   aria-selected="<?php echo $is_active ? 'true' : 'false'; ?>">
                    <?php echo esc_html($tab_label); ?>
                </a>
            <?php endforeach; ?>
            
            <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" 
               class="loginpro-tab logout-tab">
                <?php esc_html_e('🚪 خروج', 'loginpro'); ?>
            </a>
        </div>
        <?php
    }
    
    /**
     * Render tab content
     */
    private function render_tab_content($tab, $user) {
        switch ($tab) {
            case 'profile':
                $this->render_profile_tab($user);
                break;
            case 'security':
                $this->render_security_tab($user);
                break;
            case 'activity':
                $this->render_activity_tab($user);
                break;
            case 'tickets':
                $this->render_tickets_tab($user);
                break;
            case 'messages':
                $this->render_messages_tab($user);
                break;
            case 'settings':
                $this->render_settings_tab($user);
                break;
            default:
                echo '<p>' . esc_html__('محتوای این تب در حال بارگذاری است...', 'loginpro') . '</p>';
                break;
        }
    }
    
    /**
     * Render profile tab
     */
    private function render_profile_tab($user) {
        ?>
        <div class="loginpro-profile-section">
            <h2><?php esc_html_e('👤 پروفایل کاربری', 'loginpro'); ?></h2>
            
            <form id="loginpro-profile-form" method="post" action="">
                <?php wp_nonce_field('loginpro_update_profile', 'profile_nonce'); ?>
                
                <div class="loginpro-form-group">
                    <label for="display_name"><?php esc_html_e('نام نمایشی', 'loginpro'); ?></label>
                    <input type="text" id="display_name" name="display_name" 
                           value="<?php echo esc_attr($user->display_name); ?>" 
                           class="loginpro-input">
                </div>
                
                <div class="loginpro-form-group">
                    <label for="first_name"><?php esc_html_e('نام', 'loginpro'); ?></label>
                    <input type="text" id="first_name" name="first_name" 
                           value="<?php echo esc_attr($user->first_name); ?>" 
                           class="loginpro-input">
                </div>
                
                <div class="loginpro-form-group">
                    <label for="last_name"><?php esc_html_e('نام خانوادگی', 'loginpro'); ?></label>
                    <input type="text" id="last_name" name="last_name" 
                           value="<?php echo esc_attr($user->last_name); ?>" 
                           class="loginpro-input">
                </div>
                
                <div class="loginpro-form-group">
                    <label for="email"><?php esc_html_e('ایمیل', 'loginpro'); ?></label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo esc_attr($user->user_email); ?>" 
                           class="loginpro-input" readonly>
                    <small class="loginpro-field-note"><?php esc_html_e('ایمیل قابل تغییر نیست', 'loginpro'); ?></small>
                </div>
                
                <div class="loginpro-form-group">
                    <label><?php esc_html_e('تاریخ عضویت', 'loginpro'); ?></label>
                    <p class="loginpro-static-text">
                        <?php echo esc_html(date_i18n('j F Y', strtotime($user->user_registered))); ?>
                    </p>
                </div>
                
                <div class="loginpro-form-group">
                    <label><?php esc_html_e('نقش کاربری', 'loginpro'); ?></label>
                    <p class="loginpro-static-text">
                        <?php 
                        $roles = array_map(function($role) {
                            return translate_user_role($role);
                        }, $user->roles);
                        echo esc_html(implode(', ', $roles));
                        ?>
                    </p>
                </div>
                
                <button type="submit" class="loginpro-btn loginpro-btn-primary">
                    <?php esc_html_e('💾 ذخیره تغییرات', 'loginpro'); ?>
                </button>
            </form>
            
            <div id="loginpro-profile-message" class="loginpro-message" style="display:none;"></div>
        </div>
        <?php
    }
    
    /**
     * Render security tab
     */
    private function render_security_tab($user) {
        ?>
        <div class="loginpro-security-section">
            <h2><?php esc_html_e('🔐 امنیت حساب کاربری', 'loginpro'); ?></h2>
            
            <div class="loginpro-security-card">
                <h3><?php esc_html_e('تغییر رمز عبور', 'loginpro'); ?></h3>
                
                <form id="loginpro-change-password-form" method="post" action="">
                    <?php wp_nonce_field('loginpro_change_password', 'password_nonce'); ?>
                    
                    <div class="loginpro-form-group">
                        <label for="current_password"><?php esc_html_e('رمز عبور فعلی', 'loginpro'); ?></label>
                        <input type="password" id="current_password" name="current_password" 
                               class="loginpro-input" required>
                    </div>
                    
                    <div class="loginpro-form-group">
                        <label for="new_password"><?php esc_html_e('رمز عبور جدید', 'loginpro'); ?></label>
                        <input type="password" id="new_password" name="new_password" 
                               class="loginpro-input" required minlength="6">
                        <small class="loginpro-field-note"><?php esc_html_e('حداقل ۶ کاراکتر', 'loginpro'); ?></small>
                    </div>
                    
                    <div class="loginpro-form-group">
                        <label for="confirm_password"><?php esc_html_e('تکرار رمز عبور جدید', 'loginpro'); ?></label>
                        <input type="password" id="confirm_password" name="confirm_password" 
                               class="loginpro-input" required>
                    </div>
                    
                    <button type="submit" class="loginpro-btn loginpro-btn-primary">
                        <?php esc_html_e('🔑 تغییر رمز عبور', 'loginpro'); ?>
                    </button>
                </form>
                
                <div id="loginpro-password-message" class="loginpro-message" style="display:none;"></div>
            </div>
            
            <?php if (class_exists('LoginPro\Modules\Security\Services\DeviceTrackingService')): ?>
            <div class="loginpro-security-card">
                <h3><?php esc_html_e('دستگاه‌های متصل', 'loginpro'); ?></h3>
                <?php 
                try {
                    $device_service = new \LoginPro\Modules\Security\Services\DeviceTrackingService();
                    $devices = $device_service->get_user_devices(get_current_user_id());
                    
                    if (!empty($devices)) {
                        echo '<div class="loginpro-devices-list">';
                        foreach ($devices as $device) {
                            echo '<div class="loginpro-device-item">';
                            echo '<span class="device-icon">📱</span>';
                            echo '<span class="device-name">' . esc_html($device->device_name ?? 'Unknown Device') . '</span>';
                            echo '<span class="device-status ' . ($device->is_active ? 'active' : 'inactive') . '">';
                            echo $device->is_active ? '🟢' : '⚪';
                            echo '</span>';
                            echo '<span class="device-last-used">' . esc_html(date_i18n('j F Y H:i', strtotime($device->last_used_at ?? ''))) . '</span>';
                            echo '</div>';
                        }
                        echo '</div>';
                    } else {
                        echo '<p>' . esc_html__('هیچ دستگاهی متصل نیست', 'loginpro') . '</p>';
                    }
                } catch (Exception $e) {
                    echo '<p>' . esc_html__('خطا در دریافت اطلاعات دستگاه‌ها', 'loginpro') . '</p>';
                }
                ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render activity tab
     */
    private function render_activity_tab($user) {
        ?>
        <div class="loginpro-activity-section">
            <h2><?php esc_html_e('📊 فعالیت‌های اخیر', 'loginpro'); ?></h2>
            
            <div id="loginpro-activity-container">
                <div class="loginpro-loading"><?php esc_html_e('در حال بارگذاری...', 'loginpro'); ?></div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render tickets tab
     */
    private function render_tickets_tab($user) {
        ?>
        <div class="loginpro-tickets-section">
            <h2><?php esc_html_e('🎫 تیکت‌های پشتیبانی', 'loginpro'); ?></h2>
            
            <?php if (class_exists('LoginPro\Frontend\TicketView')): ?>
                <?php 
                try {
                    $ticket_view = new \LoginPro\Frontend\TicketView();
                    echo $ticket_view->render_user_tickets();
                } catch (Exception $e) {
                    echo '<p>' . esc_html__('خطا در بارگذاری تیکت‌ها', 'loginpro') . '</p>';
                }
                ?>
            <?php else: ?>
                <p><?php esc_html_e('سیستم تیکت در دسترس نیست', 'loginpro'); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render messages tab
     */
    private function render_messages_tab($user) {
        ?>
        <div class="loginpro-messages-section">
            <h2><?php esc_html_e('📨 پیام‌ها', 'loginpro'); ?></h2>
            
            <?php if (class_exists('LoginPro\Frontend\MessageSystem')): ?>
                <?php 
                try {
                    $message_system = new \LoginPro\Frontend\MessageSystem();
                    echo $message_system->render_user_messages();
                } catch (Exception $e) {
                    echo '<p>' . esc_html__('خطا در بارگذاری پیام‌ها', 'loginpro') . '</p>';
                }
                ?>
            <?php else: ?>
                <p><?php esc_html_e('سیستم پیام در دسترس نیست', 'loginpro'); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render settings tab
     */
    private function render_settings_tab($user) {
        ?>
        <div class="loginpro-settings-section">
            <h2><?php esc_html_e('⚙️ تنظیمات کاربری', 'loginpro'); ?></h2>
            
            <form id="loginpro-user-settings-form" method="post" action="">
                <?php wp_nonce_field('loginpro_user_settings', 'settings_nonce'); ?>
                
                <div class="loginpro-form-group">
                    <label for="language"><?php esc_html_e('زبان پیش‌فرض', 'loginpro'); ?></label>
                    <select id="language" name="language" class="loginpro-input">
                        <?php 
                        $current_lang = get_user_meta($user->ID, 'loginpro_language', true) ?: 'fa_IR';
                        $languages = [
                            'fa_IR' => 'فارسی',
                            'en_US' => 'English',
                            'ar_SA' => 'العربية',
                            'de_DE' => 'Deutsch',
                            'zh_CN' => '中文'
                        ];
                        foreach ($languages as $code => $label):
                        ?>
                            <option value="<?php echo esc_attr($code); ?>" 
                                <?php selected($current_lang, $code); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="loginpro-form-group">
                    <label class="loginpro-checkbox-label">
                        <input type="checkbox" name="email_notifications" value="1"
                            <?php checked(get_user_meta($user->ID, 'loginpro_email_notifications', true), '1'); ?>>
                        <?php esc_html_e('دریافت اعلان‌های ایمیلی', 'loginpro'); ?>
                    </label>
                </div>
                
                <button type="submit" class="loginpro-btn loginpro-btn-primary">
                    <?php esc_html_e('💾 ذخیره تنظیمات', 'loginpro'); ?>
                </button>
            </form>
            
            <div id="loginpro-settings-message" class="loginpro-message" style="display:none;"></div>
        </div>
        <?php
    }
    
    /**
     * Render login required message
     */
    private function render_login_required() {
        $login_url = wp_login_url(get_permalink());
        return '<div class="loginpro-login-required"><p>' . 
                sprintf(
                    esc_html__('برای مشاهده داشبورد لطفاً %sوارد شوید%s.', 'loginpro'),
                    '<a href="' . esc_url($login_url) . '">',
                    '</a>'
                ) . 
                '</p></div>';
    }
    
    /**
     * Get current tab with validation
     */
    private function get_current_tab() {
        $default_tab = 'profile';
        $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : '';
        
        // Validate tab
        if (!in_array($tab, $this->allowed_tabs)) {
            $tab = $default_tab;
        }
        
        // Verify nonce if provided
        if (isset($_GET['_wpnonce'])) {
            $nonce = $_GET['_wpnonce'];
            if (!wp_verify_nonce($nonce, 'loginpro_dashboard_tab_' . $tab)) {
                // Invalid nonce, revert to default
                $tab = $default_tab;
            } else {
                // Valid nonce, save preference
                $user_id = get_current_user_id();
                if ($user_id) {
                    update_user_meta($user_id, $this->tab_meta_key, $tab);
                }
            }
        } else {
            // No nonce, try to get saved preference
            $user_id = get_current_user_id();
            if ($user_id) {
                $saved_tab = get_user_meta($user_id, $this->tab_meta_key, true);
                if (in_array($saved_tab, $this->allowed_tabs)) {
                    $tab = $saved_tab;
                }
            }
        }
        
        return $tab;
    }
    
    /**
     * Get tabs list
     */
    private function get_tabs() {
        $tabs = [
            'profile' => __('👤 پروفایل', 'loginpro'),
            'security' => __('🔐 امنیت', 'loginpro'),
            'activity' => __('📊 فعالیت‌ها', 'loginpro'),
            'tickets' => __('🎫 تیکت‌ها', 'loginpro'),
            'messages' => __('📨 پیام‌ها', 'loginpro'),
            'settings' => __('⚙️ تنظیمات', 'loginpro')
        ];
        
        // Filter tabs
        return apply_filters('loginpro_dashboard_tabs', $tabs);
    }
    
    /**
     * Handle AJAX requests
     */
    public function handle_ajax() {
        // Verify nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_ajax')) {
            wp_send_json_error(['message' => __('درخواست غیرمجاز', 'loginpro')], 403);
            return;
        }
        
        $action = isset($_POST['sub_action']) ? sanitize_text_field($_POST['sub_action']) : '';
        
        switch ($action) {
            case 'get_activity':
                $this->ajax_get_activity();
                break;
            default:
                wp_send_json_error(['message' => __('عملیات نامعتبر', 'loginpro')], 400);
                break;
        }
    }
    
    /**
     * Update profile via AJAX
     */
    public function update_profile() {
        // Verify nonce
        if (!isset($_POST['profile_nonce']) || !wp_verify_nonce($_POST['profile_nonce'], 'loginpro_update_profile')) {
            wp_send_json_error(['message' => __('درخواست غیرمجاز', 'loginpro')], 403);
            return;
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('لطفاً وارد شوید', 'loginpro')], 401);
            return;
        }
        
        $user_id = get_current_user_id();
        $user_data = [];
        
        // Sanitize inputs
        if (isset($_POST['display_name'])) {
            $user_data['display_name'] = sanitize_text_field($_POST['display_name']);
        }
        
        if (isset($_POST['first_name'])) {
            $user_data['first_name'] = sanitize_text_field($_POST['first_name']);
        }
        
        if (isset($_POST['last_name'])) {
            $user_data['last_name'] = sanitize_text_field($_POST['last_name']);
        }
        
        // Update user
        $user_data['ID'] = $user_id;
        $result = wp_update_user($user_data);
        
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
            return;
        }
        
        wp_send_json_success(['message' => __('پروفایل با موفقیت به‌روزرسانی شد', 'loginpro')]);
    }
    
    /**
     * Change password via AJAX
     */
    public function change_password() {
        // Verify nonce
        if (!isset($_POST['password_nonce']) || !wp_verify_nonce($_POST['password_nonce'], 'loginpro_change_password')) {
            wp_send_json_error(['message' => __('درخواست غیرمجاز', 'loginpro')], 403);
            return;
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('لطفاً وارد شوید', 'loginpro')], 401);
            return;
        }
        
        $user_id = get_current_user_id();
        $user = get_user_by('ID', $user_id);
        
        if (!$user) {
            wp_send_json_error(['message' => __('کاربر یافت نشد', 'loginpro')]);
            return;
        }
        
        // Get and sanitize inputs
        $current_password = isset($_POST['current_password']) ? sanitize_text_field($_POST['current_password']) : '';
        $new_password = isset($_POST['new_password']) ? sanitize_text_field($_POST['new_password']) : '';
        $confirm_password = isset($_POST['confirm_password']) ? sanitize_text_field($_POST['confirm_password']) : '';
        
        // Validate
        if (empty($current_password)) {
            wp_send_json_error(['message' => __('رمز عبور فعلی را وارد کنید', 'loginpro')]);
            return;
        }
        
        if (empty($new_password) || strlen($new_password) < 6) {
            wp_send_json_error(['message' => __('رمز عبور جدید باید حداقل ۶ کاراکتر باشد', 'loginpro')]);
            return;
        }
        
        if ($new_password !== $confirm_password) {
            wp_send_json_error(['message' => __('رمز عبور جدید و تکرار آن مطابقت ندارند', 'loginpro')]);
            return;
        }
        
        // Verify current password
        if (!wp_check_password($current_password, $user->user_pass, $user_id)) {
            wp_send_json_error(['message' => __('رمز عبور فعلی صحیح نیست', 'loginpro')]);
            return;
        }
        
        // Update password
        wp_set_password($new_password, $user_id);
        
        wp_send_json_success(['message' => __('رمز عبور با موفقیت تغییر کرد', 'loginpro')]);
    }
    
    /**
     * Get user activity via AJAX
     */
    public function get_activity() {
        // Verify nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_ajax')) {
            wp_send_json_error(['message' => __('درخواست غیرمجاز', 'loginpro')], 403);
            return;
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('لطفاً وارد شوید', 'loginpro')], 401);
            return;
        }
        
        $user_id = get_current_user_id();
        
        // Get login history
        global $wpdb;
        $table = $wpdb->prefix . 'loginpro_login_history';
        
        $query = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d ORDER BY login_time DESC LIMIT 20",
            $user_id
        );
        
        $activities = $wpdb->get_results($query);
        
        if (!$activities) {
            wp_send_json_success(['message' => __('هیچ فعالیتی یافت نشد', 'loginpro'), 'data' => []]);
            return;
        }
        
        $formatted_activities = array_map(function($activity) {
            return [
                'time' => date_i18n('j F Y H:i', strtotime($activity->login_time)),
                'ip' => $activity->ip_address ?? '',
                'device' => $activity->device_name ?? __('ناشناس', 'loginpro'),
                'status' => $activity->status ?? 'success'
            ];
        }, $activities);
        
        wp_send_json_success([
            'message' => __('فعالیت‌ها با موفقیت بارگذاری شدند', 'loginpro'),
            'data' => $formatted_activities
        ]);
    }
    
    /**
     * AJAX handler for getting activity
     */
    private function ajax_get_activity() {
        $this->get_activity();
    }
}

// Initialize
new LoginPro_UserDashboard();

endif; // End class_exists check