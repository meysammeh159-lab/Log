<?php
/**
 * متغیرهای AJAX
 * 
 * @package LoginPro
 * @since 3.0.0
 */

defined('ABSPATH') || exit;

/**
 * افزودن متغیرهای AJAX به فرانت‌اند
 */
add_action('wp_enqueue_scripts', 'loginpro_add_ajax_variables');

function loginpro_add_ajax_variables() {
    // ✅ بررسی وجود اسکریپت loginpro-scripts
    if (!wp_script_is('loginpro-scripts', 'enqueued')) {
        return;
    }
    
    wp_localize_script('loginpro-scripts', 'loginpro_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('loginpro_ajax_nonce'),
        'plugin_url' => LOGINPRO_PLUGIN_URL,
    ]);
}