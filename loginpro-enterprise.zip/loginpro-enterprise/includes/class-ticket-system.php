<?php
/**
 * Ticket System Class - نسخه نهایی امن
 * 
 * @package LoginPro
 * @version 3.0.15
 */

defined('ABSPATH') || exit;

use LoginPro\Security\PermissionChecker;
use LoginPro\Security\NonceManager;
use LoginPro\Security\RateLimiter;
use LoginPro\Security\FileValidator;

class LoginPro_Ticket_System {
    
    private $max_message_length = 5000;
    
    public function __construct() {
        add_shortcode('loginpro_ticket_form', [$this, 'render_ticket_form']);
        add_action('wp_ajax_loginpro_submit_ticket', [$this, 'submit_ticket']);
        add_action('wp_ajax_loginpro_get_tickets', [$this, 'get_tickets']);
    }
    
    public function render_ticket_form($atts = []) {
        if (!is_user_logged_in()) {
            return '<p class="loginpro-not-logged-in">' . sprintf(
                __('لطفاً <a href="%s">وارد شوید</a>', 'loginpro'),
                esc_url(wp_login_url())
            ) . '</p>';
        }
        
        $user_id = get_current_user_id();
        $nonce = NonceManager::create('submit_ticket', $user_id);
        
        ob_start();
        ?>
        <div class="loginpro-ticket-form" data-nonce="<?php echo esc_attr($nonce); ?>">
            <h3><?php esc_html_e('📝 ارسال تیکت پشتیبانی', 'loginpro'); ?></h3>
            <div id="ticket-message" style="display:none;margin-bottom:15px;padding:12px;border-radius:8px;"></div>
            <div class="form-group" style="margin-bottom:15px;">
                <label for="ticket-subject" style="display:block;margin-bottom:5px;font-weight:500;"><?php esc_html_e('موضوع', 'loginpro'); ?></label>
                <input type="text" id="ticket-subject" placeholder="<?php esc_attr_e('موضوع تیکت', 'loginpro'); ?>" 
                       style="width:100%;height:45px;padding:0 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;" 
                       maxlength="200">
            </div>
            <div class="form-group" style="margin-bottom:15px;">
                <label for="ticket-message-text" style="display:block;margin-bottom:5px;font-weight:500;"><?php esc_html_e('متن پیام', 'loginpro'); ?></label>
                <textarea id="ticket-message-text" placeholder="<?php esc_attr_e('متن تیکت خود را وارد کنید', 'loginpro'); ?>" 
                          style="width:100%;min-height:120px;padding:10px 15px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box;font-family:inherit;" 
                          maxlength="<?php echo intval($this->max_message_length); ?>"></textarea>
                <p style="font-size:11px;color:#999;margin-top:3px;"><?php printf(esc_html__('حداکثر %d کاراکتر', 'loginpro'), $this->max_message_length); ?></p>
            </div>
            <div class="form-group" style="margin-bottom:15px;">
                <label for="ticket-attachment" style="display:block;margin-bottom:5px;font-weight:500;"><?php esc_html_e('پیوست (اختیاری)', 'loginpro'); ?></label>
                <input type="file" id="ticket-attachment" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.txt" style="width:100%;">
                <p style="font-size:12px;color:#999;margin-top:5px;"><?php esc_html_e('فرمت‌های مجاز: JPG, PNG, PDF, DOC, DOCX, TXT (حداکثر ۵ مگابایت)', 'loginpro'); ?></p>
            </div>
            <button id="submit-ticket-btn" class="loginpro-primary-btn" 
                    style="width:100%;height:48px;background:#ef394e;color:#fff;border:none;border-radius:12px;cursor:pointer;font-size:16px;font-weight:500;transition:all 0.3s ease;">
                <?php esc_html_e('ارسال تیکت', 'loginpro'); ?>
            </button>
        </div>
        <script type="text/javascript">
        (function() {
            'use strict';
            var form = document.querySelector('.loginpro-ticket-form');
            if (!form) return;
            var nonce = form.getAttribute('data-nonce');
            var btn = document.getElementById('submit-ticket-btn');
            var msg = document.getElementById('ticket-message');
            
            if (btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var subject = document.getElementById('ticket-subject').value.trim();
                    var message = document.getElementById('ticket-message-text').value.trim();
                    var fileInput = document.getElementById('ticket-attachment');
                    var file = fileInput ? fileInput.files[0] : null;
                    
                    if (!subject) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('لطفاً موضوع تیکت را وارد کنید', 'loginpro')); ?>';
                        return;
                    }
                    
                    if (!message) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('لطفاً متن تیکت را وارد کنید', 'loginpro')); ?>';
                        return;
                    }
                    
                    if (message.length > <?php echo intval($this->max_message_length); ?>) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('متن پیام بیش از حد طولانی است', 'loginpro')); ?>';
                        return;
                    }
                    
                    btn.disabled = true;
                    btn.textContent = '<?php echo esc_js(__('در حال ارسال...', 'loginpro')); ?>';
                    
                    var formData = new FormData();
                    formData.append('action', 'loginpro_submit_ticket');
                    formData.append('_nonce', nonce);
                    formData.append('subject', subject);
                    formData.append('message', message);
                    if (file) {
                        if (file.size > 5242880) {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#fff5f5';
                            msg.style.color = '#dc3545';
                            msg.style.border = '1px solid #f5c6cb';
                            msg.textContent = '❌ <?php echo esc_js(__('حجم فایل بیش از ۵ مگابایت است', 'loginpro')); ?>';
                            btn.disabled = false;
                            btn.textContent = '<?php echo esc_js(__('ارسال تیکت', 'loginpro')); ?>';
                            return;
                        }
                        formData.append('attachment', file);
                    }
                    
                    fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.success) {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#f0fff4';
                            msg.style.color = '#28a745';
                            msg.style.border = '1px solid #c3e6cb';
                            msg.textContent = '✅ ' + response.data.message;
                            document.getElementById('ticket-subject').value = '';
                            document.getElementById('ticket-message-text').value = '';
                            if (fileInput) fileInput.value = '';
                        } else {
                            msg.style.display = 'block';
                            msg.style.backgroundColor = '#fff5f5';
                            msg.style.color = '#dc3545';
                            msg.style.border = '1px solid #f5c6cb';
                            msg.textContent = '❌ ' + response.data.message;
                        }
                        btn.disabled = false;
                        btn.textContent = '<?php echo esc_js(__('ارسال تیکت', 'loginpro')); ?>';
                    })
                    .catch(function(error) {
                        msg.style.display = 'block';
                        msg.style.backgroundColor = '#fff5f5';
                        msg.style.color = '#dc3545';
                        msg.style.border = '1px solid #f5c6cb';
                        msg.textContent = '❌ <?php echo esc_js(__('خطا در ارتباط با سرور', 'loginpro')); ?>: ' + error.message;
                        btn.disabled = false;
                        btn.textContent = '<?php echo esc_js(__('ارسال تیکت', 'loginpro')); ?>';
                    });
                });
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * ارسال تیکت با اعتبارسنجی کامل امنیتی
     */
    public function submit_ticket() {
        try {
            $user_id = get_current_user_id();
            
            // ✅ بررسی Nonce
            if (!NonceManager::check_request('submit_ticket', 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            // ✅ بررسی لاگین بودن
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'لطفاً وارد شوید'], 401);
                return;
            }
            
            // ✅ محدودیت نرخ درخواست با شناسه ترکیبی
            $identifier = RateLimiter::get_ip() . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '');
            if (!RateLimiter::quick_check('submit_ticket_' . md5($identifier))) {
                wp_send_json_error(['message' => 'تعداد درخواست بیش از حد مجاز'], 429);
                return;
            }
            
            // ✅ اعتبارسنجی ورودی‌ها
            $subject = sanitize_text_field($_POST['subject'] ?? '');
            $message = wp_kses_post($_POST['message'] ?? '');
            
            // ✅ محدودیت طول
            if (empty($subject) || empty($message)) {
                wp_send_json_error(['message' => 'لطفاً تمام فیلدها را پر کنید']);
                return;
            }
            
            if (strlen($subject) > 200) {
                wp_send_json_error(['message' => 'موضوع بیش از حد طولانی است']);
                return;
            }
            
            if (strlen($message) > $this->max_message_length) {
                wp_send_json_error(['message' => 'متن پیام بیش از حد طولانی است']);
                return;
            }
            
            $attachment_path = '';
            $attachment_name = '';
            
            // ✅ پردازش فایل پیوست
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                $validator = new FileValidator([
                    'max_size' => 5 * 1024 * 1024,
                    'allowed_types' => [
                        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
                        'gif' => 'image/gif', 'pdf' => 'application/pdf', 'doc' => 'application/msword',
                        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'txt' => 'text/plain',
                    ]
                ]);
                
                $result = $validator->validate($_FILES['attachment']);
                if (!$result['valid']) {
                    wp_send_json_error(['message' => $result['error']]);
                    return;
                }
                
                $upload_dir = wp_upload_dir();
                $safe_name = $result['name'];
                $file_path = $upload_dir['path'] . '/' . $safe_name;
                
                if (move_uploaded_file($_FILES['attachment']['tmp_name'], $file_path)) {
                    $attachment_path = str_replace($upload_dir['basedir'], '', $file_path);
                    $attachment_name = $safe_name;
                }
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            // ✅ استفاده از prepared statement
            $result = $wpdb->insert(
                $table,
                [
                    'user_id' => $user_id,
                    'subject' => $subject,
                    'message' => $message,
                    'attachment' => $attachment_name,
                    'attachment_path' => $attachment_path,
                    'status' => 'pending',
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql')
                ],
                ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
            );
            
            if ($result) {
                RateLimiter::reset('submit_ticket_' . md5($identifier));
                
                // ✅ ارسال ایمیل به مدیر با اطلاعات امن
                $admin_email = get_option('admin_email');
                $site_name = get_bloginfo('name');
                $subject_email = sprintf(__('تیکت جدید در %s', 'loginpro'), $site_name);
                $message_email = sprintf(
                    __('یک تیکت جدید از طرف کاربر %s ثبت شده است.' . "\n\n" . 'موضوع: %s' . "\n" . 'متن: %s', 'loginpro'),
                    wp_get_current_user()->display_name,
                    $subject,
                    $message
                );
                wp_mail($admin_email, $subject_email, $message_email);
                
                wp_send_json_success(['message' => 'تیکت با موفقیت ارسال شد']);
            } else {
                wp_send_json_error(['message' => 'خطا در ذخیره تیکت']);
            }
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
    
    /**
     * دریافت تیکت‌ها با کوئری امن
     */
    public function get_tickets() {
        try {
            $user_id = get_current_user_id();
            
            if (!NonceManager::check_request('get_tickets', 'POST', $user_id)) {
                wp_send_json_error(['message' => 'درخواست نامعتبر'], 403);
                return;
            }
            
            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'لطفاً وارد شوید'], 401);
                return;
            }
            
            global $wpdb;
            $table = $wpdb->prefix . 'loginpro_tickets';
            
            // ✅ استفاده از prepared statement با %i برای نام جدول
            $tickets = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM %i WHERE user_id = %d ORDER BY created_at DESC",
                    $table,
                    $user_id
                )
            );
            
            // ✅ پاکسازی داده‌ها قبل از ارسال
            foreach ($tickets as $ticket) {
                $ticket->message = wp_kses_post($ticket->message);
                $ticket->subject = esc_html($ticket->subject);
            }
            
            wp_send_json_success(['tickets' => $tickets]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => 'خطا: ' . $e->getMessage()], 500);
        }
    }
}

if (class_exists('LoginPro_Ticket_System')) {
    new LoginPro_Ticket_System();
}