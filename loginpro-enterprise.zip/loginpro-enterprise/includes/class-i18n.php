<?php
/**
 * کلاس مدیریت بین‌المللی‌سازی
 * 
 * @package LoginPro
 * @subpackage I18n
 */

namespace LoginPro\Includes;

defined('ABSPATH') || exit;

class I18n {
    
    /**
     * بارگذاری فایل‌های ترجمه
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'loginpro',
            false,
            dirname(plugin_basename(LOGINPRO_PLUGIN_DIR)) . '/languages/'
        );
    }
    
    /**
     * دریافت زبان فعلی کاربر
     */
    public function get_current_language() {
        $locale = determine_locale();
        return $locale;
    }
    
    /**
     * دریافت لیست زبان‌های پشتیبانی شده
     */
    public function get_supported_languages() {
        return [
            'fa_IR' => __('فارسی', 'loginpro'),
            'en_US' => __('English', 'loginpro'),
            'ar_SA' => __('العربية', 'loginpro'),
            'tr_TR' => __('Türkçe', 'loginpro'),
            'ru_RU' => __('Русский', 'loginpro'),
            'es_ES' => __('Español', 'loginpro'),
            'de_DE' => __('Deutsch', 'loginpro'),
            'fr_FR' => __('Français', 'loginpro'),
            'zh_CN' => __('中文', 'loginpro'),
        ];
    }
    
    /**
     * دریافت لیست کشورها با کد
     */
    public static function get_countries_list() {
        return [
            'IR' => __('ایران', 'loginpro'),
            'US' => __('United States', 'loginpro'),
            'GB' => __('United Kingdom', 'loginpro'),
            'DE' => __('Germany', 'loginpro'),
            'FR' => __('France', 'loginpro'),
            'IT' => __('Italy', 'loginpro'),
            'ES' => __('Spain', 'loginpro'),
            'TR' => __('Turkey', 'loginpro'),
            'AE' => __('UAE', 'loginpro'),
            'SA' => __('Saudi Arabia', 'loginpro'),
            'RU' => __('Russia', 'loginpro'),
            'CN' => __('China', 'loginpro'),
            'JP' => __('Japan', 'loginpro'),
            'KR' => __('South Korea', 'loginpro'),
        ];
    }
    
    /**
     * دریافت لیست واحدهای پول با نماد
     */
    public static function get_currency_symbols() {
        return [
            'IRR' => '﷼',
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'TRY' => '₺',
            'RUB' => '₽',
            'CNY' => '¥',
            'JPY' => '¥',
            'AED' => 'د.إ',
            'SAR' => 'ر.س',
        ];
    }
}