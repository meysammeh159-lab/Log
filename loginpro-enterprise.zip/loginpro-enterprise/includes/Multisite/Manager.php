<?php
/**
 * Multisite Manager for LoginPro Enterprise
 * 
 * @package LoginPro
 * @since 3.0.0
 */

namespace LoginPro\Includes\Multisite;

defined('ABSPATH') || exit;

/**
 * Multisite Manager Class
 */
class MultisiteManager {
    
    /**
     * Constructor
     */
    public function __construct() {
        if (is_multisite()) {
            add_action('wpmu_new_blog', [$this, 'activate_new_site']);
            add_action('delete_blog', [$this, 'deactivate_site']);
            add_action('wp_initialize_site', [$this, 'initialize_site']);
        }
    }
    
    /**
     * Activate plugin for new site
     */
    public function activate_new_site($blog_id) {
        if (!is_plugin_active_for_network('loginpro-enterprise/loginpro.php')) {
            return;
        }
        
        switch_to_blog($blog_id);
        $this->activate_site();
        restore_current_blog();
    }
    
    /**
     * Deactivate site
     */
    public function deactivate_site($blog_id) {
        switch_to_blog($blog_id);
        $this->deactivate_site_cleanup();
        restore_current_blog();
    }
    
    /**
     * Initialize new site
     */
    public function initialize_site($site) {
        if (!is_plugin_active_for_network('loginpro-enterprise/loginpro.php')) {
            return;
        }
        
        switch_to_blog($site->blog_id);
        $this->activate_site();
        restore_current_blog();
    }
    
    /**
     * Activate site
     */
    private function activate_site() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create site-specific tables
        $tables = [
            $wpdb->prefix . 'loginpro_sessions' => "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}loginpro_sessions (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                session_token varchar(255) NOT NULL,
                ip_address varchar(45) NOT NULL,
                user_agent text,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                expires_at datetime NOT NULL,
                PRIMARY KEY (id)
            ) {$charset_collate}",
            
            $wpdb->prefix . 'loginpro_otp_logs' => "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}loginpro_otp_logs (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                identifier varchar(255) NOT NULL,
                code_hash varchar(64) NOT NULL,
                channel varchar(50) NOT NULL DEFAULT 'sms',
                status varchar(50) NOT NULL DEFAULT 'sent',
                ip_address varchar(45) NOT NULL,
                user_agent text,
                user_id bigint(20) DEFAULT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY identifier (identifier),
                KEY channel (channel),
                KEY status (status),
                KEY created_at (created_at)
            ) {$charset_collate}",
        ];
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach ($tables as $sql) {
            dbDelta($sql);
        }
        
        // Add site-specific default options
        $this->set_site_defaults();
    }
    
    /**
     * Deactivate site cleanup
     */
    private function deactivate_site_cleanup() {
        global $wpdb;
        
        $tables = [
            'loginpro_sessions',
            'loginpro_otp_logs',
        ];
        
        foreach ($tables as $table) {
            $table_name = $wpdb->prefix . $table;
            $wpdb->query("DROP TABLE IF EXISTS {$table_name}");
        }
    }
    
    /**
     * Set site default options
     */
    private function set_site_defaults() {
        $defaults = [
            'loginpro_primary_color' => '#ef394e',
            'loginpro_button_color' => '#ef394e',
            'loginpro_otp_length' => 6,
            'loginpro_otp_expiry' => 300,
        ];
        
        foreach ($defaults as $key => $value) {
            if (!get_option($key)) {
                update_option($key, $value);
            }
        }
    }
    
    /**
     * Get network settings
     */
    public static function get_network_settings() {
        if (!is_multisite()) {
            return [];
        }
        
        return get_site_option('loginpro_network_settings', []);
    }
    
    /**
     * Update network settings
     */
    public static function update_network_settings($settings) {
        if (!is_multisite()) {
            return false;
        }
        
        $current = get_site_option('loginpro_network_settings', []);
        $updated = array_merge($current, $settings);
        
        return update_site_option('loginpro_network_settings', $updated);
    }
    
    /**
     * Get site settings (with network fallback)
     */
    public static function get_site_settings($blog_id = null) {
        if (!$blog_id) {
            $blog_id = get_current_blog_id();
        }
        
        $network_settings = self::get_network_settings();
        $site_settings = get_blog_option($blog_id, 'loginpro_settings', []);
        
        return array_merge($network_settings, $site_settings);
    }
    
    /**
     * Share user across network
     */
    public static function share_user_across_network($user_id) {
        if (!is_multisite()) {
            return false;
        }
        
        $sites = get_sites([
            'number' => 0,
            'public' => 1,
        ]);
        
        foreach ($sites as $site) {
            if (!is_user_member_of_blog($user_id, $site->blog_id)) {
                add_user_to_blog($site->blog_id, $user_id, 'subscriber');
            }
        }
        
        return true;
    }
    
    /**
     * Check if user has access to site
     */
    public static function user_has_access($user_id, $blog_id = null) {
        if (!$blog_id) {
            $blog_id = get_current_blog_id();
        }
        
        if (!is_multisite()) {
            return true;
        }
        
        return is_user_member_of_blog($user_id, $blog_id);
    }
}

// ==================================================
// ✅ FIXED: ایجاد instance فقط در صورت نیاز
// ==================================================

if (is_multisite()) {
    new MultisiteManager();
}