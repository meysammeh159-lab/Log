<?php
/**
 * توابع کمکی لاگین پرو
 * 
 * @package LoginPro
 */

defined('ABSPATH') || exit;

// ==================================================
// ✅ تبدیل رنگ HEX به RGB
// ==================================================
if (!function_exists('loginpro_hex2rgb')) {
    function loginpro_hex2rgb($hex) {
        $hex = str_replace('#', '', $hex);
        if (strlen($hex) == 3) {
            $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
            $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
            $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
        } else {
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
        }
        return "$r, $g, $b";
    }
}

// ==================================================
// ✅ تبدیل اعداد انگلیسی به فارسی
// ==================================================
if (!function_exists('loginpro_en_to_fa')) {
    function loginpro_en_to_fa($number) {
        $en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        $fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str_replace($en, $fa, $number);
    }
}

// ==================================================
// ✅ تبدیل تاریخ میلادی به شمسی
// ==================================================
if (!function_exists('loginpro_gregorian_to_jalali')) {
    function loginpro_gregorian_to_jalali($gy, $gm, $gd) {
        $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * ((int)($days / 12053)));
        $days %= 12053;
        $jy += 4 * ((int)($days / 1461));
        $days %= 1461;
        if ($days > 365) {
            $jy += (int)(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + (int)($days / 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + (int)(($days - 186) / 30);
            $jd = 1 + (($days - 186) % 30);
        }
        return array($jy, $jm, $jd);
    }
}

// ==================================================
// ✅ دریافت URL پروفایل کاربر
// ==================================================
if (!function_exists('loginpro_get_profile_url')) {
    function loginpro_get_profile_url() {
        $profile_page_id = get_option('loginpro_profile_page_id', 0);
        return $profile_page_id ? get_permalink($profile_page_id) : home_url('/profile/');
    }
}