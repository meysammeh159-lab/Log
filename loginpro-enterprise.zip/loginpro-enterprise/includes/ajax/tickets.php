<?php
/**
 * LoginPro — AJAX Handlers: Support Tickets
 * مسیر: /wp-content/plugins/loginpro-enterprise/includes/ajax/tickets.php
 */

defined('ABSPATH') || exit;

// ==================================================
// جدول‌سازی ایمن (در صورت نبود جدول پیام‌ها، ایجاد می‌شود)
// ==================================================
function loginpro_maybe_create_ticket_messages_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'loginpro_ticket_messages';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") === $table) {
        return;
    }

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE {$table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        ticket_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        message LONGTEXT NOT NULL,
        is_admin TINYINT(1) NOT NULL DEFAULT 0,
        attachment VARCHAR(500) DEFAULT '',
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY ticket_id (ticket_id)
    ) {$charset_collate};";

    dbDelta($sql);
}
add_action('init', 'loginpro_maybe_create_ticket_messages_table');

// ==================================================
// Helper: بررسی nonce + لاگین بودن کاربر
// ==================================================
function loginpro_ajax_guard() {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('برای این عملیات باید وارد شوید.', 'loginpro')], 401);
    }

    $nonce = isset($_POST['_nonce']) ? sanitize_text_field(wp_unslash($_POST['_nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'loginpro_ajax_nonce')) {
        wp_send_json_error(['message' => __('نشست شما منقضی شده است، لطفاً صفحه را رفرش کنید.', 'loginpro')], 403);
    }

    return get_current_user_id();
}

// ==================================================
// Helper: واکشی یک تیکت با اطمینان از مالکیت کاربر
// ==================================================
function loginpro_get_owned_ticket($ticket_id, $user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'loginpro_tickets';

    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE id = %d AND user_id = %d",
        $ticket_id,
        $user_id
    ));
}

// ==================================================
// Helper: ساخت رشته مکالمه برای مودال جزئیات
// ==================================================
function loginpro_get_ticket_thread($ticket) {
    global $wpdb;
    $messages_table = $wpdb->prefix . 'loginpro_ticket_messages';
    $thread = [];

    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT m.*, u.display_name FROM {$messages_table} m
         LEFT JOIN {$wpdb->users} u ON u.ID = m.user_id
         WHERE m.ticket_id = %d ORDER BY m.created_at ASC",
        $ticket->id
    ));

    if ($rows) {
        foreach ($rows as $row) {
            $thread[] = [
                'message'     => $row->message,
                'is_admin'    => (bool) $row->is_admin,
                'sender_name' => $row->display_name ? $row->display_name : __('کاربر', 'loginpro'),
                'attachment'  => $row->attachment,
                'created_at'  => mysql2date('Y-m-d H:i', $row->created_at),
            ];
        }
        return $thread;
    }

    // Fallback: از ساختار قدیمی (message + reply)
    $user = get_userdata($ticket->user_id);
    $thread[] = [
        'message'     => $ticket->message,
        'is_admin'    => false,
        'sender_name' => $user ? $user->display_name : __('کاربر', 'loginpro'),
        'attachment'  => $ticket->attachment,
        'created_at'  => mysql2date('Y-m-d H:i', $ticket->created_at),
    ];

    if (!empty($ticket->reply)) {
        $thread[] = [
            'message'     => $ticket->reply,
            'is_admin'    => true,
            'sender_name' => __('پشتیبانی', 'loginpro'),
            'attachment'  => '',
            'created_at'  => $ticket->reply_date ? mysql2date('Y-m-d H:i', $ticket->reply_date) : '',
        ];
    }

    return $thread;
}

// ==================================================
// 1) ثبت تیکت جدید
// ==================================================
add_action('wp_ajax_loginpro_submit_ticket', 'loginpro_ajax_submit_ticket');
function loginpro_ajax_submit_ticket() {
    $user_id = loginpro_ajax_guard();

    $subject    = isset($_POST['subject']) ? sanitize_text_field(wp_unslash($_POST['subject'])) : '';
    $message    = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    $priority   = isset($_POST['priority']) ? sanitize_key($_POST['priority']) : 'normal';
    $department = isset($_POST['department']) ? sanitize_key($_POST['department']) : 'general';

    $allowed_priorities   = ['low', 'normal', 'high', 'urgent'];
    $allowed_departments  = ['general', 'technical', 'sales', 'support'];

    if (!in_array($priority, $allowed_priorities, true)) {
        $priority = 'normal';
    }
    if (!in_array($department, $allowed_departments, true)) {
        $department = 'general';
    }

    if ($subject === '' || $message === '') {
        wp_send_json_error(['message' => __('لطفاً موضوع و متن تیکت را وارد کنید.', 'loginpro')]);
    }

    $attachment_url = '';

    if (!empty($_FILES['ticket_file']) && !empty($_FILES['ticket_file']['name'])) {
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'txt'];
        $max_size    = 5 * 1024 * 1024;

        $file_ext = strtolower(pathinfo($_FILES['ticket_file']['name'], PATHINFO_EXTENSION));

        if (!in_array($file_ext, $allowed_ext, true)) {
            wp_send_json_error(['message' => __('فرمت فایل مجاز نیست.', 'loginpro')]);
        }

        if ($_FILES['ticket_file']['size'] > $max_size) {
            wp_send_json_error(['message' => __('حجم فایل نباید بیشتر از ۵ مگابایت باشد.', 'loginpro')]);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        $overrides = ['test_form' => false];
        $uploaded  = wp_handle_upload($_FILES['ticket_file'], $overrides);

        if (isset($uploaded['error'])) {
            wp_send_json_error(['message' => $uploaded['error']]);
        }

        $attachment_url = $uploaded['url'];
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loginpro_tickets';

    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    if (!$table_exists) {
        wp_send_json_error(['message' => 'سیستم تیکت‌ها به‌درستی راه‌اندازی نشده است. لطفاً با مدیر سایت تماس بگیرید.']);
        return;
    }

    $columns = $wpdb->get_col("DESCRIBE $table");
    if (empty($columns)) {
        wp_send_json_error(['message' => 'خطا در ارتباط با دیتابیس. لطفاً با مدیر سایت تماس بگیرید.']);
        return;
    }

    $data = [
        'user_id'    => $user_id,
        'title'      => $subject,
        'message'    => $message,
        'status'     => 'pending',
        'priority'   => $priority,
        'category'   => $department,
        'attachment' => $attachment_url,
        'created_at' => current_time('mysql'),
    ];

    $filtered_data = array_intersect_key($data, array_flip($columns));

    $required = ['user_id', 'title', 'message', 'status', 'created_at'];
    foreach ($required as $col) {
        if (!in_array($col, $columns)) {
            wp_send_json_error(['message' => "خطای ساختار دیتابیس: ستون '$col' وجود ندارد."]);
            return;
        }
    }

    $formats = [];
    foreach ($filtered_data as $key => $value) {
        if (in_array($key, ['user_id'])) {
            $formats[] = '%d';
        } else {
            $formats[] = '%s';
        }
    }

    $inserted = $wpdb->insert($table, $filtered_data, $formats);

    if ($inserted === false) {
        wp_send_json_error([
            'message' => 'خطا در ذخیره‌سازی تیکت. لطفاً دوباره تلاش کنید.',
            'error'   => $wpdb->last_error,
        ]);
        return;
    }

    do_action('loginpro_after_ticket_submitted', $wpdb->insert_id, $user_id);

    wp_send_json_success([
        'message'   => __('تیکت شما با موفقیت ثبت شد.', 'loginpro'),
        'ticket_id' => $wpdb->insert_id
    ]);
}

// ==================================================
// 2) جزئیات یک تیکت
// ==================================================
add_action('wp_ajax_loginpro_user_get_ticket_detail', 'loginpro_ajax_get_ticket_detail');
function loginpro_ajax_get_ticket_detail() {
    $user_id = loginpro_ajax_guard();

    $ticket_id = isset($_POST['ticket_id']) ? absint($_POST['ticket_id']) : 0;
    $ticket    = loginpro_get_owned_ticket($ticket_id, $user_id);

    if (!$ticket) {
        wp_send_json_error(['message' => __('تیکت یافت نشد.', 'loginpro')]);
    }

    wp_send_json_success([
        'id'         => (int) $ticket->id,
        'title'      => $ticket->title,
        'status'     => $ticket->status,
        'priority'   => $ticket->priority,
        'created_at' => mysql2date('Y-m-d H:i', $ticket->created_at),
        'avg_rating' => isset($ticket->rating) ? (float) $ticket->rating : 0,
        'messages'   => loginpro_get_ticket_thread($ticket),
    ]);
}

// ==================================================
// 3) ثبت پاسخ کاربر روی تیکت باز
// ==================================================
add_action('wp_ajax_loginpro_user_reply_ticket', 'loginpro_ajax_reply_ticket');
function loginpro_ajax_reply_ticket() {
    $user_id = loginpro_ajax_guard();

    $ticket_id = isset($_POST['ticket_id']) ? absint($_POST['ticket_id']) : 0;
    $reply     = isset($_POST['reply']) ? sanitize_textarea_field(wp_unslash($_POST['reply'])) : '';

    $ticket = loginpro_get_owned_ticket($ticket_id, $user_id);
    if (!$ticket) {
        wp_send_json_error(['message' => __('تیکت یافت نشد.', 'loginpro')]);
    }

    if ($ticket->status === 'closed') {
        wp_send_json_error(['message' => __('این تیکت بسته شده و امکان ارسال پاسخ وجود ندارد.', 'loginpro')]);
    }

    if ($reply === '') {
        wp_send_json_error(['message' => __('لطفاً متن پاسخ را وارد کنید.', 'loginpro')]);
    }

    global $wpdb;
    loginpro_maybe_create_ticket_messages_table();
    $messages_table = $wpdb->prefix . 'loginpro_ticket_messages';

    $inserted = $wpdb->insert(
        $messages_table,
        [
            'ticket_id'  => $ticket_id,
            'user_id'    => $user_id,
            'message'    => $reply,
            'is_admin'   => 0,
            'created_at' => current_time('mysql'),
        ],
        ['%d', '%d', '%s', '%d', '%s']
    );

    if ($inserted === false) {
        wp_send_json_error(['message' => __('خطا در ثبت پاسخ.', 'loginpro') . ' ' . $wpdb->last_error]);
        return;
    }

    $tickets_table = $wpdb->prefix . 'loginpro_tickets';
    $wpdb->update($tickets_table, ['status' => 'pending'], ['id' => $ticket_id], ['%s'], ['%d']);

    do_action('loginpro_after_ticket_user_reply', $ticket_id, $user_id, $reply);

    wp_send_json_success(['message' => __('پاسخ شما ثبت شد.', 'loginpro')]);
}

// ==================================================
// 4) بستن تیکت توسط کاربر
// ==================================================
add_action('wp_ajax_loginpro_user_close_ticket', 'loginpro_ajax_close_ticket');
function loginpro_ajax_close_ticket() {
    $user_id = loginpro_ajax_guard();

    $ticket_id = isset($_POST['ticket_id']) ? absint($_POST['ticket_id']) : 0;
    $ticket    = loginpro_get_owned_ticket($ticket_id, $user_id);

    if (!$ticket) {
        wp_send_json_error(['message' => __('تیکت یافت نشد.', 'loginpro')]);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loginpro_tickets';

    $updated = $wpdb->update($table, ['status' => 'closed'], ['id' => $ticket_id], ['%s'], ['%d']);

    if ($updated === false) {
        wp_send_json_error(['message' => __('خطا در بستن تیکت.', 'loginpro') . ' ' . $wpdb->last_error]);
        return;
    }

    do_action('loginpro_after_ticket_closed', $ticket_id, $user_id);

    wp_send_json_success(['message' => __('تیکت با موفقیت بسته شد.', 'loginpro')]);
}

// ==================================================
// 5) امتیازدهی به تیکت بسته‌شده
// ==================================================
add_action('wp_ajax_loginpro_user_rate_ticket', 'loginpro_ajax_rate_ticket');
function loginpro_ajax_rate_ticket() {
    $user_id = loginpro_ajax_guard();

    $ticket_id = isset($_POST['ticket_id']) ? absint($_POST['ticket_id']) : 0;
    $rating    = isset($_POST['rating']) ? absint($_POST['rating']) : 0;

    if ($rating < 1 || $rating > 5) {
        wp_send_json_error(['message' => __('امتیاز نامعتبر است.', 'loginpro')]);
    }

    $ticket = loginpro_get_owned_ticket($ticket_id, $user_id);
    if (!$ticket) {
        wp_send_json_error(['message' => __('تیکت یافت نشد.', 'loginpro')]);
    }

    if ($ticket->status !== 'closed') {
        wp_send_json_error(['message' => __('فقط تیکت‌های بسته‌شده قابل امتیازدهی هستند.', 'loginpro')]);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loginpro_tickets';

    $updated = $wpdb->update($table, ['rating' => $rating], ['id' => $ticket_id], ['%d'], ['%d']);

    if ($updated === false) {
        wp_send_json_error(['message' => __('خطا در ثبت امتیاز. لطفاً از وجود ستون rating در جدول تیکت‌ها مطمئن شوید.', 'loginpro')]);
        return;
    }

    wp_send_json_success(['message' => __('امتیاز شما ثبت شد، متشکریم!', 'loginpro')]);
}