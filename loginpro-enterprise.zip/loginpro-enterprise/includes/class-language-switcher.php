<?php
/**
 * کلاس تغییر زبان
 * 
 * @package LoginPro
 * @subpackage I18n
 */

class LoginPro_LanguageSwitcher {
    
    /**
     * نمایش سوییچر زبان در فرانت‌اند
     */
    public function render_switcher() {
        $current = determine_locale();
        $languages = (new LoginPro_I18n())->get_supported_languages();
        
        if (count($languages) <= 1) {
            return '';
        }
        
        $html = '<div class="loginpro-language-switcher">';
        $html .= '<select id="loginpro-language-select" onchange="window.location.href=this.value">';
        
        foreach ($languages as $code => $name) {
            $url = add_query_arg('lang', $code);
            $selected = ($code === $current) ? ' selected' : '';
            $html .= sprintf(
                '<option value="%s"%s>%s</option>',
                esc_url($url),
                $selected,
                esc_html($name)
            );
        }
        
        $html .= '</select>';
        $html .= '</div>';
        
        return $html;
    }
}