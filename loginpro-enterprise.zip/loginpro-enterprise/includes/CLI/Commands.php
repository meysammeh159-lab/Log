<?php
/**
 * WP CLI Commands for LoginPro Enterprise
 * 
 * @package LoginPro
 * @since 3.0.0
 */

namespace LoginPro\Includes\CLI;

defined('ABSPATH') || exit;

/**
 * LoginPro CLI Commands
 * 
 * ## EXAMPLES
 * 
 *     # List users
 *     wp loginpro user list
 *     
 *     # Clear cache
 *     wp loginpro cache clear
 *     
 *     # Run migration
 *     wp loginpro migrate
 */
class LoginPro_CLI_Commands {
    
    /**
     * List all LoginPro users
     * 
     * ## OPTIONS
     * 
     * [--role=<role>]
     * : Filter by user role
     * 
     * [--format=<format>]
     * : Output format (table, json, csv, yaml)
     * 
     * ## EXAMPLES
     * 
     *     wp loginpro user list
     *     wp loginpro user list --role=subscriber
     *     wp loginpro user list --format=json
     */
    public function user_list($args, $assoc_args) {
        $role = $assoc_args['role'] ?? '';
        $format = $assoc_args['format'] ?? 'table';
        
        $users = get_users([
            'meta_key' => 'mobile_number',
            'meta_compare' => 'EXISTS',
        ]);
        
        if ($role) {
            $users = array_filter($users, function($user) use ($role) {
                return in_array($role, $user->roles);
            });
        }
        
        $data = [];
        foreach ($users as $user) {
            $data[] = [
                'ID' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'display_name' => $user->display_name,
                'mobile' => get_user_meta($user->ID, 'mobile_number', true),
                'registered' => $user->user_registered,
                'role' => implode(', ', $user->roles),
            ];
        }
        
        if (empty($data)) {
            \WP_CLI::warning('No users found.');
            return;
        }
        
        \WP_CLI\Utils\format_items($format, $data, ['ID', 'username', 'email', 'display_name', 'mobile', 'registered', 'role']);
    }
    
    /**
     * Get or set settings
     * 
     * ## OPTIONS
     * 
     * <action>
     * : get or set
     * 
     * [--key=<key>]
     * : Setting key
     * 
     * [--value=<value>]
     * : Setting value (for set action)
     * 
     * ## EXAMPLES
     * 
     *     wp loginpro settings get --key=primary_color
     *     wp loginpro settings set --key=primary_color --value=#ff0000
     */
    public function settings($args, $assoc_args) {
        $action = $args[0] ?? 'get';
        $key = $assoc_args['key'] ?? '';
        
        if (!$key) {
            \WP_CLI::error('Please specify a key with --key=');
            return;
        }
        
        if ($action === 'get') {
            $value = get_option('loginpro_' . $key);
            if ($value === false) {
                \WP_CLI::warning("Setting '{$key}' not found.");
            } else {
                \WP_CLI::line($value);
            }
        } elseif ($action === 'set') {
            $value = $assoc_args['value'] ?? '';
            if (!$value) {
                \WP_CLI::error('Please specify a value with --value=');
                return;
            }
            update_option('loginpro_' . $key, $value);
            \WP_CLI::success("Setting '{$key}' updated to '{$value}'.");
        } else {
            \WP_CLI::error("Invalid action '{$action}'. Use 'get' or 'set'.");
        }
    }
    
    /**
     * Clear all LoginPro caches
     * 
     * ## OPTIONS
     * 
     * [--all]
     * : Clear all caches including transients
     * 
     * ## EXAMPLES
     * 
     *     wp loginpro cache clear
     *     wp loginpro cache clear --all
     */
    public function cache_clear($args, $assoc_args) {
        global $wpdb;
        
        // Clear transients
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_loginpro_%'
            )
        );
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_timeout_loginpro_%'
            )
        );
        
        // Clear object cache
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        // Clear cached version numbers
        delete_transient('loginpro_css_version');
        delete_transient('loginpro_js_version');
        
        \WP_CLI::success('Cache cleared successfully.');
    }
    
    /**
     * Run database migrations
     * 
     * ## OPTIONS
     * 
     * [--version=<version>]
     * : Target version
     * 
     * [--rollback]
     * : Rollback last migration
     * 
     * ## EXAMPLES
     * 
     *     wp loginpro migrate
     *     wp loginpro migrate --version=3.0.0
     *     wp loginpro migrate --rollback
     */
    public function migrate($args, $assoc_args) {
        global $wpdb;
        
        $version = $assoc_args['version'] ?? LOGINPRO_VERSION;
        $rollback = isset($assoc_args['rollback']);
        
        if ($rollback) {
            \WP_CLI::log('Rolling back last migration...');
            // Implement rollback logic
            \WP_CLI::success('Migration rolled back successfully.');
            return;
        }
        
        \WP_CLI::log("Running migration to version {$version}...");
        
        // Check current version
        $current_version = get_option('loginpro_db_version', '0.0.0');
        
        if (version_compare($current_version, $version, '>=')) {
            \WP_CLI::warning("Already at version {$version} or higher.");
            return;
        }
        
        // Create tables
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Add new tables or modify existing ones
        $tables = [
            // ... table definitions
        ];
        
        foreach ($tables as $sql) {
            dbDelta($sql);
        }
        
        update_option('loginpro_db_version', $version);
        
        \WP_CLI::success("Migration to version {$version} completed successfully.");
    }
    
    /**
     * Generate OTP for a user
     * 
     * ## OPTIONS
     * 
     * <user>
     * : User ID, username, or email
     * 
     * [--length=<length>]
     * : OTP length (default: 6)
     * 
     * ## EXAMPLES
     * 
     *     wp loginpro otp generate --user=john
     *     wp loginpro otp generate --user=123 --length=8
     */
    public function otp_generate($args, $assoc_args) {
        $user = $assoc_args['user'] ?? '';
        
        if (!$user) {
            \WP_CLI::error('Please specify a user with --user=');
            return;
        }
        
        $user_obj = get_user_by('ID', $user) ?: get_user_by('login', $user) ?: get_user_by('email', $user);
        
        if (!$user_obj) {
            \WP_CLI::error("User '{$user}' not found.");
            return;
        }
        
        $length = $assoc_args['length'] ?? 6;
        
        // Generate OTP
        $otp = '';
        for ($i = 0; $i < (int) $length; $i++) {
            $otp .= wp_rand(0, 9);
        }
        
        \WP_CLI::line("OTP for user {$user_obj->display_name}: {$otp}");
    }
    
    /**
     * Clean old data
     * 
     * ## OPTIONS
     * 
     * [--days=<days>]
     * : Delete data older than X days (default: 30)
     * 
     * [--type=<type>]
     * : Type of data to clean (logs, otps, sessions)
     * 
     * ## EXAMPLES
     * 
     *     wp loginpro clean
     *     wp loginpro clean --days=7
     *     wp loginpro clean --type=logs
     */
    public function clean($args, $assoc_args) {
        global $wpdb;
        
        $days = (int) ($assoc_args['days'] ?? 30);
        $type = $assoc_args['type'] ?? 'all';
        
        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        $tables = [
            'loginpro_otp_logs' => 'created_at',
            'loginpro_security_events' => 'created_at',
            'loginpro_login_history' => 'created_at',
            'loginpro_sessions' => 'created_at',
        ];
        
        $total_deleted = 0;
        
        foreach ($tables as $table => $column) {
            if ($type !== 'all' && $type !== $table) {
                continue;
            }
            
            $full_table = $wpdb->prefix . $table;
            $deleted = $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$full_table} WHERE {$column} < %s",
                    $date
                )
            );
            
            if ($deleted) {
                \WP_CLI::log("Deleted {$deleted} rows from {$table}");
                $total_deleted += $deleted;
            }
        }
        
        \WP_CLI::success("Cleaned {$total_deleted} rows older than {$days} days.");
    }
}

// ==================================================
// ✅ FIXED: ثبت دستورات فقط در صورت وجود WP_CLI
// ==================================================

if (class_exists('WP_CLI')) {
    \WP_CLI::add_command('loginpro', 'LoginPro_CLI_Commands');
}