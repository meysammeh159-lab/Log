<?php
/**
 * Nonce Manager Class
 * مدیریت امن توکن‌های Nonce با قابلیت اختصاصی‌سازی برای هر کاربر و عملیات
 * 
 * @package LoginPro
 * @version 3.0.14
 * @since 3.0.14
 */

namespace LoginPro\Security;

defined('ABSPATH') || exit;

class NonceManager {
    
    private static $prefix = 'loginpro_';
    private static $lifetime = 86400; // 24 ساعت
    
    /**
     * ایجاد Nonce اختصاصی برای کاربر و عملیات
     */
    public static function create($action, $user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        if (!$user_id) {
            $user_id = 0;
        }
        
        $salt = wp_salt();
        $timestamp = floor(time() / self::$lifetime);
        $token = $action . '|' . $user_id . '|' . $timestamp . '|' . $salt;
        
        return wp_hash($token);
    }
    
    /**
     * بررسی اعتبار Nonce
     */
    public static function verify($nonce, $action, $user_id = null) {
        if (empty($nonce) || empty($action)) {
            return false;
        }
        
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        if (!$user_id) {
            $user_id = 0;
        }
        
        $current_token = self::create($action, $user_id);
        if (hash_equals($current_token, $nonce)) {
            return true;
        }
        
        $previous_token = self::create_previous($action, $user_id);
        if (hash_equals($previous_token, $nonce)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * ایجاد توکن برای پنجره زمانی قبلی
     */
    private static function create_previous($action, $user_id) {
        $salt = wp_salt();
        $timestamp = floor(time() / self::$lifetime) - 1;
        $token = $action . '|' . $user_id . '|' . $timestamp . '|' . $salt;
        
        return wp_hash($token);
    }
    
    /**
     * بررسی وجود Nonce در درخواست
     */
    public static function check_request($action, $method = 'POST', $user_id = null) {
        $nonce = '';
        
        if ($method === 'POST') {
            $nonce = isset($_POST['_nonce']) ? sanitize_text_field($_POST['_nonce']) : '';
        } elseif ($method === 'GET') {
            $nonce = isset($_GET['_nonce']) ? sanitize_text_field($_GET['_nonce']) : '';
        } else {
            return false;
        }
        
        if (empty($nonce)) {
            return false;
        }
        
        return self::verify($nonce, $action, $user_id);
    }
    
    /**
     * ایجاد Nonce برای استفاده در فرم‌ها
     */
    public static function create_field($action, $user_id = null) {
        $nonce = self::create($action, $user_id);
        return '<input type="hidden" name="_nonce" value="' . esc_attr($nonce) . '" />';
    }
}