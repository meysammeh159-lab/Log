<?php
/**
 * Permission Checker Class
 * بررسی و مدیریت دسترسی‌های کاربران به صورت متمرکز
 * 
 * @package LoginPro
 * @version 3.0.14
 * @since 3.0.14
 */

namespace LoginPro\Security;

defined('ABSPATH') || exit;

class PermissionChecker {
    
    private static $error_messages = [
        'not_logged_in' => 'لطفاً ابتدا وارد شوید.',
        'insufficient_permission' => 'شما دسترسی لازم برای انجام این عملیات را ندارید.',
        'invalid_user' => 'کاربر نامعتبر.',
        'invalid_request' => 'درخواست نامعتبر.',
        'rate_limited' => 'تعداد درخواست‌های شما بیش از حد مجاز است.',
    ];
    
    /**
     * بررسی لاگین بودن کاربر
     */
    public static function is_logged_in($send_response = true) {
        if (is_user_logged_in()) {
            return true;
        }
        
        if ($send_response) {
            wp_send_json_error([
                'message' => self::$error_messages['not_logged_in'],
                'code' => 'not_logged_in'
            ], 401);
        }
        
        return false;
    }
    
    /**
     * بررسی دسترسی کاربر
     */
    public static function check($capability, $user_id = null, $send_response = true) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            if ($send_response) {
                wp_send_json_error([
                    'message' => self::$error_messages['not_logged_in'],
                    'code' => 'not_logged_in'
                ], 401);
            }
            return false;
        }
        
        $capabilities = is_array($capability) ? $capability : [$capability];
        
        foreach ($capabilities as $cap) {
            if (user_can($user_id, $cap)) {
                return true;
            }
        }
        
        if ($send_response) {
            wp_send_json_error([
                'message' => self::$error_messages['insufficient_permission'],
                'code' => 'insufficient_permission',
                'required' => $capability
            ], 403);
        }
        
        return false;
    }
    
    /**
     * بررسی مالکیت کاربر
     */
    public static function is_owner($resource_user_id, $current_user_id = null, $send_response = true) {
        if ($current_user_id === null) {
            $current_user_id = get_current_user_id();
        }
        
        if (!$current_user_id) {
            if ($send_response) {
                wp_send_json_error([
                    'message' => self::$error_messages['not_logged_in'],
                    'code' => 'not_logged_in'
                ], 401);
            }
            return false;
        }
        
        if (intval($resource_user_id) === intval($current_user_id)) {
            return true;
        }
        
        if (user_can($current_user_id, 'manage_options')) {
            return true;
        }
        
        if ($send_response) {
            wp_send_json_error([
                'message' => 'شما مالک این منبع نیستید.',
                'code' => 'not_owner'
            ], 403);
        }
        
        return false;
    }
}