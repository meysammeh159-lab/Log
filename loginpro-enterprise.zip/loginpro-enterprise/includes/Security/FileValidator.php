<?php
/**
 * File Validator Class
 * اعتبارسنجی امن فایل‌های آپلودی
 * 
 * @package LoginPro
 * @version 3.0.14
 * @since 3.0.14
 */

namespace LoginPro\Security;

defined('ABSPATH') || exit;

class FileValidator {
    
    private $allowed_types = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp',
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'txt' => 'text/plain',
        'zip' => 'application/zip',
    ];
    
    private $forbidden_extensions = [
        'php', 'php3', 'php4', 'php5', 'phtml', 'phar',
        'htaccess', 'htpasswd', 'ini', 'conf',
        'exe', 'bat', 'cmd', 'com', 'scr',
        'js', 'html', 'htm'
    ];
    
    private $max_size = 5242880; // 5MB
    private $min_size = 1;
    private $scan_content = true;
    
    public function __construct($options = []) {
        if (isset($options['max_size'])) {
            $this->max_size = intval($options['max_size']);
        }
        if (isset($options['min_size'])) {
            $this->min_size = intval($options['min_size']);
        }
        if (isset($options['scan_content'])) {
            $this->scan_content = boolval($options['scan_content']);
        }
        if (isset($options['allowed_types']) && is_array($options['allowed_types'])) {
            $this->allowed_types = array_merge($this->allowed_types, $options['allowed_types']);
        }
    }
    
    /**
     * اعتبارسنجی کامل فایل
     */
    public function validate($file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return $this->error('خطا در آپلود فایل: ' . $this->get_upload_error_message($file['error']));
        }
        
        if (!isset($file['tmp_name']) || !file_exists($file['tmp_name'])) {
            return $this->error('فایل آپلود شده یافت نشد.');
        }
        
        $size_result = $this->validate_size($file['size']);
        if (!$size_result['valid']) {
            return $this->error($size_result['error']);
        }
        
        $type_result = $this->validate_type($file);
        if (!$type_result['valid']) {
            return $this->error($type_result['error']);
        }
        
        if ($this->scan_content) {
            $content_result = $this->scan_file_content($file['tmp_name']);
            if (!$content_result['valid']) {
                return $this->error($content_result['error']);
            }
        }
        
        return [
            'valid' => true,
            'extension' => $type_result['extension'],
            'mime_type' => $type_result['mime_type'],
            'size' => $file['size'],
            'name' => $this->generate_safe_filename($file['name'], $type_result['extension'])
        ];
    }
    
    /**
     * اعتبارسنجی سایز فایل
     */
    public function validate_size($size) {
        if ($size < $this->min_size) {
            return ['valid' => false, 'error' => 'حجم فایل بسیار کم است.'];
        }
        if ($size > $this->max_size) {
            return ['valid' => false, 'error' => 'حجم فایل بیش از حد مجاز است (حداکثر ' . ($this->max_size / 1024 / 1024) . 'MB).'];
        }
        return ['valid' => true];
    }
    
    /**
     * اعتبارسنجی نوع فایل
     */
    public function validate_type($file) {
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (in_array($extension, $this->forbidden_extensions)) {
            return ['valid' => false, 'error' => 'پسوند فایل مجاز نیست: ' . $extension];
        }
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime_type = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!isset($this->allowed_types[$extension])) {
            return ['valid' => false, 'error' => 'پسوند فایل مجاز نیست.'];
        }
        
        if ($this->allowed_types[$extension] !== $mime_type) {
            return ['valid' => false, 'error' => 'نوع فایل با پسوند آن مطابقت ندارد.'];
        }
        
        return ['valid' => true, 'extension' => $extension, 'mime_type' => $mime_type];
    }
    
    /**
     * اسکن محتوای فایل
     */
    public function scan_file_content($file_path) {
        if (!file_exists($file_path)) {
            return ['valid' => false, 'error' => 'فایل برای اسکن یافت نشد.'];
        }
        
        $content = file_get_contents($file_path);
        if ($content === false) {
            return ['valid' => false, 'error' => 'خطا در خواندن محتوای فایل.'];
        }
        
        $patterns = [
            '/<\?php/i', '/<\?=.*?php/i', '/eval\s*\(/i', '/base64_decode\s*\(/i',
            '/system\s*\(/i', '/exec\s*\(/i', '/shell_exec\s*\(/i', '/passthru\s*\(/i',
            '/popen\s*\(/i', '/proc_open\s*\(/i', '/gzinflate\s*\(/i',
            '/str_rot13\s*\(/i', '/assert\s*\(/i', '/create_function\s*\(/i',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $content)) {
                return ['valid' => false, 'error' => 'محتوای فایل حاوی کدهای مخرب احتمالی است.'];
            }
        }
        
        return ['valid' => true];
    }
    
    /**
     * تولید نام فایل امن
     */
    public function generate_safe_filename($original_name, $extension = null) {
        if ($extension === null) {
            $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        }
        $prefix = 'loginpro_';
        $timestamp = time();
        $random = wp_rand(10000, 99999);
        $user_id = get_current_user_id() ?: 'guest';
        
        return $prefix . $user_id . '_' . $timestamp . '_' . $random . '.' . $extension;
    }
    
    private function get_upload_error_message($error_code) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'حجم فایل بیشتر از max_upload_filesize است.',
            UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیشتر از MAX_FILE_SIZE است.',
            UPLOAD_ERR_PARTIAL => 'فایل فقط تا حدی آپلود شده است.',
            UPLOAD_ERR_NO_FILE => 'هیچ فایلی آپلود نشده است.',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت آپلود وجود ندارد.',
            UPLOAD_ERR_CANT_WRITE => 'خطا در نوشتن فایل روی دیسک.',
            UPLOAD_ERR_EXTENSION => 'آپلود فایل توسط افزونه PHP متوقف شده است.',
        ];
        return isset($messages[$error_code]) ? $messages[$error_code] : 'خطای ناشناخته آپلود.';
    }
    
    private function error($message) {
        return ['valid' => false, 'error' => $message];
    }
}