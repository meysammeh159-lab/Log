<?php
/**
 * Rate Limiter Class
 * محدودیت نرخ درخواست برای جلوگیری از حملات Brute Force و DoS
 * 
 * @package LoginPro
 * @version 3.0.14
 * @since 3.0.14
 */

namespace LoginPro\Security;

defined('ABSPATH') || exit;

class RateLimiter {
    
    private $limit = 5;
    private $window = 300;
    private $key_prefix = 'loginpro_rate_';
    
    public function __construct($options = []) {
        if (isset($options['limit'])) {
            $this->limit = intval($options['limit']);
        }
        if (isset($options['window'])) {
            $this->window = intval($options['window']);
        }
        if (isset($options['key_prefix'])) {
            $this->key_prefix = $options['key_prefix'];
        }
    }
    
    /**
     * بررسی اجازه درخواست
     */
    public function check($identifier) {
        $key = $this->get_key($identifier);
        $data = get_transient($key);
        
        $current_time = time();
        
        if ($data && isset($data['attempts']) && isset($data['first_attempt'])) {
            if ($current_time - $data['first_attempt'] > $this->window) {
                $data = null;
            }
        }
        
        if (!$data) {
            set_transient($key, [
                'attempts' => 1,
                'first_attempt' => $current_time,
                'last_attempt' => $current_time,
            ], $this->window);
            return true;
        }
        
        if ($data['attempts'] >= $this->limit) {
            return false;
        }
        
        $data['attempts']++;
        $data['last_attempt'] = $current_time;
        set_transient($key, $data, $this->window);
        
        return true;
    }
    
    /**
     * بازنشانی تعداد درخواست‌ها
     */
    public function reset($identifier) {
        $key = $this->get_key($identifier);
        delete_transient($key);
    }
    
    /**
     * دریافت تعداد درخواست‌های باقیمانده
     */
    public function get_remaining($identifier) {
        $key = $this->get_key($identifier);
        $data = get_transient($key);
        
        if (!$data || !isset($data['attempts'])) {
            return $this->limit;
        }
        
        $current_time = time();
        if (isset($data['first_attempt']) && $current_time - $data['first_attempt'] > $this->window) {
            return $this->limit;
        }
        
        return max(0, $this->limit - $data['attempts']);
    }
    
    /**
     * ایجاد کلید یکتا
     */
    private function get_key($identifier) {
        return $this->key_prefix . md5($identifier);
    }
    
    /**
     * دریافت آدرس IP کاربر
     */
    public static function get_ip() {
        $ip = '0.0.0.0';
        
        $headers = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];
        
        foreach ($headers as $header) {
            if (isset($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                foreach ($ips as $ip_address) {
                    $ip_address = trim($ip_address);
                    if (filter_var($ip_address, FILTER_VALIDATE_IP)) {
                        $ip = $ip_address;
                        break 2;
                    }
                }
            }
        }
        
        return $ip;
    }
    
    /**
     * بررسی سریع با تنظیمات پیش‌فرض
     */
    public static function quick_check($operation, $identifier = null) {
        if ($identifier === null) {
            $identifier = self::get_ip();
        }
        
        $limiter = new self();
        return $limiter->check($operation . '_' . $identifier);
    }
}