<?php
namespace LoginPro\Admin;

defined('ABSPATH') || exit;

class ProfileTabsPage
{
    public function get_active_tabs()
    {
        return [
            'profile' => '👤 پروفایل',
            'security' => '🔒 امنیت',
            'tickets' => '🎫 تیکت‌ها'
        ];
    }
    
    public function render()
    {
        echo '<div>تنظیمات تب‌های کاربری</div>';
    }
}