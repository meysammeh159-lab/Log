<?php
/**
 * Uninstall handler for LoginPro Enterprise
 * 
 * This file runs when the plugin is uninstalled.
 * It removes all plugin data if the user has opted to do so.
 * 
 * @package LoginPro
 * @since 3.0.0
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Security: Check if the uninstall is properly initiated
if (!defined('WP_UNINSTALL_PLUGIN') || !WP_UNINSTALL_PLUGIN) {
    exit;
}

// ==================================================
// Check if we should remove data
// ==================================================
$remove_data = get_option('loginpro_remove_data_on_uninstall', false);

if (!$remove_data) {
    // Only remove the option that controls data removal
    delete_option('loginpro_remove_data_on_uninstall');
    return;
}

// ==================================================
// Main uninstall process
// ==================================================
global $wpdb;

// Get table prefix
$prefix = $wpdb->prefix;

// ==================================================
// Drop plugin tables with proper SQL injection prevention
// ==================================================
$tables = [
    'loginpro_otps',
    'loginpro_sessions',
    'loginpro_devices',
    'loginpro_login_history',
    'loginpro_security_events',
    'loginpro_tickets',
    'loginpro_ticket_replies',
    'loginpro_queue_jobs',
    'loginpro_provider_logs',
    'loginpro_queue',
    'loginpro_tickets_attachments',
    'loginpro_conversations',
    'loginpro_messages',
    'loginpro_webauthn_credentials',
    'loginpro_otp_logs'
];

foreach ($tables as $table) {
    $table_name = $prefix . $table;
    
    // SECURITY FIXED: Use proper table name escaping with backticks
    // WordPress 6.1+ supports %i placeholder for identifiers
    if (version_compare($wpdb->db_version(), '8.0.0', '>=') && method_exists($wpdb, 'prepare')) {
        // Use prepared statement with table name placeholder (MySQL 8.0+)
        try {
            $wpdb->query(
                $wpdb->prepare(
                    "DROP TABLE IF EXISTS `%s`",
                    $table_name
                )
            );
        } catch (Exception $e) {
            // Fallback for older MySQL versions
            $wpdb->query("DROP TABLE IF EXISTS `$table_name`");
        }
    } else {
        // Safe fallback for older versions
        $wpdb->query("DROP TABLE IF EXISTS `$table_name`");
    }
}

// ==================================================
// Delete user meta data
// ==================================================
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
        'loginpro_%'
    )
);

// ==================================================
// Remove plugin options
// ==================================================
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
        'loginpro_%'
    )
);

// ==================================================
// Delete transients
// ==================================================
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
        '_transient_loginpro_%'
    )
);

$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
        '_transient_timeout_loginpro_%'
    )
);

// ==================================================
// Clean up Cron jobs
// ==================================================
$cron_jobs = [
    'loginpro_cleanup_otps',
    'loginpro_cleanup_sessions',
    'loginpro_cleanup_logs',
    'loginpro_queue_worker',
    'loginpro_security_cleanup'
];

foreach ($cron_jobs as $cron_job) {
    if (wp_next_scheduled($cron_job)) {
        wp_clear_scheduled_hook($cron_job);
    }
}

// ==================================================
// Remove user roles and capabilities
// ==================================================
$plugin_capabilities = [
    'loginpro_manage_settings',
    'loginpro_view_tickets',
    'loginpro_manage_tickets',
    'loginpro_view_reports'
];

// Remove capabilities from all roles
$roles = wp_roles()->roles;
foreach ($roles as $role_name => $role_data) {
    $role = get_role($role_name);
    if ($role) {
        foreach ($plugin_capabilities as $cap) {
            $role->remove_cap($cap);
        }
    }
}

// ==================================================
// Flush rewrite rules
// ==================================================
flush_rewrite_rules();

// ==================================================
// Clear cache
// ==================================================
if (function_exists('wp_cache_flush')) {
    wp_cache_flush();
}

// ==================================================
// Clean up custom upload directories
// ==================================================
$upload_dir = wp_upload_dir();
$plugin_upload_dirs = glob($upload_dir['basedir'] . '/loginpro-*', GLOB_ONLYDIR);

if (!empty($plugin_upload_dirs) && is_array($plugin_upload_dirs)) {
    foreach ($plugin_upload_dirs as $dir) {
        if (is_dir($dir) && strpos($dir, 'loginpro-') !== false) {
            // Recursively delete directory contents
            try {
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::CHILD_FIRST
                );
                
                foreach ($files as $fileinfo) {
                    if ($fileinfo->isDir()) {
                        @rmdir($fileinfo->getRealPath());
                    } else {
                        @unlink($fileinfo->getRealPath());
                    }
                }
                
                @rmdir($dir);
            } catch (Exception $e) {
                // Log error but continue
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('LoginPro uninstall: ' . $e->getMessage());
                }
            }
        }
    }
}

// ==================================================
// Delete the uninstall option itself
// ==================================================
delete_option('loginpro_remove_data_on_uninstall');

// ==================================================
// Trigger action for other plugins to hook into
// ==================================================
if (function_exists('do_action')) {
    do_action('loginpro_after_uninstall');
}

// ==================================================
// END OF FILE
// ==================================================