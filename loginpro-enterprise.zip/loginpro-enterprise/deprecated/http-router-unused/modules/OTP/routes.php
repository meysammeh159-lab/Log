<?php
use LoginPro\Core\Http\Router;

Router::post('otp/send', [\LoginPro\Modules\OTP\Controllers\OtpController::class, 'send']);
Router::post('otp/verify', [\LoginPro\Modules\OTP\Controllers\OtpController::class, 'verify']);
Router::post('otp/resend', [\LoginPro\Modules\OTP\Controllers\OtpController::class, 'resend']);
