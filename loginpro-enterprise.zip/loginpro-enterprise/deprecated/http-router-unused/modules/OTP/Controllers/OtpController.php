<?php
namespace LoginPro\Modules\OTP\Controllers;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Modules\OTP\Services\OtpService;

class OtpController {
    private $otpService;
    
    public function __construct() {
        $this->otpService = new OtpService();
    }
    
    public function send(Request $request) {
        $data = $request->validate([
            'user_id' => 'required|integer',
            'type' => 'string'
        ]);
        
        $type = $data['type'] ?? 'verification';
        $otp = $this->otpService->generate($data['user_id'], $type);
        $sent = $this->otpService->send($data['user_id'], $otp, $type);
        
        if ($sent) {
            return Response::json([
                'success' => true,
                'message' => 'OTP sent successfully',
                'otp_id' => $otp['id'],
                'expires_in' => 300
            ]);
        }
        
        return Response::json([
            'success' => false,
            'message' => 'Failed to send OTP'
        ], 500);
    }
    
    public function verify(Request $request) {
        $data = $request->validate([
            'otp' => 'required|string|size:6',
            'otp_id' => 'required|integer'
        ]);
        
        $result = $this->otpService->verify($data['otp_id'], $data['otp']);
        
        if ($result) {
            return Response::json([
                'success' => true,
                'message' => 'OTP verified successfully',
                'user_id' => $result['user_id']
            ]);
        }
        
        return Response::json([
            'success' => false,
            'message' => 'Invalid or expired OTP'
        ], 400);
    }
    
    public function resend(Request $request) {
        $data = $request->validate([
            'otp_id' => 'required|integer'
        ]);
        
        $result = $this->otpService->resend($data['otp_id']);
        
        if ($result) {
            return Response::json([
                'success' => true,
                'message' => 'OTP resent successfully',
                'otp_id' => $result['id']
            ]);
        }
        
        return Response::json([
            'success' => false,
            'message' => 'Cannot resend OTP. Please request a new one.'
        ], 400);
    }
}
