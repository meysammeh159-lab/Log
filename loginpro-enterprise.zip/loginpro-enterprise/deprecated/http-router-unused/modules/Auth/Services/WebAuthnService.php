<?php
/**
 * WebAuthn Service for LoginPro
 * مدیریت احراز هویت بیومتریک با WebAuthn
 * 
 * @package LoginPro
 * @version 3.0.19
 */

namespace LoginPro\Modules\Auth\Services;

defined('ABSPATH') || exit;

use Exception;
use WP_Error;

/**
 * WebAuthn Service Class
 * 
 * @since 3.0.0
 */
class WebAuthnService {
    
    /**
     * @var string Plugin prefix for options
     */
    private $prefix = 'loginpro_webauthn_';
    
    /**
     * @var array تنظیمات پیش‌فرض
     */
    private $defaults = [
        'enabled' => false,
        'rp_id' => '',
        'rp_name' => 'LoginPro',
        'timeout' => 60000,
        'authenticator_selection' => 'platform',
        'user_verification' => 'required',
        'attestation' => 'none'
    ];
    
    /**
     * @var array ذخیره موقت داده‌های WebAuthn
     */
    private $session_data = [];
    
    /**
     * Constructor
     */
    public function __construct() {
        // Initialize session data from WordPress user meta
        add_action('init', [$this, 'init_session']);
    }
    
    /**
     * Initialize session data
     */
    public function init_session() {
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $this->session_data = get_user_meta($user_id, 'loginpro_webauthn_data', true);
            if (!is_array($this->session_data)) {
                $this->session_data = [];
            }
        }
    }
    
    /**
     * Check if WebAuthn is enabled
     */
    public function is_enabled() {
        $settings = get_option($this->prefix . 'settings', $this->defaults);
        return !empty($settings['enabled']) && !empty($settings['rp_id']);
    }
    
    /**
     * Get WebAuthn settings
     */
    public function get_settings() {
        $settings = get_option($this->prefix . 'settings', $this->defaults);
        return wp_parse_args($settings, $this->defaults);
    }
    
    /**
     * Update WebAuthn settings
     */
    public function update_settings($settings) {
        if (!is_array($settings)) {
            return false;
        }
        
        $sanitized = [];
        $string_fields = ['rp_id', 'rp_name', 'authenticator_selection', 'user_verification', 'attestation'];
        foreach ($string_fields as $field) {
            if (isset($settings[$field])) {
                $sanitized[$field] = sanitize_text_field($settings[$field]);
            }
        }
        
        if (isset($settings['enabled'])) {
            $sanitized['enabled'] = filter_var($settings['enabled'], FILTER_VALIDATE_BOOLEAN);
        }
        
        if (isset($settings['timeout'])) {
            $sanitized['timeout'] = intval($settings['timeout']);
            if ($sanitized['timeout'] < 10000) {
                $sanitized['timeout'] = 60000;
            }
        }
        
        return update_option($this->prefix . 'settings', $sanitized);
    }
    
    /**
     * Generate registration options
     * 
     * @param int $user_id
     * @return array|WP_Error
     */
    public function generate_registration_options($user_id) {
        if (!$this->is_enabled()) {
            return new WP_Error('webauthn_disabled', __('WebAuthn فعال نیست', 'loginpro'));
        }
        
        $user = get_user_by('ID', $user_id);
        if (!$user) {
            return new WP_Error('user_not_found', __('کاربر یافت نشد', 'loginpro'));
        }
        
        $settings = $this->get_settings();
        
        // Prepare challenge
        $challenge = $this->generate_challenge();
        
        // Store challenge in user meta
        update_user_meta($user_id, $this->prefix . 'challenge', $challenge);
        
        // Get existing credentials
        $credentials = $this->get_user_credentials($user_id);
        $exclude = [];
        foreach ($credentials as $cred) {
            if (!empty($cred['credential_id'])) {
                $exclude[] = $cred['credential_id'];
            }
        }
        
        // Build options
        $options = [
            'challenge' => $challenge,
            'rp' => [
                'name' => $settings['rp_name'],
                'id' => $settings['rp_id']
            ],
            'user' => [
                'id' => base64_encode(str_pad($user_id, 32, '0', STR_PAD_LEFT)),
                'name' => $user->user_login,
                'displayName' => $user->display_name ?: $user->user_login
            ],
            'pubKeyCredParams' => [
                ['type' => 'public-key', 'alg' => -7],
                ['type' => 'public-key', 'alg' => -257],
                ['type' => 'public-key', 'alg' => -35],
                ['type' => 'public-key', 'alg' => -8],
                ['type' => 'public-key', 'alg' => -36],
                ['type' => 'public-key', 'alg' => -37],
                ['type' => 'public-key', 'alg' => -38],
                ['type' => 'public-key', 'alg' => -39],
                ['type' => 'public-key', 'alg' => -40]
            ],
            'timeout' => $settings['timeout'],
            'authenticatorSelection' => [
                'authenticatorAttachment' => $settings['authenticator_selection'] === 'platform' 
                    ? 'platform' 
                    : 'cross-platform',
                'residentKey' => 'preferred',
                'userVerification' => $settings['user_verification']
            ],
            'attestation' => $settings['attestation'],
            'excludeCredentials' => $exclude
        ];
        
        // Store options for verification
        update_user_meta($user_id, $this->prefix . 'registration_options', $options);
        
        return $options;
    }
    
    /**
     * Verify registration response
     * 
     * @param int $user_id
     * @param array $response
     * @return bool|WP_Error
     */
    public function verify_registration($user_id, $response) {
        if (!$this->is_enabled()) {
            return new WP_Error('webauthn_disabled', __('WebAuthn فعال نیست', 'loginpro'));
        }
        
        if (empty($response) || !is_array($response)) {
            return new WP_Error('invalid_response', __('پاسخ نامعتبر است', 'loginpro'));
        }
        
        // Validate required fields
        $required = ['id', 'rawId', 'response', 'type'];
        foreach ($required as $field) {
            if (empty($response[$field])) {
                return new WP_Error('missing_field', sprintf(__('فیلد %s خالی است', 'loginpro'), $field));
            }
        }
        
        if ($response['type'] !== 'public-key') {
            return new WP_Error('invalid_type', __('نوع نامعتبر', 'loginpro'));
        }
        
        // Get stored challenge
        $challenge = get_user_meta($user_id, $this->prefix . 'challenge', true);
        if (empty($challenge)) {
            return new WP_Error('missing_challenge', __('چالش یافت نشد', 'loginpro'));
        }
        
        // Decode response
        $rawId = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['rawId']));
        $clientDataJSON = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['response']['clientDataJSON']));
        $attestationObject = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['response']['attestationObject']));
        
        if ($clientDataJSON === false || $attestationObject === false) {
            return new WP_Error('invalid_encoding', __('خطا در دیکد کردن داده‌ها', 'loginpro'));
        }
        
        // Parse client data
        $clientData = json_decode($clientDataJSON, true);
        if (!$clientData || !is_array($clientData)) {
            return new WP_Error('invalid_client_data', __('داده‌های کلاینت نامعتبر', 'loginpro'));
        }
        
        // Verify challenge
        $clientChallenge = base64_decode(str_replace(['-', '_'], ['+', '/'], $clientData['challenge']));
        if ($clientChallenge !== $challenge) {
            return new WP_Error('challenge_mismatch', __('چالش مطابقت ندارد', 'loginpro'));
        }
        
        // Parse attestation object
        // Note: In production, use WebAuthn library for proper parsing
        // This is a simplified version
        $attestation = $this->parse_attestation_object($attestationObject);
        if (!$attestation) {
            return new WP_Error('invalid_attestation', __('اطلاعات احراز هویت نامعتبر', 'loginpro'));
        }
        
        // Extract credential ID
        $credentialId = $rawId;
        $credentialIdBase64 = base64_encode($credentialId);
        
        // Extract public key
        $publicKey = isset($attestation['publicKey']) ? $attestation['publicKey'] : '';
        if (empty($publicKey)) {
            return new WP_Error('missing_public_key', __('کلید عمومی یافت نشد', 'loginpro'));
        }
        
        // Save credential
        $credential_data = [
            'user_id' => $user_id,
            'credential_id' => $credentialIdBase64,
            'public_key' => base64_encode($publicKey),
            'sign_count' => 0,
            'device_name' => $this->get_device_name($response),
            'created_at' => current_time('mysql'),
            'last_used' => current_time('mysql'),
            'is_active' => true
        ];
        
        $result = $this->save_credential($credential_data);
        if (!$result) {
            return new WP_Error('save_failed', __('خطا در ذخیره اطلاعات', 'loginpro'));
        }
        
        // Clear challenge
        delete_user_meta($user_id, $this->prefix . 'challenge');
        
        return true;
    }
    
    /**
     * Generate authentication options
     * 
     * @param int $user_id
     * @return array|WP_Error
     */
    public function generate_authentication_options($user_id) {
        if (!$this->is_enabled()) {
            return new WP_Error('webauthn_disabled', __('WebAuthn فعال نیست', 'loginpro'));
        }
        
        $user = get_user_by('ID', $user_id);
        if (!$user) {
            return new WP_Error('user_not_found', __('کاربر یافت نشد', 'loginpro'));
        }
        
        $settings = $this->get_settings();
        
        // Get credentials
        $credentials = $this->get_user_credentials($user_id);
        if (empty($credentials)) {
            return new WP_Error('no_credentials', __('هیچ دستگاه احراز هویتی یافت نشد', 'loginpro'));
        }
        
        // Prepare challenge
        $challenge = $this->generate_challenge();
        update_user_meta($user_id, $this->prefix . 'auth_challenge', $challenge);
        
        // Build options
        $allowCredentials = [];
        foreach ($credentials as $cred) {
            if (!empty($cred['credential_id'])) {
                $allowCredentials[] = [
                    'type' => 'public-key',
                    'id' => $cred['credential_id']
                ];
            }
        }
        
        $options = [
            'challenge' => $challenge,
            'timeout' => $settings['timeout'],
            'rpId' => $settings['rp_id'],
            'allowCredentials' => $allowCredentials,
            'userVerification' => $settings['user_verification']
        ];
        
        return $options;
    }
    
    /**
     * Verify authentication response
     * 
     * @param int $user_id
     * @param array $response
     * @return bool|WP_Error
     */
    public function verify_authentication($user_id, $response) {
        if (!$this->is_enabled()) {
            return new WP_Error('webauthn_disabled', __('WebAuthn فعال نیست', 'loginpro'));
        }
        
        if (empty($response) || !is_array($response)) {
            return new WP_Error('invalid_response', __('پاسخ نامعتبر است', 'loginpro'));
        }
        
        $required = ['id', 'rawId', 'response', 'type'];
        foreach ($required as $field) {
            if (empty($response[$field])) {
                return new WP_Error('missing_field', sprintf(__('فیلد %s خالی است', 'loginpro'), $field));
            }
        }
        
        if ($response['type'] !== 'public-key') {
            return new WP_Error('invalid_type', __('نوع نامعتبر', 'loginpro'));
        }
        
        // Get stored challenge
        $challenge = get_user_meta($user_id, $this->prefix . 'auth_challenge', true);
        if (empty($challenge)) {
            return new WP_Error('missing_challenge', __('چالش یافت نشد', 'loginpro'));
        }
        
        // Get credential
        $credential_id = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['id']));
        $credential_id_base64 = base64_encode($credential_id);
        $credential = $this->get_credential_by_id($user_id, $credential_id_base64);
        
        if (!$credential) {
            return new WP_Error('credential_not_found', __('دستگاه احراز هویت یافت نشد', 'loginpro'));
        }
        
        // Decode response data
        $rawId = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['rawId']));
        $clientDataJSON = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['response']['clientDataJSON']));
        $authenticatorData = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['response']['authenticatorData']));
        $signature = base64_decode(str_replace(['-', '_'], ['+', '/'], $response['response']['signature']));
        
        if ($clientDataJSON === false || $authenticatorData === false || $signature === false) {
            return new WP_Error('invalid_encoding', __('خطا در دیکد کردن داده‌ها', 'loginpro'));
        }
        
        // Parse client data
        $clientData = json_decode($clientDataJSON, true);
        if (!$clientData || !is_array($clientData)) {
            return new WP_Error('invalid_client_data', __('داده‌های کلاینت نامعتبر', 'loginpro'));
        }
        
        // Verify challenge
        $clientChallenge = base64_decode(str_replace(['-', '_'], ['+', '/'], $clientData['challenge']));
        if ($clientChallenge !== $challenge) {
            return new WP_Error('challenge_mismatch', __('چالش مطابقت ندارد', 'loginpro'));
        }
        
        // Verify origin
        $settings = $this->get_settings();
        $expected_origin = 'https://' . $settings['rp_id'];
        if ($clientData['origin'] !== $expected_origin) {
            return new WP_Error('origin_mismatch', __('Origin مطابقت ندارد', 'loginpro'));
        }
        
        // Update credential last used
        $this->update_credential_last_used($user_id, $credential_id_base64);
        
        // Clear challenge
        delete_user_meta($user_id, $this->prefix . 'auth_challenge');
        
        return true;
    }
    
    /**
     * Generate a cryptographically secure challenge
     */
    private function generate_challenge() {
        if (function_exists('random_bytes')) {
            return random_bytes(32);
        }
        return openssl_random_pseudo_bytes(32);
    }
    
    /**
     * Parse attestation object (simplified)
     */
    private function parse_attestation_object($attestationObject) {
        // In production, use a proper CBOR library
        // This is a placeholder for demonstration
        return [
            'publicKey' => $attestationObject
        ];
    }
    
    /**
     * Get user credentials
     */
    private function get_user_credentials($user_id) {
        $credentials = get_user_meta($user_id, $this->prefix . 'credentials', true);
        if (!is_array($credentials)) {
            return [];
        }
        return $credentials;
    }
    
    /**
     * Get credential by ID
     */
    private function get_credential_by_id($user_id, $credential_id) {
        $credentials = $this->get_user_credentials($user_id);
        foreach ($credentials as $cred) {
            if (!empty($cred['credential_id']) && $cred['credential_id'] === $credential_id) {
                return $cred;
            }
        }
        return null;
    }
    
    /**
     * Save credential
     */
    private function save_credential($data) {
        if (empty($data) || empty($data['user_id']) || empty($data['credential_id'])) {
            return false;
        }
        
        $user_id = $data['user_id'];
        $credentials = $this->get_user_credentials($user_id);
        
        // Check if credential already exists
        foreach ($credentials as $key => $cred) {
            if (!empty($cred['credential_id']) && $cred['credential_id'] === $data['credential_id']) {
                // Update existing
                $credentials[$key] = array_merge($cred, $data);
                return update_user_meta($user_id, $this->prefix . 'credentials', $credentials);
            }
        }
        
        // Add new credential
        $credentials[] = $data;
        return update_user_meta($user_id, $this->prefix . 'credentials', $credentials);
    }
    
    /**
     * Update credential last used
     */
    private function update_credential_last_used($user_id, $credential_id) {
        $credentials = $this->get_user_credentials($user_id);
        foreach ($credentials as $key => $cred) {
            if (!empty($cred['credential_id']) && $cred['credential_id'] === $credential_id) {
                $credentials[$key]['last_used'] = current_time('mysql');
                update_user_meta($user_id, $this->prefix . 'credentials', $credentials);
                break;
            }
        }
    }
    
    /**
     * Get device name from browser data
     */
    private function get_device_name($response) {
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        
        if (strpos($user_agent, 'iPhone') !== false) {
            return 'iPhone';
        } elseif (strpos($user_agent, 'iPad') !== false) {
            return 'iPad';
        } elseif (strpos($user_agent, 'Android') !== false) {
            return 'Android Device';
        } elseif (strpos($user_agent, 'Windows') !== false) {
            return 'Windows PC';
        } elseif (strpos($user_agent, 'Macintosh') !== false) {
            return 'Mac';
        } elseif (strpos($user_agent, 'Linux') !== false) {
            return 'Linux';
        }
        
        return __('دستگاه ناشناس', 'loginpro');
    }
    
    /**
     * Delete credential
     */
    public function delete_credential($user_id, $credential_id) {
        $credentials = $this->get_user_credentials($user_id);
        foreach ($credentials as $key => $cred) {
            if (!empty($cred['credential_id']) && $cred['credential_id'] === $credential_id) {
                unset($credentials[$key]);
                return update_user_meta($user_id, $this->prefix . 'credentials', array_values($credentials));
            }
        }
        return false;
    }
    
    /**
     * Get user credentials for display
     */
    public function get_user_credentials_display($user_id) {
        $credentials = $this->get_user_credentials($user_id);
        $display = [];
        
        foreach ($credentials as $cred) {
            $display[] = [
                'id' => $cred['credential_id'] ?? '',
                'device_name' => $cred['device_name'] ?? __('دستگاه ناشناس', 'loginpro'),
                'created_at' => $cred['created_at'] ?? '',
                'last_used' => $cred['last_used'] ?? '',
                'is_active' => isset($cred['is_active']) ? (bool)$cred['is_active'] : true
            ];
        }
        
        return $display;
    }
}

// Initialize service
new WebAuthnService();
