<?php
namespace LoginPro\Modules\Auth\Controllers;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Core\Security\Validator;

class RegisterController {
    private $validator;
    
    public function __construct() {
        $this->validator = new Validator();
    }
    
    public function showForm() {
        if (is_user_logged_in()) {
            wp_redirect(home_url('/dashboard'));
            exit;
        }
        
        include LOGINPRO_PLUGIN_DIR . 'frontend/Views/auth/register.php';
    }
    
    public function register(Request $request) {
        $data = $request->validate([
            'email' => 'required|email',
            'username' => 'required|string|min:3',
            'password' => 'required|string|min:8',
            'mobile' => 'required|string',
            'first_name' => 'string',
            'last_name' => 'string'
        ]);
        
        if (email_exists($data['email'])) {
            return Response::json([
                'success' => false,
                'message' => 'Email already registered'
            ], 400);
        }
        
        if (username_exists($data['username'])) {
            return Response::json([
                'success' => false,
                'message' => 'Username already taken'
            ], 400);
        }
        
        $userId = wp_insert_user([
            'user_login' => $data['username'],
            'user_email' => $data['email'],
            'user_pass' => $data['password'],
            'first_name' => $data['first_name'] ?? '',
            'last_name' => $data['last_name'] ?? '',
            'role' => get_option('loginpro_default_role', 'subscriber')
        ]);
        
        if (is_wp_error($userId)) {
            return Response::json([
                'success' => false,
                'message' => $userId->get_error_message()
            ], 400);
        }
        
        update_user_meta($userId, 'mobile_number', $data['mobile']);
        update_user_meta($userId, 'registered_via', 'loginpro');
        
        wp_set_current_user($userId);
        wp_set_auth_cookie($userId, true);
        
        do_action('loginpro_user_registered', $userId, $data);
        
        if ($request->expectsJson()) {
            return Response::json([
                'success' => true,
                'message' => 'Registration successful',
                'redirect' => home_url('/dashboard')
            ]);
        }
        
        wp_redirect(home_url('/dashboard'));
        exit;
    }
}
