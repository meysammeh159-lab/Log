<?php
namespace LoginPro\Modules\Auth\Controllers;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Modules\OTP\Services\OtpService;

class TwoFactorController {
    private $otpService;
    
    public function __construct() {
        $this->otpService = new OtpService();
    }
    
    public function showForm() {
        include LOGINPRO_PLUGIN_DIR . 'frontend/Views/auth/two-factor.php';
    }
    
    public function verify(Request $request) {
        $data = $request->validate([
            'otp' => 'required|string|size:6',
            'user_id' => 'required|integer'
        ]);
        
        $verify = $this->otpService->verifyByUser($data['user_id'], $data['otp'], 'login');
        
        if (!$verify) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid OTP code'
            ], 400);
        }
        
        wp_set_current_user($data['user_id']);
        wp_set_auth_cookie($data['user_id'], true);
        
        unset($_SESSION['loginpro_2fa_required']);
        
        return Response::json([
            'success' => true,
            'message' => 'Verified successfully',
            'redirect' => apply_filters('loginpro_2fa_redirect', home_url('/dashboard'))
        ]);
    }
    
    public function resend(Request $request) {
        $data = $request->validate([
            'user_id' => 'required|integer'
        ]);
        
        $otp = $this->otpService->generate($data['user_id'], 'login');
        $this->otpService->send($data['user_id'], $otp, 'login');
        
        return Response::json([
            'success' => true,
            'message' => 'OTP resent successfully',
            'otp_id' => $otp['id']
        ]);
    }
    
    public function enable(Request $request) {
        $userId = get_current_user_id();
        update_user_meta($userId, 'loginpro_2fa_enabled', 'yes');
        
        return Response::json([
            'success' => true,
            'message' => 'Two-factor authentication enabled'
        ]);
    }
    
    public function disable(Request $request) {
        $userId = get_current_user_id();
        update_user_meta($userId, 'loginpro_2fa_enabled', 'no');
        
        return Response::json([
            'success' => true,
            'message' => 'Two-factor authentication disabled'
        ]);
    }
}
