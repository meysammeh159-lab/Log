<?php
namespace LoginPro\Modules\Auth\Controllers;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;
use LoginPro\Modules\OTP\Services\OtpService;

class ResetPasswordController {
    private $otpService;
    
    public function __construct() {
        $this->otpService = new OtpService();
    }
    
    public function showForm() {
        include LOGINPRO_PLUGIN_DIR . 'frontend/Views/auth/reset-password.php';
    }
    
    public function sendOtp(Request $request) {
        $data = $request->validate([
            'email' => 'required|email'
        ]);
        
        $user = get_user_by('email', $data['email']);
        
        if (!$user) {
            return Response::json([
                'success' => false,
                'message' => 'No user found with this email'
            ], 404);
        }
        
        $otp = $this->otpService->generate($user->ID, 'password_reset');
        $this->otpService->send($user->ID, $otp, 'password_reset');
        
        return Response::json([
            'success' => true,
            'message' => 'OTP sent to your email',
            'otp_id' => $otp['id']
        ]);
    }
    
    public function reset(Request $request) {
        $data = $request->validate([
            'otp' => 'required|string|size:6',
            'otp_id' => 'required|integer',
            'new_password' => 'required|string|min:8'
        ]);
        
        $verify = $this->otpService->verify($data['otp_id'], $data['otp']);
        
        if (!$verify) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid or expired OTP'
            ], 400);
        }
        
        $user = get_user_by('id', $verify['user_id']);
        
        if (!$user) {
            return Response::json([
                'success' => false,
                'message' => 'User not found'
            ], 404);
        }
        
        wp_set_password($data['new_password'], $user->ID);
        $this->otpService->invalidate($data['otp_id']);
        
        return Response::json([
            'success' => true,
            'message' => 'Password reset successful. You can now login.'
        ]);
    }
}
