<?php
/**
 * WebAuthn Controller
 * مدیریت درخواست‌های احراز هویت بیومتریک
 */

namespace LoginPro\Modules\Auth\Controllers;

use LoginPro\Modules\Auth\Services\WebAuthnService;

class WebAuthnController
{
    /**
     * @var WebAuthnService
     */
    private $service;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->service = new WebAuthnService();
    }

    /**
     * دریافت گزینه‌های ثبت‌نام
     */
    public function registerOptions()
    {
        // بررسی لاگین بودن کاربر
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'You must be logged in'], 401);
            return;
        }

        // بررسی nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_webauthn')) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
            return;
        }

        $user = wp_get_current_user();
        
        $options = $this->service->generateRegistrationOptions(
            $user->ID,
            $user->user_login,
            $user->display_name
        );

        if (is_wp_error($options)) {
            wp_send_json_error(['message' => $options->get_error_message()]);
            return;
        }

        wp_send_json_success(['options' => $options]);
    }

    /**
     * تأیید ثبت‌نام
     */
    public function verifyRegistration()
    {
        // بررسی لاگین بودن کاربر
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'You must be logged in'], 401);
            return;
        }

        // بررسی nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_webauthn')) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
            return;
        }

        $credentialData = json_decode(stripslashes($_POST['credential'] ?? ''), true);
        
        if (!$credentialData) {
            wp_send_json_error(['message' => 'Invalid credential data']);
            return;
        }

        $result = $this->service->verifyRegistration($credentialData);

        if (!$result['success']) {
            wp_send_json_error(['message' => $result['message']]);
            return;
        }

        wp_send_json_success($result);
    }

    /**
     * دریافت گزینه‌های ورود
     */
    public function loginOptions()
    {
        // بررسی nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_webauthn')) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
            return;
        }

        $userId = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;
        
        $options = $this->service->generateLoginOptions($userId);

        if (is_wp_error($options)) {
            wp_send_json_error(['message' => $options->get_error_message()]);
            return;
        }

        wp_send_json_success(['options' => $options]);
    }

    /**
     * تأیید ورود
     */
    public function verifyLogin()
    {
        // بررسی nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_webauthn')) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
            return;
        }

        $credentialData = json_decode(stripslashes($_POST['credential'] ?? ''), true);
        
        if (!$credentialData) {
            wp_send_json_error(['message' => 'Invalid credential data']);
            return;
        }

        $result = $this->service->verifyLogin($credentialData);

        if (!$result['success']) {
            wp_send_json_error(['message' => $result['message']]);
            return;
        }

        // لاگین کاربر
        $user = get_user_by('ID', $result['user_id']);
        
        if (!$user) {
            wp_send_json_error(['message' => 'User not found']);
            return;
        }

        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        do_action('wp_login', $user->user_login, $user);

        wp_send_json_success([
            'message' => 'Login successful',
            'redirect' => apply_filters('loginpro_login_redirect', home_url(), $user)
        ]);
    }

    /**
     * حذف کلید
     */
    public function deleteCredential()
    {
        // بررسی لاگین بودن کاربر
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'You must be logged in'], 401);
            return;
        }

        // بررسی nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_webauthn')) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
            return;
        }

        $id = intval($_POST['id'] ?? 0);
        $userId = get_current_user_id();

        if (!$id) {
            wp_send_json_error(['message' => 'Invalid credential ID']);
            return;
        }

        $result = $this->service->deleteCredential($id, $userId);

        if (!$result['success']) {
            wp_send_json_error(['message' => $result['message']]);
            return;
        }

        wp_send_json_success($result);
    }

    /**
     * دریافت لیست کلیدها
     */
    public function getCredentials()
    {
        // بررسی لاگین بودن کاربر
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'You must be logged in'], 401);
            return;
        }

        // بررسی nonce
        if (!isset($_POST['_nonce']) || !wp_verify_nonce($_POST['_nonce'], 'loginpro_webauthn')) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
            return;
        }

        $userId = get_current_user_id();
        $credentials = $this->service->getCredentials($userId);

        wp_send_json_success([
            'credentials' => $credentials,
            'count' => count($credentials)
        ]);
    }
}

// ==================================================
// ثبت AJAX actions
// ==================================================
add_action('wp_ajax_loginpro_webauthn_register', function() {
    $controller = new WebAuthnController();
    $controller->registerOptions();
});

add_action('wp_ajax_loginpro_webauthn_verify_register', function() {
    $controller = new WebAuthnController();
    $controller->verifyRegistration();
});

add_action('wp_ajax_nopriv_loginpro_webauthn_login_options', function() {
    $controller = new WebAuthnController();
    $controller->loginOptions();
});

add_action('wp_ajax_nopriv_loginpro_webauthn_verify_login', function() {
    $controller = new WebAuthnController();
    $controller->verifyLogin();
});

add_action('wp_ajax_loginpro_webauthn_delete', function() {
    $controller = new WebAuthnController();
    $controller->deleteCredential();
});

add_action('wp_ajax_loginpro_webauthn_list', function() {
    $controller = new WebAuthnController();
    $controller->getCredentials();
});