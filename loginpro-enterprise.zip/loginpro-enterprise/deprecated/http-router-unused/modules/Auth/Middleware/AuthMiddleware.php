<?php
namespace LoginPro\Modules\Auth\Middleware;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;

class AuthMiddleware {
    
    public function handle(Request $request, $next) {
        if (!is_user_logged_in()) {
            if ($request->expectsJson()) {
                return Response::json(['error' => 'Unauthenticated'], 401);
            }
            
            $loginUrl = add_query_arg('redirect_to', urlencode($request->getUri()), wp_login_url());
            return Response::redirect($loginUrl);
        }
        
        return $next($request);
    }
}
