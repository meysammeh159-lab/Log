<?php
namespace LoginPro\Modules\Auth\Middleware;

use LoginPro\Core\Http\Request;
use LoginPro\Core\Http\Response;

class GuestMiddleware {
    
    public function handle(Request $request, $next) {
        if (is_user_logged_in()) {
            if ($request->expectsJson()) {
                return Response::json(['error' => 'Already authenticated'], 403);
            }
            return Response::redirect(home_url('/dashboard'));
        }
        
        return $next($request);
    }
}
