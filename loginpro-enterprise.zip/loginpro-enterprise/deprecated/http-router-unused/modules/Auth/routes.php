<?php
use LoginPro\Core\Http\Router;

Router::get('login', [\LoginPro\Modules\Auth\Controllers\LoginController::class, 'showForm']);
Router::post('login', [\LoginPro\Modules\Auth\Controllers\LoginController::class, 'login']);
Router::get('logout', [\LoginPro\Modules\Auth\Controllers\LoginController::class, 'logout']);
Router::get('register', [\LoginPro\Modules\Auth\Controllers\RegisterController::class, 'showForm']);
Router::post('register', [\LoginPro\Modules\Auth\Controllers\RegisterController::class, 'register']);
Router::get('forgot-password', [\LoginPro\Modules\Auth\Controllers\ResetPasswordController::class, 'showForm']);
Router::post('forgot-password', [\LoginPro\Modules\Auth\Controllers\ResetPasswordController::class, 'sendOtp']);
Router::post('reset-password', [\LoginPro\Modules\Auth\Controllers\ResetPasswordController::class, 'reset']);
Router::get('2fa', [\LoginPro\Modules\Auth\Controllers\TwoFactorController::class, 'showForm']);
Router::post('2fa/verify', [\LoginPro\Modules\Auth\Controllers\TwoFactorController::class, 'verify']);
Router::post('2fa/resend', [\LoginPro\Modules\Auth\Controllers\TwoFactorController::class, 'resend']);
