# این پوشه: کد مرده / بایگانی‌شده

فایل‌های این پوشه بخشی از یک لایه‌ی معماری MVC (Router + Middleware + CSRF) بودند که در کد اصلی
پلاگین ساخته شده بودند اما **هرگز به چرخه‌ی واقعی درخواست وردپرس متصل نشدند**.

## چرا اینجا هستند؟

با بررسی کامل کدبیس تأیید شد که:
- `LoginPro\Core\Http\Router::dispatch()` در هیچ‌کجای پروژه فراخوانی نمی‌شود.
- کنترلرهای زیر فقط در فایل‌های `routes.php` (که خودشان هم اجرا نمی‌شوند) ارجاع داده شده‌اند و
  در هیچ `add_action('wp_ajax_...')` یا مکانیزم دیگری زنده نیستند:
  - `TwoFactorController` (شامل یک باگ بحرانی: گرفتن `user_id` مستقیم از ورودی کاربر بدون
    CSRF و بدون گره‌خوردن به session لاگین واقعی — اگر این فایل روزی فعال شود باید این باگ
    قبل از هر چیز رفع شود)
  - `WebAuthnController` و `WebAuthnService`
  - `RegisterController` و `ResetPasswordController` (نسخه‌ی Router-based — نسخه‌ی زنده و امن
    این قابلیت‌ها در `modules/Auth/Controllers/LoginController.php` با متدهای
    `handleRegister`/`handleResetPassword` پیاده‌سازی شده و دست‌نخورده باقی مانده)
  - `AuthMiddleware`, `GuestMiddleware`, `CsrfMiddleware` (این‌ها حتی اگر Router فعال می‌شد،
    باز هم اجرا نمی‌شدند چون `Router::dispatch()` پارامتر middleware هر route را نادیده می‌گیرد)
  - `OtpController` (نسخه‌ی Router-based)
  - `modules/Auth/routes.php`, `modules/OTP/routes.php`, `routes/web.php`

## چرا حذف نشدند؟

طبق دستورالعمل «هیچ Feature حذف نشود»، این فایل‌ها به‌جای حذف، فقط **جابه‌جا و مستندسازی** شدند.
اگر تصمیم دارید این معماری Router را کامل کنید، این فایل‌ها نقطه‌ی شروع خوبی هستند — اما قبل از
فعال‌سازی حتماً باید:
1. `Router::dispatch()` را واقعاً به یک middleware pipeline متصل کنید (الان کاملاً نادیده گرفته می‌شود).
2. باگ `user_id` در `TwoFactorController::verify()` را با گره‌زدن به یک session/token لاگین واقعی رفع کنید.
3. متدهای گمشده (`login`, `logout`) را به `LoginController` اضافه کنید یا routes را به متدهای
   موجود (`handleLogin` و ...) اصلاح کنید.

## چه چیزی دست‌نخورده باقی ماند؟

`core/Http/Router.php` و `core/Http/Kernel.php` **در جای اصلی خود باقی ماندند** چون
`modules/Security/routes.php` و `modules/User/routes.php` هنوز در زمان اجرا (`Module::init()`)
این کلاس‌ها را `use` و فراخوانی می‌کنند (فقط برای «ثبت» route، نه dispatch). حذف یا جابه‌جایی
`Router.php` باعث Fatal Error در هر بارگذاری صفحه می‌شد. این دو فایل route (`Security/routes.php`
و `User/routes.php`) هم مرده هستند (چون dispatch نمی‌شوند) اما بی‌خطرند و دست‌نخورده باقی ماندند.
