<?php
namespace LoginPro\Core\Http\Middleware;

use LoginPro\Core\Http\Request;

class CsrfMiddleware {
    public function handle(Request $request, $next) {
        if ($request->method() === 'POST') {
            $token = $request->post('csrf_token');
            if (!$token || !wp_verify_nonce($token, 'loginpro_csrf')) {
                wp_die('CSRF token validation failed', 'Security Error', ['response' => 403]);
            }
        }
        return $next($request);
    }
}
