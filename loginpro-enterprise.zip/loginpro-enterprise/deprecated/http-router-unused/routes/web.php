<?php
use LoginPro\Core\Http\Router;

Router::get('/', function() {
    echo 'LoginPro is active!';
});

Router::get('login', [\LoginPro\Modules\Auth\Controllers\LoginController::class, 'showForm']);
Router::post('login', [\LoginPro\Modules\Auth\Controllers\LoginController::class, 'login']);
Router::get('logout', [\LoginPro\Modules\Auth\Controllers\LoginController::class, 'logout']);
Router::get('register', [\LoginPro\Modules\Auth\Controllers\RegisterController::class, 'showForm']);
Router::post('register', [\LoginPro\Modules\Auth\Controllers\RegisterController::class, 'register']);
Router::get('forgot-password', [\LoginPro\Modules\Auth\Controllers\ResetPasswordController::class, 'showForm']);
Router::get('dashboard', [\LoginPro\Modules\User\Controllers\DashboardController::class, 'index']);
Router::get('profile', [\LoginPro\Modules\User\Controllers\ProfileController::class, 'show']);
Router::post('profile', [\LoginPro\Modules\User\Controllers\ProfileController::class, 'update']);
Router::get('security', [\LoginPro\Modules\User\Controllers\SecurityController::class, 'devices']);
