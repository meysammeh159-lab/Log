<?php
/**
 * Create Provider Logs Table
 * ایجاد جدول لاگ‌های ارائه‌دهندگان
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

class CreateProviderLogsTable extends Migration {
    
    private $table = 'loginpro_provider_logs';
    
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            provider_type varchar(50) NOT NULL,
            provider_name varchar(100) NOT NULL,
            action varchar(50) NOT NULL,
            identifier varchar(255) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'success',
            request_data longtext DEFAULT NULL,
            response_data longtext DEFAULT NULL,
            error_message text DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY provider_type (provider_type),
            KEY provider_name (provider_name),
            KEY action (action),
            KEY status (status),
            KEY created_at (created_at)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    public function down() {
        return $this->drop_table($this->table);
    }
}