<?php
/**
 * Create Failed Login Attempts Table
 * ایجاد جدول تلاش‌های ناموفق ورود
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

class CreateFailedLoginAttemptsTable extends Migration {
    
    private $table = 'loginpro_failed_login_attempts';
    
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT NULL,
            username varchar(255) NOT NULL,
            password_hash varchar(255) DEFAULT NULL,
            ip_address varchar(45) NOT NULL,
            user_agent text DEFAULT NULL,
            attempt_count int(11) NOT NULL DEFAULT 1,
            first_attempt datetime DEFAULT CURRENT_TIMESTAMP,
            last_attempt datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY username (username),
            KEY ip_address (ip_address),
            KEY user_id (user_id),
            KEY last_attempt (last_attempt),
            INDEX idx_ip_username (ip_address, username)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    public function down() {
        return $this->drop_table($this->table);
    }
}