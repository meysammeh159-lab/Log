<?php
/**
 * Create OTPs Table
 * ایجاد جدول کدهای یکبارمصرف
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

class CreateOtpsTable extends Migration {
    
    private $table = 'loginpro_otps';
    
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT NULL,
            identifier varchar(255) NOT NULL,
            code varchar(10) NOT NULL,
            type varchar(50) NOT NULL DEFAULT 'login',
            channel varchar(50) NOT NULL DEFAULT 'sms',
            attempts int(11) NOT NULL DEFAULT 0,
            max_attempts int(11) NOT NULL DEFAULT 3,
            expires_at datetime NOT NULL,
            is_used tinyint(1) NOT NULL DEFAULT 0,
            used_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY identifier (identifier),
            KEY code (code),
            KEY type (type),
            KEY channel (channel),
            KEY expires_at (expires_at),
            KEY is_used (is_used)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    public function down() {
        return $this->drop_table($this->table);
    }
}