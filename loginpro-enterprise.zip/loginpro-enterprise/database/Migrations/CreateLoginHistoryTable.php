<?php
/**
 * Create Login History Table
 * ایجاد جدول تاریخچه ورود
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

class CreateLoginHistoryTable extends Migration {
    
    private $table = 'loginpro_login_history';
    
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            login_type varchar(50) NOT NULL DEFAULT 'password',
            ip_address varchar(45) NOT NULL,
            user_agent text DEFAULT NULL,
            location varchar(255) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'success',
            error_message text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY login_type (login_type),
            KEY ip_address (ip_address),
            KEY status (status),
            KEY created_at (created_at),
            INDEX idx_user_date (user_id, created_at)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    public function down() {
        return $this->drop_table($this->table);
    }
}