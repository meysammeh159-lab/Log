<?php
/**
 * Create Queue Jobs Table
 * ایجاد جدول کارهای صف
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

class CreateQueueJobsTable extends Migration {
    
    private $table = 'loginpro_queue_jobs';
    
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            queue varchar(50) NOT NULL DEFAULT 'default',
            job_class varchar(255) NOT NULL,
            payload longtext NOT NULL,
            attempts int(11) NOT NULL DEFAULT 0,
            max_attempts int(11) NOT NULL DEFAULT 3,
            priority int(11) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            error text DEFAULT NULL,
            scheduled_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            started_at datetime DEFAULT NULL,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY queue (queue),
            KEY status (status),
            KEY priority (priority),
            KEY scheduled_at (scheduled_at),
            INDEX idx_queue_status (queue, status)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    public function down() {
        return $this->drop_table($this->table);
    }
}