<?php
/**
 * Create WebAuthn Credentials Table
 * ایجاد جدول اعتبارنامه‌های WebAuthn
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

/**
 * کلاس Migration برای ایجاد جدول WebAuthn Credentials
 */
class CreateWebAuthnCredentialsTable extends Migration {
    
    /**
     * نام جدول
     */
    private $table = 'loginpro_webauthn_credentials';
    
    /**
     * اجرای Migration
     * 
     * @return bool
     */
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            credential_id text NOT NULL,
            public_key text NOT NULL,
            sign_count int(11) NOT NULL DEFAULT 0,
            device_name varchar(255) DEFAULT NULL,
            device_type varchar(50) DEFAULT NULL,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY credential_id (credential_id(191)),
            KEY is_active (is_active)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    /**
     * بازگشت Migration
     * 
     * @return bool
     */
    public function down() {
        return $this->drop_table($this->table);
    }
}