<?php
/**
 * Create Devices Table
 * ایجاد جدول دستگاه‌ها
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

class CreateDevicesTable extends Migration {
    
    private $table = 'loginpro_devices';
    
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            device_token varchar(255) NOT NULL,
            device_name varchar(255) NOT NULL,
            device_type varchar(50) NOT NULL,
            ip_address varchar(45) DEFAULT NULL,
            user_agent text DEFAULT NULL,
            last_activity datetime DEFAULT CURRENT_TIMESTAMP,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY device_token (device_token),
            KEY user_id (user_id),
            KEY device_type (device_type),
            KEY last_activity (last_activity)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    public function down() {
        return $this->drop_table($this->table);
    }
}