<?php
/**
 * Create Security Events Table
 * ایجاد جدول رویدادهای امنیتی
 * 
 * @package LoginPro
 * @version 3.0.15
 * @since 3.0.0
 */

namespace LoginPro\Database\Migrations;

defined('ABSPATH') || exit;

use LoginPro\Core\Database\Migration;

class CreateSecurityEventsTable extends Migration {
    
    private $table = 'loginpro_security_events';
    
    public function up() {
        $sql = "
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT NULL,
            event_type varchar(50) NOT NULL,
            severity varchar(20) NOT NULL DEFAULT 'info',
            ip_address varchar(45) DEFAULT NULL,
            user_agent text DEFAULT NULL,
            details longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY event_type (event_type),
            KEY severity (severity),
            KEY ip_address (ip_address),
            KEY created_at (created_at),
            INDEX idx_type_severity (event_type, severity)
        ";
        
        return $this->create_table($this->table, $sql);
    }
    
    public function down() {
        return $this->drop_table($this->table);
    }
}