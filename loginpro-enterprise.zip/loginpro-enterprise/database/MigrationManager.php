<?php
namespace LoginPro\Database;

defined('ABSPATH') || exit;

class MigrationManager {
    
    private array $migrations = [];
    private string $version_option = 'loginpro_db_version';
    private string $current_version;
    private bool $has_error = false;
    
    public function __construct() {
        $this->current_version = get_option($this->version_option, '0.0.0');
        $this->registerMigrations();
    }
    
    /**
     * ثبت تمام migration‌ها با نسخه‌بندی صحیح
     */
    private function registerMigrations(): void {
        $this->migrations = [
            '1.0.0' => [
                'CreateOtpsTable',
                'CreateLoginHistoryTable',
                'CreateSecurityEventsTable',
                'CreateProviderLogsTable',
                'CreateSessionsTable'
            ],
            '1.1.0' => [
                'CreateQueueJobsTable'
            ]
        ];
    }
    
    /**
     * اجرای تمام migration‌های جدید
     */
    public function run(): bool {
        $latest_version = $this->getLatestVersion();
        
        if (version_compare($this->current_version, $latest_version, '>=')) {
            $this->log("Database is up to date (version: {$this->current_version})");
            return true;
        }
        
        $this->log("Starting migration from {$this->current_version} to {$latest_version}");
        
        foreach ($this->migrations as $version => $migration_classes) {
            if (version_compare($this->current_version, $version, '<')) {
                $this->log("Running migrations for version {$version}");
                
                if (!$this->runMigrations($migration_classes, $version)) {
                    $this->logError("Migration failed for version {$version}");
                    return false;
                }
            }
        }
        
        update_option($this->version_option, $latest_version);
        $this->log("Migration completed successfully. Current version: {$latest_version}");
        
        return true;
    }
    
    /**
     * اجرای یک آرایه از migration‌ها
     */
    private function runMigrations(array $migration_classes, string $version): bool {
        global $wpdb;
        
        // شروع تراکنش برای اطمینان از اجرای کامل
        $wpdb->query('START TRANSACTION');
        
        try {
            foreach ($migration_classes as $class_name) {
                $full_class = "\\LoginPro\\Database\\Migrations\\{$class_name}";
                
                if (!class_exists($full_class)) {
                    throw new \Exception("Migration class not found: {$full_class}");
                }
                
                $migration = new $full_class();
                
                if (!method_exists($migration, 'up')) {
                    throw new \Exception("Migration {$full_class} has no up() method");
                }
                
                $this->log("Running migration: {$class_name}");
                $result = $migration->up();
                
                if ($result === false) {
                    throw new \Exception("Migration {$class_name} returned false");
                }
            }
            
            $wpdb->query('COMMIT');
            return true;
            
        } catch (\Exception $e) {
            $wpdb->query('ROLLBACK');
            $this->logError("Migration error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * برگرداندن آخرین نسخه (rollback) - برای مواقع خطا
     */
    public function rollback(string $target_version = ''): bool {
        global $wpdb;
        
        $versions = array_keys($this->migrations);
        usort($versions, 'version_compare');
        
        if (empty($target_version)) {
            // برگرداندن یک نسخه به عقب
            $current_index = array_search($this->current_version, $versions);
            if ($current_index === false || $current_index === 0) {
                $this->logError("Cannot rollback further");
                return false;
            }
            $target_version = $versions[$current_index - 1];
        }
        
        $this->log("Rolling back from {$this->current_version} to {$target_version}");
        
        $wpdb->query('START TRANSACTION');
        
        try {
            foreach (array_reverse($this->migrations, true) as $version => $migration_classes) {
                if (version_compare($version, $target_version, '>') && 
                    version_compare($version, $this->current_version, '<=')) {
                    
                    $this->log("Rolling back version {$version}");
                    
                    foreach (array_reverse($migration_classes) as $class_name) {
                        $full_class = "\\LoginPro\\Database\\Migrations\\{$class_name}";
                        
                        if (class_exists($full_class)) {
                            $migration = new $full_class();
                            if (method_exists($migration, 'down')) {
                                $migration->down();
                                $this->log("Rolled back: {$class_name}");
                            }
                        }
                    }
                }
            }
            
            update_option($this->version_option, $target_version);
            $wpdb->query('COMMIT');
            
            $this->log("Rollback completed. Current version: {$target_version}");
            return true;
            
        } catch (\Exception $e) {
            $wpdb->query('ROLLBACK');
            $this->logError("Rollback error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * بررسی وضعیت migration‌ها
     */
    public function getStatus(): array {
        $status = [
            'current_version' => $this->current_version,
            'latest_version' => $this->getLatestVersion(),
            'is_up_to_date' => $this->isUpToDate(),
            'migrations' => []
        ];
        
        foreach ($this->migrations as $version => $classes) {
            $is_migrated = version_compare($this->current_version, $version, '>=');
            $status['migrations'][$version] = [
                'status' => $is_migrated ? 'migrated' : 'pending',
                'classes' => $classes
            ];
        }
        
        return $status;
    }
    
    /**
     * حذف تمام جداول افزونه (uninstall)
     */
    public function uninstall(): bool {
        global $wpdb;
        
        $this->log("Uninstalling all database tables");
        
        $tables = [
            'loginpro_otps',
            'loginpro_login_history',
            'loginpro_security_events',
            'loginpro_provider_logs',
            'loginpro_sessions',
            'loginpro_queue_jobs'
        ];
        
        foreach ($tables as $table) {
            $full_table = $wpdb->prefix . $table;
            $wpdb->query("DROP TABLE IF EXISTS {$full_table}");
            $this->log("Dropped table: {$full_table}");
        }
        
        delete_option($this->version_option);
        delete_option('loginpro_installed');
        
        $this->log("Uninstall completed");
        
        return true;
    }
    
    /**
     * دریافت آخرین نسخه موجود
     */
    private function getLatestVersion(): string {
        $versions = array_keys($this->migrations);
        usort($versions, 'version_compare');
        $latest = end($versions);
        return $latest ?: '0.0.0';
    }
    
    /**
     * بررسی به‌روز بودن دیتابیس
     */
    public function isUpToDate(): bool {
        return version_compare($this->current_version, $this->getLatestVersion(), '>=');
    }
    
    /**
     * دریافت نسخه فعلی
     */
    public function getCurrentVersion(): string {
        return $this->current_version;
    }
    
    /**
     * ثبت لاگ معمولی
     */
    private function log(string $message): void {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[LoginPro Migration] {$message}");
        }
    }
    
    /**
     * ثبت خطا
     */
    private function logError(string $message): void {
        $this->has_error = true;
        error_log("[LoginPro Migration ERROR] {$message}");
    }
    
    /**
     * بررسی وجود خطا
     */
    public function hasError(): bool {
        return $this->has_error;
    }
}

/**
 * تابع کمکی برای اجرای migration از بیرون کلاس
 */
function run_loginpro_migrations() {
    $migration_manager = new MigrationManager();
    return $migration_manager->run();
}