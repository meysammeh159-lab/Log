<?php
/**
 * ایجاد صفحه لاگین جدید
 * مسیر: wp-content/plugins/loginpro-enterprise/create-login-page.php
 */

define('WP_USE_THEMES', false);
require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';

echo '<pre>';
echo "=== ایجاد صفحه لاگین جدید ===\n\n";

// 1. حذف شناسه قدیمی
$old_page_id = get_option('loginpro_login_page_id', 0);
if ($old_page_id) {
    delete_option('loginpro_login_page_id');
    echo "✅ شناسه قدیمی صفحه لاگین حذف شد: " . $old_page_id . "\n";
}

// 2. ایجاد صفحه جدید با شورت‌کد صحیح
$page_data = [
    'post_title'   => 'ورود',
    'post_content' => '[loginpro_login]',
    'post_status'  => 'publish',
    'post_type'    => 'page',
    'post_name'    => 'login',
    'comment_status' => 'closed',
    'ping_status'   => 'closed',
];

$new_page_id = wp_insert_post($page_data);

if ($new_page_id && !is_wp_error($new_page_id)) {
    echo "✅ صفحه لاگین با شناسه " . $new_page_id . " ایجاد شد.\n";
    update_option('loginpro_login_page_id', $new_page_id);
    echo "✅ شناسه صفحه در تنظیمات ذخیره شد.\n";
    
    // 3. نمایش اطلاعات صفحه
    $page = get_post($new_page_id);
    echo "\n--- اطلاعات صفحه ---\n";
    echo "عنوان: " . $page->post_title . "\n";
    echo "شناسه: " . $page->ID . "\n";
    echo "لینک: " . get_permalink($page->ID) . "\n";
    echo "محتوای صفحه:\n" . $page->post_content . "\n";
} else {
    echo "❌ خطا در ایجاد صفحه.\n";
    if (is_wp_error($new_page_id)) {
        echo "خطا: " . $new_page_id->get_error_message() . "\n";
    }
}

echo "\n=== پایان ===\n";
echo '</pre>';