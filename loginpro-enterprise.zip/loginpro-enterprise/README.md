# LoginPro Enterprise v3.0

Enterprise-grade authentication system for WordPress.

## Features

- Multi-factor Authentication (OTP via SMS/Email/WhatsApp)
- Advanced Security (Brute Force Protection, Rate Limiting, CSRF)
- User Management System
- Support Ticket System
- Admin Dashboard
- REST API
- Queue System
- Comprehensive Logging
- Multi-drive Cache System

## Requirements

- WordPress 6.6+
- PHP 7.4+
- MySQL 5.7+ / MariaDB 10.2+

## Installation

1. Upload `loginpro-enterprise` to `/wp-content/plugins/`
2. Activate the plugin
3. Configure settings from WordPress Admin > LoginPro

## Shortcodes

- `[loginpro_login]` - Display login form
- `[loginpro_register]` - Display registration form
- `[loginpro_dashboard]` - Display user dashboard

## Documentation

Visit https://docs.loginpro.io for full documentation.

## Changelog

### 3.0.0
- Complete rewrite with modular architecture
- Added OTP via WhatsApp
- Enhanced security features
- Improved performance
